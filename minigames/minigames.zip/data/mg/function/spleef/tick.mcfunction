execute if score #spleef_cd mg matches 1.. run scoreboard players remove #spleef_cd mg 1
execute if score #spleef_cd mg matches 1.. run return 0
execute if score #spleef mg matches 1 run title @a[tag=mg_duel_spleef] actionbar {"text": "LOS!", "color": "aqua", "bold": true}
scoreboard players set #spleef mg 2
execute store result score #n mg if entity @a[tag=mg_duel_spleef]
execute if score #n mg matches ..1 run return run function mg:spleef/forfeit
execute as @a[tag=mg_duel_spleef,scores={mg_deaths=1..}] run function mg:spleef/lose
execute as @a[tag=mg_duel_spleef] at @s if entity @s[y=-64,dy=160] run function mg:spleef/lose
