execute if score #spleef_cd mg matches 1.. run scoreboard players remove #spleef_cd mg 1
execute if score #spleef mg matches 1 if score #spleef_cd mg matches 0 run function mg:spleef/go
execute if score #spleef mg matches 1 if score #spleef_cd mg matches 0 run scoreboard players set #spleef mg 2
execute if score #spleef mg matches 1 run execute in minecraft:overworld run kill @e[type=#mg:projectiles,x=3955,dx=90,y=70,dy=80,z=-45,dz=90]
execute unless score #spleef mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_spleef]
execute if score #n mg matches ..1 run return run function mg:spleef/forfeit
execute as @a[tag=mg_duel_spleef] at @s if entity @s[y=-64,dy=160] run function mg:spleef/lose
execute as @e[type=minecraft:player,tag=mg_duel_spleef,scores={mg_deaths=1..}] run function mg:spleef/lose
