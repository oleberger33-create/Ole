execute in minecraft:overworld run fill 3990 100 -10 4010 100 10 minecraft:snow_block
