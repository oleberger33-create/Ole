function mg:spleef/reset_floor
title @a[tag=mg_duel_spleef] actionbar {"text": "LOS!", "color": "aqua", "bold": true}
execute as @a[tag=mg_duel_spleef] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
