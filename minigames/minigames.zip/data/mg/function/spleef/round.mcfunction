function mg:spleef/reset_floor
execute in minecraft:overworld run kill @e[type=minecraft:item,x=3955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=3955,dx=90,y=70,dy=80,z=-45,dz=90]
execute as @a[tag=mg_duel_spleef] run function mg:spleef/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_spleef,tag=mg_p1,limit=1] 3994 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_spleef,tag=mg_p2,limit=1] 4006 101 0 90 0
execute as @a[tag=mg_duel_spleef] run execute in minecraft:overworld run spawnpoint @s 0 101 17
kill @e[type=minecraft:horse,tag=mg_horse_spleef]
scoreboard players set #spleef_cd mg 60
scoreboard players set #spleef mg 1
title @a[tag=mg_duel_spleef] times 0 30 10
title @a[tag=mg_duel_spleef] title {"text": "Spleef", "color": "aqua", "bold": true}
title @a[tag=mg_duel_spleef] subtitle [{"score":{"name":"@a[tag=mg_duel_spleef,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_spleef,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
scoreboard players add #spleef_r mg 1
