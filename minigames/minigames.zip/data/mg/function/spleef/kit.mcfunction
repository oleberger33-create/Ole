clear @s
effect clear @s
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
scoreboard players set @s mg_deaths 0
execute in minecraft:overworld run spawnpoint @s 0 101 0
effect give @s minecraft:slowness 3 255 true
effect give @s minecraft:resistance 3 4 true
give @s minecraft:diamond_shovel[minecraft:can_break={blocks:"minecraft:snow_block"},minecraft:enchantments={"minecraft:efficiency":5},minecraft:unbreakable={}]
