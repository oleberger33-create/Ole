execute if score #spleef mg matches ..1 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_spleef] remove mg_rw
tag @a[tag=mg_duel_spleef] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_spleef] mg_round 1
tellraw @a[tag=mg_duel_spleef] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_spleef]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "aqua"}]
execute as @a[tag=mg_duel_spleef] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_spleef,scores={mg_round=2..}] run return run function mg:spleef/win
scoreboard players set #spleef mg 1
function mg:spleef/round
