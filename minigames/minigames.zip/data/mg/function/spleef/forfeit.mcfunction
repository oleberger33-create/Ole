execute as @a[tag=mg_duel_spleef] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Spleef – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_spleef] mg_wins 1
function mg:spleef/stop
