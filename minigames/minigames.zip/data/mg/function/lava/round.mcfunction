execute as @a[tag=mg_duel_lava] run function mg:lava/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_lava,tag=mg_p1,limit=1] 10995 101 -5 -45 0
execute in minecraft:overworld run tp @a[tag=mg_duel_lava,tag=mg_p2,limit=1] 11005 101 5 135 0
execute as @a[tag=mg_duel_lava] run execute in minecraft:overworld run spawnpoint @s 0 101 0
kill @e[type=minecraft:horse,tag=mg_horse_lava]
scoreboard players set #lava_cd mg 60
scoreboard players set #lava mg 1
title @a[tag=mg_duel_lava] times 0 30 10
title @a[tag=mg_duel_lava] title {"text": "Steigende Lava", "color": "red", "bold": true}
title @a[tag=mg_duel_lava] subtitle [{"score":{"name":"@a[tag=mg_duel_lava,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_lava,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
