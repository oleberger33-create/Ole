execute in minecraft:overworld run fill 10994 101 -6 11006 139 6 minecraft:air
scoreboard players set #lava_lvl mg 0
scoreboard players set #lava_t mg -160
title @a[tag=mg_duel_lava] actionbar {"text": "Bau dich hoch – in 12 Sekunden steigt die Lava!", "color": "gold"}
execute in minecraft:overworld run kill @e[type=minecraft:item,x=10955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=10955,dx=90,y=70,dy=80,z=-45,dz=90]
title @a[tag=mg_duel_lava] actionbar {"text": "LOS!", "color": "red", "bold": true}
execute as @a[tag=mg_duel_lava] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
