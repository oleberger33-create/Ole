scoreboard players set #lava_lvl mg 0
scoreboard players set #lava_t mg -160
title @a[tag=mg_duel_lava] actionbar {"text": "Bau dich hoch – in 12 Sekunden steigt die Lava!", "color": "gold"}
title @a[tag=mg_duel_lava] actionbar {"text": "LOS!", "color": "red", "bold": true}
execute as @a[tag=mg_duel_lava] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
