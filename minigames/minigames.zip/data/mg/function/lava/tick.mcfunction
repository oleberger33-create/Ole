execute if score #lava_cd mg matches 1.. run scoreboard players remove #lava_cd mg 1
execute if score #lava mg matches 1 if score #lava_cd mg matches 0 run function mg:lava/go
execute if score #lava mg matches 1 if score #lava_cd mg matches 0 run scoreboard players set #lava mg 2
execute if score #lava mg matches 1 run execute in minecraft:overworld run kill @e[type=#mg:projectiles,x=10955,dx=90,y=70,dy=80,z=-45,dz=90]
execute unless score #lava mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_lava]
execute if score #n mg matches ..1 run return run function mg:lava/forfeit
execute as @e[type=minecraft:player,tag=mg_duel_lava,scores={mg_deaths=1..}] run function mg:lava/lose
execute as @a[tag=mg_duel_lava] at @s if entity @s[y=-64,dy=154] run function mg:lava/lose
scoreboard players add #lava_t mg 1
execute if score #lava_t mg matches 80.. if score #lava_lvl mg matches ..37 run function mg:lava/rise
