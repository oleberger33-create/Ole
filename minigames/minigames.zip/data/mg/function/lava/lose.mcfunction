execute unless score #lava mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_lava] remove mg_rw
tag @a[tag=mg_duel_lava] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_lava] mg_round 1
tellraw @a[tag=mg_duel_lava] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_lava]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "red"}]
execute as @a[tag=mg_duel_lava] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_lava,scores={mg_round=2..}] run return run function mg:lava/win
scoreboard players set #lava mg 1
function mg:lava/round
