scoreboard players set #lava mg 0
kill @e[type=minecraft:horse,tag=mg_horse_lava]
execute as @a[tag=mg_duel_lava] run function mg:hub/enter
tag @a remove mg_duel_lava
tag @a[tag=mg_hub] remove mg_rw
execute in minecraft:overworld run kill @e[type=minecraft:item,x=10955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=10955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run fill 10994 101 -6 11006 139 6 minecraft:air
