$execute in minecraft:overworld positioned 11000 100 0 run fill ~-6 ~$(y) ~-6 ~6 ~$(y) ~6 minecraft:lava replace minecraft:air
