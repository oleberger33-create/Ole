scoreboard players set #lava_t mg 0
scoreboard players add #lava_lvl mg 1
execute store result storage mg:tmp l.y int 1 run scoreboard players get #lava_lvl mg
function mg:lava/fill with storage mg:tmp l
title @a[tag=mg_duel_lava] actionbar {"text": "Die Lava steigt!", "color": "red", "bold": true}
