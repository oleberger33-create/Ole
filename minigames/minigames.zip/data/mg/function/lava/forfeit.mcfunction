execute as @a[tag=mg_duel_lava] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Steigende Lava – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_lava] mg_wins 1
function mg:lava/stop
