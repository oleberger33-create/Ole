execute if score #lava_r mg matches 2.. as @a[tag=mg_duel_lava] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Steigende Lava – Gegner ist weg.", "color": "white"}]
execute if score #lava_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_lava] mg_wins 1
execute if score #lava_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_lava] mg_coins 5
execute if score #lava_r mg matches ..1 run tellraw @a[tag=mg_duel_lava] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dein Gegner ist weg, bevor eine Runde fertig war – keine Wertung.", "color": "gray"}]
function mg:lava/stop
