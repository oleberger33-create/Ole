scoreboard players add @a[tag=mg_rw,tag=mg_duel_lava] mg_wins 1
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_lava]", "color": "gold", "bold": true}, {"text": " gewinnt Steigende Lava!", "color": "white"}]
title @a[tag=mg_duel_lava] times 10 50 15
title @a[tag=mg_duel_lava,tag=mg_rw] title {"text": "SIEG!", "color": "gold", "bold": true}
title @a[tag=mg_duel_lava,tag=!mg_rw] title {"text": "Verloren", "color": "red", "bold": true}
execute as @a[tag=mg_rw] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"star",colors:[I;16766720],has_twinkle:true}]}}}}
function mg:lava/stop
