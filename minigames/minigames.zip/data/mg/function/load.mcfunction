execute in minecraft:overworld run forceload remove all
execute in minecraft:overworld run forceload add -56 -56 56 56
execute in minecraft:overworld run forceload remove 984 -96 1176 96
execute in minecraft:overworld run forceload add 1968 -32 2032 32
execute in minecraft:overworld run forceload add 2976 -24 3024 24
execute in minecraft:overworld run forceload add 3976 -24 4024 24
execute in minecraft:overworld run forceload add 4976 -24 5024 24
scoreboard objectives add mg dummy
scoreboard objectives add mg_click minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add mg_deaths deathCount
scoreboard objectives add mg_leave minecraft.custom:minecraft.leave_game
scoreboard objectives add mg_cp dummy
scoreboard objectives add mg_lane dummy
scoreboard objectives add mg_prog dummy {"text": "Fortschritt (Inseln /24)", "color": "green", "bold": true}
scoreboard objectives add mg_cx dummy
scoreboard objectives add mg_cy dummy
scoreboard objectives add mg_cz dummy
scoreboard objectives add mg_loot dummy
scoreboard objectives add mg_round dummy
scoreboard objectives add mg_aktion trigger
scoreboard objectives add mg_coins dummy {"text": "Münzen", "color": "yellow"}
scoreboard objectives add mg_trail dummy
scoreboard objectives add mg_hat dummy
scoreboard objectives add mg_wins dummy {"text": "Siege", "color": "gold"}
scoreboard objectives setdisplay list mg_wins
scoreboard objectives add mg_side dummy {"text": "MINIGAMES", "color": "gold", "bold": true}
scoreboard objectives modify mg_side numberformat blank
scoreboard objectives setdisplay sidebar mg_side
scoreboard players set #20 mg 20
scoreboard players set #1000 mg 1000
scoreboard players set #60 mg 60
scoreboard players set #6 mg 6
scoreboard players set #6 mg 6
execute unless score #rush mg matches 0.. run scoreboard players set #rush mg 0
execute unless score #sumo mg matches 0.. run scoreboard players set #sumo mg 0
execute unless score #spleef mg matches 0.. run scoreboard players set #spleef mg 0
execute unless score #duell mg matches 0.. run scoreboard players set #duell mg 0
gamerule pvp true
gamerule keep_inventory false
gamerule immediate_respawn true
gamerule spawn_monsters false
gamerule spawn_mobs false
gamerule advance_time false
gamerule advance_weather false
gamerule fall_damage true
gamerule show_death_messages false
gamerule respawn_radius 0
gamerule natural_health_regeneration true
time set 6000
weather clear
setworldspawn 0 101 17
difficulty normal
bossbar add mg:rush {"text": "Parkour-Rush"}
bossbar set mg:rush color green
function mg:hub/sidebar
execute if score #rush mg matches 2.. run scoreboard objectives setdisplay sidebar mg_prog
execute unless score #built mg matches 6 run schedule function mg:build/try 40t
execute if score #built mg matches 6 unless score #lanes mg matches 6 run schedule function mg:build/lane_resume 40t
scoreboard players set #2 mg 2
scoreboard players set #3 mg 3
scoreboard players set #4 mg 4
scoreboard players set #5 mg 5
scoreboard players set #100 mg 100
scoreboard objectives add mg_ctf_k playerKillCount
scoreboard objectives add mg_ctf_rs dummy
scoreboard objectives add mg_ctf_a dummy
scoreboard objectives add mg_ctf_cap dummy
bossbar add mg:ctf {"text": "Capture the Flag"}
bossbar set mg:ctf max 9600
bossbar set mg:ctf style notched_10
scoreboard players set #ctf_len mg 9600
execute unless entity @a[tag=mg_ctf] run bossbar set mg:ctf visible false
execute unless entity @a[tag=mg_ctf] run bossbar set mg:ctf players
team add mg_ctf_rot
team modify mg_ctf_rot color red
team modify mg_ctf_rot friendlyFire false
team modify mg_ctf_rot seeFriendlyInvisibles true
team modify mg_ctf_rot displayName {"text": "Team Rot", "color": "red", "italic": false}
team modify mg_ctf_rot prefix {"text": "[Rot] ", "color": "red"}
team add mg_ctf_blau
team modify mg_ctf_blau color blue
team modify mg_ctf_blau friendlyFire false
team modify mg_ctf_blau seeFriendlyInvisibles true
team modify mg_ctf_blau displayName {"text": "Team Blau", "color": "blue", "italic": false}
team modify mg_ctf_blau prefix {"text": "[Blau] ", "color": "blue"}
execute unless entity @a[tag=mg_ctf] run scoreboard players set #ctf mg 0
scoreboard objectives add mg_elytra_p dummy
scoreboard objectives add mg_elytra_g dummy
scoreboard objectives add mg_elytra_pl dummy
execute unless entity @a[tag=mg_elytra] run scoreboard players set #elytra mg 0
bossbar add mg:farben {"text": "Farbenparty"}
execute unless entity @a[tag=mg_farben] run bossbar set mg:farben visible false
execute unless entity @a[tag=mg_farben] run scoreboard players set #farben mg 0
scoreboard objectives add mg_kbffa_k dummy
scoreboard objectives add mg_kbffa_s dummy
scoreboard objectives add mg_kbffa_d dummy
scoreboard objectives add mg_kbffa_best dummy
scoreboard objectives add mg_kbffa_id dummy
scoreboard objectives add mg_kbffa_lh dummy
scoreboard objectives add mg_kbffa_lt dummy
scoreboard objectives add mg_kbffa_pc dummy
scoreboard objectives add mg_kbffa_ps dummy
scoreboard objectives add mg_kbffa_sp dummy
scoreboard objectives add mg_kbffa_pv dummy
scoreboard objectives add mg_kbffa_pad dummy
scoreboard objectives add mg_kbffa_col dummy
scoreboard objectives add mg_kbffa_n dummy
scoreboard objectives add mg_kbffa_hold dummy
scoreboard objectives add mg_kbffa_pid dummy
scoreboard objectives add mg_kbffa_lv dummy
scoreboard objectives add mg_kbffa_cn dummy
scoreboard objectives add mg_kbffa_dd minecraft.custom:minecraft.damage_dealt
scoreboard objectives add mg_kbffa_dt minecraft.custom:minecraft.damage_taken
scoreboard objectives add mg_kbffa_use minecraft.used:minecraft.carrot_on_a_stick
scoreboard players set #kbffa_45 mg 45
scoreboard players set #10 mg 10
execute unless score #kbffa mg matches 0.. run scoreboard players set #kbffa mg 0
execute unless score #kbffa_rec mg matches 0.. run scoreboard players set #kbffa_rec mg 0
execute unless entity @a[tag=mg_kbffa] run scoreboard players set #kbffa mg 0
execute if score #kbffa mg matches 1.. run execute in minecraft:overworld run forceload add 75960 -39 76039 39
scoreboard objectives add mg_murder_k playerKillCount
scoreboard objectives add mg_murder_g dummy
scoreboard objectives add mg_murder_cd dummy
team add mg_murder_t
team modify mg_murder_t nametagVisibility never
team modify mg_murder_t deathMessageVisibility never
team modify mg_murder_t friendlyFire true
team modify mg_murder_t seeFriendlyInvisibles false
bossbar add mg:murder {"text": "Murder Mystery"}
bossbar set mg:murder max 4800
bossbar set mg:murder style notched_10
scoreboard players set #murder_len mg 4800
scoreboard players set #murder_200 mg 200
execute unless entity @a[tag=mg_murder] run scoreboard players set #murder mg 0
execute unless entity @a[tag=mg_tntrun] run scoreboard players set #tntrun mg 0
scoreboard objectives add mg_bwt dummy
scoreboard objectives add mg_rt dummy
execute unless entity @a[tag=mg_sw] run scoreboard players set #sw mg 0
execute unless entity @a[tag=mg_bw] run scoreboard players set #bw mg 0
team add mg_bw1
team modify mg_bw1 color red
team modify mg_bw1 friendlyFire false
team modify mg_bw1 prefix {"text": "[Rot] ", "color": "red"}
team add mg_bw2
team modify mg_bw2 color blue
team modify mg_bw2 friendlyFire false
team modify mg_bw2 prefix {"text": "[Blau] ", "color": "blue"}
team add mg_bw3
team modify mg_bw3 color green
team modify mg_bw3 friendlyFire false
team modify mg_bw3 prefix {"text": "[Grün] ", "color": "green"}
team add mg_bw4
team modify mg_bw4 color yellow
team modify mg_bw4 friendlyFire false
team modify mg_bw4 prefix {"text": "[Gelb] ", "color": "yellow"}
execute unless score #big mg matches 6 run schedule function mg:build/big_try 60t
execute unless score #wind mg matches 0.. run scoreboard players set #wind mg 0
execute unless score #kb mg matches 0.. run scoreboard players set #kb mg 0
execute unless score #pfeil mg matches 0.. run scoreboard players set #pfeil mg 0
execute unless score #kolben mg matches 0.. run scoreboard players set #kolben mg 0
execute unless score #bruecke mg matches 0.. run scoreboard players set #bruecke mg 0
execute unless score #lava mg matches 0.. run scoreboard players set #lava mg 0
execute unless score #boden mg matches 0.. run scoreboard players set #boden mg 0
execute unless score #boxen mg matches 0.. run scoreboard players set #boxen mg 0
execute unless score #pferd mg matches 0.. run scoreboard players set #pferd mg 0
execute unless score #parkour mg matches 0.. run scoreboard players set #parkour mg 0
execute unless score #stickbett mg matches 0.. run scoreboard players set #stickbett mg 0
scoreboard objectives add mg_dmg minecraft.custom:minecraft.damage_dealt
scoreboard objectives add mg_hits dummy
scoreboard objectives add mg_lap dummy
scoreboard objectives add mg_gate dummy
scoreboard players set #10 mg 10
execute unless score #arenas mg matches 3 run scoreboard players set #aq mg 0
execute unless score #arenas mg matches 3 run schedule function mg:build/a_next 100t
scoreboard players set #zero mg 0
