execute in minecraft:overworld run forceload remove all
execute in minecraft:overworld run forceload add -32 -32 32 32
execute in minecraft:overworld run forceload remove 984 -96 1176 96
execute in minecraft:overworld run forceload add 1968 -32 2032 32
execute in minecraft:overworld run forceload add 2976 -24 3024 24
execute in minecraft:overworld run forceload add 3976 -24 4024 24
execute in minecraft:overworld run forceload add 4976 -24 5024 24
scoreboard objectives add mg dummy
scoreboard objectives add mg_click minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add mg_deaths deathCount
scoreboard objectives add mg_leave minecraft.custom:minecraft.leave_game
scoreboard objectives add mg_cp dummy
scoreboard objectives add mg_lane dummy
scoreboard objectives add mg_prog dummy {"text": "Fortschritt (Inseln /24)", "color": "green", "bold": true}
scoreboard objectives add mg_cx dummy
scoreboard objectives add mg_cy dummy
scoreboard objectives add mg_cz dummy
scoreboard objectives add mg_loot dummy
scoreboard objectives add mg_round dummy
scoreboard objectives add mg_aktion trigger
scoreboard objectives add mg_wins dummy {"text": "Siege", "color": "gold"}
scoreboard objectives setdisplay list mg_wins
scoreboard objectives add mg_side dummy {"text": "MINIGAMES", "color": "gold", "bold": true}
scoreboard objectives modify mg_side numberformat blank
scoreboard objectives setdisplay sidebar mg_side
scoreboard players set #20 mg 20
scoreboard players set #60 mg 60
scoreboard players set #6 mg 6
scoreboard players set #6 mg 6
execute unless score #rush mg matches 0.. run scoreboard players set #rush mg 0
execute unless score #sumo mg matches 0.. run scoreboard players set #sumo mg 0
execute unless score #spleef mg matches 0.. run scoreboard players set #spleef mg 0
execute unless score #duell mg matches 0.. run scoreboard players set #duell mg 0
gamerule pvp true
gamerule keep_inventory false
gamerule immediate_respawn true
gamerule spawn_monsters false
gamerule spawn_mobs false
gamerule advance_time false
gamerule advance_weather false
gamerule fall_damage true
gamerule show_death_messages false
gamerule respawn_radius 0
gamerule natural_health_regeneration true
time set 6000
weather clear
setworldspawn 0 101 0
difficulty normal
bossbar add mg:rush {"text": "Parkour-Rush"}
bossbar set mg:rush color green
function mg:hub/sidebar
execute unless score #built mg matches 6 run schedule function mg:build/try 40t
execute if score #built mg matches 6 unless score #lanes mg matches 6 run schedule function mg:build/lane_resume 40t
execute unless score #wind mg matches 0.. run scoreboard players set #wind mg 0
execute unless score #kb mg matches 0.. run scoreboard players set #kb mg 0
execute unless score #pfeil mg matches 0.. run scoreboard players set #pfeil mg 0
execute unless score #kolben mg matches 0.. run scoreboard players set #kolben mg 0
execute unless score #bruecke mg matches 0.. run scoreboard players set #bruecke mg 0
execute unless score #lava mg matches 0.. run scoreboard players set #lava mg 0
execute unless score #boden mg matches 0.. run scoreboard players set #boden mg 0
execute unless score #boxen mg matches 0.. run scoreboard players set #boxen mg 0
execute unless score #pferd mg matches 0.. run scoreboard players set #pferd mg 0
execute unless score #parkour mg matches 0.. run scoreboard players set #parkour mg 0
scoreboard objectives add mg_dmg minecraft.custom:minecraft.damage_dealt
scoreboard objectives add mg_hits dummy
scoreboard objectives add mg_lap dummy
scoreboard objectives add mg_gate dummy
scoreboard players set #10 mg 10
execute unless score #arenas mg matches 1 run scoreboard players set #aq mg 0
execute unless score #arenas mg matches 1 run schedule function mg:build/a_next 100t
scoreboard players set #zero mg 0
