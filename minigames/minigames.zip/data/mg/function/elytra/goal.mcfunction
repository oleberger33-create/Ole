tag @s add mg_elytra_fin
scoreboard players add #elytra_place mg 1
scoreboard players operation @s mg_elytra_pl = #elytra_place mg
scoreboard players operation #elytra_sec mg = #elytra_t mg
scoreboard players remove #elytra_sec mg 120
scoreboard players operation #elytra_ten mg = #elytra_sec mg
scoreboard players operation #elytra_ten mg %= #20 mg
scoreboard players operation #elytra_ten mg /= #2 mg
scoreboard players operation #elytra_sec mg /= #20 mg
effect clear @s minecraft:glowing
tag @s remove mg_elytra_lead
title @s times 5 50 15
execute if score #elytra_place mg matches 1 run function mg:elytra/first
execute if score #elytra_place mg matches 2.. run title @s title {"text": "IM ZIEL!", "color": "aqua", "bold": true}
execute if score #elytra_place mg matches 2.. run title @s subtitle [{"text": "Platz ", "color": "white"}, {"score": {"name": "@s", "objective": "mg_elytra_pl"}, "color": "gold", "bold": true}, {"text": "  ·  ", "color": "dark_gray"}, {"score": {"name": "#elytra_sec", "objective": "mg"}, "color": "white"}, {"text": ",", "color": "white"}, {"score": {"name": "#elytra_ten", "objective": "mg"}, "color": "white"}, {"text": " s", "color": "white"}]
execute if score #elytra_place mg matches 2.. run tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist im Ziel – ", "color": "gray"}, {"text": "Platz ", "color": "aqua"}, {"score": {"name": "@s", "objective": "mg_elytra_pl"}, "color": "aqua", "bold": true}, {"text": "  ·  ", "color": "dark_gray"}, {"score": {"name": "#elytra_sec", "objective": "mg"}, "color": "white"}, {"text": ",", "color": "white"}, {"score": {"name": "#elytra_ten", "objective": "mg"}, "color": "white"}, {"text": " s", "color": "white"}]
scoreboard players add @s mg_coins 3
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:15,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"star",colors:[I;16766720,65535],has_trail:true}]}}}}
clear @s
gamemode spectator @s
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du bist jetzt Zuschauer – schau den anderen beim Fliegen zu.", "color": "gray"}]
