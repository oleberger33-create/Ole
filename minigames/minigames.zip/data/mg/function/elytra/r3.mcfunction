function mg:elytra/pass
playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 0.87
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.4
execute in minecraft:overworld run particle minecraft:firework 80006.5 143.5 -41.5 0.15 1.40 1.40 0.05 25 force
title @s times 0 15 5
title @s title {"text":""}
title @s subtitle {"text":"✔ Ring 3/15","color":"green","bold":true}
