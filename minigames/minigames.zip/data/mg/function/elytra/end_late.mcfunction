tellraw @a[tag=mg_al_elytra,tag=!mg_elytra_fin] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zeit abgelaufen – du hast es nicht mehr ins Ziel geschafft.", "color": "red"}]
function mg:elytra/end_go
