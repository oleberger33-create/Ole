function mg:elytra/pass
playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.05
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.4
execute in minecraft:overworld run particle minecraft:firework 80052.5 135.5 -19.5 1.75 1.75 0.15 0.05 25 force
give @s minecraft:firework_rocket 2
playsound minecraft:entity.item.pickup master @s ~ ~ ~ 1 0.8
title @s times 0 25 8
title @s title {"text":""}
title @s subtitle [{"text":"✔ Ring 5/15  ","color":"green","bold":true},{"text":"+2 Raketen!","color":"gold","bold":true}]
