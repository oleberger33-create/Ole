execute store result score #n mg if entity @a[tag=mg_q_elytra,tag=mg_hub]
execute if score #n mg matches 1.. run scoreboard players set #elytra_cd mg 300
execute if score #n mg matches 1.. run execute in minecraft:overworld run forceload add 79940 -60 80060 60
execute if score #n mg matches 1.. run tellraw @a[tag=mg_q_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Elytra-Rennen startet in 15 Sekunden!", "color": "dark_aqua"}]
execute if score #n mg matches 1.. run scoreboard players set #elytra mg 1
