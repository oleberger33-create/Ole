scoreboard players add #elytra_t mg 1
execute if score #elytra_t mg matches 60 run function mg:elytra/cd3
execute if score #elytra_t mg matches 80 run function mg:elytra/cd2
execute if score #elytra_t mg matches 100 run function mg:elytra/cd1
execute if score #elytra_t mg matches 120 run function mg:elytra/go
execute as @e[type=minecraft:player,tag=mg_al_elytra,tag=!mg_elytra_fin] run function mg:elytra/pl
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=0}] positioned 79970.5 150.2 -39.5 if entity @s[distance=..6] positioned 79968.5 144.5 -45.5 if entity @s[dx=3,dy=12,dz=12] at @s run function mg:elytra/r1
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=1}] positioned 79988.5 147.2 -35.5 if entity @s[distance=..5] positioned 79986.5 142.5 -40.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r2
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=2}] positioned 80006.5 143.2 -41.5 if entity @s[distance=..5] positioned 80004.5 138.5 -46.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r3
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=3}] positioned 80024.5 139.2 -39.5 if entity @s[distance=..5] positioned 80022.5 134.5 -44.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r4
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=4}] positioned 80052.5 135.2 -19.5 if entity @s[distance=..6] positioned 80046.5 129.5 -21.5 if entity @s[dx=12,dy=12,dz=3] at @s run function mg:elytra/r5
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=5}] positioned 80024.5 131.2 0.5 if entity @s[distance=..5] positioned 80022.5 126.5 -4.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r6
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=6}] positioned 80006.5 124.2 2.5 if entity @s[distance=..5] positioned 80004.5 119.5 -2.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r7
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=7}] positioned 79988.5 127.2 -1.5 if entity @s[distance=..5] positioned 79986.5 122.5 -6.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r8
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=8}] positioned 79970.5 122.2 0.5 if entity @s[distance=..5] positioned 79968.5 117.5 -4.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r9
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=9}] positioned 79948.5 118.2 20.5 if entity @s[distance=..6] positioned 79942.5 112.5 18.5 if entity @s[dx=12,dy=12,dz=3] at @s run function mg:elytra/r10
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=10}] positioned 79974.5 115.2 40.5 if entity @s[distance=..5] positioned 79972.5 110.5 35.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r11
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=11}] positioned 79992.5 111.2 37.5 if entity @s[distance=..4] positioned 79990.5 107.5 33.5 if entity @s[dx=3,dy=8,dz=8] at @s run function mg:elytra/r12
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=12}] positioned 80010.5 114.2 43.5 if entity @s[distance=..5] positioned 80008.5 109.5 38.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r13
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=13}] positioned 80028.5 109.2 40.5 if entity @s[distance=..5] positioned 80026.5 104.5 35.5 if entity @s[dx=3,dy=10,dz=10] at @s run function mg:elytra/r14
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=14}] positioned 80048.5 106.2 40.5 if entity @s[distance=..7] positioned 80046.5 99.5 33.5 if entity @s[dx=3,dy=14,dz=14] at @s run function mg:elytra/r15
scoreboard players operation #elytra_m mg = #elytra_t mg
scoreboard players operation #elytra_m mg %= #4 mg
execute if score #elytra_m mg matches 0 if score #elytra_t mg matches 120.. run function mg:elytra/hud
execute if score #elytra_m mg matches 2 run execute in minecraft:overworld run kill @e[type=minecraft:item,x=79938,y=90,z=-62,dx=124,dy=115,dz=124]
execute if score #elytra_place mg matches 1.. run scoreboard players operation #elytra_r2 mg = #elytra_dl mg
execute if score #elytra_place mg matches 1.. run scoreboard players operation #elytra_r2 mg -= #elytra_t mg
execute if score #elytra_place mg matches 1.. if score #elytra_r2 mg matches 1200 run tellraw @a[tag=mg_al_elytra,tag=!mg_elytra_fin] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 60 Sekunden!", "color": "red", "bold": true}]
execute if score #elytra_place mg matches 1.. if score #elytra_r2 mg matches 1200 as @a[tag=mg_al_elytra,tag=!mg_elytra_fin] at @s run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 1 0.6
execute if score #elytra_place mg matches 0 if score #elytra_t mg matches 6120 run tellraw @a[tag=mg_al_elytra,tag=!mg_elytra_fin] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 60 Sekunden! Danach gewinnt, wer am weitesten ist.", "color": "red", "bold": true}]
execute if score #elytra_place mg matches 1.. if score #elytra_r2 mg matches 600 run tellraw @a[tag=mg_al_elytra,tag=!mg_elytra_fin] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 30 Sekunden!", "color": "red", "bold": true}]
execute if score #elytra_place mg matches 1.. if score #elytra_r2 mg matches 600 as @a[tag=mg_al_elytra,tag=!mg_elytra_fin] at @s run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 1 0.6
execute if score #elytra_place mg matches 0 if score #elytra_t mg matches 6720 run tellraw @a[tag=mg_al_elytra,tag=!mg_elytra_fin] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 30 Sekunden! Danach gewinnt, wer am weitesten ist.", "color": "red", "bold": true}]
execute if score #elytra_place mg matches 1.. if score #elytra_r2 mg matches 200 run tellraw @a[tag=mg_al_elytra,tag=!mg_elytra_fin] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 10 Sekunden!", "color": "red", "bold": true}]
execute if score #elytra_place mg matches 1.. if score #elytra_r2 mg matches 200 as @a[tag=mg_al_elytra,tag=!mg_elytra_fin] at @s run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 1 0.6
execute if score #elytra_place mg matches 0 if score #elytra_t mg matches 7120 run tellraw @a[tag=mg_al_elytra,tag=!mg_elytra_fin] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 10 Sekunden! Danach gewinnt, wer am weitesten ist.", "color": "red", "bold": true}]
execute unless entity @a[tag=mg_elytra] run return run function mg:elytra/end_go
execute if score #elytra_place mg matches 1.. unless entity @a[tag=mg_al_elytra,tag=!mg_elytra_fin] run return run function mg:elytra/end_go
execute if score #elytra_place mg matches 1.. if score #elytra_r2 mg matches ..0 run return run function mg:elytra/end_late
execute if score #elytra_place mg matches 0 if score #elytra_t mg matches 7320.. run return run function mg:elytra/end_time
