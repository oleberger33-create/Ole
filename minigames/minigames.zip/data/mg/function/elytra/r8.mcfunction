function mg:elytra/pass
playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.32
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.4
execute in minecraft:overworld run particle minecraft:firework 79988.5 127.5 -1.5 0.15 1.40 1.40 0.05 25 force
title @s times 0 15 5
title @s title {"text":""}
title @s subtitle {"text":"✔ Ring 8/15","color":"green","bold":true}
