execute if score @s mg_deaths matches 1.. run return run function mg:elytra/died
execute if entity @s[y=-64,dy=162] run return run function mg:elytra/crash_low
execute unless entity @s[x=79938,y=90,z=-62,dx=124,dy=115,dz=124] run return run function mg:elytra/crash_out
execute store success score #elytra_og mg if predicate {type:"minecraft:entity_properties",entity:"this",predicate:{flags:{is_on_ground:true}}}
execute if score #elytra_og mg matches 1 at @s if block ~ ~-0.5 ~ minecraft:smooth_quartz run scoreboard players set #elytra_og mg 0
execute if score #elytra_og mg matches 0 run scoreboard players set @s mg_elytra_g 0
execute if score #elytra_og mg matches 1 run scoreboard players add @s mg_elytra_g 1
execute if score @s mg_elytra_g matches 8.. run function mg:elytra/crash_ground
