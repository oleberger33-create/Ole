execute store result score #n mg if entity @a[tag=mg_q_elytra,tag=mg_hub]
execute if score #n mg matches ..0 run execute in minecraft:overworld run forceload remove 79940 -60 80060 60
execute if score #n mg matches ..0 run tellraw @a[tag=mg_q_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zu wenig Spieler – Elytra-Rennen abgebrochen.", "color": "red"}]
execute if score #n mg matches ..0 run return run scoreboard players set #elytra mg 0
scoreboard players remove #elytra_cd mg 1
scoreboard players operation #s mg = #elytra_cd mg
scoreboard players operation #s mg /= #20 mg
execute as @a[tag=mg_q_elytra] run title @s actionbar [{"text":"Elytra-Rennen startet in ","color":"dark_aqua"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true},{"text":" s","color":"dark_aqua"}]
execute if score #elytra_cd mg matches 60 as @a[tag=mg_q_elytra] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #elytra_cd mg matches 40 as @a[tag=mg_q_elytra] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #elytra_cd mg matches 20 as @a[tag=mg_q_elytra] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #elytra_cd mg matches ..0 in minecraft:overworld if loaded 79948 100 -52 if loaded 80052 100 52 run function mg:elytra/start
