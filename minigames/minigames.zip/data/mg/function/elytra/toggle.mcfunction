execute if entity @s[tag=mg_q_elytra] run return run function mg:elytra/leave
function mg:q/leave_all
tag @s add mg_q_elytra
execute if score #elytra mg matches 1.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Elytra-Rennen läuft gerade – du bist in der Warteschlange für die nächste Runde.", "color": "gray"}]
execute unless score #elytra mg matches 1.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du kannst auch alleine spielen – in 15 Sekunden geht es los, bis dahin können noch andere mitmachen.", "color": "gray"}]
tellraw @a[tag=mg_hub] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " wartet auf ", "color": "gray"}, {"text": "Elytra-Rennen", "color": "dark_aqua", "bold": true}, {"text": " – ", "color": "gray"}, {"text": "[Mitspielen]", "color": "green", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 65"}}]
