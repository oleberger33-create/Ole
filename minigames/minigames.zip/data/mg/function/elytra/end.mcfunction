execute as @a[tag=mg_al_elytra] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Elytra-Rennen!", "color": "white"}]
execute unless entity @a[tag=mg_al_elytra] run tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Unentschieden – niemand hat überlebt.", "color": "gray"}]
scoreboard players add @a[tag=mg_al_elytra] mg_wins 1
scoreboard players add @a[tag=mg_al_elytra] mg_coins 0
title @a[tag=mg_elytra] title {"text": "Spiel vorbei!", "color": "dark_aqua", "bold": true}
execute as @a[tag=mg_al_elytra] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720],has_twinkle:true}]}}}}
scoreboard players set #elytra mg 3
schedule function mg:elytra/finish 100t
