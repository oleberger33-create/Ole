scoreboard players add @s mg_elytra_p 1
scoreboard players set @s mg_elytra_g 0
execute if score @s mg_elytra_p matches ..14 if score @s mg_elytra_p > #elytra_best mg unless entity @s[tag=mg_elytra_lead] run function mg:elytra/newlead
execute if score @s mg_elytra_p > #elytra_best mg run scoreboard players operation #elytra_best mg = @s mg_elytra_p
