scoreboard players operation #pbv mg = #elytra_t mg
scoreboard players remove #pbv mg 120
scoreboard players operation #elys_d mg = #pbv mg
scoreboard players operation #elys_d mg /= #2 mg
scoreboard players operation #elys_s1 mg = #elys_d mg
scoreboard players operation #elys_s1 mg /= #10 mg
scoreboard players operation #elys_m mg = #elys_s1 mg
scoreboard players operation #elys_m mg /= #60 mg
scoreboard players operation #elys_s1 mg %= #60 mg
scoreboard players operation #elys_s10 mg = #elys_s1 mg
scoreboard players operation #elys_s10 mg /= #10 mg
scoreboard players operation #elys_s1 mg %= #10 mg
scoreboard players operation #elys_d mg %= #10 mg
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Ziel! ", "color": "aqua", "bold": true}, {"text": "Alle 15 Ringe in ", "color": "gray"}, {"score": {"name": "#elys_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#elys_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#elys_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#elys_d", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": "  +2 Münzen", "color": "yellow"}]
scoreboard players add @s mg_coins 2
function mg:elytra/pb
execute if score #pbn mg matches 1 run scoreboard players add @s mg_coins 3
execute if score #pbn mg matches 1 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Rekord-Bonus: ", "color": "gold"}, {"text": "+3 Münzen", "color": "yellow"}]
title @s subtitle [{"text": "Zeit: ", "color": "white"}, {"score": {"name": "#elys_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#elys_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#elys_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#elys_d", "objective": "mg"}, "color": "yellow", "bold": true}]
execute if score #pbn mg matches 1 run title @s subtitle [{"text": "★ Neuer Rekord: ", "color": "gold", "bold": true}, {"score": {"name": "#elys_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#elys_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#elys_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#elys_d", "objective": "mg"}, "color": "yellow", "bold": true}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:15,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"star",colors:[I;16766720,65535],has_trail:true}]}}}}
clear @s
gamemode spectator @s
function mg:elytra/end
