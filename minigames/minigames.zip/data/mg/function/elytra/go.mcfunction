execute in minecraft:overworld run fill 79955 163 -44 79955 166 -36 minecraft:air
title @a[tag=mg_elytra] times 0 30 10
title @a[tag=mg_elytra] title {"text": "LOS!", "color": "green", "bold": true}
title @a[tag=mg_elytra] subtitle {"text": "Spring vom Turm und gleite durch Ring 1!", "color": "white"}
execute as @a[tag=mg_elytra] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
execute as @a[tag=mg_elytra] at @s run playsound minecraft:entity.firework_rocket.launch master @s ~ ~ ~ 1 1
give @a[tag=mg_al_elytra,tag=!mg_elytra_fin] minecraft:firework_rocket 3
tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Tipp: ", "color": "yellow"}, {"text": "Lauf über die Kante und drück in der Luft ", "color": "gray"}, {"text": "Springen", "color": "white"}, {"text": " zum Gleiten. ", "color": "gray"}, {"text": "Rechtsklick mit Rakete", "color": "white"}, {"text": " = Schub. Die Funken zeigen zum nächsten Ring.", "color": "gray"}]
execute in minecraft:overworld run particle minecraft:firework 79955.5 165 -39.5 0.3 2 4 0.05 60 force
