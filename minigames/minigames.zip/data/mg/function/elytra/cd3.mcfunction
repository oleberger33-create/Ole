execute in minecraft:overworld run fill 79955 163 -44 79955 166 -36 minecraft:red_stained_glass
title @a[tag=mg_elytra] times 0 22 4
title @a[tag=mg_elytra] title {"text": "3", "color": "red", "bold": true}
title @a[tag=mg_elytra] subtitle {"text": "Gleich öffnet sich das Tor ...", "color": "gray"}
execute as @a[tag=mg_elytra] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 0.7
