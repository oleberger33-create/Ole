tag @s add mg_elytra_win
function mg:elytra/award
scoreboard players operation #elytra_dl mg = #elytra_t mg
scoreboard players add #elytra_dl mg 3600
title @s title {"text": "SIEG!", "color": "gold", "bold": true}
title @s subtitle [{"text": "Platz 1  ·  ", "color": "white"}, {"score": {"name": "#elytra_sec", "objective": "mg"}, "color": "white"}, {"text": ",", "color": "white"}, {"score": {"name": "#elytra_ten", "objective": "mg"}, "color": "white"}, {"text": " s", "color": "white"}]
tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " fliegt als Erster durchs Ziel! ", "color": "yellow"}, {"score": {"name": "#elytra_sec", "objective": "mg"}, "color": "white"}, {"text": ",", "color": "white"}, {"score": {"name": "#elytra_ten", "objective": "mg"}, "color": "white"}, {"text": " s", "color": "white"}]
tellraw @a[tag=!mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Elytra-Rennen!", "color": "white"}]
tellraw @a[tag=mg_al_elytra,tag=!mg_elytra_fin] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Ihr habt noch 3 Minuten, um ins Ziel zu kommen!", "color": "red"}]
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin] at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.4 1.6
