execute if score #elytra mg matches 2 run function mg:elytra/game
