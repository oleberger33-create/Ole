execute at @s run particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
execute at @s run playsound minecraft:entity.player.big_fall master @s ~ ~ ~ 1 0.8
title @s times 0 30 10
title @s title {"text": "✖", "color": "red", "bold": true}
title @s subtitle [{"text": "Außerhalb der Strecke! ", "color": "red", "bold": true}, {"text": "Zurück zum letzten Ring", "color": "gray"}]
function mg:elytra/respawn
