effect clear @a[tag=mg_elytra_lead] minecraft:glowing
tag @a[tag=mg_elytra_lead] remove mg_elytra_lead
tag @s add mg_elytra_lead
effect give @s minecraft:glowing infinite 0 true
execute if score #elytra_best mg matches 1.. run tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " übernimmt die Führung! ", "color": "aqua"}, {"text": "(Ring ", "color": "gray"}, {"score": {"name": "@s", "objective": "mg_elytra_p"}, "color": "gray"}, {"text": ")", "color": "gray"}]
