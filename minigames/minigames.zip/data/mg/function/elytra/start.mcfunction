function mg:elytra/build
tag @a[tag=mg_q_elytra,tag=mg_hub,limit=16,sort=random] add mg_elytra
tag @a[tag=mg_elytra] remove mg_q_elytra
execute as @a[tag=mg_elytra] run function mg:q/leave_all
tag @a[tag=mg_elytra] remove mg_hub
clear @a[tag=mg_elytra]
effect clear @a[tag=mg_elytra]
gamemode adventure @a[tag=mg_elytra]
tag @a[tag=mg_elytra] add mg_al_elytra
scoreboard players set @a[tag=mg_elytra] mg_deaths 0
execute as @a[tag=mg_elytra] run execute in minecraft:overworld run spawnpoint @s 80000 175 0
scoreboard players set #elytra_t mg 0
scoreboard players set #elytra_place mg 0
scoreboard players set #elytra_best mg 0
scoreboard players set #elytra_dl mg 0
scoreboard players set #elytra_r2 mg 1
scoreboard players set #elytra_sec mg 0
tag @a remove mg_elytra_fin
tag @a remove mg_elytra_win
tag @a remove mg_elytra_lead
scoreboard players set @a[tag=mg_elytra] mg_elytra_p 0
scoreboard players set @a[tag=mg_elytra] mg_elytra_g 0
scoreboard players set @a[tag=mg_elytra] mg_elytra_pl 0
execute in minecraft:overworld run tp @a[tag=mg_elytra] 79950.5 163 -39.5
execute in minecraft:overworld run spreadplayers 79950.5 -39.5 1 3 false @a[tag=mg_elytra]
execute as @a[tag=mg_elytra] at @s run tp @s ~ ~ ~ facing 79970.5 150.5 -39.5
item replace entity @a[tag=mg_elytra] armor.chest with minecraft:elytra[minecraft:unbreakable={},minecraft:enchantments={"minecraft:binding_curse":1},minecraft:tooltip_display={hidden_components:["minecraft:unbreakable"]},minecraft:custom_name={"text":"Renn-Elytra","color":"aqua","italic":false}]
effect give @a[tag=mg_elytra] minecraft:saturation infinite 0 true
effect give @a[tag=mg_elytra] minecraft:resistance infinite 4 true
effect give @a[tag=mg_elytra] minecraft:weakness infinite 255 true
execute in minecraft:overworld run forceload remove 79940 -60 80060 60
scoreboard players set #elytra mg 2
title @a[tag=mg_elytra] times 5 50 10
title @a[tag=mg_elytra] title {"text": "ELYTRA-RENNEN", "color": "dark_aqua", "bold": true}
title @a[tag=mg_elytra] subtitle {"text": "Flieg durch alle 15 Ringe!", "color": "white"}
tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Gleite mit der Elytra vom Startturm durch alle 15 Ringe – in der richtigen Reihenfolge. Raketen geben Schub (Nachschub an Ring 5 und 10). Absturz oder Bodenkontakt = zurück zum letzten Ring. Wer zuerst durchs goldene Ziel fliegt, gewinnt!", "color": "gray"}]
tellraw @a[tag=mg_elytra] [{"text": "  "}, {"text": "[Spiel verlassen]", "color": "red", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 99"}}]
