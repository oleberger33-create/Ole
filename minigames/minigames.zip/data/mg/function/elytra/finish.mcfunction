execute as @a[tag=mg_elytra] run function mg:hub/enter
tag @a remove mg_elytra
tag @a remove mg_al_elytra
scoreboard players set #elytra mg 0
execute in minecraft:overworld run fill 79955 163 -44 79955 166 -36 minecraft:red_stained_glass
execute in minecraft:overworld run kill @e[type=minecraft:item,x=79940,dx=120,y=60,dy=90,z=-60,dz=120]
