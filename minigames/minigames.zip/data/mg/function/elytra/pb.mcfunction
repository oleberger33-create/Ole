scoreboard players set #pbn mg 0
execute unless score @s mg_elytra_pb matches 1.. run scoreboard players set #pbn mg 1
execute if score @s mg_elytra_pb matches 1.. if score #pbv mg < @s mg_elytra_pb run scoreboard players set #pbn mg 1
execute if score #pbv mg matches ..0 run scoreboard players set #pbn mg 0
scoreboard players operation #pa_d mg = #pbv mg
scoreboard players operation #pa_d mg /= #2 mg
scoreboard players operation #pa_s1 mg = #pa_d mg
scoreboard players operation #pa_s1 mg /= #10 mg
scoreboard players operation #pa_m mg = #pa_s1 mg
scoreboard players operation #pa_m mg /= #60 mg
scoreboard players operation #pa_s1 mg %= #60 mg
scoreboard players operation #pa_s10 mg = #pa_s1 mg
scoreboard players operation #pa_s10 mg /= #10 mg
scoreboard players operation #pa_s1 mg %= #10 mg
scoreboard players operation #pa_d mg %= #10 mg
scoreboard players operation #pb_d mg = @s mg_elytra_pb
scoreboard players operation #pb_d mg /= #2 mg
scoreboard players operation #pb_s1 mg = #pb_d mg
scoreboard players operation #pb_s1 mg /= #10 mg
scoreboard players operation #pb_m mg = #pb_s1 mg
scoreboard players operation #pb_m mg /= #60 mg
scoreboard players operation #pb_s1 mg %= #60 mg
scoreboard players operation #pb_s10 mg = #pb_s1 mg
scoreboard players operation #pb_s10 mg /= #10 mg
scoreboard players operation #pb_s1 mg %= #10 mg
scoreboard players operation #pb_d mg %= #10 mg
execute if score #pbn mg matches 0 if score @s mg_elytra_pb matches 1.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Ergebnis: ", "color": "gray"}, {"score": {"name": "#pa_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#pa_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#pa_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#pa_d", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": "   ·   Dein Rekord (Bestzeit): ", "color": "gray"}, {"score": {"name": "#pb_m", "objective": "mg"}, "color": "gold", "bold": true}, {"text": ":", "color": "gold", "bold": true}, {"score": {"name": "#pb_s10", "objective": "mg"}, "color": "gold", "bold": true}, {"score": {"name": "#pb_s1", "objective": "mg"}, "color": "gold", "bold": true}, {"text": ".", "color": "gold", "bold": true}, {"score": {"name": "#pb_d", "objective": "mg"}, "color": "gold", "bold": true}]
execute if score #pbn mg matches 1 run scoreboard players operation @s mg_elytra_pb = #pbv mg
execute if score #pbn mg matches 1 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " – neuer persönlicher Rekord in Elytra-Rennen: ", "color": "gray"}, {"score": {"name": "#pa_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#pa_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#pa_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#pa_d", "objective": "mg"}, "color": "yellow", "bold": true}]
execute if score #pbn mg matches 1 run title @s actionbar [{"text": "★ NEUER REKORD ★  ", "color": "gold", "bold": true}, {"score": {"name": "#pa_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#pa_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#pa_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#pa_d", "objective": "mg"}, "color": "yellow", "bold": true}]
execute if score #pbn mg matches 1 at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.3
