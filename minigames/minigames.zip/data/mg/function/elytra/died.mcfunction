scoreboard players set @s mg_deaths 0
item replace entity @s armor.chest with minecraft:elytra[minecraft:unbreakable={},minecraft:enchantments={"minecraft:binding_curse":1},minecraft:tooltip_display={hidden_components:["minecraft:unbreakable"]},minecraft:custom_name={"text":"Renn-Elytra","color":"aqua","italic":false}]
effect give @s minecraft:saturation infinite 0 true
effect give @s minecraft:resistance infinite 4 true
effect give @s minecraft:weakness infinite 255 true
execute if entity @s[tag=mg_elytra_lead] run effect give @s minecraft:glowing infinite 0 true
execute if score #elytra_t mg matches 120.. run give @s minecraft:firework_rocket 2
function mg:elytra/respawn
