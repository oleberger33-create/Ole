tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zeit abgelaufen! Niemand hat das Ziel erreicht – wer am weitesten kam, gewinnt.", "color": "red"}]
execute if score #elytra_best mg matches 1.. as @a[tag=mg_al_elytra,tag=!mg_elytra_fin] if score @s mg_elytra_p = #elytra_best mg run tag @s add mg_elytra_win
execute as @a[tag=mg_elytra,tag=mg_elytra_win] run function mg:elytra/award
execute as @a[tag=mg_elytra,tag=mg_elytra_win] run tellraw @a[tag=!mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Elytra-Rennen!", "color": "white"}]
function mg:elytra/end_go
