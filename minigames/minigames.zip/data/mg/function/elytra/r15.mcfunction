function mg:elytra/pass
playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.95
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.5 1.4
execute in minecraft:overworld run particle minecraft:firework 80048.5 106.5 40.5 0.15 2.10 2.10 0.05 25 force
function mg:elytra/goal
