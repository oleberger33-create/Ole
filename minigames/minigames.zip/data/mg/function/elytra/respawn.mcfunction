scoreboard players set @s mg_elytra_g 0
execute if score @s mg_elytra_p matches 0 run execute in minecraft:overworld run tp @s 79952.5 163 -39.5 facing 79970.5 150.5 -39.5
execute if score @s mg_elytra_p matches 1 run execute in minecraft:overworld run tp @s 79970.5 159 -39.5 facing 79988.5 147.5 -35.5
execute if score @s mg_elytra_p matches 2 run execute in minecraft:overworld run tp @s 79988.5 155 -35.5 facing 80006.5 143.5 -41.5
execute if score @s mg_elytra_p matches 3 run execute in minecraft:overworld run tp @s 80006.5 151 -41.5 facing 80024.5 139.5 -39.5
execute if score @s mg_elytra_p matches 4 run execute in minecraft:overworld run tp @s 80024.5 147 -39.5 facing 80052.5 135.5 -19.5
execute if score @s mg_elytra_p matches 5 run execute in minecraft:overworld run tp @s 80052.5 144 -19.5 facing 80024.5 131.5 0.5
execute if score @s mg_elytra_p matches 6 run execute in minecraft:overworld run tp @s 80024.5 139 0.5 facing 80006.5 124.5 2.5
execute if score @s mg_elytra_p matches 7 run execute in minecraft:overworld run tp @s 80006.5 132 2.5 facing 79988.5 127.5 -1.5
execute if score @s mg_elytra_p matches 8 run execute in minecraft:overworld run tp @s 79988.5 135 -1.5 facing 79970.5 122.5 0.5
execute if score @s mg_elytra_p matches 9 run execute in minecraft:overworld run tp @s 79970.5 130 0.5 facing 79948.5 118.5 20.5
execute if score @s mg_elytra_p matches 10 run execute in minecraft:overworld run tp @s 79948.5 127 20.5 facing 79974.5 115.5 40.5
execute if score @s mg_elytra_p matches 11 run execute in minecraft:overworld run tp @s 79974.5 123 40.5 facing 79992.5 111.5 37.5
execute if score @s mg_elytra_p matches 12 run execute in minecraft:overworld run tp @s 79992.5 118 37.5 facing 80010.5 114.5 43.5
execute if score @s mg_elytra_p matches 13 run execute in minecraft:overworld run tp @s 80010.5 122 43.5 facing 80028.5 109.5 40.5
execute if score @s mg_elytra_p matches 14 run execute in minecraft:overworld run tp @s 80028.5 117 40.5 facing 80048.5 106.5 40.5
execute if score #elytra_t mg matches 120.. store result score #elytra_fw mg run clear @s minecraft:firework_rocket 0
execute if score #elytra_t mg matches 120.. if score #elytra_fw mg matches 0 run give @s minecraft:firework_rocket 1
execute at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.8 1.2
