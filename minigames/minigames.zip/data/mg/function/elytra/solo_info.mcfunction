scoreboard players operation #elyb_d mg = @s mg_elytra_pb
scoreboard players operation #elyb_d mg /= #2 mg
scoreboard players operation #elyb_s1 mg = #elyb_d mg
scoreboard players operation #elyb_s1 mg /= #10 mg
scoreboard players operation #elyb_m mg = #elyb_s1 mg
scoreboard players operation #elyb_m mg /= #60 mg
scoreboard players operation #elyb_s1 mg %= #60 mg
scoreboard players operation #elyb_s10 mg = #elyb_s1 mg
scoreboard players operation #elyb_s10 mg /= #10 mg
scoreboard players operation #elyb_s1 mg %= #10 mg
scoreboard players operation #elyb_d mg %= #10 mg
execute if score @s mg_elytra_pb matches 1.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Solo-Lauf gegen die Uhr! ", "color": "aqua", "bold": true}, {"text": "Deine Bestzeit: ", "color": "gray"}, {"score": {"name": "#elyb_m", "objective": "mg"}, "color": "gold", "bold": true}, {"text": ":", "color": "gold", "bold": true}, {"score": {"name": "#elyb_s10", "objective": "mg"}, "color": "gold", "bold": true}, {"score": {"name": "#elyb_s1", "objective": "mg"}, "color": "gold", "bold": true}, {"text": ".", "color": "gold", "bold": true}, {"score": {"name": "#elyb_d", "objective": "mg"}, "color": "gold", "bold": true}, {"text": " – schaffst du sie?", "color": "gray"}]
execute unless score @s mg_elytra_pb matches 1.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Solo-Lauf gegen die Uhr! ", "color": "aqua", "bold": true}, {"text": "Flieg durch alle 15 Ringe und stell deine erste Bestzeit auf. Du hast 6 Minuten.", "color": "gray"}]
