tag @a[tag=mg_elytra] remove mg_al_elytra
title @a[tag=mg_elytra] times 10 60 20
effect clear @a[tag=mg_elytra] minecraft:glowing
execute as @a[tag=mg_elytra,tag=mg_elytra_win] run tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Elytra-Rennen!", "color": "white"}]
execute unless entity @a[tag=mg_elytra,tag=mg_elytra_win] if score #elytra_place mg matches 1.. run tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Der Sieger hat das Rennen schon verlassen – sein Sieg zählt trotzdem.", "color": "gray"}]
execute unless entity @a[tag=mg_elytra,tag=mg_elytra_win] if score #elytra_place mg matches 0 run tellraw @a[tag=mg_elytra] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Unentschieden – niemand hat einen Ring geschafft.", "color": "gray"}]
title @a[tag=mg_elytra] title {"text": "Spiel vorbei!", "color": "dark_aqua", "bold": true}
execute as @a[tag=mg_elytra,tag=mg_elytra_win] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720],has_twinkle:true}]}}}}
scoreboard players set #elytra mg 3
schedule function mg:elytra/finish 100t
