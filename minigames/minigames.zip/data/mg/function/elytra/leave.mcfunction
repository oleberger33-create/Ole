tag @s remove mg_q_elytra
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Elytra-Rennen-Warteschlange verlassen.", "color": "gray"}]
