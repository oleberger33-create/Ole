effect clear @a[tag=mg_elytra] minecraft:glowing
tag @a[tag=mg_elytra] remove mg_al_elytra
title @a[tag=mg_elytra] times 10 60 20
title @a[tag=mg_elytra] title {"text": "Solo-Runde vorbei", "color": "dark_aqua", "bold": true}
scoreboard players set #elytra mg 3
schedule function mg:elytra/finish 100t
