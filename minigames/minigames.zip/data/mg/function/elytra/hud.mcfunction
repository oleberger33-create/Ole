scoreboard players operation #elytra_sec mg = #elytra_t mg
scoreboard players remove #elytra_sec mg 120
scoreboard players operation #elytra_sec mg /= #20 mg
execute if score #elytra_place mg matches 1.. run scoreboard players operation #elytra_rem mg = #elytra_dl mg
execute if score #elytra_place mg matches 1.. run scoreboard players operation #elytra_rem mg -= #elytra_t mg
execute if score #elytra_place mg matches 1.. run scoreboard players operation #elytra_rem mg /= #20 mg
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=0}] run particle minecraft:end_rod 79970.5 150.5 -39.5 0.15 1.75 1.75 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=0}] at @s anchored eyes facing 79970.5 150.5 -39.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=0}] at @s anchored eyes facing 79970.5 150.5 -39.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=1}] run particle minecraft:end_rod 79988.5 147.5 -35.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=1}] at @s anchored eyes facing 79988.5 147.5 -35.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=1}] at @s anchored eyes facing 79988.5 147.5 -35.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=2}] run particle minecraft:end_rod 80006.5 143.5 -41.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=2}] at @s anchored eyes facing 80006.5 143.5 -41.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=2}] at @s anchored eyes facing 80006.5 143.5 -41.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=3}] run particle minecraft:end_rod 80024.5 139.5 -39.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=3}] at @s anchored eyes facing 80024.5 139.5 -39.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=3}] at @s anchored eyes facing 80024.5 139.5 -39.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=4}] run particle minecraft:end_rod 80052.5 135.5 -19.5 1.75 1.75 0.15 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=4}] at @s anchored eyes facing 80052.5 135.5 -19.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=4}] at @s anchored eyes facing 80052.5 135.5 -19.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=5}] run particle minecraft:end_rod 80024.5 131.5 0.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=5}] at @s anchored eyes facing 80024.5 131.5 0.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=5}] at @s anchored eyes facing 80024.5 131.5 0.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=6}] run particle minecraft:end_rod 80006.5 124.5 2.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=6}] at @s anchored eyes facing 80006.5 124.5 2.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=6}] at @s anchored eyes facing 80006.5 124.5 2.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=7}] run particle minecraft:end_rod 79988.5 127.5 -1.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=7}] at @s anchored eyes facing 79988.5 127.5 -1.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=7}] at @s anchored eyes facing 79988.5 127.5 -1.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=8}] run particle minecraft:end_rod 79970.5 122.5 0.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=8}] at @s anchored eyes facing 79970.5 122.5 0.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=8}] at @s anchored eyes facing 79970.5 122.5 0.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=9}] run particle minecraft:end_rod 79948.5 118.5 20.5 1.75 1.75 0.15 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=9}] at @s anchored eyes facing 79948.5 118.5 20.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=9}] at @s anchored eyes facing 79948.5 118.5 20.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=10}] run particle minecraft:end_rod 79974.5 115.5 40.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=10}] at @s anchored eyes facing 79974.5 115.5 40.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=10}] at @s anchored eyes facing 79974.5 115.5 40.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=11}] run particle minecraft:end_rod 79992.5 111.5 37.5 0.15 1.05 1.05 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=11}] at @s anchored eyes facing 79992.5 111.5 37.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=11}] at @s anchored eyes facing 79992.5 111.5 37.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=12}] run particle minecraft:end_rod 80010.5 114.5 43.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=12}] at @s anchored eyes facing 80010.5 114.5 43.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=12}] at @s anchored eyes facing 80010.5 114.5 43.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=13}] run particle minecraft:end_rod 80028.5 109.5 40.5 0.15 1.40 1.40 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=13}] at @s anchored eyes facing 80028.5 109.5 40.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=13}] at @s anchored eyes facing 80028.5 109.5 40.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=14}] run particle minecraft:end_rod 80048.5 106.5 40.5 0.15 2.10 2.10 0 10 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=14}] at @s anchored eyes facing 80048.5 106.5 40.5 run particle minecraft:electric_spark ^ ^ ^5 0 0 0 0 1 force @s
execute as @a[tag=mg_al_elytra,tag=!mg_elytra_fin,scores={mg_elytra_p=14}] at @s anchored eyes facing 80048.5 106.5 40.5 run particle minecraft:electric_spark ^ ^ ^6.5 0 0 0 0 1 force @s
execute if score #elytra_place mg matches 0 as @a[tag=mg_al_elytra,tag=!mg_elytra_fin] run title @s actionbar [{"text": "Ring ", "color": "gray"}, {"score": {"name": "@s", "objective": "mg_elytra_p"}, "color": "gold", "bold": true}, {"text": "/15", "color": "gold"}, {"text": "   ⏱ ", "color": "dark_gray"}, {"score": {"name": "#elytra_sec", "objective": "mg"}, "color": "white"}, {"text": " s", "color": "gray"}]
execute if score #elytra_place mg matches 1.. as @a[tag=mg_al_elytra,tag=!mg_elytra_fin] run title @s actionbar [{"text": "Ring ", "color": "gray"}, {"score": {"name": "@s", "objective": "mg_elytra_p"}, "color": "gold", "bold": true}, {"text": "/15", "color": "gold"}, {"text": "   noch ", "color": "red"}, {"score": {"name": "#elytra_rem", "objective": "mg"}, "color": "red", "bold": true}, {"text": " s", "color": "red"}]
execute as @a[tag=mg_elytra,tag=mg_elytra_fin] run title @s actionbar [{"text": "Im Ziel  ·  Platz ", "color": "aqua"}, {"score": {"name": "@s", "objective": "mg_elytra_pl"}, "color": "gold", "bold": true}]
