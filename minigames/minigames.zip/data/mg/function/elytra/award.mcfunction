scoreboard players add @s mg_wins 1
scoreboard players add @s mg_coins 15
