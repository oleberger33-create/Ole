scoreboard players remove #sw_cd mg 1
scoreboard players operation #s mg = #sw_cd mg
scoreboard players operation #s mg /= #20 mg
execute if score #sw_cd mg matches 1.. run title @a[tag=mg_sw] actionbar [{"text":"Käfig öffnet in ","color":"gray"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true}]
execute if score #sw_cd mg matches ..0 run function mg:sw/release
