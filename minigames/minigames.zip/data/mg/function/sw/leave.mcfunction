tag @s remove mg_q_sw
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "SkyWars-Warteschlange verlassen.", "color": "gray"}]
