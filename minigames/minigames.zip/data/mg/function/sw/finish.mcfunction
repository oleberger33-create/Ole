execute as @a[tag=mg_sw] run function mg:hub/enter
tag @a remove mg_sw
tag @a remove mg_alive
scoreboard players set #sw mg 0
execute in minecraft:overworld run kill @e[type=minecraft:item,x=39960,dx=80,y=60,dy=80,z=-40,dz=80]
