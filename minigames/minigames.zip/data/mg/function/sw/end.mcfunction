execute as @a[tag=mg_sw,tag=mg_alive] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt SkyWars!", "color": "white"}]
scoreboard players add @a[tag=mg_sw,tag=mg_alive] mg_wins 1
title @a[tag=mg_sw] title {"text": "Spiel vorbei!", "color": "aqua", "bold": true}
execute as @a[tag=mg_sw,tag=mg_alive] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;5636095],has_twinkle:true}]}}}}
scoreboard players set #sw mg 4
schedule function mg:sw/finish 100t
