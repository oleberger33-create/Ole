scoreboard players set #sw_t mg 0
execute in minecraft:overworld run fill 39970 101 -30 40030 104 30 minecraft:air replace minecraft:glass
scoreboard players set #sw mg 3
title @a[tag=mg_sw] title {"text": "LOS!", "color": "aqua", "bold": true}
execute as @a[tag=mg_sw] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.6 1.3
