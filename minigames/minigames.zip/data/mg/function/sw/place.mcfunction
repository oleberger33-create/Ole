tag @s add mg_placed
$execute in minecraft:overworld run tp @s $(x) 101 $(z) facing 40000.5 101 0.5
execute in minecraft:overworld run spawnpoint @s 40000 112 0
