tag @s add mg_placed
$execute in minecraft:overworld run tp @s $(x).5 101 $(z).5 facing 40000.5 101 0.5
execute in minecraft:overworld run spawnpoint @s 40000 112 0
