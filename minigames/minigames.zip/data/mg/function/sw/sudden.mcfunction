effect give @a[tag=mg_al_sw] minecraft:glowing infinite 0 true
title @a[tag=mg_sw] title {"text": "SUDDEN DEATH", "color": "red", "bold": true}
title @a[tag=mg_sw] subtitle {"text": "Alle leuchten – in 4 Minuten ist Schluss", "color": "white"}
