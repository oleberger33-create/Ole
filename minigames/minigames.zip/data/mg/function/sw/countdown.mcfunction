execute store result score #n mg if entity @a[tag=mg_q_sw,tag=mg_hub]
execute if score #n mg matches ..1 run execute in minecraft:overworld run forceload remove 39960 -40 40040 40
execute if score #n mg matches ..1 run tellraw @a[tag=mg_q_sw] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zu wenig Spieler – SkyWars abgebrochen.", "color": "red"}]
execute if score #n mg matches ..1 run return run scoreboard players set #sw mg 0
scoreboard players remove #sw_cd mg 1
scoreboard players operation #s mg = #sw_cd mg
scoreboard players operation #s mg /= #20 mg
execute as @a[tag=mg_q_sw] run title @s actionbar [{"text":"SkyWars startet in ","color":"aqua"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true},{"text":" s","color":"aqua"}]
execute if score #sw_cd mg matches ..0 in minecraft:overworld if loaded 39968 100 -32 if loaded 40032 100 32 run function mg:sw/start
