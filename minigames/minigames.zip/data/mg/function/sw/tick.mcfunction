execute if score #sw mg matches 0 run return run function mg:sw/idle
execute if score #sw mg matches 1 run return run function mg:sw/countdown
execute if score #sw mg matches 2 run return run function mg:sw/cage
execute if score #sw mg matches 3 run return run function mg:sw/game
