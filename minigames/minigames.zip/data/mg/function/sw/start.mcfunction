function mg:sw/build
execute in minecraft:overworld run forceload remove 39960 -40 40040 40
tag @a[tag=mg_q_sw,tag=mg_hub,limit=8,sort=random] add mg_sw
tag @a[tag=mg_sw] remove mg_q_sw
tag @a[tag=mg_sw] remove mg_hub
execute as @a[tag=mg_sw] run function mg:q/leave_all
clear @a[tag=mg_sw]
effect clear @a[tag=mg_sw]
gamemode adventure @a[tag=mg_sw]
tag @a[tag=mg_sw] add mg_alive
scoreboard players set @a[tag=mg_sw] mg_deaths 0
scoreboard players set #k mg 0
execute as @a[tag=mg_sw,tag=!mg_placed,limit=1,sort=random] run function mg:sw/place {x:40025,z:0}
execute as @a[tag=mg_sw,tag=!mg_placed,limit=1,sort=random] run function mg:sw/place {x:40018,z:18}
execute as @a[tag=mg_sw,tag=!mg_placed,limit=1,sort=random] run function mg:sw/place {x:40000,z:25}
execute as @a[tag=mg_sw,tag=!mg_placed,limit=1,sort=random] run function mg:sw/place {x:39982,z:18}
execute as @a[tag=mg_sw,tag=!mg_placed,limit=1,sort=random] run function mg:sw/place {x:39975,z:0}
execute as @a[tag=mg_sw,tag=!mg_placed,limit=1,sort=random] run function mg:sw/place {x:39982,z:-18}
execute as @a[tag=mg_sw,tag=!mg_placed,limit=1,sort=random] run function mg:sw/place {x:40000,z:-25}
execute as @a[tag=mg_sw,tag=!mg_placed,limit=1,sort=random] run function mg:sw/place {x:40018,z:-18}
tag @a remove mg_placed
scoreboard players set #sw mg 2
scoreboard players set #sw_cd mg 100
title @a[tag=mg_sw] title {"text": "SKYWARS", "color": "aqua", "bold": true}
title @a[tag=mg_sw] subtitle {"text": "Truhen plündern – der Letzte gewinnt", "color": "white"}
