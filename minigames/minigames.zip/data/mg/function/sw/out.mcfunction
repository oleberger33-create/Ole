tag @s remove mg_alive
execute store result score #alive mg if entity @a[tag=mg_sw,tag=mg_alive]
scoreboard players set @s mg_deaths 0
gamemode spectator @s
tellraw @a[tag=mg_sw] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist raus! ", "color": "red"}, {"text": "Noch ", "color": "gray"}, {"score": {"name": "#alive", "objective": "mg"}, "color": "white"}, {"text": " übrig.", "color": "gray"}]
execute in minecraft:overworld run tp @s 40000 115 0
