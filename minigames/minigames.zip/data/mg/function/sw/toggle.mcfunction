execute if entity @s[tag=mg_q_sw] run return run function mg:sw/leave
function mg:q/leave_all
tag @s add mg_q_sw
tellraw @a[tag=mg_hub] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " wartet auf ", "color": "gray"}, {"text": "SkyWars", "color": "aqua", "bold": true}, {"text": " – ", "color": "gray"}, {"text": "[Mitspielen]", "color": "green", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 52"}}]
