execute store result score #n mg if entity @a[tag=mg_q_sw,tag=mg_hub]
execute if score #n mg matches 2.. run scoreboard players set #sw_cd mg 300
execute if score #n mg matches 2.. run execute in minecraft:overworld run forceload add 39960 -40 40040 40
execute if score #n mg matches 2.. run tellraw @a[tag=mg_q_sw] [{"text": "» ", "color": "gold", "bold": true}, {"text": "SkyWars startet in 15 Sekunden!", "color": "aqua"}]
execute if score #n mg matches 2.. run scoreboard players set #sw mg 1
