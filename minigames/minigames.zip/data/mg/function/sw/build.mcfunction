kill @e[type=minecraft:text_display,tag=mg_swh]
execute in minecraft:overworld run fill 39969 94 -31 39974 116 31 minecraft:air
execute in minecraft:overworld run fill 39975 94 -31 39980 116 31 minecraft:air
execute in minecraft:overworld run fill 39981 94 -31 39986 116 31 minecraft:air
execute in minecraft:overworld run fill 39987 94 -31 39992 116 31 minecraft:air
execute in minecraft:overworld run fill 39993 94 -31 39998 116 31 minecraft:air
execute in minecraft:overworld run fill 39999 94 -31 40004 116 31 minecraft:air
execute in minecraft:overworld run fill 40005 94 -31 40010 116 31 minecraft:air
execute in minecraft:overworld run fill 40011 94 -31 40016 116 31 minecraft:air
execute in minecraft:overworld run fill 40017 94 -31 40022 116 31 minecraft:air
execute in minecraft:overworld run fill 40023 94 -31 40028 116 31 minecraft:air
execute in minecraft:overworld run fill 40029 94 -31 40031 116 31 minecraft:air
execute in minecraft:overworld run fill 40024 100 -3 40026 100 -3 minecraft:grass_block
execute in minecraft:overworld run fill 40023 100 -2 40027 100 -2 minecraft:grass_block
execute in minecraft:overworld run fill 40022 100 -1 40028 100 -1 minecraft:grass_block
execute in minecraft:overworld run fill 40022 100 0 40028 100 0 minecraft:grass_block
execute in minecraft:overworld run fill 40022 100 1 40028 100 1 minecraft:grass_block
execute in minecraft:overworld run fill 40023 100 2 40027 100 2 minecraft:grass_block
execute in minecraft:overworld run fill 40024 100 3 40026 100 3 minecraft:grass_block
execute in minecraft:overworld run fill 40024 99 -3 40026 99 -3 minecraft:dirt
execute in minecraft:overworld run fill 40023 99 -2 40027 99 -2 minecraft:dirt
execute in minecraft:overworld run fill 40022 99 -1 40028 99 -1 minecraft:dirt
execute in minecraft:overworld run fill 40022 99 0 40028 99 0 minecraft:dirt
execute in minecraft:overworld run fill 40022 99 1 40028 99 1 minecraft:dirt
execute in minecraft:overworld run fill 40023 99 2 40027 99 2 minecraft:dirt
execute in minecraft:overworld run fill 40024 99 3 40026 99 3 minecraft:dirt
execute in minecraft:overworld run fill 40024 98 -2 40026 98 -2 minecraft:stone
execute in minecraft:overworld run fill 40023 98 -1 40027 98 -1 minecraft:stone
execute in minecraft:overworld run fill 40023 98 0 40027 98 0 minecraft:stone
execute in minecraft:overworld run fill 40023 98 1 40027 98 1 minecraft:stone
execute in minecraft:overworld run fill 40024 98 2 40026 98 2 minecraft:stone
execute in minecraft:overworld run fill 40024 97 -1 40026 97 -1 minecraft:stone
execute in minecraft:overworld run fill 40024 97 0 40026 97 0 minecraft:stone
execute in minecraft:overworld run fill 40024 97 1 40026 97 1 minecraft:stone
execute in minecraft:overworld run setblock 40025 101 -2 minecraft:chest[facing=south]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run setblock 40025 101 2 minecraft:chest[facing=north]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run fill 40024 101 -1 40026 104 1 minecraft:glass hollow
execute in minecraft:overworld run fill 40025 101 0 40025 103 0 minecraft:air
execute in minecraft:overworld run setblock 40027 101 1 minecraft:oak_log
execute in minecraft:overworld run setblock 40027 102 1 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 40017 100 15 40019 100 15 minecraft:grass_block
execute in minecraft:overworld run fill 40016 100 16 40020 100 16 minecraft:grass_block
execute in minecraft:overworld run fill 40015 100 17 40021 100 17 minecraft:grass_block
execute in minecraft:overworld run fill 40015 100 18 40021 100 18 minecraft:grass_block
execute in minecraft:overworld run fill 40015 100 19 40021 100 19 minecraft:grass_block
execute in minecraft:overworld run fill 40016 100 20 40020 100 20 minecraft:grass_block
execute in minecraft:overworld run fill 40017 100 21 40019 100 21 minecraft:grass_block
execute in minecraft:overworld run fill 40017 99 15 40019 99 15 minecraft:dirt
execute in minecraft:overworld run fill 40016 99 16 40020 99 16 minecraft:dirt
execute in minecraft:overworld run fill 40015 99 17 40021 99 17 minecraft:dirt
execute in minecraft:overworld run fill 40015 99 18 40021 99 18 minecraft:dirt
execute in minecraft:overworld run fill 40015 99 19 40021 99 19 minecraft:dirt
execute in minecraft:overworld run fill 40016 99 20 40020 99 20 minecraft:dirt
execute in minecraft:overworld run fill 40017 99 21 40019 99 21 minecraft:dirt
execute in minecraft:overworld run fill 40017 98 16 40019 98 16 minecraft:stone
execute in minecraft:overworld run fill 40016 98 17 40020 98 17 minecraft:stone
execute in minecraft:overworld run fill 40016 98 18 40020 98 18 minecraft:stone
execute in minecraft:overworld run fill 40016 98 19 40020 98 19 minecraft:stone
execute in minecraft:overworld run fill 40017 98 20 40019 98 20 minecraft:stone
execute in minecraft:overworld run fill 40017 97 17 40019 97 17 minecraft:stone
execute in minecraft:overworld run fill 40017 97 18 40019 97 18 minecraft:stone
execute in minecraft:overworld run fill 40017 97 19 40019 97 19 minecraft:stone
execute in minecraft:overworld run setblock 40018 101 16 minecraft:chest[facing=south]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run setblock 40018 101 20 minecraft:chest[facing=north]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run fill 40017 101 17 40019 104 19 minecraft:glass hollow
execute in minecraft:overworld run fill 40018 101 18 40018 103 18 minecraft:air
execute in minecraft:overworld run setblock 40020 101 19 minecraft:oak_log
execute in minecraft:overworld run setblock 40020 102 19 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 39999 100 22 40001 100 22 minecraft:grass_block
execute in minecraft:overworld run fill 39998 100 23 40002 100 23 minecraft:grass_block
execute in minecraft:overworld run fill 39997 100 24 40003 100 24 minecraft:grass_block
execute in minecraft:overworld run fill 39997 100 25 40003 100 25 minecraft:grass_block
execute in minecraft:overworld run fill 39997 100 26 40003 100 26 minecraft:grass_block
execute in minecraft:overworld run fill 39998 100 27 40002 100 27 minecraft:grass_block
execute in minecraft:overworld run fill 39999 100 28 40001 100 28 minecraft:grass_block
execute in minecraft:overworld run fill 39999 99 22 40001 99 22 minecraft:dirt
execute in minecraft:overworld run fill 39998 99 23 40002 99 23 minecraft:dirt
execute in minecraft:overworld run fill 39997 99 24 40003 99 24 minecraft:dirt
execute in minecraft:overworld run fill 39997 99 25 40003 99 25 minecraft:dirt
execute in minecraft:overworld run fill 39997 99 26 40003 99 26 minecraft:dirt
execute in minecraft:overworld run fill 39998 99 27 40002 99 27 minecraft:dirt
execute in minecraft:overworld run fill 39999 99 28 40001 99 28 minecraft:dirt
execute in minecraft:overworld run fill 39999 98 23 40001 98 23 minecraft:stone
execute in minecraft:overworld run fill 39998 98 24 40002 98 24 minecraft:stone
execute in minecraft:overworld run fill 39998 98 25 40002 98 25 minecraft:stone
execute in minecraft:overworld run fill 39998 98 26 40002 98 26 minecraft:stone
execute in minecraft:overworld run fill 39999 98 27 40001 98 27 minecraft:stone
execute in minecraft:overworld run fill 39999 97 24 40001 97 24 minecraft:stone
execute in minecraft:overworld run fill 39999 97 25 40001 97 25 minecraft:stone
execute in minecraft:overworld run fill 39999 97 26 40001 97 26 minecraft:stone
execute in minecraft:overworld run setblock 40000 101 23 minecraft:chest[facing=south]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run setblock 40000 101 27 minecraft:chest[facing=north]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run fill 39999 101 24 40001 104 26 minecraft:glass hollow
execute in minecraft:overworld run fill 40000 101 25 40000 103 25 minecraft:air
execute in minecraft:overworld run setblock 40002 101 26 minecraft:oak_log
execute in minecraft:overworld run setblock 40002 102 26 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 39981 100 15 39983 100 15 minecraft:grass_block
execute in minecraft:overworld run fill 39980 100 16 39984 100 16 minecraft:grass_block
execute in minecraft:overworld run fill 39979 100 17 39985 100 17 minecraft:grass_block
execute in minecraft:overworld run fill 39979 100 18 39985 100 18 minecraft:grass_block
execute in minecraft:overworld run fill 39979 100 19 39985 100 19 minecraft:grass_block
execute in minecraft:overworld run fill 39980 100 20 39984 100 20 minecraft:grass_block
execute in minecraft:overworld run fill 39981 100 21 39983 100 21 minecraft:grass_block
execute in minecraft:overworld run fill 39981 99 15 39983 99 15 minecraft:dirt
execute in minecraft:overworld run fill 39980 99 16 39984 99 16 minecraft:dirt
execute in minecraft:overworld run fill 39979 99 17 39985 99 17 minecraft:dirt
execute in minecraft:overworld run fill 39979 99 18 39985 99 18 minecraft:dirt
execute in minecraft:overworld run fill 39979 99 19 39985 99 19 minecraft:dirt
execute in minecraft:overworld run fill 39980 99 20 39984 99 20 minecraft:dirt
execute in minecraft:overworld run fill 39981 99 21 39983 99 21 minecraft:dirt
execute in minecraft:overworld run fill 39981 98 16 39983 98 16 minecraft:stone
execute in minecraft:overworld run fill 39980 98 17 39984 98 17 minecraft:stone
execute in minecraft:overworld run fill 39980 98 18 39984 98 18 minecraft:stone
execute in minecraft:overworld run fill 39980 98 19 39984 98 19 minecraft:stone
execute in minecraft:overworld run fill 39981 98 20 39983 98 20 minecraft:stone
execute in minecraft:overworld run fill 39981 97 17 39983 97 17 minecraft:stone
execute in minecraft:overworld run fill 39981 97 18 39983 97 18 minecraft:stone
execute in minecraft:overworld run fill 39981 97 19 39983 97 19 minecraft:stone
execute in minecraft:overworld run setblock 39982 101 16 minecraft:chest[facing=south]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run setblock 39982 101 20 minecraft:chest[facing=north]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run fill 39981 101 17 39983 104 19 minecraft:glass hollow
execute in minecraft:overworld run fill 39982 101 18 39982 103 18 minecraft:air
execute in minecraft:overworld run setblock 39984 101 19 minecraft:oak_log
execute in minecraft:overworld run setblock 39984 102 19 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 39974 100 -3 39976 100 -3 minecraft:grass_block
execute in minecraft:overworld run fill 39973 100 -2 39977 100 -2 minecraft:grass_block
execute in minecraft:overworld run fill 39972 100 -1 39978 100 -1 minecraft:grass_block
execute in minecraft:overworld run fill 39972 100 0 39978 100 0 minecraft:grass_block
execute in minecraft:overworld run fill 39972 100 1 39978 100 1 minecraft:grass_block
execute in minecraft:overworld run fill 39973 100 2 39977 100 2 minecraft:grass_block
execute in minecraft:overworld run fill 39974 100 3 39976 100 3 minecraft:grass_block
execute in minecraft:overworld run fill 39974 99 -3 39976 99 -3 minecraft:dirt
execute in minecraft:overworld run fill 39973 99 -2 39977 99 -2 minecraft:dirt
execute in minecraft:overworld run fill 39972 99 -1 39978 99 -1 minecraft:dirt
execute in minecraft:overworld run fill 39972 99 0 39978 99 0 minecraft:dirt
execute in minecraft:overworld run fill 39972 99 1 39978 99 1 minecraft:dirt
execute in minecraft:overworld run fill 39973 99 2 39977 99 2 minecraft:dirt
execute in minecraft:overworld run fill 39974 99 3 39976 99 3 minecraft:dirt
execute in minecraft:overworld run fill 39974 98 -2 39976 98 -2 minecraft:stone
execute in minecraft:overworld run fill 39973 98 -1 39977 98 -1 minecraft:stone
execute in minecraft:overworld run fill 39973 98 0 39977 98 0 minecraft:stone
execute in minecraft:overworld run fill 39973 98 1 39977 98 1 minecraft:stone
execute in minecraft:overworld run fill 39974 98 2 39976 98 2 minecraft:stone
execute in minecraft:overworld run fill 39974 97 -1 39976 97 -1 minecraft:stone
execute in minecraft:overworld run fill 39974 97 0 39976 97 0 minecraft:stone
execute in minecraft:overworld run fill 39974 97 1 39976 97 1 minecraft:stone
execute in minecraft:overworld run setblock 39975 101 -2 minecraft:chest[facing=south]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run setblock 39975 101 2 minecraft:chest[facing=north]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run fill 39974 101 -1 39976 104 1 minecraft:glass hollow
execute in minecraft:overworld run fill 39975 101 0 39975 103 0 minecraft:air
execute in minecraft:overworld run setblock 39977 101 1 minecraft:oak_log
execute in minecraft:overworld run setblock 39977 102 1 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 39981 100 -21 39983 100 -21 minecraft:grass_block
execute in minecraft:overworld run fill 39980 100 -20 39984 100 -20 minecraft:grass_block
execute in minecraft:overworld run fill 39979 100 -19 39985 100 -19 minecraft:grass_block
execute in minecraft:overworld run fill 39979 100 -18 39985 100 -18 minecraft:grass_block
execute in minecraft:overworld run fill 39979 100 -17 39985 100 -17 minecraft:grass_block
execute in minecraft:overworld run fill 39980 100 -16 39984 100 -16 minecraft:grass_block
execute in minecraft:overworld run fill 39981 100 -15 39983 100 -15 minecraft:grass_block
execute in minecraft:overworld run fill 39981 99 -21 39983 99 -21 minecraft:dirt
execute in minecraft:overworld run fill 39980 99 -20 39984 99 -20 minecraft:dirt
execute in minecraft:overworld run fill 39979 99 -19 39985 99 -19 minecraft:dirt
execute in minecraft:overworld run fill 39979 99 -18 39985 99 -18 minecraft:dirt
execute in minecraft:overworld run fill 39979 99 -17 39985 99 -17 minecraft:dirt
execute in minecraft:overworld run fill 39980 99 -16 39984 99 -16 minecraft:dirt
execute in minecraft:overworld run fill 39981 99 -15 39983 99 -15 minecraft:dirt
execute in minecraft:overworld run fill 39981 98 -20 39983 98 -20 minecraft:stone
execute in minecraft:overworld run fill 39980 98 -19 39984 98 -19 minecraft:stone
execute in minecraft:overworld run fill 39980 98 -18 39984 98 -18 minecraft:stone
execute in minecraft:overworld run fill 39980 98 -17 39984 98 -17 minecraft:stone
execute in minecraft:overworld run fill 39981 98 -16 39983 98 -16 minecraft:stone
execute in minecraft:overworld run fill 39981 97 -19 39983 97 -19 minecraft:stone
execute in minecraft:overworld run fill 39981 97 -18 39983 97 -18 minecraft:stone
execute in minecraft:overworld run fill 39981 97 -17 39983 97 -17 minecraft:stone
execute in minecraft:overworld run setblock 39982 101 -20 minecraft:chest[facing=south]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run setblock 39982 101 -16 minecraft:chest[facing=north]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run fill 39981 101 -19 39983 104 -17 minecraft:glass hollow
execute in minecraft:overworld run fill 39982 101 -18 39982 103 -18 minecraft:air
execute in minecraft:overworld run setblock 39984 101 -17 minecraft:oak_log
execute in minecraft:overworld run setblock 39984 102 -17 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 39999 100 -28 40001 100 -28 minecraft:grass_block
execute in minecraft:overworld run fill 39998 100 -27 40002 100 -27 minecraft:grass_block
execute in minecraft:overworld run fill 39997 100 -26 40003 100 -26 minecraft:grass_block
execute in minecraft:overworld run fill 39997 100 -25 40003 100 -25 minecraft:grass_block
execute in minecraft:overworld run fill 39997 100 -24 40003 100 -24 minecraft:grass_block
execute in minecraft:overworld run fill 39998 100 -23 40002 100 -23 minecraft:grass_block
execute in minecraft:overworld run fill 39999 100 -22 40001 100 -22 minecraft:grass_block
execute in minecraft:overworld run fill 39999 99 -28 40001 99 -28 minecraft:dirt
execute in minecraft:overworld run fill 39998 99 -27 40002 99 -27 minecraft:dirt
execute in minecraft:overworld run fill 39997 99 -26 40003 99 -26 minecraft:dirt
execute in minecraft:overworld run fill 39997 99 -25 40003 99 -25 minecraft:dirt
execute in minecraft:overworld run fill 39997 99 -24 40003 99 -24 minecraft:dirt
execute in minecraft:overworld run fill 39998 99 -23 40002 99 -23 minecraft:dirt
execute in minecraft:overworld run fill 39999 99 -22 40001 99 -22 minecraft:dirt
execute in minecraft:overworld run fill 39999 98 -27 40001 98 -27 minecraft:stone
execute in minecraft:overworld run fill 39998 98 -26 40002 98 -26 minecraft:stone
execute in minecraft:overworld run fill 39998 98 -25 40002 98 -25 minecraft:stone
execute in minecraft:overworld run fill 39998 98 -24 40002 98 -24 minecraft:stone
execute in minecraft:overworld run fill 39999 98 -23 40001 98 -23 minecraft:stone
execute in minecraft:overworld run fill 39999 97 -26 40001 97 -26 minecraft:stone
execute in minecraft:overworld run fill 39999 97 -25 40001 97 -25 minecraft:stone
execute in minecraft:overworld run fill 39999 97 -24 40001 97 -24 minecraft:stone
execute in minecraft:overworld run setblock 40000 101 -27 minecraft:chest[facing=south]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run setblock 40000 101 -23 minecraft:chest[facing=north]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run fill 39999 101 -26 40001 104 -24 minecraft:glass hollow
execute in minecraft:overworld run fill 40000 101 -25 40000 103 -25 minecraft:air
execute in minecraft:overworld run setblock 40002 101 -24 minecraft:oak_log
execute in minecraft:overworld run setblock 40002 102 -24 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 40017 100 -21 40019 100 -21 minecraft:grass_block
execute in minecraft:overworld run fill 40016 100 -20 40020 100 -20 minecraft:grass_block
execute in minecraft:overworld run fill 40015 100 -19 40021 100 -19 minecraft:grass_block
execute in minecraft:overworld run fill 40015 100 -18 40021 100 -18 minecraft:grass_block
execute in minecraft:overworld run fill 40015 100 -17 40021 100 -17 minecraft:grass_block
execute in minecraft:overworld run fill 40016 100 -16 40020 100 -16 minecraft:grass_block
execute in minecraft:overworld run fill 40017 100 -15 40019 100 -15 minecraft:grass_block
execute in minecraft:overworld run fill 40017 99 -21 40019 99 -21 minecraft:dirt
execute in minecraft:overworld run fill 40016 99 -20 40020 99 -20 minecraft:dirt
execute in minecraft:overworld run fill 40015 99 -19 40021 99 -19 minecraft:dirt
execute in minecraft:overworld run fill 40015 99 -18 40021 99 -18 minecraft:dirt
execute in minecraft:overworld run fill 40015 99 -17 40021 99 -17 minecraft:dirt
execute in minecraft:overworld run fill 40016 99 -16 40020 99 -16 minecraft:dirt
execute in minecraft:overworld run fill 40017 99 -15 40019 99 -15 minecraft:dirt
execute in minecraft:overworld run fill 40017 98 -20 40019 98 -20 minecraft:stone
execute in minecraft:overworld run fill 40016 98 -19 40020 98 -19 minecraft:stone
execute in minecraft:overworld run fill 40016 98 -18 40020 98 -18 minecraft:stone
execute in minecraft:overworld run fill 40016 98 -17 40020 98 -17 minecraft:stone
execute in minecraft:overworld run fill 40017 98 -16 40019 98 -16 minecraft:stone
execute in minecraft:overworld run fill 40017 97 -19 40019 97 -19 minecraft:stone
execute in minecraft:overworld run fill 40017 97 -18 40019 97 -18 minecraft:stone
execute in minecraft:overworld run fill 40017 97 -17 40019 97 -17 minecraft:stone
execute in minecraft:overworld run setblock 40018 101 -20 minecraft:chest[facing=south]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run setblock 40018 101 -16 minecraft:chest[facing=north]{LootTable:"mg:sw_island"}
execute in minecraft:overworld run fill 40017 101 -19 40019 104 -17 minecraft:glass hollow
execute in minecraft:overworld run fill 40018 101 -18 40018 103 -18 minecraft:air
execute in minecraft:overworld run setblock 40020 101 -17 minecraft:oak_log
execute in minecraft:overworld run setblock 40020 102 -17 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 39998 100 -6 40002 100 -6 minecraft:smooth_stone
execute in minecraft:overworld run fill 39996 100 -5 40004 100 -5 minecraft:smooth_stone
execute in minecraft:overworld run fill 39995 100 -4 40005 100 -4 minecraft:smooth_stone
execute in minecraft:overworld run fill 39995 100 -3 40005 100 -3 minecraft:smooth_stone
execute in minecraft:overworld run fill 39994 100 -2 40006 100 -2 minecraft:smooth_stone
execute in minecraft:overworld run fill 39994 100 -1 40006 100 -1 minecraft:smooth_stone
execute in minecraft:overworld run fill 39994 100 0 40006 100 0 minecraft:smooth_stone
execute in minecraft:overworld run fill 39994 100 1 40006 100 1 minecraft:smooth_stone
execute in minecraft:overworld run fill 39994 100 2 40006 100 2 minecraft:smooth_stone
execute in minecraft:overworld run fill 39995 100 3 40005 100 3 minecraft:smooth_stone
execute in minecraft:overworld run fill 39995 100 4 40005 100 4 minecraft:smooth_stone
execute in minecraft:overworld run fill 39996 100 5 40004 100 5 minecraft:smooth_stone
execute in minecraft:overworld run fill 39998 100 6 40002 100 6 minecraft:smooth_stone
execute in minecraft:overworld run fill 39998 99 -6 40002 99 -6 minecraft:dirt
execute in minecraft:overworld run fill 39996 99 -5 40004 99 -5 minecraft:dirt
execute in minecraft:overworld run fill 39995 99 -4 40005 99 -4 minecraft:dirt
execute in minecraft:overworld run fill 39995 99 -3 40005 99 -3 minecraft:dirt
execute in minecraft:overworld run fill 39994 99 -2 40006 99 -2 minecraft:dirt
execute in minecraft:overworld run fill 39994 99 -1 40006 99 -1 minecraft:dirt
execute in minecraft:overworld run fill 39994 99 0 40006 99 0 minecraft:dirt
execute in minecraft:overworld run fill 39994 99 1 40006 99 1 minecraft:dirt
execute in minecraft:overworld run fill 39994 99 2 40006 99 2 minecraft:dirt
execute in minecraft:overworld run fill 39995 99 3 40005 99 3 minecraft:dirt
execute in minecraft:overworld run fill 39995 99 4 40005 99 4 minecraft:dirt
execute in minecraft:overworld run fill 39996 99 5 40004 99 5 minecraft:dirt
execute in minecraft:overworld run fill 39998 99 6 40002 99 6 minecraft:dirt
execute in minecraft:overworld run fill 39998 98 -5 40002 98 -5 minecraft:stone
execute in minecraft:overworld run fill 39997 98 -4 40003 98 -4 minecraft:stone
execute in minecraft:overworld run fill 39996 98 -3 40004 98 -3 minecraft:stone
execute in minecraft:overworld run fill 39995 98 -2 40005 98 -2 minecraft:stone
execute in minecraft:overworld run fill 39995 98 -1 40005 98 -1 minecraft:stone
execute in minecraft:overworld run fill 39995 98 0 40005 98 0 minecraft:stone
execute in minecraft:overworld run fill 39995 98 1 40005 98 1 minecraft:stone
execute in minecraft:overworld run fill 39995 98 2 40005 98 2 minecraft:stone
execute in minecraft:overworld run fill 39996 98 3 40004 98 3 minecraft:stone
execute in minecraft:overworld run fill 39997 98 4 40003 98 4 minecraft:stone
execute in minecraft:overworld run fill 39998 98 5 40002 98 5 minecraft:stone
execute in minecraft:overworld run fill 39998 97 -4 40002 97 -4 minecraft:stone
execute in minecraft:overworld run fill 39997 97 -3 40003 97 -3 minecraft:stone
execute in minecraft:overworld run fill 39996 97 -2 40004 97 -2 minecraft:stone
execute in minecraft:overworld run fill 39996 97 -1 40004 97 -1 minecraft:stone
execute in minecraft:overworld run fill 39996 97 0 40004 97 0 minecraft:stone
execute in minecraft:overworld run fill 39996 97 1 40004 97 1 minecraft:stone
execute in minecraft:overworld run fill 39996 97 2 40004 97 2 minecraft:stone
execute in minecraft:overworld run fill 39997 97 3 40003 97 3 minecraft:stone
execute in minecraft:overworld run fill 39998 97 4 40002 97 4 minecraft:stone
execute in minecraft:overworld run setblock 40002 101 0 minecraft:chest[facing=west]{LootTable:"mg:sw_center"}
execute in minecraft:overworld run setblock 39998 101 0 minecraft:chest[facing=east]{LootTable:"mg:sw_center"}
execute in minecraft:overworld run setblock 40000 101 2 minecraft:chest[facing=north]{LootTable:"mg:sw_center"}
execute in minecraft:overworld run setblock 40000 101 -2 minecraft:chest[facing=south]{LootTable:"mg:sw_center"}
execute in minecraft:overworld run setblock 40000 101 0 minecraft:enchanting_table
execute in minecraft:overworld run summon minecraft:text_display 40000 104 0 {Tags:["mg_holo","mg_swh"],billboard:"center",background:0,shadow:true,text:{"text": "SKYWARS", "color": "aqua", "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[3.0f,3.0f,3.0f]}}
