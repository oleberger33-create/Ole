execute as @a[tag=mg_sw,tag=mg_al_sw] at @s if entity @s[y=-64,dy=144] run kill @s
scoreboard players add #sw_t mg 1
execute if score #sw_t mg matches 9600 run function mg:sw/sudden
execute if score #sw_t mg matches 14400.. run return run function mg:sw/end
execute store result score #surv mg if entity @a[tag=mg_al_sw,scores={mg_deaths=0}]
execute if score #surv mg matches 0 if entity @a[tag=mg_al_sw] run return run function mg:sw/end
execute as @a[tag=mg_sw,tag=mg_al_sw,scores={mg_deaths=1..}] run function mg:sw/out
execute store result score #alive mg if entity @a[tag=mg_sw,tag=mg_al_sw]
execute if score #alive mg matches ..1 run function mg:sw/end
