execute as @a[tag=mg_sw,tag=mg_alive] at @s if entity @s[y=-64,dy=144] run kill @s
execute as @a[tag=mg_sw,tag=mg_alive,scores={mg_deaths=1..}] run function mg:sw/out
execute store result score #alive mg if entity @a[tag=mg_sw,tag=mg_alive]
execute if score #alive mg matches ..1 run function mg:sw/end
