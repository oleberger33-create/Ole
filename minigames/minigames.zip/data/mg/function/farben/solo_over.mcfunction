execute as @a[tag=mg_farben,tag=mg_farben_fell] run function mg:farben/solo_res
tag @a[tag=mg_farben] remove mg_farben_fell
bossbar set mg:farben name {"text": "Farbenparty – Solo-Runde vorbei", "color": "light_purple", "bold": true}
bossbar set mg:farben value 0
bossbar set mg:farben players @a[tag=mg_farben]
function mg:farben/end
