tag @a[tag=mg_farben,tag=mg_farben_fell] add mg_farben_rev
tag @a[tag=mg_farben_rev] add mg_al_farben
tag @a[tag=mg_farben_rev] remove mg_farben_fell
tellraw @a[tag=mg_farben] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Alle sind gefallen – diese Runde zählt nicht! Weiter geht's.", "color": "yellow"}]
