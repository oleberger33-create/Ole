execute as @a[tag=mg_al_farben] at @s if entity @s[y=-64,dy=163.95] run function mg:farben/fall
execute if score #farben_np mg matches ..1 unless entity @a[tag=mg_al_farben] run return run function mg:farben/solo_over
execute store result score #farben_n mg if entity @a[tag=mg_al_farben]
execute if score #farben_n mg matches 0 if entity @a[tag=mg_farben,tag=mg_farben_fell] run function mg:farben/revive
execute store result score #farben_n mg if entity @a[tag=mg_al_farben]
execute as @a[tag=mg_farben,tag=mg_farben_fell] run function mg:farben/elim
execute if score #farben_np mg matches 2.. if score #farben_n mg matches ..1 run return run function mg:farben/end
execute as @a[tag=mg_al_farben] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.4
function mg:farben/round
execute if entity @a[tag=mg_farben_rev] run function mg:farben/revive2
