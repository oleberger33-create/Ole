tag @s remove mg_q_farben
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Farbenparty-Warteschlange verlassen.", "color": "gray"}]
