execute in minecraft:overworld run kill @e[type=minecraft:text_display,tag=mg_farbenh]
execute in minecraft:overworld run fill 71976 78 -24 71981 114 24 minecraft:air
execute in minecraft:overworld run fill 71982 78 -24 71987 114 24 minecraft:air
execute in minecraft:overworld run fill 71988 78 -24 71993 114 24 minecraft:air
execute in minecraft:overworld run fill 71994 78 -24 71999 114 24 minecraft:air
execute in minecraft:overworld run fill 72000 78 -24 72005 114 24 minecraft:air
execute in minecraft:overworld run fill 72006 78 -24 72011 114 24 minecraft:air
execute in minecraft:overworld run fill 72012 78 -24 72017 114 24 minecraft:air
execute in minecraft:overworld run fill 72018 78 -24 72023 114 24 minecraft:air
execute in minecraft:overworld run fill 72024 78 -24 72024 114 24 minecraft:air
execute in minecraft:overworld run fill 71983 100 -17 72016 100 -17 minecraft:sea_lantern
execute in minecraft:overworld run fill 71983 100 16 72016 100 16 minecraft:sea_lantern
execute in minecraft:overworld run fill 71983 100 -17 71983 100 16 minecraft:sea_lantern
execute in minecraft:overworld run fill 72016 100 -17 72016 100 16 minecraft:sea_lantern
execute in minecraft:overworld run fill 71982 100 -18 72017 100 -18 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71982 100 17 72017 100 17 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71982 100 -18 71982 100 17 minecraft:smooth_quartz
execute in minecraft:overworld run fill 72017 100 -18 72017 100 17 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71980 100 -20 72019 100 -20 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71980 100 19 72019 100 19 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71980 100 -20 71980 100 19 minecraft:smooth_quartz
execute in minecraft:overworld run fill 72019 100 -20 72019 100 19 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71983 99 -17 72016 99 -17 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71983 99 16 72016 99 16 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71983 99 -17 71983 99 16 minecraft:smooth_quartz
execute in minecraft:overworld run fill 72016 99 -17 72016 99 16 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71982 99 -18 72017 99 -18 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71982 99 17 72017 99 17 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71982 99 -18 71982 99 17 minecraft:smooth_quartz
execute in minecraft:overworld run fill 72017 99 -18 72017 99 17 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71981 99 -19 72018 99 -19 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71981 99 18 72018 99 18 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71981 99 -19 71981 99 18 minecraft:smooth_quartz
execute in minecraft:overworld run fill 72018 99 -19 72018 99 18 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71980 99 -20 72019 99 -20 minecraft:quartz_bricks
execute in minecraft:overworld run fill 71980 99 19 72019 99 19 minecraft:quartz_bricks
execute in minecraft:overworld run fill 71980 99 -20 71980 99 19 minecraft:quartz_bricks
execute in minecraft:overworld run fill 72019 99 -20 72019 99 19 minecraft:quartz_bricks
execute in minecraft:overworld run fill 71981 98 -19 72018 98 -19 minecraft:sea_lantern
execute in minecraft:overworld run fill 71981 98 18 72018 98 18 minecraft:sea_lantern
execute in minecraft:overworld run fill 71981 98 -19 71981 98 18 minecraft:sea_lantern
execute in minecraft:overworld run fill 72018 98 -19 72018 98 18 minecraft:sea_lantern
execute in minecraft:overworld run fill 71980 98 -20 72019 98 -20 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71980 98 19 72019 98 19 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71980 98 -20 71980 98 19 minecraft:smooth_quartz
execute in minecraft:overworld run fill 72019 98 -20 72019 98 19 minecraft:smooth_quartz
execute in minecraft:overworld run fill 71980 97 -20 72019 97 -20 minecraft:smooth_quartz_slab
execute in minecraft:overworld run fill 71980 97 19 72019 97 19 minecraft:smooth_quartz_slab
execute in minecraft:overworld run fill 71980 97 -20 71980 97 19 minecraft:smooth_quartz_slab
execute in minecraft:overworld run fill 72019 97 -20 72019 97 19 minecraft:smooth_quartz_slab
execute in minecraft:overworld run fill 71983 101 -17 72016 103 -17 minecraft:barrier
execute in minecraft:overworld run fill 71983 101 16 72016 103 16 minecraft:barrier
execute in minecraft:overworld run fill 71983 101 -17 71983 103 16 minecraft:barrier
execute in minecraft:overworld run fill 72016 101 -17 72016 103 16 minecraft:barrier
execute in minecraft:overworld run fill 71982 101 -18 72017 101 -18 minecraft:white_stained_glass
execute in minecraft:overworld run fill 71982 101 17 72017 101 17 minecraft:white_stained_glass
execute in minecraft:overworld run fill 71982 101 -18 71982 101 17 minecraft:white_stained_glass
execute in minecraft:overworld run fill 72017 101 -18 72017 101 17 minecraft:white_stained_glass
execute in minecraft:overworld run fill 71981 100 -19 71982 100 -19 minecraft:red_concrete
execute in minecraft:overworld run fill 71983 100 -19 71984 100 -19 minecraft:orange_concrete
execute in minecraft:overworld run fill 71985 100 -19 71986 100 -19 minecraft:yellow_concrete
execute in minecraft:overworld run fill 71987 100 -19 71988 100 -19 minecraft:lime_concrete
execute in minecraft:overworld run fill 71989 100 -19 71990 100 -19 minecraft:green_concrete
execute in minecraft:overworld run fill 71991 100 -19 71992 100 -19 minecraft:cyan_concrete
execute in minecraft:overworld run fill 71993 100 -19 71994 100 -19 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 71995 100 -19 71996 100 -19 minecraft:blue_concrete
execute in minecraft:overworld run fill 71997 100 -19 71998 100 -19 minecraft:purple_concrete
execute in minecraft:overworld run fill 71999 100 -19 72000 100 -19 minecraft:magenta_concrete
execute in minecraft:overworld run fill 72001 100 -19 72002 100 -19 minecraft:pink_concrete
execute in minecraft:overworld run fill 72003 100 -19 72004 100 -19 minecraft:red_concrete
execute in minecraft:overworld run fill 72005 100 -19 72006 100 -19 minecraft:orange_concrete
execute in minecraft:overworld run fill 72007 100 -19 72008 100 -19 minecraft:yellow_concrete
execute in minecraft:overworld run fill 72009 100 -19 72010 100 -19 minecraft:lime_concrete
execute in minecraft:overworld run fill 72011 100 -19 72012 100 -19 minecraft:green_concrete
execute in minecraft:overworld run fill 72013 100 -19 72014 100 -19 minecraft:cyan_concrete
execute in minecraft:overworld run fill 72015 100 -19 72016 100 -19 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 72017 100 -19 72018 100 -19 minecraft:blue_concrete
execute in minecraft:overworld run fill 72018 100 -18 72018 100 -17 minecraft:purple_concrete
execute in minecraft:overworld run fill 72018 100 -16 72018 100 -15 minecraft:magenta_concrete
execute in minecraft:overworld run fill 72018 100 -14 72018 100 -13 minecraft:pink_concrete
execute in minecraft:overworld run fill 72018 100 -12 72018 100 -11 minecraft:red_concrete
execute in minecraft:overworld run fill 72018 100 -10 72018 100 -9 minecraft:orange_concrete
execute in minecraft:overworld run fill 72018 100 -8 72018 100 -7 minecraft:yellow_concrete
execute in minecraft:overworld run fill 72018 100 -6 72018 100 -5 minecraft:lime_concrete
execute in minecraft:overworld run fill 72018 100 -4 72018 100 -3 minecraft:green_concrete
execute in minecraft:overworld run fill 72018 100 -2 72018 100 -1 minecraft:cyan_concrete
execute in minecraft:overworld run fill 72018 100 0 72018 100 1 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 72018 100 2 72018 100 3 minecraft:blue_concrete
execute in minecraft:overworld run fill 72018 100 4 72018 100 5 minecraft:purple_concrete
execute in minecraft:overworld run fill 72018 100 6 72018 100 7 minecraft:magenta_concrete
execute in minecraft:overworld run fill 72018 100 8 72018 100 9 minecraft:pink_concrete
execute in minecraft:overworld run fill 72018 100 10 72018 100 11 minecraft:red_concrete
execute in minecraft:overworld run fill 72018 100 12 72018 100 13 minecraft:orange_concrete
execute in minecraft:overworld run fill 72018 100 14 72018 100 15 minecraft:yellow_concrete
execute in minecraft:overworld run fill 72018 100 16 72018 100 17 minecraft:lime_concrete
execute in minecraft:overworld run fill 72018 100 18 72017 100 18 minecraft:green_concrete
execute in minecraft:overworld run fill 72016 100 18 72015 100 18 minecraft:cyan_concrete
execute in minecraft:overworld run fill 72014 100 18 72013 100 18 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 72012 100 18 72011 100 18 minecraft:blue_concrete
execute in minecraft:overworld run fill 72010 100 18 72009 100 18 minecraft:purple_concrete
execute in minecraft:overworld run fill 72008 100 18 72007 100 18 minecraft:magenta_concrete
execute in minecraft:overworld run fill 72006 100 18 72005 100 18 minecraft:pink_concrete
execute in minecraft:overworld run fill 72004 100 18 72003 100 18 minecraft:red_concrete
execute in minecraft:overworld run fill 72002 100 18 72001 100 18 minecraft:orange_concrete
execute in minecraft:overworld run fill 72000 100 18 71999 100 18 minecraft:yellow_concrete
execute in minecraft:overworld run fill 71998 100 18 71997 100 18 minecraft:lime_concrete
execute in minecraft:overworld run fill 71996 100 18 71995 100 18 minecraft:green_concrete
execute in minecraft:overworld run fill 71994 100 18 71993 100 18 minecraft:cyan_concrete
execute in minecraft:overworld run fill 71992 100 18 71991 100 18 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 71990 100 18 71989 100 18 minecraft:blue_concrete
execute in minecraft:overworld run fill 71988 100 18 71987 100 18 minecraft:purple_concrete
execute in minecraft:overworld run fill 71986 100 18 71985 100 18 minecraft:magenta_concrete
execute in minecraft:overworld run fill 71984 100 18 71983 100 18 minecraft:pink_concrete
execute in minecraft:overworld run fill 71982 100 18 71981 100 18 minecraft:red_concrete
execute in minecraft:overworld run fill 71981 100 17 71981 100 16 minecraft:orange_concrete
execute in minecraft:overworld run fill 71981 100 15 71981 100 14 minecraft:yellow_concrete
execute in minecraft:overworld run fill 71981 100 13 71981 100 12 minecraft:lime_concrete
execute in minecraft:overworld run fill 71981 100 11 71981 100 10 minecraft:green_concrete
execute in minecraft:overworld run fill 71981 100 9 71981 100 8 minecraft:cyan_concrete
execute in minecraft:overworld run fill 71981 100 7 71981 100 6 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 71981 100 5 71981 100 4 minecraft:blue_concrete
execute in minecraft:overworld run fill 71981 100 3 71981 100 2 minecraft:purple_concrete
execute in minecraft:overworld run fill 71981 100 1 71981 100 0 minecraft:magenta_concrete
execute in minecraft:overworld run fill 71981 100 -1 71981 100 -2 minecraft:pink_concrete
execute in minecraft:overworld run fill 71981 100 -3 71981 100 -4 minecraft:red_concrete
execute in minecraft:overworld run fill 71981 100 -5 71981 100 -6 minecraft:orange_concrete
execute in minecraft:overworld run fill 71981 100 -7 71981 100 -8 minecraft:yellow_concrete
execute in minecraft:overworld run fill 71981 100 -9 71981 100 -10 minecraft:lime_concrete
execute in minecraft:overworld run fill 71981 100 -11 71981 100 -12 minecraft:green_concrete
execute in minecraft:overworld run fill 71981 100 -13 71981 100 -14 minecraft:cyan_concrete
execute in minecraft:overworld run fill 71981 100 -15 71981 100 -16 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 71981 100 -17 71981 100 -18 minecraft:blue_concrete
execute in minecraft:overworld run fill 71980 92 -20 71980 106 -20 minecraft:quartz_pillar
execute in minecraft:overworld run setblock 71980 91 -20 minecraft:sea_lantern
execute in minecraft:overworld run setblock 71980 90 -20 minecraft:end_rod[facing=down]
execute in minecraft:overworld run setblock 71980 107 -20 minecraft:sea_lantern
execute in minecraft:overworld run setblock 71980 108 -20 minecraft:end_rod
execute in minecraft:overworld run fill 71979 106 -21 71981 106 -19 minecraft:magenta_stained_glass replace minecraft:air
execute in minecraft:overworld run fill 71979 101 -21 71981 102 -19 minecraft:note_block replace minecraft:air
execute in minecraft:overworld run fill 71979 103 -21 71981 103 -19 minecraft:jukebox replace minecraft:air
execute in minecraft:overworld run fill 72019 92 -20 72019 106 -20 minecraft:quartz_pillar
execute in minecraft:overworld run setblock 72019 91 -20 minecraft:sea_lantern
execute in minecraft:overworld run setblock 72019 90 -20 minecraft:end_rod[facing=down]
execute in minecraft:overworld run setblock 72019 107 -20 minecraft:sea_lantern
execute in minecraft:overworld run setblock 72019 108 -20 minecraft:end_rod
execute in minecraft:overworld run fill 72018 106 -21 72020 106 -19 minecraft:magenta_stained_glass replace minecraft:air
execute in minecraft:overworld run fill 72018 101 -21 72020 102 -19 minecraft:note_block replace minecraft:air
execute in minecraft:overworld run fill 72018 103 -21 72020 103 -19 minecraft:jukebox replace minecraft:air
execute in minecraft:overworld run fill 71980 92 19 71980 106 19 minecraft:quartz_pillar
execute in minecraft:overworld run setblock 71980 91 19 minecraft:sea_lantern
execute in minecraft:overworld run setblock 71980 90 19 minecraft:end_rod[facing=down]
execute in minecraft:overworld run setblock 71980 107 19 minecraft:sea_lantern
execute in minecraft:overworld run setblock 71980 108 19 minecraft:end_rod
execute in minecraft:overworld run fill 71979 106 18 71981 106 20 minecraft:magenta_stained_glass replace minecraft:air
execute in minecraft:overworld run fill 71979 101 18 71981 102 20 minecraft:note_block replace minecraft:air
execute in minecraft:overworld run fill 71979 103 18 71981 103 20 minecraft:jukebox replace minecraft:air
execute in minecraft:overworld run fill 72019 92 19 72019 106 19 minecraft:quartz_pillar
execute in minecraft:overworld run setblock 72019 91 19 minecraft:sea_lantern
execute in minecraft:overworld run setblock 72019 90 19 minecraft:end_rod[facing=down]
execute in minecraft:overworld run setblock 72019 107 19 minecraft:sea_lantern
execute in minecraft:overworld run setblock 72019 108 19 minecraft:end_rod
execute in minecraft:overworld run fill 72018 106 18 72020 106 20 minecraft:magenta_stained_glass replace minecraft:air
execute in minecraft:overworld run fill 72018 101 18 72020 102 20 minecraft:note_block replace minecraft:air
execute in minecraft:overworld run fill 72018 103 18 72020 103 20 minecraft:jukebox replace minecraft:air
execute in minecraft:overworld run fill 71994 101 -20 72005 101 -20 minecraft:end_rod
execute in minecraft:overworld run fill 71994 101 19 72005 101 19 minecraft:end_rod
execute in minecraft:overworld run fill 71980 101 -6 71980 101 5 minecraft:end_rod
execute in minecraft:overworld run fill 72019 101 -6 72019 101 5 minecraft:end_rod
execute in minecraft:overworld run fill 71980 80 -20 72019 80 19 minecraft:black_concrete
execute in minecraft:overworld run fill 71984 80 -20 71984 80 19 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 71990 80 -20 71990 80 19 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 71996 80 -20 71996 80 19 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 72002 80 -20 72002 80 19 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 72008 80 -20 72008 80 19 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 72014 80 -20 72014 80 19 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 71980 80 -16 72019 80 -16 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 71980 80 -10 72019 80 -10 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 71980 80 -4 72019 80 -4 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 71980 80 2 72019 80 2 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 71980 80 8 72019 80 8 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 71980 80 14 72019 80 14 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 71980 79 -20 72019 79 19 minecraft:sea_lantern
execute in minecraft:overworld run summon minecraft:text_display 72000.5 110 -20.5 {Tags:["mg_holo","mg_farbenh"],billboard:"center",background:0,shadow:true,text:[{"text": ""}, {"text": "F", "color": "#F04438", "bold": true}, {"text": "A", "color": "#F9801D", "bold": true}, {"text": "R", "color": "#FED83D", "bold": true}, {"text": "B", "color": "#8BD42A", "bold": true}, {"text": "E", "color": "#6E9420", "bold": true}, {"text": "N", "color": "#1FB5B5", "bold": true}, {"text": "P", "color": "#5CC8EE", "bold": true}, {"text": "A", "color": "#5361E8", "bold": true}, {"text": "R", "color": "#A45ADB", "bold": true}, {"text": "T", "color": "#D35BC9", "bold": true}, {"text": "Y", "color": "#F7A1BC", "bold": true}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4.0f,4.0f,4.0f]}}
execute in minecraft:overworld run summon minecraft:text_display 72000.5 108.6 -20.5 {Tags:["mg_holo","mg_farbenh"],billboard:"center",background:0,shadow:true,text:{"text": "Musik stoppt → Farbe merken → drauf stellen!", "color": "white"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
function mg:farben/pal/0
scoreboard players set #farben_p mg 8
function mg:farben/p/8 with storage mg:farben pal
