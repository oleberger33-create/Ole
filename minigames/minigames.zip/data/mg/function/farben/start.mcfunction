function mg:farben/build
tag @a[tag=mg_q_farben,tag=mg_hub,limit=16,sort=random] add mg_farben
tag @a[tag=mg_farben] remove mg_q_farben
execute as @a[tag=mg_farben] run function mg:q/leave_all
tag @a[tag=mg_farben] remove mg_hub
clear @a[tag=mg_farben]
effect clear @a[tag=mg_farben]
gamemode adventure @a[tag=mg_farben]
tag @a[tag=mg_farben] add mg_al_farben
scoreboard players set @a[tag=mg_farben] mg_deaths 0
execute as @a[tag=mg_farben] run execute in minecraft:overworld run spawnpoint @s 72000 114 0
scoreboard players set #farben_t mg 0
execute in minecraft:overworld run spreadplayers 72000 0 3 12 false @a[tag=mg_farben]
effect give @a[tag=mg_farben] minecraft:saturation infinite 0 true
effect give @a[tag=mg_farben] minecraft:resistance infinite 4 true
scoreboard players set #farben_r mg 0
scoreboard players set #farben_ph mg 3
scoreboard players set #farben_pt mg 70
scoreboard players set #farben_7 mg 7
tag @a[tag=mg_farben] remove mg_farben_fell
tag @a[tag=mg_farben] remove mg_farben_rev
bossbar set mg:farben name {"text": "Farbenparty – gleich geht es los!", "color": "light_purple", "bold": true}
bossbar set mg:farben color pink
bossbar set mg:farben max 1
bossbar set mg:farben value 1
bossbar set mg:farben players @a[tag=mg_farben]
bossbar set mg:farben visible true
execute in minecraft:overworld run forceload remove 71976 -24 72024 24
scoreboard players set #farben mg 2
title @a[tag=mg_farben] times 5 50 10
title @a[tag=mg_farben] title {"text": "FARBENPARTY", "color": "light_purple", "bold": true}
title @a[tag=mg_farben] subtitle {"text": "Merk dir die Farbe!", "color": "white"}
tellraw @a[tag=mg_farben] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Wenn die Musik stoppt, wird eine Farbe angesagt. Stell dich schnell auf ein Feld dieser Farbe – alle anderen Felder verschwinden! Jede Runde wird die Zeit kürzer. Wer zuletzt noch steht, gewinnt.", "color": "gray"}]
tellraw @a[tag=mg_farben] [{"text": "  "}, {"text": "[Spiel verlassen]", "color": "red", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 99"}}]
