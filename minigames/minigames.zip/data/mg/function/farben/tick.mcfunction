execute if score #farben mg matches 2 run function mg:farben/game
