title @a[tag=mg_farben] times 2 40 6
$title @a[tag=mg_farben] subtitle {"text":"Stell dich auf $(n)!","color":"white"}
$title @a[tag=mg_farben] title {"text":"$(u)","color":"$(h)","bold":true}
$item replace entity @a[tag=mg_al_farben] hotbar.0 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$item replace entity @a[tag=mg_al_farben] hotbar.1 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$item replace entity @a[tag=mg_al_farben] hotbar.2 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$item replace entity @a[tag=mg_al_farben] hotbar.3 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$item replace entity @a[tag=mg_al_farben] hotbar.4 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$item replace entity @a[tag=mg_al_farben] hotbar.5 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$item replace entity @a[tag=mg_al_farben] hotbar.6 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$item replace entity @a[tag=mg_al_farben] hotbar.7 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$item replace entity @a[tag=mg_al_farben] hotbar.8 with minecraft:$(c)_concrete[minecraft:custom_name={"text":"$(u)","color":"$(h)","bold":true,"italic":false}]
$bossbar set mg:farben name [{"text":"Runde ","color":"light_purple","bold":true},{"score":{"name":"#farben_r","objective":"mg"},"color":"white","bold":true},{"text":"  ▶ ","color":"gray","bold":false},{"text":"$(u)","color":"$(h)","bold":true},{"text":" ◀","color":"gray","bold":false}]
$bossbar set mg:farben color $(b)
