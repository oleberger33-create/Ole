$title @a[tag=mg_farben] actionbar [{"text":"▶  ","color":"$(h)"},{"text":"$(u)","color":"$(h)","bold":true},{"text":"  ◀","color":"$(h)"}]
