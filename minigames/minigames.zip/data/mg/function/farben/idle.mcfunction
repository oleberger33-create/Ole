execute store result score #n mg if entity @a[tag=mg_q_farben,tag=mg_hub]
execute if score #n mg matches 2.. run scoreboard players set #farben_cd mg 300
execute if score #n mg matches 2.. run execute in minecraft:overworld run forceload add 71976 -24 72024 24
execute if score #n mg matches 2.. run tellraw @a[tag=mg_q_farben] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Farbenparty startet in 15 Sekunden!", "color": "light_purple"}]
execute if score #n mg matches 2.. run scoreboard players set #farben mg 1
