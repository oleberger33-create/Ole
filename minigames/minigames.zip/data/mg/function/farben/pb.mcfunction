scoreboard players set #pbn mg 0
execute unless score @s mg_farben_pb matches 1.. run scoreboard players set #pbn mg 1
execute if score @s mg_farben_pb matches 1.. if score #pbv mg > @s mg_farben_pb run scoreboard players set #pbn mg 1
execute if score #pbv mg matches ..0 run scoreboard players set #pbn mg 0
data modify storage mg:pb u1 set value "Runden"
data modify storage mg:pb u2 set value "Runden"
execute if score #pbv mg matches 1 run data modify storage mg:pb u1 set value "Runde"
execute if score @s mg_farben_pb matches 1 run data modify storage mg:pb u2 set value "Runde"
execute if score #pbn mg matches 0 if score @s mg_farben_pb matches 1.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Ergebnis: ", "color": "gray"}, {"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " ", "color": "yellow"}, {"nbt": "u1", "storage": "mg:pb", "interpret": true, "color": "yellow"}, {"text": "   ·   Dein Rekord (meiste Runden): ", "color": "gray"}, {"score": {"name": "@s", "objective": "mg_farben_pb"}, "color": "gold", "bold": true}, {"text": " ", "color": "gold"}, {"nbt": "u2", "storage": "mg:pb", "interpret": true, "color": "gold"}]
execute if score #pbn mg matches 1 run scoreboard players operation @s mg_farben_pb = #pbv mg
execute if score #pbn mg matches 1 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " – neuer persönlicher Rekord in Farbenparty: ", "color": "gray"}, {"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " ", "color": "yellow"}, {"nbt": "u1", "storage": "mg:pb", "interpret": true, "color": "yellow"}]
execute if score #pbn mg matches 1 run title @s actionbar [{"text": "★ NEUER REKORD ★  ", "color": "gold", "bold": true}, {"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " ", "color": "yellow"}, {"nbt": "u1", "storage": "mg:pb", "interpret": true, "color": "yellow"}]
execute if score #pbn mg matches 1 at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.3
