execute as @a[tag=mg_farben] run function mg:hub/enter
tag @a remove mg_farben
tag @a remove mg_al_farben
scoreboard players set #farben mg 0
bossbar set mg:farben players
bossbar set mg:farben visible false
scoreboard players set #farben_ph mg 3
execute in minecraft:overworld run kill @e[type=minecraft:item,x=71976,dx=48,y=60,dy=90,z=-24,dz=48]
