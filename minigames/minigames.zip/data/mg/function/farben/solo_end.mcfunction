title @a[tag=mg_farben] title {"text": "Solo-Runde vorbei", "color": "light_purple", "bold": true}
scoreboard players set #farben mg 3
schedule function mg:farben/finish 100t
