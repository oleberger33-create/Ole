tag @s remove mg_al_farben
tag @s add mg_farben_fell
scoreboard players set @s mg_deaths 0
gamemode spectator @s
clear @s
experience set @s 0 levels
execute in minecraft:overworld run tp @s 72000.5 114 0.5 0 60
title @s title {"text": "Runtergefallen!", "color": "red", "bold": true}
title @s subtitle {"text": "Mal sehen, ob die anderen es schaffen …", "color": "gray"}
execute at @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.6
tellraw @a[tag=mg_farben] [{"text": "» ", "color": "gold", "bold": true}, {"text": "✖ ", "color": "red"}, {"selector": "@s", "color": "white"}, {"text": " ist gefallen!", "color": "gray"}]
