scoreboard players add #farben_t mg 1
execute as @a[tag=mg_al_farben] at @s if entity @s[y=-64,dy=160] run function mg:farben/fall
execute as @a[tag=mg_al_farben,scores={mg_deaths=1..}] run function mg:farben/fall
execute if score #farben_np mg matches ..1 unless entity @a[tag=mg_al_farben] run return run function mg:farben/solo_over
scoreboard players remove #farben_pt mg 1
execute if score #farben_ph mg matches 3 if score #farben_pt mg matches ..0 run function mg:farben/round
execute if score #farben_ph mg matches 0 run function mg:farben/music
execute if score #farben_ph mg matches 0 if score #farben_pt mg matches ..0 run function mg:farben/choose
execute if score #farben_ph mg matches 1 run scoreboard players add #farben_pt mg 1
execute if score #farben_ph mg matches 1 run function mg:farben/ph_count
execute if score #farben_ph mg matches 2 if score #farben_pt mg matches ..0 run function mg:farben/eval
execute store result score #farben_n mg if entity @a[tag=mg_al_farben]
execute if score #farben mg matches 2 if score #farben_np mg matches 2.. if score #farben_n mg matches ..1 unless entity @a[tag=mg_farben,tag=mg_farben_fell] run function mg:farben/end
scoreboard players operation #m mg = #farben_t mg
scoreboard players operation #m mg %= #5 mg
execute if score #m mg matches 0 run bossbar set mg:farben players @a[tag=mg_farben]
execute if score #m mg matches 0 run bossbar set mg:farben visible true
