scoreboard players add #farben_r mg 1
scoreboard players set #farben_ph mg 0
scoreboard players set #farben_m mg -1
execute store result score #farben_pt mg run random value 50..110
execute store result score #farben_np mg run random value 0..15
execute if score #farben_np mg = #farben_p mg run scoreboard players add #farben_np mg 1
execute if score #farben_np mg matches 16.. run scoreboard players set #farben_np mg 0
scoreboard players operation #farben_p mg = #farben_np mg
execute store result score #farben_pl mg run random value 0..4
execute if score #farben_r mg matches 6.. store result score #farben_pl mg run random value 0..5
function mg:farben/pal
function mg:farben/pat
clear @a[tag=mg_al_farben]
experience set @a[tag=mg_farben] 0 levels
execute in minecraft:overworld run kill @e[type=minecraft:item,x=71978,y=70,z=-22,dx=44,dy=45,dz=44]
bossbar set mg:farben name [{"text":"Runde ","color":"light_purple","bold":true},{"score":{"name":"#farben_r","objective":"mg"},"color":"white","bold":true},{"text":"  ♪ Tanz! Gleich kommt die Farbe …","color":"gray","bold":false}]
bossbar set mg:farben color pink
bossbar set mg:farben max 1
bossbar set mg:farben value 1
title @a[tag=mg_farben] actionbar [{"text":"♪ Runde ","color":"light_purple"},{"score":{"name":"#farben_r","objective":"mg"},"color":"white","bold":true},{"text":" ♪","color":"light_purple"}]
execute as @a[tag=mg_farben] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 1.6
