function mg:farben/dropc with storage mg:farben cur
clear @a[tag=mg_al_farben]
experience set @a[tag=mg_farben] 0 levels
bossbar set mg:farben value 0
title @a[tag=mg_farben] clear
execute as @a[tag=mg_farben] at @s run playsound minecraft:block.glass.break master @s ~ ~ ~ 1 0.6
execute as @a[tag=mg_farben] at @s run playsound minecraft:entity.breeze.wind_burst master @s ~ ~ ~ 0.7 0.8
scoreboard players set #farben_ph mg 2
scoreboard players set #farben_pt mg 50
