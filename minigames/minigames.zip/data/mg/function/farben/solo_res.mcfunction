scoreboard players operation #pbv mg = #farben_r mg
scoreboard players remove #pbv mg 1
execute if score #pbv mg matches ..-1 run scoreboard players set #pbv mg 0
scoreboard players set #farben_ob mg 0
execute if score @s mg_farben_pb matches 1.. run scoreboard players operation #farben_ob mg = @s mg_farben_pb
title @s times 5 60 15
execute unless score #pbv mg matches 1 run title @s subtitle [{"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " Runden geschafft", "color": "white"}]
execute unless score #pbv mg matches 1 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Runtergefallen! ", "color": "red", "bold": true}, {"text": "Du hast ", "color": "gray"}, {"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " Runden geschafft.", "color": "gray"}]
execute if score #pbv mg matches 1 run title @s subtitle [{"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " Runde geschafft", "color": "white"}]
execute if score #pbv mg matches 1 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Runtergefallen! ", "color": "red", "bold": true}, {"text": "Du hast ", "color": "gray"}, {"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " Runde geschafft.", "color": "gray"}]
function mg:farben/pb
execute if score #pbn mg matches 1 unless score #pbv mg matches 1 run title @s subtitle [{"text": "★ Neuer Rekord: ", "color": "gold", "bold": true}, {"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " Runden", "color": "yellow"}]
execute if score #pbn mg matches 1 if score #pbv mg matches 1 run title @s subtitle [{"text": "★ Neuer Rekord: ", "color": "gold", "bold": true}, {"score": {"name": "#pbv", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": " Runde", "color": "yellow"}]
scoreboard players operation #farben_ob mg /= #5 mg
scoreboard players operation #farben_nb mg = #pbv mg
scoreboard players operation #farben_nb mg /= #5 mg
execute if score #pbv mg matches 5.. run scoreboard players add @s mg_coins 2
execute if score #pbv mg matches 5.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "+2 Münzen", "color": "yellow"}]
execute unless score #pbv mg matches 5.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Ab 5 Runden gibt es Münzen.", "color": "gray"}]
execute if score #pbn mg matches 1 if score #farben_nb mg > #farben_ob mg run scoreboard players add @s mg_coins 2
execute if score #pbn mg matches 1 if score #farben_nb mg > #farben_ob mg run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Rekord-Bonus: ", "color": "gold"}, {"text": "+2 Münzen", "color": "yellow"}]
