gamemode adventure @a[tag=mg_farben_rev]
execute in minecraft:overworld run spreadplayers 72000 0 2 12 false @a[tag=mg_farben_rev]
effect give @a[tag=mg_farben_rev] minecraft:saturation infinite 0 true
effect give @a[tag=mg_farben_rev] minecraft:resistance infinite 4 true
title @a[tag=mg_farben_rev] title {"text":"Zurück im Spiel!","color":"green","bold":true}
tag @a[tag=mg_farben_rev] remove mg_farben_rev
