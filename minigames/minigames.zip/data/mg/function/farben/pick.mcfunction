$execute if score #farben_s mg matches 0 run data modify storage mg:farben cur set value {c:"$(c0)",n:"$(n0)",u:"$(u0)",h:"$(h0)",b:"$(b0)"}
$execute if score #farben_s mg matches 1 run data modify storage mg:farben cur set value {c:"$(c1)",n:"$(n1)",u:"$(u1)",h:"$(h1)",b:"$(b1)"}
$execute if score #farben_s mg matches 2 run data modify storage mg:farben cur set value {c:"$(c2)",n:"$(n2)",u:"$(u2)",h:"$(h2)",b:"$(b2)"}
$execute if score #farben_s mg matches 3 run data modify storage mg:farben cur set value {c:"$(c3)",n:"$(n3)",u:"$(u3)",h:"$(h3)",b:"$(b3)"}
$execute if score #farben_s mg matches 4 run data modify storage mg:farben cur set value {c:"$(c4)",n:"$(n4)",u:"$(u4)",h:"$(h4)",b:"$(b4)"}
$execute if score #farben_s mg matches 5 run data modify storage mg:farben cur set value {c:"$(c5)",n:"$(n5)",u:"$(u5)",h:"$(h5)",b:"$(b5)"}
$execute if score #farben_s mg matches 6 run data modify storage mg:farben cur set value {c:"$(c6)",n:"$(n6)",u:"$(u6)",h:"$(h6)",b:"$(b6)"}
$execute if score #farben_s mg matches 7 run data modify storage mg:farben cur set value {c:"$(c7)",n:"$(n7)",u:"$(u7)",h:"$(h7)",b:"$(b7)"}
