scoreboard players remove #farben_pt mg 1
execute store result bossbar mg:farben value run scoreboard players get #farben_pt mg
execute if score #farben_pt mg matches ..0 run return run function mg:farben/drop
execute if score #farben_pt mg matches 1..20 run experience set @a[tag=mg_al_farben] 1 levels
execute if score #farben_pt mg matches 21..40 run experience set @a[tag=mg_al_farben] 2 levels
execute if score #farben_pt mg matches 41..60 run experience set @a[tag=mg_al_farben] 3 levels
execute if score #farben_pt mg matches 61..80 run experience set @a[tag=mg_al_farben] 4 levels
execute if score #farben_pt mg matches 81..100 run experience set @a[tag=mg_al_farben] 5 levels
execute if score #farben_pt mg matches 20 as @a[tag=mg_farben] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1.50
execute if score #farben_pt mg matches 40 as @a[tag=mg_farben] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1.38
execute if score #farben_pt mg matches 60 as @a[tag=mg_farben] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1.25
execute if score #farben_pt mg matches 80 as @a[tag=mg_farben] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1.12
execute if score #farben_pt mg matches 15 as @a[tag=mg_farben] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.8 1.62
execute if score #farben_pt mg matches 10 as @a[tag=mg_farben] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.8 1.75
execute if score #farben_pt mg matches 5 as @a[tag=mg_farben] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.8 1.88
execute if score #farben_pt mg matches 20 run function mg:farben/ab with storage mg:farben cur
execute if score #farben_pt mg matches 50 run function mg:farben/ab with storage mg:farben cur
