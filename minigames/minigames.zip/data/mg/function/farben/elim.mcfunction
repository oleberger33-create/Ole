tag @s remove mg_farben_fell
scoreboard players add @s mg_coins 2
tellraw @a[tag=mg_farben] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist raus! ", "color": "red"}, {"text": "Noch ", "color": "gray"}, {"score": {"name": "#farben_n", "objective": "mg"}, "color": "white"}, {"text": " übrig.", "color": "gray"}]
