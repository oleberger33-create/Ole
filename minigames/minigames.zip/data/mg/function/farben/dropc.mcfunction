$function mg:farben/d/$(c)
$bossbar set mg:farben name [{"text":"$(u)","color":"$(h)","bold":true},{"text":" bleibt – alles andere ist weg!","color":"gray","bold":false}]
