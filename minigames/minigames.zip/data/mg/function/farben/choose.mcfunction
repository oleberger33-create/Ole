execute store result score #farben_s mg run random value 0..7
function mg:farben/pick with storage mg:farben pal
scoreboard players operation #farben_d mg = #farben_r mg
scoreboard players remove #farben_d mg 1
scoreboard players operation #farben_d mg *= #farben_7 mg
scoreboard players set #farben_pt mg 100
scoreboard players operation #farben_pt mg -= #farben_d mg
execute if score #farben_pt mg matches ..30 run scoreboard players set #farben_pt mg 30
execute store result bossbar mg:farben max run scoreboard players get #farben_pt mg
execute store result bossbar mg:farben value run scoreboard players get #farben_pt mg
function mg:farben/announce with storage mg:farben cur
function mg:farben/ab with storage mg:farben cur
execute as @a[tag=mg_farben] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
execute as @a[tag=mg_farben] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 0.6
scoreboard players set #farben_ph mg 1
