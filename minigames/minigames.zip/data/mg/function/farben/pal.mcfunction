execute if score #farben_pl mg matches 0 run return run function mg:farben/pal/0
execute if score #farben_pl mg matches 1 run return run function mg:farben/pal/1
execute if score #farben_pl mg matches 2 run return run function mg:farben/pal/2
execute if score #farben_pl mg matches 3 run return run function mg:farben/pal/3
execute if score #farben_pl mg matches 4 run return run function mg:farben/pal/4
execute if score #farben_pl mg matches 5 run return run function mg:farben/pal/5
