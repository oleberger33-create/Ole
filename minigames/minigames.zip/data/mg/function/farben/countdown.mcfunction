execute store result score #n mg if entity @a[tag=mg_q_farben,tag=mg_hub]
execute if score #n mg matches ..1 run execute in minecraft:overworld run forceload remove 71976 -24 72024 24
execute if score #n mg matches ..1 run tellraw @a[tag=mg_q_farben] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zu wenig Spieler – Farbenparty abgebrochen.", "color": "red"}]
execute if score #n mg matches ..1 run return run scoreboard players set #farben mg 0
scoreboard players remove #farben_cd mg 1
scoreboard players operation #s mg = #farben_cd mg
scoreboard players operation #s mg /= #20 mg
execute as @a[tag=mg_q_farben] run title @s actionbar [{"text":"Farbenparty startet in ","color":"light_purple"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true},{"text":" s","color":"light_purple"}]
execute if score #farben_cd mg matches 60 as @a[tag=mg_q_farben] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #farben_cd mg matches 40 as @a[tag=mg_q_farben] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #farben_cd mg matches 20 as @a[tag=mg_q_farben] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #farben_cd mg matches ..0 in minecraft:overworld if loaded 71984 100 -16 if loaded 72016 100 16 run function mg:farben/start
