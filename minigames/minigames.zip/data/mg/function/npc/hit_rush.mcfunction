execute on target run function mg:npc/rush
data remove entity @s interaction
