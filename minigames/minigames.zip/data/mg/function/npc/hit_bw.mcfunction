execute on target run function mg:npc/bw
data remove entity @s interaction
