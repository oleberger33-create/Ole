execute on target run function mg:npc/duel
data remove entity @s interaction
