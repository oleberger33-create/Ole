execute unless entity @s[tag=mg_hub] run return 0
function mg:bw/toggle
execute at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
