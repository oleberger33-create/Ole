execute on target run function mg:npc/sw
data remove entity @s interaction
