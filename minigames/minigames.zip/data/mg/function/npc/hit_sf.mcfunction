execute on target run function mg:npc/sf
data remove entity @s interaction
