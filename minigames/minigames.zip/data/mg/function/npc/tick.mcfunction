execute as @e[type=minecraft:interaction,tag=mg_npc_rush] if data entity @s interaction run function mg:npc/hit_rush
execute as @e[type=minecraft:interaction,tag=mg_npc_bw] if data entity @s interaction run function mg:npc/hit_bw
execute as @e[type=minecraft:interaction,tag=mg_npc_sw] if data entity @s interaction run function mg:npc/hit_sw
execute as @e[type=minecraft:interaction,tag=mg_npc_sf] if data entity @s interaction run function mg:npc/hit_sf
execute as @e[type=minecraft:interaction,tag=mg_npc_duel] if data entity @s interaction run function mg:npc/hit_duel
