title @a[tag=mg_duel_boxen] actionbar {"text": "LOS!", "color": "gray", "bold": true}
execute as @a[tag=mg_duel_boxen] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
