execute unless score #boxen mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_boxen] remove mg_rw
tag @a[tag=mg_duel_boxen] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_boxen] mg_round 1
tellraw @a[tag=mg_duel_boxen] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_boxen]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "gray"}]
execute as @a[tag=mg_duel_boxen] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_boxen,scores={mg_round=1..}] run return run function mg:boxen/win
scoreboard players set #boxen mg 1
function mg:boxen/round
