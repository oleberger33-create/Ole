execute as @a[tag=mg_duel_boxen] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Boxen – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_boxen] mg_wins 1
scoreboard players add @a[tag=mg_duel_boxen] mg_coins 5
function mg:boxen/stop
