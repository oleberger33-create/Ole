execute if score #boxen_r mg matches 2.. as @a[tag=mg_duel_boxen] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Boxen – Gegner ist weg.", "color": "white"}]
execute if score #boxen_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_boxen] mg_wins 1
execute if score #boxen_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_boxen] mg_coins 5
execute if score #boxen_r mg matches ..1 run tellraw @a[tag=mg_duel_boxen] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dein Gegner ist weg, bevor eine Runde fertig war – keine Wertung.", "color": "gray"}]
function mg:boxen/stop
