execute in minecraft:overworld run kill @e[type=minecraft:item,x=12955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=12955,dx=90,y=70,dy=80,z=-45,dz=90]
execute as @a[tag=mg_duel_boxen] run function mg:boxen/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_boxen,tag=mg_p1,limit=1] 12997 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_boxen,tag=mg_p2,limit=1] 13003 101 0 90 0
execute as @a[tag=mg_duel_boxen] run execute in minecraft:overworld run spawnpoint @s 0 101 17
kill @e[type=minecraft:horse,tag=mg_horse_boxen]
scoreboard players set #boxen_cd mg 60
scoreboard players set #boxen mg 1
title @a[tag=mg_duel_boxen] times 0 30 10
title @a[tag=mg_duel_boxen] title {"text": "Boxen", "color": "gray", "bold": true}
title @a[tag=mg_duel_boxen] subtitle [{"score":{"name":"@a[tag=mg_duel_boxen,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_boxen,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
scoreboard players add #boxen_r mg 1
