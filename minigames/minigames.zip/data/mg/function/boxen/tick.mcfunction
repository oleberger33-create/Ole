execute if score #boxen_cd mg matches 1.. run scoreboard players remove #boxen_cd mg 1
execute if score #boxen mg matches 1 if score #boxen_cd mg matches 0 run function mg:boxen/go
execute if score #boxen mg matches 1 if score #boxen_cd mg matches 0 run scoreboard players set #boxen mg 2
execute unless score #boxen mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_boxen]
execute if score #n mg matches ..1 run return run function mg:boxen/forfeit
execute as @a[tag=mg_duel_boxen,scores={mg_dmg=250..}] run function mg:boxen/point
execute as @a[tag=mg_duel_boxen] run scoreboard players operation @s mg_hits = @s mg_dmg
execute as @a[tag=mg_duel_boxen] run scoreboard players operation @s mg_hits /= #10 mg
execute as @a[tag=mg_duel_boxen] run title @s actionbar [{"text":"Treffer: ","color":"gray"},{"score":{"name":"@s","objective":"mg_hits"},"color":"white","bold":true},{"text":"/25","color":"gray"}]
