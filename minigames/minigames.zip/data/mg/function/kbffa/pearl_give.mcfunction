scoreboard players set @s mg_kbffa_pc 0
give @s minecraft:ender_pearl[minecraft:lore=[{"text": "Wird 10 s nach dem Werfen aufgefüllt", "color": "gray", "italic": false}]] 1
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.4 1.8
