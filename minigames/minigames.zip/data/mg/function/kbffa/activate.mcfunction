execute in minecraft:overworld run forceload add 75960 -39 76039 39
scoreboard players set #kbffa mg 1
scoreboard players set #kbffa_lw mg 0
