tag @s remove mg_kbffa_wait
function mg:kbffa/respawn
title @s times 5 50 10
title @s title {"text": "KNOCKBACK-FFA", "color": "light_purple", "italic": false, "bold": true}
title @s subtitle {"text": "Stoß alle ins Nichts!", "color": "white", "italic": false}
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Knockback-FFA", "color": "light_purple", "italic": false, "bold": true}, {"text": " – Schubs die anderen mit dem Rückstoß-Stock von der Insel. Wer dich zuletzt (10 s) getroffen hat, bekommt den Kill. Sandstein zerfällt nach ~8 s, die Enderperle kommt 10 s nach dem Wurf zurück. Am Spawn gibt es kein PvP.", "color": "gray", "italic": false}]
tellraw @s [{"text": "  Serien: ", "color": "gold", "italic": false, "bold": true}, {"text": "3 = Tempo · 5 = Extra-Perle · 10 = Donner-Stock", "color": "white", "italic": false}]
tellraw @s [{"text": "  "}, {"text": "[Spiel verlassen]", "color": "red", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 99"}}]
execute store result score #kbffa_n mg if entity @a[tag=mg_kbffa,tag=!mg_kbffa_wait]
tellraw @a[tag=mg_kbffa] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist in der Arena! ", "color": "light_purple", "italic": false}, {"text": "(", "color": "dark_gray", "italic": false}, {"score": {"name": "#kbffa_n", "objective": "mg"}, "color": "white"}, {"text": " Spieler)", "color": "dark_gray", "italic": false}]
tellraw @a[tag=mg_hub] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " spielt jetzt ", "color": "gray", "italic": false}, {"text": "Knockback-FFA", "color": "light_purple", "italic": false, "bold": true}, {"text": " – ", "color": "gray", "italic": false}, {"text": "[Mitspielen]", "color": "green", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 63"}}]
execute at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1
