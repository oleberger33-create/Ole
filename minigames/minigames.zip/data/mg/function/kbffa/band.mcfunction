execute in minecraft:overworld run fill 75991 109 -9 76009 120 9 minecraft:air replace minecraft:sandstone
execute in minecraft:overworld run fill 75991 109 -9 76009 120 9 minecraft:air replace #minecraft:terracotta
