execute unless entity @a[tag=mg_kbffa] run return run function mg:kbffa/deactivate
execute as @a[tag=mg_kbffa,scores={mg_kbffa_use=1..}] run function mg:kbffa/use
execute if score #kbffa mg matches 1 run return run function mg:kbffa/loading
scoreboard players add #kbffa_t mg 1
scoreboard players operation #kbffa_m mg = #kbffa_t mg
scoreboard players operation #kbffa_m mg %= #kbffa_45 mg
scoreboard players operation #kbffa_m10 mg = #kbffa_t mg
scoreboard players operation #kbffa_m10 mg %= #10 mg
tag @a[tag=mg_kbffa,scores={mg_kbffa_dd=1..}] add mg_kbffa_atk
execute as @a[tag=mg_kbffa,scores={mg_kbffa_dt=1..}] at @s run function mg:kbffa/hurt
scoreboard players set @a[tag=mg_kbffa_atk] mg_kbffa_dd 0
tag @a[tag=mg_kbffa_atk] remove mg_kbffa_atk
execute as @e[type=minecraft:player,tag=mg_kbffa,tag=!mg_kbffa_wait,scores={mg_deaths=1..}] at @s run function mg:kbffa/died
execute as @a[tag=mg_kbffa,tag=!mg_kbffa_wait] at @s run function mg:kbffa/ptick
execute if score #kbffa_m mg matches 0 run function mg:kbffa/decay0
execute if score #kbffa_m mg matches 5 run function mg:kbffa/decay1
execute if score #kbffa_m mg matches 10 run function mg:kbffa/decay2
execute if score #kbffa_m mg matches 15 run function mg:kbffa/decay3
execute if score #kbffa_m mg matches 20 run function mg:kbffa/decay4
execute if score #kbffa_m mg matches 25 run function mg:kbffa/decay5
execute if score #kbffa_m mg matches 30 run function mg:kbffa/decay6
execute if score #kbffa_m mg matches 35 run function mg:kbffa/decay7
scoreboard players operation #kbffa_m2 mg = #kbffa_t mg
scoreboard players operation #kbffa_m2 mg %= #2 mg
execute if score #kbffa_m2 mg matches 0 run function mg:kbffa/band
execute if score #kbffa_m mg matches 22 run function mg:kbffa/slow
