execute if score #kbffa_pay mg matches 0 run return 0
$scoreboard players add @s mg_coins $(n)
$scoreboard players add @s mg_kbffa_cn $(n)
