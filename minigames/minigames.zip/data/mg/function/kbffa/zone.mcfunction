execute unless entity @s[tag=mg_kbffa_fresh] run return run function mg:kbffa/no_return
execute unless entity @s[tag=mg_kbffa_safe] run attribute @s minecraft:knockback_resistance modifier add mg:kbffa_safe 1 add_value
effect give @s minecraft:resistance 1 4 true
effect give @s minecraft:weakness 1 100 true
tag @s add mg_kbffa_safe
scoreboard players add @s mg_kbffa_sp 1
execute if score @s mg_kbffa_sp matches 300 run title @s actionbar {"text": "Noch 5 Sekunden am Spawn – spring runter!", "color": "yellow", "italic": false, "bold": true}
execute if score @s mg_kbffa_sp matches 300 run scoreboard players set @s mg_kbffa_hold 40
execute if score @s mg_kbffa_sp matches 400.. run function mg:kbffa/kick_spawn
