execute unless entity @s[tag=mg_hub] run return 0
function mg:q/leave_all
tag @s remove mg_hub
tag @s add mg_kbffa
tag @s add mg_kbffa_wait
scoreboard players set @s mg_kbffa_k 0
scoreboard players set @s mg_kbffa_d 0
scoreboard players set @s mg_kbffa_best 0
scoreboard players set @s mg_kbffa_use 0
scoreboard players set @s mg_kbffa_pad 0
scoreboard players set @s mg_kbffa_cn 0
scoreboard players set @s mg_kbffa_hold 0
execute unless score @s mg_kbffa_pid matches 1.. run scoreboard players add #kbffa_pid mg 1
execute unless score @s mg_kbffa_pid matches 1.. run scoreboard players operation @s mg_kbffa_pid = #kbffa_pid mg
scoreboard players add #kbffa_id mg 1
scoreboard players operation @s mg_kbffa_id = #kbffa_id mg
execute store result score @s mg_kbffa_col run random value 0..7
ride @s dismount
clear @s
effect clear @s
gamemode adventure @s
attribute @s minecraft:fall_damage_multiplier base set 0
execute in minecraft:overworld run spawnpoint @s 76000 114 0
execute if score #kbffa mg matches 0 run function mg:kbffa/activate
execute if score #kbffa mg matches 2 run return run function mg:kbffa/enter
execute in minecraft:overworld run tp @s 76000.5 114 0.5
effect give @s minecraft:blindness 2 0 true
effect give @s minecraft:resistance 5 4 true
