title @s actionbar {"text": "Spawn-Schutz gibt es nur direkt nach dem Respawn!", "color": "red", "italic": false, "bold": true}
function mg:kbffa/drop
