scoreboard players add @s mg_kbffa_pc 1
execute if score @s mg_kbffa_pc matches 200.. run function mg:kbffa/pearl_give
