execute in minecraft:overworld run kill @e[type=minecraft:item,x=75960,dx=79,y=33,dy=100,z=-39,dz=78]
execute as @a[tag=mg_kbffa,tag=!mg_kbffa_wait] run function mg:kbffa/restock
execute in minecraft:overworld run particle minecraft:end_rod 76000.5 114.2 0.5 3.5 0.1 3.5 0 8
execute in minecraft:overworld run particle minecraft:portal 76000.5 101.3 9.5 0.4 0.3 0.4 0.3 25
execute in minecraft:overworld run particle minecraft:portal 76000.5 101.3 -9.5 0.4 0.3 0.4 0.3 25
