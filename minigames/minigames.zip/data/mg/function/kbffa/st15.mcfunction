give @s minecraft:ender_pearl[minecraft:lore=[{"text": "Wird 10 s nach dem Werfen aufgefüllt", "color": "gray", "italic": false}]] 1
function mg:kbffa/coin {n:2}
tellraw @a[tag=mg_kbffa] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " ist auf einer ", "color": "yellow", "italic": false}, {"score": {"name": "@s", "objective": "mg_kbffa_s"}, "color": "red", "bold": true}, {"text": "er-Serie! Stoppt ihn!", "color": "yellow", "italic": false}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.2
