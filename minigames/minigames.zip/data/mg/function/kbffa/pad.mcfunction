scoreboard players set @s mg_kbffa_pad 50
effect give @s minecraft:levitation 2 5 true
effect give @s minecraft:slow_falling 7 0 true
playsound minecraft:entity.breeze.wind_burst master @a[distance=..16] ~ ~ ~ 0.8 1.3
particle minecraft:dragon_breath ~ ~0.2 ~ 0.4 0.1 0.4 0.02 20
