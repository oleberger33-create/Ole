execute store result score #kbffa_r mg run random value 1..5
scoreboard players operation #kbffa_r mg += #kbffa_last mg
scoreboard players set #kbffa_6 mg 6
scoreboard players operation #kbffa_r mg %= #kbffa_6 mg
scoreboard players operation #kbffa_last mg = #kbffa_r mg
execute if score #kbffa_r mg matches 0 in minecraft:overworld run tp @s 76003.5 114 0.5 -90 10
execute if score #kbffa_r mg matches 1 in minecraft:overworld run tp @s 76002.5 114 3.5 -30 10
execute if score #kbffa_r mg matches 2 in minecraft:overworld run tp @s 75999.5 114 3.5 30 10
execute if score #kbffa_r mg matches 3 in minecraft:overworld run tp @s 75997.5 114 0.5 90 10
execute if score #kbffa_r mg matches 4 in minecraft:overworld run tp @s 75998.5 114 -3.5 150 10
execute if score #kbffa_r mg matches 5 in minecraft:overworld run tp @s 76002.5 114 -3.5 210 10
