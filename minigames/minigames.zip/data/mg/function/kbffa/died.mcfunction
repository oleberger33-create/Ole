scoreboard players set @s mg_deaths 0
function mg:kbffa/fall
