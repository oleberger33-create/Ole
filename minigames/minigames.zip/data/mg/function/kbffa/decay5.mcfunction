execute in minecraft:overworld run fill 76010 83 -39 76019 123 39 minecraft:air replace minecraft:red_terracotta
execute in minecraft:overworld run fill 76010 83 -39 76019 123 39 minecraft:red_terracotta replace minecraft:orange_terracotta
execute in minecraft:overworld run fill 76010 83 -39 76019 123 39 minecraft:orange_terracotta replace minecraft:yellow_terracotta
execute in minecraft:overworld run fill 76010 83 -39 76019 123 39 minecraft:yellow_terracotta replace minecraft:sandstone
