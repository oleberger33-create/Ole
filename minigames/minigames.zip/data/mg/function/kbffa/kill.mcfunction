scoreboard players set #kbffa_kf mg 1
tag @s add mg_kbffa_klr
scoreboard players set #kbffa_pay mg 1
execute if score @s mg_kbffa_lv = #kbffa_vid mg run scoreboard players set #kbffa_pay mg 0
execute if score @s mg_kbffa_cn matches 30.. run scoreboard players set #kbffa_pay mg 0
scoreboard players operation @s mg_kbffa_lv = #kbffa_vid mg
scoreboard players add @s mg_kbffa_k 1
scoreboard players add @s mg_kbffa_s 1
function mg:kbffa/coin {n:1}
tellraw @a[tag=mg_kbffa] [{"text": "» ", "color": "gold", "bold": true}, {"text": "☠ ", "color": "red", "italic": false}, {"selector": "@a[tag=mg_kbffa_vic,limit=1]", "color": "white"}, {"text": " wurde von ", "color": "gray", "italic": false}, {"selector": "@s", "color": "gold"}, {"text": " ins Nichts gestoßen ", "color": "gray", "italic": false}, {"text": "(Serie ", "color": "dark_gray", "italic": false}, {"score": {"name": "@s", "objective": "mg_kbffa_s"}, "color": "red"}, {"text": ")", "color": "dark_gray", "italic": false}]
title @s times 0 25 8
title @s title {"text": "", "color": "white", "italic": false}
title @s subtitle [{"text": "☠ ", "color": "red", "italic": false}, {"selector": "@a[tag=mg_kbffa_vic,limit=1]", "color": "white"}, {"text": "  +1 Kill", "color": "gold", "italic": false, "bold": true}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1.2
playsound minecraft:entity.arrow.hit_player master @s ~ ~ ~ 0.8 1
execute as @a[tag=mg_kbffa_vic,limit=1] run title @s times 0 25 8
execute as @a[tag=mg_kbffa_vic,limit=1] run title @s title {"text": "Runtergestoßen!", "color": "red", "italic": false, "bold": true}
execute as @a[tag=mg_kbffa_vic,limit=1] run title @s subtitle [{"text": "von ", "color": "gray", "italic": false}, {"selector": "@a[tag=mg_kbffa_klr,limit=1]", "color": "gold"}]
effect give @s minecraft:instant_health 1 1 true
function mg:kbffa/refill
execute if score #kbffa_vs mg matches 5.. run tellraw @a[tag=mg_kbffa] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " beendet die ", "color": "yellow", "italic": false}, {"score": {"name": "#kbffa_vs", "objective": "mg"}, "color": "red", "bold": true}, {"text": "er-Serie von ", "color": "yellow", "italic": false}, {"selector": "@a[tag=mg_kbffa_vic,limit=1]", "color": "white"}, {"text": "!", "color": "yellow", "italic": false}]
execute if score #kbffa_vs mg matches 5.. run function mg:kbffa/coin {n:3}
function mg:kbffa/streak
execute if score @s mg_kbffa_s > @s mg_kbffa_best run scoreboard players operation @s mg_kbffa_best = @s mg_kbffa_s
execute if score @s mg_kbffa_s matches 5.. if score @s mg_kbffa_s > #kbffa_rec mg unless entity @s[tag=mg_kbffa_rech] run tellraw @a[tag=mg_kbffa] [{"text": "» ", "color": "gold", "bold": true}, {"text": "★ Neuer Arena-Rekord: ", "color": "light_purple", "italic": false, "bold": true}, {"score": {"name": "@s", "objective": "mg_kbffa_s"}, "color": "white", "bold": true}, {"text": " Kills in Folge von ", "color": "light_purple", "italic": false}, {"selector": "@s", "color": "white"}]
execute if score @s mg_kbffa_s matches 5.. if score @s mg_kbffa_s > #kbffa_rec mg run tag @s add mg_kbffa_rech
execute if score @s mg_kbffa_s > #kbffa_rec mg run scoreboard players operation #kbffa_rec mg = @s mg_kbffa_s
tag @s remove mg_kbffa_klr
