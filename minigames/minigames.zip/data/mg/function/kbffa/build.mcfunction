kill @e[type=minecraft:text_display,tag=mg_kbffah]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=75960,dx=79,y=33,dy=100,z=-39,dz=78]
execute in minecraft:overworld run kill @e[type=minecraft:ender_pearl,x=75960,dx=79,y=33,dy=100,z=-39,dz=78]
execute in minecraft:overworld run fill 75960 83 -39 75964 123 39 minecraft:air
execute in minecraft:overworld run fill 75965 83 -39 75969 123 39 minecraft:air
execute in minecraft:overworld run fill 75970 83 -39 75974 123 39 minecraft:air
execute in minecraft:overworld run fill 75975 83 -39 75979 123 39 minecraft:air
execute in minecraft:overworld run fill 75980 83 -39 75984 123 39 minecraft:air
execute in minecraft:overworld run fill 75985 83 -39 75989 123 39 minecraft:air
execute in minecraft:overworld run fill 75990 83 -39 75994 123 39 minecraft:air
execute in minecraft:overworld run fill 75995 83 -39 75999 123 39 minecraft:air
execute in minecraft:overworld run fill 76000 83 -39 76004 123 39 minecraft:air
execute in minecraft:overworld run fill 76005 83 -39 76009 123 39 minecraft:air
execute in minecraft:overworld run fill 76010 83 -39 76014 123 39 minecraft:air
execute in minecraft:overworld run fill 76015 83 -39 76019 123 39 minecraft:air
execute in minecraft:overworld run fill 76020 83 -39 76024 123 39 minecraft:air
execute in minecraft:overworld run fill 76025 83 -39 76029 123 39 minecraft:air
execute in minecraft:overworld run fill 76030 83 -39 76034 123 39 minecraft:air
execute in minecraft:overworld run fill 76035 83 -39 76039 123 39 minecraft:air
execute in minecraft:overworld run fill 75965 121 -35 76035 121 35 minecraft:barrier
execute in minecraft:overworld run fill 75996 100 -21 76004 100 -21 minecraft:grass_block
execute in minecraft:overworld run fill 75993 100 -20 76007 100 -20 minecraft:grass_block
execute in minecraft:overworld run fill 75990 100 -19 76010 100 -19 minecraft:grass_block
execute in minecraft:overworld run fill 75989 100 -18 76011 100 -18 minecraft:grass_block
execute in minecraft:overworld run fill 75987 100 -17 76013 100 -17 minecraft:grass_block
execute in minecraft:overworld run fill 75986 100 -16 76014 100 -16 minecraft:grass_block
execute in minecraft:overworld run fill 75985 100 -15 76015 100 -15 minecraft:grass_block
execute in minecraft:overworld run fill 75984 100 -14 76016 100 -14 minecraft:grass_block
execute in minecraft:overworld run fill 75983 100 -13 76017 100 -13 minecraft:grass_block
execute in minecraft:overworld run fill 75983 100 -12 76017 100 -12 minecraft:grass_block
execute in minecraft:overworld run fill 75982 100 -11 76018 100 -11 minecraft:grass_block
execute in minecraft:overworld run fill 75981 100 -10 76019 100 -10 minecraft:grass_block
execute in minecraft:overworld run fill 75981 100 -9 76019 100 -9 minecraft:grass_block
execute in minecraft:overworld run fill 75981 100 -8 76019 100 -8 minecraft:grass_block
execute in minecraft:overworld run fill 75980 100 -7 76020 100 -7 minecraft:grass_block
execute in minecraft:overworld run fill 75980 100 -6 76020 100 -6 minecraft:grass_block
execute in minecraft:overworld run fill 75980 100 -5 76020 100 -5 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 -4 76021 100 -4 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 -3 76021 100 -3 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 -2 76021 100 -2 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 -1 76021 100 -1 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 0 76021 100 0 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 1 76021 100 1 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 2 76021 100 2 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 3 76021 100 3 minecraft:grass_block
execute in minecraft:overworld run fill 75979 100 4 76021 100 4 minecraft:grass_block
execute in minecraft:overworld run fill 75980 100 5 76020 100 5 minecraft:grass_block
execute in minecraft:overworld run fill 75980 100 6 76020 100 6 minecraft:grass_block
execute in minecraft:overworld run fill 75980 100 7 76020 100 7 minecraft:grass_block
execute in minecraft:overworld run fill 75981 100 8 76019 100 8 minecraft:grass_block
execute in minecraft:overworld run fill 75981 100 9 76019 100 9 minecraft:grass_block
execute in minecraft:overworld run fill 75981 100 10 76019 100 10 minecraft:grass_block
execute in minecraft:overworld run fill 75982 100 11 76018 100 11 minecraft:grass_block
execute in minecraft:overworld run fill 75983 100 12 76017 100 12 minecraft:grass_block
execute in minecraft:overworld run fill 75983 100 13 76017 100 13 minecraft:grass_block
execute in minecraft:overworld run fill 75984 100 14 76016 100 14 minecraft:grass_block
execute in minecraft:overworld run fill 75985 100 15 76015 100 15 minecraft:grass_block
execute in minecraft:overworld run fill 75986 100 16 76014 100 16 minecraft:grass_block
execute in minecraft:overworld run fill 75987 100 17 76013 100 17 minecraft:grass_block
execute in minecraft:overworld run fill 75989 100 18 76011 100 18 minecraft:grass_block
execute in minecraft:overworld run fill 75990 100 19 76010 100 19 minecraft:grass_block
execute in minecraft:overworld run fill 75993 100 20 76007 100 20 minecraft:grass_block
execute in minecraft:overworld run fill 75996 100 21 76004 100 21 minecraft:grass_block
execute in minecraft:overworld run fill 75996 99 -21 76004 99 -21 minecraft:dirt
execute in minecraft:overworld run fill 75993 99 -20 76007 99 -20 minecraft:dirt
execute in minecraft:overworld run fill 75990 99 -19 76010 99 -19 minecraft:dirt
execute in minecraft:overworld run fill 75989 99 -18 76011 99 -18 minecraft:dirt
execute in minecraft:overworld run fill 75987 99 -17 76013 99 -17 minecraft:dirt
execute in minecraft:overworld run fill 75986 99 -16 76014 99 -16 minecraft:dirt
execute in minecraft:overworld run fill 75985 99 -15 76015 99 -15 minecraft:dirt
execute in minecraft:overworld run fill 75984 99 -14 76016 99 -14 minecraft:dirt
execute in minecraft:overworld run fill 75983 99 -13 76017 99 -13 minecraft:dirt
execute in minecraft:overworld run fill 75983 99 -12 76017 99 -12 minecraft:dirt
execute in minecraft:overworld run fill 75982 99 -11 76018 99 -11 minecraft:dirt
execute in minecraft:overworld run fill 75981 99 -10 76019 99 -10 minecraft:dirt
execute in minecraft:overworld run fill 75981 99 -9 76019 99 -9 minecraft:dirt
execute in minecraft:overworld run fill 75981 99 -8 76019 99 -8 minecraft:dirt
execute in minecraft:overworld run fill 75980 99 -7 76020 99 -7 minecraft:dirt
execute in minecraft:overworld run fill 75980 99 -6 76020 99 -6 minecraft:dirt
execute in minecraft:overworld run fill 75980 99 -5 76020 99 -5 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 -4 76021 99 -4 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 -3 76021 99 -3 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 -2 76021 99 -2 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 -1 76021 99 -1 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 0 76021 99 0 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 1 76021 99 1 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 2 76021 99 2 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 3 76021 99 3 minecraft:dirt
execute in minecraft:overworld run fill 75979 99 4 76021 99 4 minecraft:dirt
execute in minecraft:overworld run fill 75980 99 5 76020 99 5 minecraft:dirt
execute in minecraft:overworld run fill 75980 99 6 76020 99 6 minecraft:dirt
execute in minecraft:overworld run fill 75980 99 7 76020 99 7 minecraft:dirt
execute in minecraft:overworld run fill 75981 99 8 76019 99 8 minecraft:dirt
execute in minecraft:overworld run fill 75981 99 9 76019 99 9 minecraft:dirt
execute in minecraft:overworld run fill 75981 99 10 76019 99 10 minecraft:dirt
execute in minecraft:overworld run fill 75982 99 11 76018 99 11 minecraft:dirt
execute in minecraft:overworld run fill 75983 99 12 76017 99 12 minecraft:dirt
execute in minecraft:overworld run fill 75983 99 13 76017 99 13 minecraft:dirt
execute in minecraft:overworld run fill 75984 99 14 76016 99 14 minecraft:dirt
execute in minecraft:overworld run fill 75985 99 15 76015 99 15 minecraft:dirt
execute in minecraft:overworld run fill 75986 99 16 76014 99 16 minecraft:dirt
execute in minecraft:overworld run fill 75987 99 17 76013 99 17 minecraft:dirt
execute in minecraft:overworld run fill 75989 99 18 76011 99 18 minecraft:dirt
execute in minecraft:overworld run fill 75990 99 19 76010 99 19 minecraft:dirt
execute in minecraft:overworld run fill 75993 99 20 76007 99 20 minecraft:dirt
execute in minecraft:overworld run fill 75996 99 21 76004 99 21 minecraft:dirt
execute in minecraft:overworld run fill 75996 98 -20 76004 98 -20 minecraft:dirt
execute in minecraft:overworld run fill 75993 98 -19 76007 98 -19 minecraft:dirt
execute in minecraft:overworld run fill 75991 98 -18 76009 98 -18 minecraft:dirt
execute in minecraft:overworld run fill 75989 98 -17 76011 98 -17 minecraft:dirt
execute in minecraft:overworld run fill 75988 98 -16 76012 98 -16 minecraft:dirt
execute in minecraft:overworld run fill 75987 98 -15 76013 98 -15 minecraft:dirt
execute in minecraft:overworld run fill 75986 98 -14 76014 98 -14 minecraft:dirt
execute in minecraft:overworld run fill 75985 98 -13 76015 98 -13 minecraft:dirt
execute in minecraft:overworld run fill 75984 98 -12 76016 98 -12 minecraft:dirt
execute in minecraft:overworld run fill 75983 98 -11 76017 98 -11 minecraft:dirt
execute in minecraft:overworld run fill 75983 98 -10 76017 98 -10 minecraft:dirt
execute in minecraft:overworld run fill 75982 98 -9 76018 98 -9 minecraft:dirt
execute in minecraft:overworld run fill 75982 98 -8 76018 98 -8 minecraft:dirt
execute in minecraft:overworld run fill 75981 98 -7 76019 98 -7 minecraft:dirt
execute in minecraft:overworld run fill 75981 98 -6 76019 98 -6 minecraft:dirt
execute in minecraft:overworld run fill 75981 98 -5 76019 98 -5 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 -4 76020 98 -4 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 -3 76020 98 -3 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 -2 76020 98 -2 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 -1 76020 98 -1 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 0 76020 98 0 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 1 76020 98 1 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 2 76020 98 2 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 3 76020 98 3 minecraft:dirt
execute in minecraft:overworld run fill 75980 98 4 76020 98 4 minecraft:dirt
execute in minecraft:overworld run fill 75981 98 5 76019 98 5 minecraft:dirt
execute in minecraft:overworld run fill 75981 98 6 76019 98 6 minecraft:dirt
execute in minecraft:overworld run fill 75981 98 7 76019 98 7 minecraft:dirt
execute in minecraft:overworld run fill 75982 98 8 76018 98 8 minecraft:dirt
execute in minecraft:overworld run fill 75982 98 9 76018 98 9 minecraft:dirt
execute in minecraft:overworld run fill 75983 98 10 76017 98 10 minecraft:dirt
execute in minecraft:overworld run fill 75983 98 11 76017 98 11 minecraft:dirt
execute in minecraft:overworld run fill 75984 98 12 76016 98 12 minecraft:dirt
execute in minecraft:overworld run fill 75985 98 13 76015 98 13 minecraft:dirt
execute in minecraft:overworld run fill 75986 98 14 76014 98 14 minecraft:dirt
execute in minecraft:overworld run fill 75987 98 15 76013 98 15 minecraft:dirt
execute in minecraft:overworld run fill 75988 98 16 76012 98 16 minecraft:dirt
execute in minecraft:overworld run fill 75989 98 17 76011 98 17 minecraft:dirt
execute in minecraft:overworld run fill 75991 98 18 76009 98 18 minecraft:dirt
execute in minecraft:overworld run fill 75993 98 19 76007 98 19 minecraft:dirt
execute in minecraft:overworld run fill 75996 98 20 76004 98 20 minecraft:dirt
execute in minecraft:overworld run fill 75996 97 -19 76004 97 -19 minecraft:stone
execute in minecraft:overworld run fill 75993 97 -18 76007 97 -18 minecraft:stone
execute in minecraft:overworld run fill 75991 97 -17 76009 97 -17 minecraft:stone
execute in minecraft:overworld run fill 75989 97 -16 76011 97 -16 minecraft:stone
execute in minecraft:overworld run fill 75988 97 -15 76012 97 -15 minecraft:stone
execute in minecraft:overworld run fill 75987 97 -14 76013 97 -14 minecraft:stone
execute in minecraft:overworld run fill 75986 97 -13 76014 97 -13 minecraft:stone
execute in minecraft:overworld run fill 75985 97 -12 76015 97 -12 minecraft:stone
execute in minecraft:overworld run fill 75984 97 -11 76016 97 -11 minecraft:stone
execute in minecraft:overworld run fill 75984 97 -10 76016 97 -10 minecraft:stone
execute in minecraft:overworld run fill 75983 97 -9 76017 97 -9 minecraft:stone
execute in minecraft:overworld run fill 75983 97 -8 76017 97 -8 minecraft:stone
execute in minecraft:overworld run fill 75982 97 -7 76018 97 -7 minecraft:stone
execute in minecraft:overworld run fill 75982 97 -6 76018 97 -6 minecraft:stone
execute in minecraft:overworld run fill 75982 97 -5 76018 97 -5 minecraft:stone
execute in minecraft:overworld run fill 75981 97 -4 76019 97 -4 minecraft:stone
execute in minecraft:overworld run fill 75981 97 -3 76019 97 -3 minecraft:stone
execute in minecraft:overworld run fill 75981 97 -2 76019 97 -2 minecraft:stone
execute in minecraft:overworld run fill 75981 97 -1 76019 97 -1 minecraft:stone
execute in minecraft:overworld run fill 75981 97 0 76019 97 0 minecraft:stone
execute in minecraft:overworld run fill 75981 97 1 76019 97 1 minecraft:stone
execute in minecraft:overworld run fill 75981 97 2 76019 97 2 minecraft:stone
execute in minecraft:overworld run fill 75981 97 3 76019 97 3 minecraft:stone
execute in minecraft:overworld run fill 75981 97 4 76019 97 4 minecraft:stone
execute in minecraft:overworld run fill 75982 97 5 76018 97 5 minecraft:stone
execute in minecraft:overworld run fill 75982 97 6 76018 97 6 minecraft:stone
execute in minecraft:overworld run fill 75982 97 7 76018 97 7 minecraft:stone
execute in minecraft:overworld run fill 75983 97 8 76017 97 8 minecraft:stone
execute in minecraft:overworld run fill 75983 97 9 76017 97 9 minecraft:stone
execute in minecraft:overworld run fill 75984 97 10 76016 97 10 minecraft:stone
execute in minecraft:overworld run fill 75984 97 11 76016 97 11 minecraft:stone
execute in minecraft:overworld run fill 75985 97 12 76015 97 12 minecraft:stone
execute in minecraft:overworld run fill 75986 97 13 76014 97 13 minecraft:stone
execute in minecraft:overworld run fill 75987 97 14 76013 97 14 minecraft:stone
execute in minecraft:overworld run fill 75988 97 15 76012 97 15 minecraft:stone
execute in minecraft:overworld run fill 75989 97 16 76011 97 16 minecraft:stone
execute in minecraft:overworld run fill 75991 97 17 76009 97 17 minecraft:stone
execute in minecraft:overworld run fill 75993 97 18 76007 97 18 minecraft:stone
execute in minecraft:overworld run fill 75996 97 19 76004 97 19 minecraft:stone
execute in minecraft:overworld run fill 75996 96 -17 76004 96 -17 minecraft:stone
execute in minecraft:overworld run fill 75993 96 -16 76007 96 -16 minecraft:stone
execute in minecraft:overworld run fill 75991 96 -15 76009 96 -15 minecraft:stone
execute in minecraft:overworld run fill 75990 96 -14 76010 96 -14 minecraft:stone
execute in minecraft:overworld run fill 75989 96 -13 76011 96 -13 minecraft:stone
execute in minecraft:overworld run fill 75988 96 -12 76012 96 -12 minecraft:stone
execute in minecraft:overworld run fill 75987 96 -11 76013 96 -11 minecraft:stone
execute in minecraft:overworld run fill 75986 96 -10 76014 96 -10 minecraft:stone
execute in minecraft:overworld run fill 75985 96 -9 76015 96 -9 minecraft:stone
execute in minecraft:overworld run fill 75985 96 -8 76015 96 -8 minecraft:stone
execute in minecraft:overworld run fill 75984 96 -7 76016 96 -7 minecraft:stone
execute in minecraft:overworld run fill 75984 96 -6 76016 96 -6 minecraft:stone
execute in minecraft:overworld run fill 75984 96 -5 76016 96 -5 minecraft:stone
execute in minecraft:overworld run fill 75983 96 -4 76017 96 -4 minecraft:stone
execute in minecraft:overworld run fill 75983 96 -3 76017 96 -3 minecraft:stone
execute in minecraft:overworld run fill 75983 96 -2 76017 96 -2 minecraft:stone
execute in minecraft:overworld run fill 75983 96 -1 76017 96 -1 minecraft:stone
execute in minecraft:overworld run fill 75983 96 0 76017 96 0 minecraft:stone
execute in minecraft:overworld run fill 75983 96 1 76017 96 1 minecraft:stone
execute in minecraft:overworld run fill 75983 96 2 76017 96 2 minecraft:stone
execute in minecraft:overworld run fill 75983 96 3 76017 96 3 minecraft:stone
execute in minecraft:overworld run fill 75983 96 4 76017 96 4 minecraft:stone
execute in minecraft:overworld run fill 75984 96 5 76016 96 5 minecraft:stone
execute in minecraft:overworld run fill 75984 96 6 76016 96 6 minecraft:stone
execute in minecraft:overworld run fill 75984 96 7 76016 96 7 minecraft:stone
execute in minecraft:overworld run fill 75985 96 8 76015 96 8 minecraft:stone
execute in minecraft:overworld run fill 75985 96 9 76015 96 9 minecraft:stone
execute in minecraft:overworld run fill 75986 96 10 76014 96 10 minecraft:stone
execute in minecraft:overworld run fill 75987 96 11 76013 96 11 minecraft:stone
execute in minecraft:overworld run fill 75988 96 12 76012 96 12 minecraft:stone
execute in minecraft:overworld run fill 75989 96 13 76011 96 13 minecraft:stone
execute in minecraft:overworld run fill 75990 96 14 76010 96 14 minecraft:stone
execute in minecraft:overworld run fill 75991 96 15 76009 96 15 minecraft:stone
execute in minecraft:overworld run fill 75993 96 16 76007 96 16 minecraft:stone
execute in minecraft:overworld run fill 75996 96 17 76004 96 17 minecraft:stone
execute in minecraft:overworld run fill 75997 95 -15 76003 95 -15 minecraft:andesite
execute in minecraft:overworld run fill 75994 95 -14 76006 95 -14 minecraft:andesite
execute in minecraft:overworld run fill 75992 95 -13 76008 95 -13 minecraft:andesite
execute in minecraft:overworld run fill 75991 95 -12 76009 95 -12 minecraft:andesite
execute in minecraft:overworld run fill 75990 95 -11 76010 95 -11 minecraft:andesite
execute in minecraft:overworld run fill 75989 95 -10 76011 95 -10 minecraft:andesite
execute in minecraft:overworld run fill 75988 95 -9 76012 95 -9 minecraft:andesite
execute in minecraft:overworld run fill 75987 95 -8 76013 95 -8 minecraft:andesite
execute in minecraft:overworld run fill 75987 95 -7 76013 95 -7 minecraft:andesite
execute in minecraft:overworld run fill 75986 95 -6 76014 95 -6 minecraft:andesite
execute in minecraft:overworld run fill 75986 95 -5 76014 95 -5 minecraft:andesite
execute in minecraft:overworld run fill 75986 95 -4 76014 95 -4 minecraft:andesite
execute in minecraft:overworld run fill 75985 95 -3 76015 95 -3 minecraft:andesite
execute in minecraft:overworld run fill 75985 95 -2 76015 95 -2 minecraft:andesite
execute in minecraft:overworld run fill 75985 95 -1 76015 95 -1 minecraft:andesite
execute in minecraft:overworld run fill 75985 95 0 76015 95 0 minecraft:andesite
execute in minecraft:overworld run fill 75985 95 1 76015 95 1 minecraft:andesite
execute in minecraft:overworld run fill 75985 95 2 76015 95 2 minecraft:andesite
execute in minecraft:overworld run fill 75985 95 3 76015 95 3 minecraft:andesite
execute in minecraft:overworld run fill 75986 95 4 76014 95 4 minecraft:andesite
execute in minecraft:overworld run fill 75986 95 5 76014 95 5 minecraft:andesite
execute in minecraft:overworld run fill 75986 95 6 76014 95 6 minecraft:andesite
execute in minecraft:overworld run fill 75987 95 7 76013 95 7 minecraft:andesite
execute in minecraft:overworld run fill 75987 95 8 76013 95 8 minecraft:andesite
execute in minecraft:overworld run fill 75988 95 9 76012 95 9 minecraft:andesite
execute in minecraft:overworld run fill 75989 95 10 76011 95 10 minecraft:andesite
execute in minecraft:overworld run fill 75990 95 11 76010 95 11 minecraft:andesite
execute in minecraft:overworld run fill 75991 95 12 76009 95 12 minecraft:andesite
execute in minecraft:overworld run fill 75992 95 13 76008 95 13 minecraft:andesite
execute in minecraft:overworld run fill 75994 95 14 76006 95 14 minecraft:andesite
execute in minecraft:overworld run fill 75997 95 15 76003 95 15 minecraft:andesite
execute in minecraft:overworld run fill 75997 94 -13 76003 94 -13 minecraft:stone
execute in minecraft:overworld run fill 75994 94 -12 76006 94 -12 minecraft:stone
execute in minecraft:overworld run fill 75993 94 -11 76007 94 -11 minecraft:stone
execute in minecraft:overworld run fill 75991 94 -10 76009 94 -10 minecraft:stone
execute in minecraft:overworld run fill 75990 94 -9 76010 94 -9 minecraft:stone
execute in minecraft:overworld run fill 75990 94 -8 76010 94 -8 minecraft:stone
execute in minecraft:overworld run fill 75989 94 -7 76011 94 -7 minecraft:stone
execute in minecraft:overworld run fill 75988 94 -6 76012 94 -6 minecraft:stone
execute in minecraft:overworld run fill 75988 94 -5 76012 94 -5 minecraft:stone
execute in minecraft:overworld run fill 75988 94 -4 76012 94 -4 minecraft:stone
execute in minecraft:overworld run fill 75987 94 -3 76013 94 -3 minecraft:stone
execute in minecraft:overworld run fill 75987 94 -2 76013 94 -2 minecraft:stone
execute in minecraft:overworld run fill 75987 94 -1 76013 94 -1 minecraft:stone
execute in minecraft:overworld run fill 75987 94 0 76013 94 0 minecraft:stone
execute in minecraft:overworld run fill 75987 94 1 76013 94 1 minecraft:stone
execute in minecraft:overworld run fill 75987 94 2 76013 94 2 minecraft:stone
execute in minecraft:overworld run fill 75987 94 3 76013 94 3 minecraft:stone
execute in minecraft:overworld run fill 75988 94 4 76012 94 4 minecraft:stone
execute in minecraft:overworld run fill 75988 94 5 76012 94 5 minecraft:stone
execute in minecraft:overworld run fill 75988 94 6 76012 94 6 minecraft:stone
execute in minecraft:overworld run fill 75989 94 7 76011 94 7 minecraft:stone
execute in minecraft:overworld run fill 75990 94 8 76010 94 8 minecraft:stone
execute in minecraft:overworld run fill 75990 94 9 76010 94 9 minecraft:stone
execute in minecraft:overworld run fill 75991 94 10 76009 94 10 minecraft:stone
execute in minecraft:overworld run fill 75993 94 11 76007 94 11 minecraft:stone
execute in minecraft:overworld run fill 75994 94 12 76006 94 12 minecraft:stone
execute in minecraft:overworld run fill 75997 94 13 76003 94 13 minecraft:stone
execute in minecraft:overworld run fill 75997 93 -11 76003 93 -11 minecraft:tuff
execute in minecraft:overworld run fill 75995 93 -10 76005 93 -10 minecraft:tuff
execute in minecraft:overworld run fill 75993 93 -9 76007 93 -9 minecraft:tuff
execute in minecraft:overworld run fill 75992 93 -8 76008 93 -8 minecraft:tuff
execute in minecraft:overworld run fill 75991 93 -7 76009 93 -7 minecraft:tuff
execute in minecraft:overworld run fill 75991 93 -6 76009 93 -6 minecraft:tuff
execute in minecraft:overworld run fill 75990 93 -5 76010 93 -5 minecraft:tuff
execute in minecraft:overworld run fill 75990 93 -4 76010 93 -4 minecraft:tuff
execute in minecraft:overworld run fill 75989 93 -3 76011 93 -3 minecraft:tuff
execute in minecraft:overworld run fill 75989 93 -2 76011 93 -2 minecraft:tuff
execute in minecraft:overworld run fill 75989 93 -1 76011 93 -1 minecraft:tuff
execute in minecraft:overworld run fill 75989 93 0 76011 93 0 minecraft:tuff
execute in minecraft:overworld run fill 75989 93 1 76011 93 1 minecraft:tuff
execute in minecraft:overworld run fill 75989 93 2 76011 93 2 minecraft:tuff
execute in minecraft:overworld run fill 75989 93 3 76011 93 3 minecraft:tuff
execute in minecraft:overworld run fill 75990 93 4 76010 93 4 minecraft:tuff
execute in minecraft:overworld run fill 75990 93 5 76010 93 5 minecraft:tuff
execute in minecraft:overworld run fill 75991 93 6 76009 93 6 minecraft:tuff
execute in minecraft:overworld run fill 75991 93 7 76009 93 7 minecraft:tuff
execute in minecraft:overworld run fill 75992 93 8 76008 93 8 minecraft:tuff
execute in minecraft:overworld run fill 75993 93 9 76007 93 9 minecraft:tuff
execute in minecraft:overworld run fill 75995 93 10 76005 93 10 minecraft:tuff
execute in minecraft:overworld run fill 75997 93 11 76003 93 11 minecraft:tuff
execute in minecraft:overworld run fill 75997 92 -9 76003 92 -9 minecraft:tuff
execute in minecraft:overworld run fill 75995 92 -8 76005 92 -8 minecraft:tuff
execute in minecraft:overworld run fill 75994 92 -7 76006 92 -7 minecraft:tuff
execute in minecraft:overworld run fill 75993 92 -6 76007 92 -6 minecraft:tuff
execute in minecraft:overworld run fill 75992 92 -5 76008 92 -5 minecraft:tuff
execute in minecraft:overworld run fill 75992 92 -4 76008 92 -4 minecraft:tuff
execute in minecraft:overworld run fill 75991 92 -3 76009 92 -3 minecraft:tuff
execute in minecraft:overworld run fill 75991 92 -2 76009 92 -2 minecraft:tuff
execute in minecraft:overworld run fill 75991 92 -1 76009 92 -1 minecraft:tuff
execute in minecraft:overworld run fill 75991 92 0 76009 92 0 minecraft:tuff
execute in minecraft:overworld run fill 75991 92 1 76009 92 1 minecraft:tuff
execute in minecraft:overworld run fill 75991 92 2 76009 92 2 minecraft:tuff
execute in minecraft:overworld run fill 75991 92 3 76009 92 3 minecraft:tuff
execute in minecraft:overworld run fill 75992 92 4 76008 92 4 minecraft:tuff
execute in minecraft:overworld run fill 75992 92 5 76008 92 5 minecraft:tuff
execute in minecraft:overworld run fill 75993 92 6 76007 92 6 minecraft:tuff
execute in minecraft:overworld run fill 75994 92 7 76006 92 7 minecraft:tuff
execute in minecraft:overworld run fill 75995 92 8 76005 92 8 minecraft:tuff
execute in minecraft:overworld run fill 75997 92 9 76003 92 9 minecraft:tuff
execute in minecraft:overworld run fill 75998 91 -7 76002 91 -7 minecraft:deepslate
execute in minecraft:overworld run fill 75996 91 -6 76004 91 -6 minecraft:deepslate
execute in minecraft:overworld run fill 75995 91 -5 76005 91 -5 minecraft:deepslate
execute in minecraft:overworld run fill 75994 91 -4 76006 91 -4 minecraft:deepslate
execute in minecraft:overworld run fill 75994 91 -3 76006 91 -3 minecraft:deepslate
execute in minecraft:overworld run fill 75993 91 -2 76007 91 -2 minecraft:deepslate
execute in minecraft:overworld run fill 75993 91 -1 76007 91 -1 minecraft:deepslate
execute in minecraft:overworld run fill 75993 91 0 76007 91 0 minecraft:deepslate
execute in minecraft:overworld run fill 75993 91 1 76007 91 1 minecraft:deepslate
execute in minecraft:overworld run fill 75993 91 2 76007 91 2 minecraft:deepslate
execute in minecraft:overworld run fill 75994 91 3 76006 91 3 minecraft:deepslate
execute in minecraft:overworld run fill 75994 91 4 76006 91 4 minecraft:deepslate
execute in minecraft:overworld run fill 75995 91 5 76005 91 5 minecraft:deepslate
execute in minecraft:overworld run fill 75996 91 6 76004 91 6 minecraft:deepslate
execute in minecraft:overworld run fill 75998 91 7 76002 91 7 minecraft:deepslate
execute in minecraft:overworld run fill 75998 90 -5 76002 90 -5 minecraft:deepslate
execute in minecraft:overworld run fill 75997 90 -4 76003 90 -4 minecraft:deepslate
execute in minecraft:overworld run fill 75996 90 -3 76004 90 -3 minecraft:deepslate
execute in minecraft:overworld run fill 75995 90 -2 76005 90 -2 minecraft:deepslate
execute in minecraft:overworld run fill 75995 90 -1 76005 90 -1 minecraft:deepslate
execute in minecraft:overworld run fill 75995 90 0 76005 90 0 minecraft:deepslate
execute in minecraft:overworld run fill 75995 90 1 76005 90 1 minecraft:deepslate
execute in minecraft:overworld run fill 75995 90 2 76005 90 2 minecraft:deepslate
execute in minecraft:overworld run fill 75996 90 3 76004 90 3 minecraft:deepslate
execute in minecraft:overworld run fill 75997 90 4 76003 90 4 minecraft:deepslate
execute in minecraft:overworld run fill 75998 90 5 76002 90 5 minecraft:deepslate
execute in minecraft:overworld run fill 75999 89 -3 76001 89 -3 minecraft:deepslate
execute in minecraft:overworld run fill 75998 89 -2 76002 89 -2 minecraft:deepslate
execute in minecraft:overworld run fill 75997 89 -1 76003 89 -1 minecraft:deepslate
execute in minecraft:overworld run fill 75997 89 0 76003 89 0 minecraft:deepslate
execute in minecraft:overworld run fill 75997 89 1 76003 89 1 minecraft:deepslate
execute in minecraft:overworld run fill 75998 89 2 76002 89 2 minecraft:deepslate
execute in minecraft:overworld run fill 75999 89 3 76001 89 3 minecraft:deepslate
execute in minecraft:overworld run fill 75999 88 -1 76001 88 -1 minecraft:amethyst_block
execute in minecraft:overworld run fill 75999 88 0 76001 88 0 minecraft:amethyst_block
execute in minecraft:overworld run fill 75999 88 1 76001 88 1 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76020 97 0 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76019 97 6 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76017 97 11 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76013 97 16 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76007 97 19 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76002 97 20 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75996 97 20 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75990 97 17 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75986 97 14 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75982 97 9 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75980 97 3 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75980 97 -2 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75982 97 -8 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75985 97 -13 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75989 97 -17 minecraft:hanging_roots
execute in minecraft:overworld run setblock 75995 97 -19 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76001 97 -20 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76007 97 -19 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76012 97 -16 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76016 97 -12 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76019 97 -7 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76020 97 -1 minecraft:hanging_roots
execute in minecraft:overworld run setblock 76013 93 2 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76010 93 8 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76005 93 12 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 75999 93 13 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 75993 93 11 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 75988 93 6 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 75987 93 0 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 75989 93 -7 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 75993 93 -11 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76000 93 -13 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76006 93 -11 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76011 93 -7 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76013 93 -1 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76000 87 0 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76020 100 2 minecraft:moss_block
execute in minecraft:overworld run setblock 76009 100 -15 minecraft:moss_block
execute in minecraft:overworld run setblock 76009 100 -4 minecraft:moss_block
execute in minecraft:overworld run setblock 76008 100 4 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76019 100 4 minecraft:moss_block
execute in minecraft:overworld run setblock 76001 100 9 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75983 100 12 minecraft:moss_block
execute in minecraft:overworld run setblock 75995 100 19 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75989 100 -15 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75999 100 12 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76000 100 8 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76005 100 -11 minecraft:moss_block
execute in minecraft:overworld run setblock 76017 100 -1 minecraft:moss_block
execute in minecraft:overworld run setblock 75995 100 9 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 75995 100 10 minecraft:moss_block
execute in minecraft:overworld run setblock 76014 100 4 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76010 100 15 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75994 100 17 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76001 100 -20 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 76009 100 1 minecraft:moss_block
execute in minecraft:overworld run setblock 76012 100 -16 minecraft:moss_block
execute in minecraft:overworld run setblock 76015 100 11 minecraft:moss_block
execute in minecraft:overworld run setblock 76002 100 -13 minecraft:moss_block
execute in minecraft:overworld run setblock 76001 100 14 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76016 100 -14 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75994 100 -11 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 76006 100 -14 minecraft:moss_block
execute in minecraft:overworld run setblock 76000 100 19 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 76000 100 20 minecraft:moss_block
execute in minecraft:overworld run setblock 75991 100 -9 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75982 100 -1 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 75994 100 -10 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 75990 100 -9 minecraft:moss_block
execute in minecraft:overworld run setblock 75995 100 -13 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 75987 100 2 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75988 100 17 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75992 100 6 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 76000 100 10 minecraft:moss_block
execute in minecraft:overworld run setblock 76002 100 14 minecraft:moss_block
execute in minecraft:overworld run setblock 75983 100 -2 minecraft:moss_block
execute in minecraft:overworld run setblock 75989 100 -18 minecraft:moss_block
execute in minecraft:overworld run setblock 75999 100 -14 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75999 100 -18 minecraft:moss_block
execute in minecraft:overworld run setblock 76014 100 14 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 75985 100 0 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75997 100 -18 minecraft:moss_block
execute in minecraft:overworld run setblock 75995 100 16 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 76001 100 14 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 75987 100 17 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76011 100 -2 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76011 100 15 minecraft:moss_block
execute in minecraft:overworld run setblock 75997 100 -18 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76010 100 -5 minecraft:moss_block
execute in minecraft:overworld run setblock 76003 100 7 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76013 100 -8 minecraft:moss_block
execute in minecraft:overworld run setblock 75986 100 7 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 75998 100 9 minecraft:rooted_dirt
execute in minecraft:overworld run setblock 76003 100 15 minecraft:moss_block
execute in minecraft:overworld run setblock 76017 100 -5 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 76006 100 20 minecraft:moss_block
execute in minecraft:overworld run setblock 76010 100 -8 minecraft:moss_block
execute in minecraft:overworld run setblock 76015 100 -7 minecraft:moss_block
execute in minecraft:overworld run setblock 75996 100 13 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75980 100 -2 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75980 100 1 minecraft:moss_block
execute in minecraft:overworld run setblock 75988 100 9 minecraft:moss_block
execute in minecraft:overworld run setblock 75982 100 -8 minecraft:moss_block
execute in minecraft:overworld run setblock 75985 100 -14 minecraft:coarse_dirt
execute in minecraft:overworld run setblock 75994 100 -2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75994 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75994 100 0 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75994 100 1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75994 100 2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75995 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75995 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75995 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75995 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75995 100 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75995 100 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75995 100 2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75995 100 3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75995 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 -4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75996 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75996 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75996 100 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75997 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75997 100 -4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75997 100 -3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75997 100 -2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75997 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75997 100 0 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75997 100 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75997 100 2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75997 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75997 100 4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75997 100 5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75998 100 -6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75998 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75998 100 -4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75998 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75998 100 -2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75998 100 2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75998 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75998 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75998 100 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75998 100 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75999 100 -6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75999 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75999 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75999 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75999 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75999 100 4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75999 100 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75999 100 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76000 100 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76000 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76000 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76000 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76000 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76000 100 4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76000 100 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76000 100 6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76001 100 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76001 100 -5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76001 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76001 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76001 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76001 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76001 100 5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76001 100 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76002 100 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76002 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76002 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76002 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76002 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76002 100 2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76002 100 3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76002 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76002 100 5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76002 100 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76003 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76003 100 -4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76003 100 -3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76003 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76003 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76003 100 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76003 100 1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76003 100 2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76003 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76003 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76003 100 5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76004 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76004 100 2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 -2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76005 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76005 100 2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76006 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76006 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76006 100 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76006 100 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76006 100 2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75985 100 -15 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75985 100 -14 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75985 100 15 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75986 100 -15 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75986 100 -14 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75986 100 -13 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75986 100 14 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75986 100 15 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75987 100 -14 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75987 100 -13 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75987 100 -12 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75987 100 13 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75987 100 14 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 100 -13 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75988 100 -12 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 100 -11 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 100 12 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 100 13 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75989 100 -12 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75989 100 -11 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75989 100 -10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75989 100 11 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75989 100 12 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75990 100 -11 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75990 100 -10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75990 100 -9 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75990 100 10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75990 100 11 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75991 100 -10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75991 100 -9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75991 100 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75991 100 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75991 100 10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75992 100 -9 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75992 100 -8 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75992 100 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75992 100 8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75992 100 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75993 100 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75993 100 -7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75993 100 -6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75993 100 7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75993 100 8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75994 100 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75994 100 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75994 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75994 100 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75994 100 7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75995 100 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75995 100 -5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75995 100 -4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75995 100 5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75995 100 6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75996 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 -4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75996 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75996 100 4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75996 100 5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75997 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75997 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 -3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76004 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76004 100 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 -5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76005 100 -4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76005 100 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76005 100 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76006 100 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76006 100 -5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76006 100 5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76006 100 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76006 100 7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76007 100 -7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76007 100 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76007 100 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76007 100 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76007 100 8 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76008 100 -8 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76008 100 -7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76008 100 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76008 100 8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76008 100 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76009 100 -9 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76009 100 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76009 100 8 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76009 100 9 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76009 100 10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76010 100 -10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76010 100 -9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76010 100 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76010 100 10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76010 100 11 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76011 100 -11 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76011 100 -10 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76011 100 10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76011 100 11 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76011 100 12 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 100 -12 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76012 100 -11 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 100 11 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 100 12 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 100 13 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76013 100 -13 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76013 100 -12 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76013 100 12 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76013 100 13 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76013 100 14 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76014 100 -14 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76014 100 -13 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76014 100 13 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76014 100 14 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76014 100 15 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76015 100 -15 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76015 100 -14 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76015 100 14 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76015 100 15 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76008 100 4 minecraft:sea_lantern
execute in minecraft:overworld run setblock 76005 100 8 minecraft:sea_lantern
execute in minecraft:overworld run setblock 75996 100 8 minecraft:sea_lantern
execute in minecraft:overworld run setblock 75992 100 4 minecraft:sea_lantern
execute in minecraft:overworld run setblock 75992 100 -5 minecraft:sea_lantern
execute in minecraft:overworld run setblock 75995 100 -8 minecraft:sea_lantern
execute in minecraft:overworld run setblock 76005 100 -8 minecraft:sea_lantern
execute in minecraft:overworld run setblock 76008 100 -5 minecraft:sea_lantern
execute in minecraft:overworld run fill 75999 101 -1 76001 112 1 minecraft:calcite
execute in minecraft:overworld run fill 75999 101 -1 75999 112 -1 minecraft:amethyst_block
execute in minecraft:overworld run fill 75999 101 1 75999 112 1 minecraft:amethyst_block
execute in minecraft:overworld run fill 76001 101 -1 76001 112 -1 minecraft:amethyst_block
execute in minecraft:overworld run fill 76001 101 1 76001 112 1 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76000 106 -1 minecraft:sea_lantern
execute in minecraft:overworld run setblock 76000 106 1 minecraft:sea_lantern
execute in minecraft:overworld run setblock 75999 106 0 minecraft:sea_lantern
execute in minecraft:overworld run setblock 76001 106 0 minecraft:sea_lantern
execute in minecraft:overworld run fill 75999 112 -3 76001 112 -3 minecraft:amethyst_block
execute in minecraft:overworld run fill 75998 112 -2 76002 112 -2 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 112 -1 76003 112 -1 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 112 0 76003 112 0 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 112 1 76003 112 1 minecraft:amethyst_block
execute in minecraft:overworld run fill 75998 112 2 76002 112 2 minecraft:amethyst_block
execute in minecraft:overworld run fill 75999 112 3 76001 112 3 minecraft:amethyst_block
execute in minecraft:overworld run fill 75998 113 -5 76002 113 -5 minecraft:calcite
execute in minecraft:overworld run fill 75997 113 -4 76003 113 -4 minecraft:calcite
execute in minecraft:overworld run fill 75996 113 -3 76004 113 -3 minecraft:calcite
execute in minecraft:overworld run fill 75995 113 -2 76005 113 -2 minecraft:calcite
execute in minecraft:overworld run fill 75995 113 -1 76005 113 -1 minecraft:calcite
execute in minecraft:overworld run fill 75995 113 0 76005 113 0 minecraft:calcite
execute in minecraft:overworld run fill 75995 113 1 76005 113 1 minecraft:calcite
execute in minecraft:overworld run fill 75995 113 2 76005 113 2 minecraft:calcite
execute in minecraft:overworld run fill 75996 113 3 76004 113 3 minecraft:calcite
execute in minecraft:overworld run fill 75997 113 4 76003 113 4 minecraft:calcite
execute in minecraft:overworld run fill 75998 113 5 76002 113 5 minecraft:calcite
execute in minecraft:overworld run setblock 75995 113 -2 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75995 113 -1 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75995 113 0 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75995 113 1 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75995 113 2 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75996 113 -3 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75996 113 3 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75997 113 -4 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75997 113 4 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75998 113 -5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75998 113 5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75999 113 -5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 75999 113 5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76000 113 -5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76000 113 5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76001 113 -5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76001 113 5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76002 113 -5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76002 113 5 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76003 113 -4 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76003 113 4 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76004 113 -3 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76004 113 3 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76005 113 -2 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76005 113 -1 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76005 113 0 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76005 113 1 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76005 113 2 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76000 113 0 minecraft:sea_lantern
execute in minecraft:overworld run setblock 75998 113 -1 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 75998 113 0 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 75998 113 1 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 75999 113 -2 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 75999 113 2 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 76000 113 -2 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 76000 113 2 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 76001 113 -2 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 76001 113 2 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 76002 113 -1 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 76002 113 0 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 76002 113 1 minecraft:smooth_quartz
execute in minecraft:overworld run fill 76015 101 -10 76015 103 -10 minecraft:stone_bricks
execute in minecraft:overworld run fill 76013 101 -9 76016 103 -9 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 -8 76016 103 -8 minecraft:stone_bricks
execute in minecraft:overworld run fill 76010 101 -7 76017 103 -7 minecraft:stone_bricks
execute in minecraft:overworld run fill 76010 101 -6 76017 103 -6 minecraft:stone_bricks
execute in minecraft:overworld run fill 76011 101 -5 76017 103 -5 minecraft:stone_bricks
execute in minecraft:overworld run fill 76011 101 -4 76018 103 -4 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 -3 76018 103 -3 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 -2 76018 103 -2 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 -1 76018 103 -1 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 0 76018 103 0 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 1 76018 103 1 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 2 76018 103 2 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 3 76018 103 3 minecraft:stone_bricks
execute in minecraft:overworld run fill 76011 101 4 76018 103 4 minecraft:stone_bricks
execute in minecraft:overworld run fill 76011 101 5 76017 103 5 minecraft:stone_bricks
execute in minecraft:overworld run fill 76010 101 6 76017 103 6 minecraft:stone_bricks
execute in minecraft:overworld run fill 76010 101 7 76017 103 7 minecraft:stone_bricks
execute in minecraft:overworld run fill 76012 101 8 76016 103 8 minecraft:stone_bricks
execute in minecraft:overworld run fill 76013 101 9 76016 103 9 minecraft:stone_bricks
execute in minecraft:overworld run fill 76015 101 10 76015 103 10 minecraft:stone_bricks
execute in minecraft:overworld run fill 76015 104 -10 76015 104 -10 minecraft:grass_block
execute in minecraft:overworld run fill 76013 104 -9 76016 104 -9 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 -8 76016 104 -8 minecraft:grass_block
execute in minecraft:overworld run fill 76010 104 -7 76017 104 -7 minecraft:grass_block
execute in minecraft:overworld run fill 76010 104 -6 76017 104 -6 minecraft:grass_block
execute in minecraft:overworld run fill 76011 104 -5 76017 104 -5 minecraft:grass_block
execute in minecraft:overworld run fill 76011 104 -4 76018 104 -4 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 -3 76018 104 -3 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 -2 76018 104 -2 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 -1 76018 104 -1 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 0 76018 104 0 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 1 76018 104 1 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 2 76018 104 2 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 3 76018 104 3 minecraft:grass_block
execute in minecraft:overworld run fill 76011 104 4 76018 104 4 minecraft:grass_block
execute in minecraft:overworld run fill 76011 104 5 76017 104 5 minecraft:grass_block
execute in minecraft:overworld run fill 76010 104 6 76017 104 6 minecraft:grass_block
execute in minecraft:overworld run fill 76010 104 7 76017 104 7 minecraft:grass_block
execute in minecraft:overworld run fill 76012 104 8 76016 104 8 minecraft:grass_block
execute in minecraft:overworld run fill 76013 104 9 76016 104 9 minecraft:grass_block
execute in minecraft:overworld run fill 76015 104 10 76015 104 10 minecraft:grass_block
execute in minecraft:overworld run setblock 76015 102 -10 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76017 102 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76018 102 -3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76018 102 -2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76018 102 2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76018 102 4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76010 104 -7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76010 104 -6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76010 104 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76010 104 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76011 104 -7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76011 104 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76011 104 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76011 104 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76011 104 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76011 104 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76012 104 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 104 -3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76012 104 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 104 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 104 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 104 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76012 104 2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 104 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76012 104 8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76013 104 -9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76013 104 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76014 104 -9 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76014 104 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76015 104 -10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76015 104 10 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76016 104 -9 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76016 104 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76016 104 8 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76016 104 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76017 104 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76017 104 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76017 104 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76017 104 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76017 104 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76017 104 7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76018 104 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76018 104 -3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76018 104 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76018 104 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76018 104 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76018 104 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76018 104 2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 76018 104 3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 76018 104 4 minecraft:stone_bricks
execute in minecraft:overworld run fill 76009 101 -1 76009 101 1 minecraft:polished_andesite
execute in minecraft:overworld run fill 76010 101 -1 76010 102 1 minecraft:polished_andesite
execute in minecraft:overworld run fill 76011 101 -1 76011 103 1 minecraft:polished_andesite
execute in minecraft:overworld run fill 76014 105 5 76014 106 5 minecraft:stone_brick_wall
execute in minecraft:overworld run setblock 76014 107 5 minecraft:lantern
execute in minecraft:overworld run setblock 76015 105 -5 minecraft:flowering_azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 76016 105 -5 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run fill 75985 101 -10 75985 103 -10 minecraft:stone_bricks
execute in minecraft:overworld run fill 75984 101 -9 75987 103 -9 minecraft:stone_bricks
execute in minecraft:overworld run fill 75984 101 -8 75988 103 -8 minecraft:stone_bricks
execute in minecraft:overworld run fill 75983 101 -7 75990 103 -7 minecraft:stone_bricks
execute in minecraft:overworld run fill 75983 101 -6 75990 103 -6 minecraft:stone_bricks
execute in minecraft:overworld run fill 75983 101 -5 75989 103 -5 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 -4 75989 103 -4 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 -3 75988 103 -3 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 -2 75988 103 -2 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 -1 75988 103 -1 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 0 75988 103 0 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 1 75988 103 1 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 2 75988 103 2 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 3 75988 103 3 minecraft:stone_bricks
execute in minecraft:overworld run fill 75982 101 4 75989 103 4 minecraft:stone_bricks
execute in minecraft:overworld run fill 75983 101 5 75989 103 5 minecraft:stone_bricks
execute in minecraft:overworld run fill 75983 101 6 75990 103 6 minecraft:stone_bricks
execute in minecraft:overworld run fill 75983 101 7 75990 103 7 minecraft:stone_bricks
execute in minecraft:overworld run fill 75984 101 8 75988 103 8 minecraft:stone_bricks
execute in minecraft:overworld run fill 75984 101 9 75987 103 9 minecraft:stone_bricks
execute in minecraft:overworld run fill 75985 101 10 75985 103 10 minecraft:stone_bricks
execute in minecraft:overworld run fill 75985 104 -10 75985 104 -10 minecraft:grass_block
execute in minecraft:overworld run fill 75984 104 -9 75987 104 -9 minecraft:grass_block
execute in minecraft:overworld run fill 75984 104 -8 75988 104 -8 minecraft:grass_block
execute in minecraft:overworld run fill 75983 104 -7 75990 104 -7 minecraft:grass_block
execute in minecraft:overworld run fill 75983 104 -6 75990 104 -6 minecraft:grass_block
execute in minecraft:overworld run fill 75983 104 -5 75989 104 -5 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 -4 75989 104 -4 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 -3 75988 104 -3 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 -2 75988 104 -2 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 -1 75988 104 -1 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 0 75988 104 0 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 1 75988 104 1 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 2 75988 104 2 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 3 75988 104 3 minecraft:grass_block
execute in minecraft:overworld run fill 75982 104 4 75989 104 4 minecraft:grass_block
execute in minecraft:overworld run fill 75983 104 5 75989 104 5 minecraft:grass_block
execute in minecraft:overworld run fill 75983 104 6 75990 104 6 minecraft:grass_block
execute in minecraft:overworld run fill 75983 104 7 75990 104 7 minecraft:grass_block
execute in minecraft:overworld run fill 75984 104 8 75988 104 8 minecraft:grass_block
execute in minecraft:overworld run fill 75984 104 9 75987 104 9 minecraft:grass_block
execute in minecraft:overworld run fill 75985 104 10 75985 104 10 minecraft:grass_block
execute in minecraft:overworld run setblock 75982 102 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75983 102 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75984 102 -9 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75984 102 -8 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75985 102 -10 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75982 104 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75982 104 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75982 104 -2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75982 104 -1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75982 104 0 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75982 104 1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75982 104 2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75982 104 3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75982 104 4 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75983 104 -7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75983 104 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75983 104 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75983 104 5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75983 104 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75983 104 7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75984 104 -9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75984 104 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75984 104 8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75984 104 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75985 104 -10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75985 104 10 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75986 104 -9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75986 104 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75987 104 -9 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75987 104 9 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 104 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 104 -3 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 104 -2 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75988 104 -1 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 104 0 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75988 104 1 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75988 104 2 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75988 104 3 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75988 104 8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75989 104 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75989 104 -5 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75989 104 -4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75989 104 4 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75989 104 5 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75989 104 7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75990 104 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 75990 104 -6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75990 104 6 minecraft:stone_bricks
execute in minecraft:overworld run setblock 75990 104 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 75991 101 -1 75991 101 1 minecraft:polished_andesite
execute in minecraft:overworld run fill 75990 101 -1 75990 102 1 minecraft:polished_andesite
execute in minecraft:overworld run fill 75989 101 -1 75989 103 1 minecraft:polished_andesite
execute in minecraft:overworld run fill 75986 105 -5 75986 106 -5 minecraft:stone_brick_wall
execute in minecraft:overworld run setblock 75986 107 -5 minecraft:lantern
execute in minecraft:overworld run setblock 75985 105 5 minecraft:flowering_azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 75986 105 5 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run fill 75999 108 11 76001 108 11 minecraft:amethyst_block
execute in minecraft:overworld run fill 75998 108 12 76002 108 12 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 108 13 76003 108 13 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 108 14 76003 108 14 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 108 15 76003 108 15 minecraft:amethyst_block
execute in minecraft:overworld run fill 75998 108 16 76002 108 16 minecraft:amethyst_block
execute in minecraft:overworld run fill 75999 108 17 76001 108 17 minecraft:amethyst_block
execute in minecraft:overworld run fill 75999 107 12 76001 107 12 minecraft:calcite
execute in minecraft:overworld run fill 75998 107 13 76002 107 13 minecraft:calcite
execute in minecraft:overworld run fill 75998 107 14 76002 107 14 minecraft:calcite
execute in minecraft:overworld run fill 75998 107 15 76002 107 15 minecraft:calcite
execute in minecraft:overworld run fill 75999 107 16 76001 107 16 minecraft:calcite
execute in minecraft:overworld run setblock 76000 106 14 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76000 105 14 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76000 108 14 minecraft:sea_lantern
execute in minecraft:overworld run setblock 76003 109 14 minecraft:amethyst_cluster[facing=up]
execute in minecraft:overworld run setblock 75997 109 14 minecraft:small_amethyst_bud[facing=up]
execute in minecraft:overworld run fill 75999 100 8 76001 100 10 minecraft:polished_andesite
execute in minecraft:overworld run setblock 76000 100 9 minecraft:purple_glazed_terracotta
execute in minecraft:overworld run fill 75999 108 -17 76001 108 -17 minecraft:amethyst_block
execute in minecraft:overworld run fill 75998 108 -16 76002 108 -16 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 108 -15 76003 108 -15 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 108 -14 76003 108 -14 minecraft:amethyst_block
execute in minecraft:overworld run fill 75997 108 -13 76003 108 -13 minecraft:amethyst_block
execute in minecraft:overworld run fill 75998 108 -12 76002 108 -12 minecraft:amethyst_block
execute in minecraft:overworld run fill 75999 108 -11 76001 108 -11 minecraft:amethyst_block
execute in minecraft:overworld run fill 75999 107 -16 76001 107 -16 minecraft:calcite
execute in minecraft:overworld run fill 75998 107 -15 76002 107 -15 minecraft:calcite
execute in minecraft:overworld run fill 75998 107 -14 76002 107 -14 minecraft:calcite
execute in minecraft:overworld run fill 75998 107 -13 76002 107 -13 minecraft:calcite
execute in minecraft:overworld run fill 75999 107 -12 76001 107 -12 minecraft:calcite
execute in minecraft:overworld run setblock 76000 106 -14 minecraft:amethyst_block
execute in minecraft:overworld run setblock 76000 105 -14 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run setblock 76000 108 -14 minecraft:sea_lantern
execute in minecraft:overworld run setblock 75997 109 -14 minecraft:amethyst_cluster[facing=up]
execute in minecraft:overworld run setblock 76003 109 -14 minecraft:small_amethyst_bud[facing=up]
execute in minecraft:overworld run fill 75999 100 -10 76001 100 -8 minecraft:polished_andesite
execute in minecraft:overworld run setblock 76000 100 -9 minecraft:purple_glazed_terracotta
execute in minecraft:overworld run fill 76018 97 16 76022 97 16 minecraft:grass_block
execute in minecraft:overworld run fill 76017 97 17 76023 97 17 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 18 76024 97 18 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 19 76024 97 19 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 20 76024 97 20 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 21 76024 97 21 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 22 76024 97 22 minecraft:grass_block
execute in minecraft:overworld run fill 76017 97 23 76023 97 23 minecraft:grass_block
execute in minecraft:overworld run fill 76018 97 24 76022 97 24 minecraft:grass_block
execute in minecraft:overworld run fill 76018 96 16 76022 96 16 minecraft:dirt
execute in minecraft:overworld run fill 76017 96 17 76023 96 17 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 18 76024 96 18 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 19 76024 96 19 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 20 76024 96 20 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 21 76024 96 21 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 22 76024 96 22 minecraft:dirt
execute in minecraft:overworld run fill 76017 96 23 76023 96 23 minecraft:dirt
execute in minecraft:overworld run fill 76018 96 24 76022 96 24 minecraft:dirt
execute in minecraft:overworld run fill 76019 95 17 76021 95 17 minecraft:stone
execute in minecraft:overworld run fill 76018 95 18 76022 95 18 minecraft:stone
execute in minecraft:overworld run fill 76017 95 19 76023 95 19 minecraft:stone
execute in minecraft:overworld run fill 76017 95 20 76023 95 20 minecraft:stone
execute in minecraft:overworld run fill 76017 95 21 76023 95 21 minecraft:stone
execute in minecraft:overworld run fill 76018 95 22 76022 95 22 minecraft:stone
execute in minecraft:overworld run fill 76019 95 23 76021 95 23 minecraft:stone
execute in minecraft:overworld run fill 76019 94 18 76021 94 18 minecraft:tuff
execute in minecraft:overworld run fill 76018 94 19 76022 94 19 minecraft:tuff
execute in minecraft:overworld run fill 76018 94 20 76022 94 20 minecraft:tuff
execute in minecraft:overworld run fill 76018 94 21 76022 94 21 minecraft:tuff
execute in minecraft:overworld run fill 76019 94 22 76021 94 22 minecraft:tuff
execute in minecraft:overworld run setblock 76020 93 20 minecraft:deepslate
execute in minecraft:overworld run setblock 76020 92 20 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run fill 76020 98 20 76020 99 20 minecraft:mossy_stone_brick_wall
execute in minecraft:overworld run setblock 76020 100 20 minecraft:lantern
execute in minecraft:overworld run setblock 76022 98 19 minecraft:short_grass
execute in minecraft:overworld run setblock 76018 98 21 minecraft:allium
execute in minecraft:overworld run setblock 76019 98 18 minecraft:short_grass
execute in minecraft:overworld run fill 75978 97 16 75982 97 16 minecraft:grass_block
execute in minecraft:overworld run fill 75977 97 17 75983 97 17 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 18 75984 97 18 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 19 75984 97 19 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 20 75984 97 20 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 21 75984 97 21 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 22 75984 97 22 minecraft:grass_block
execute in minecraft:overworld run fill 75977 97 23 75983 97 23 minecraft:grass_block
execute in minecraft:overworld run fill 75978 97 24 75982 97 24 minecraft:grass_block
execute in minecraft:overworld run fill 75978 96 16 75982 96 16 minecraft:dirt
execute in minecraft:overworld run fill 75977 96 17 75983 96 17 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 18 75984 96 18 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 19 75984 96 19 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 20 75984 96 20 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 21 75984 96 21 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 22 75984 96 22 minecraft:dirt
execute in minecraft:overworld run fill 75977 96 23 75983 96 23 minecraft:dirt
execute in minecraft:overworld run fill 75978 96 24 75982 96 24 minecraft:dirt
execute in minecraft:overworld run fill 75979 95 17 75981 95 17 minecraft:stone
execute in minecraft:overworld run fill 75978 95 18 75982 95 18 minecraft:stone
execute in minecraft:overworld run fill 75977 95 19 75983 95 19 minecraft:stone
execute in minecraft:overworld run fill 75977 95 20 75983 95 20 minecraft:stone
execute in minecraft:overworld run fill 75977 95 21 75983 95 21 minecraft:stone
execute in minecraft:overworld run fill 75978 95 22 75982 95 22 minecraft:stone
execute in minecraft:overworld run fill 75979 95 23 75981 95 23 minecraft:stone
execute in minecraft:overworld run fill 75979 94 18 75981 94 18 minecraft:tuff
execute in minecraft:overworld run fill 75978 94 19 75982 94 19 minecraft:tuff
execute in minecraft:overworld run fill 75978 94 20 75982 94 20 minecraft:tuff
execute in minecraft:overworld run fill 75978 94 21 75982 94 21 minecraft:tuff
execute in minecraft:overworld run fill 75979 94 22 75981 94 22 minecraft:tuff
execute in minecraft:overworld run setblock 75980 93 20 minecraft:deepslate
execute in minecraft:overworld run setblock 75980 92 20 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run fill 75980 98 20 75980 99 20 minecraft:mossy_stone_brick_wall
execute in minecraft:overworld run setblock 75980 100 20 minecraft:lantern
execute in minecraft:overworld run setblock 75982 98 19 minecraft:short_grass
execute in minecraft:overworld run setblock 75978 98 21 minecraft:allium
execute in minecraft:overworld run setblock 75979 98 18 minecraft:short_grass
execute in minecraft:overworld run fill 75978 97 -24 75982 97 -24 minecraft:grass_block
execute in minecraft:overworld run fill 75977 97 -23 75983 97 -23 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 -22 75984 97 -22 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 -21 75984 97 -21 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 -20 75984 97 -20 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 -19 75984 97 -19 minecraft:grass_block
execute in minecraft:overworld run fill 75976 97 -18 75984 97 -18 minecraft:grass_block
execute in minecraft:overworld run fill 75977 97 -17 75983 97 -17 minecraft:grass_block
execute in minecraft:overworld run fill 75978 97 -16 75982 97 -16 minecraft:grass_block
execute in minecraft:overworld run fill 75978 96 -24 75982 96 -24 minecraft:dirt
execute in minecraft:overworld run fill 75977 96 -23 75983 96 -23 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 -22 75984 96 -22 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 -21 75984 96 -21 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 -20 75984 96 -20 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 -19 75984 96 -19 minecraft:dirt
execute in minecraft:overworld run fill 75976 96 -18 75984 96 -18 minecraft:dirt
execute in minecraft:overworld run fill 75977 96 -17 75983 96 -17 minecraft:dirt
execute in minecraft:overworld run fill 75978 96 -16 75982 96 -16 minecraft:dirt
execute in minecraft:overworld run fill 75979 95 -23 75981 95 -23 minecraft:stone
execute in minecraft:overworld run fill 75978 95 -22 75982 95 -22 minecraft:stone
execute in minecraft:overworld run fill 75977 95 -21 75983 95 -21 minecraft:stone
execute in minecraft:overworld run fill 75977 95 -20 75983 95 -20 minecraft:stone
execute in minecraft:overworld run fill 75977 95 -19 75983 95 -19 minecraft:stone
execute in minecraft:overworld run fill 75978 95 -18 75982 95 -18 minecraft:stone
execute in minecraft:overworld run fill 75979 95 -17 75981 95 -17 minecraft:stone
execute in minecraft:overworld run fill 75979 94 -22 75981 94 -22 minecraft:tuff
execute in minecraft:overworld run fill 75978 94 -21 75982 94 -21 minecraft:tuff
execute in minecraft:overworld run fill 75978 94 -20 75982 94 -20 minecraft:tuff
execute in minecraft:overworld run fill 75978 94 -19 75982 94 -19 minecraft:tuff
execute in minecraft:overworld run fill 75979 94 -18 75981 94 -18 minecraft:tuff
execute in minecraft:overworld run setblock 75980 93 -20 minecraft:deepslate
execute in minecraft:overworld run setblock 75980 92 -20 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run fill 75980 98 -20 75980 99 -20 minecraft:mossy_stone_brick_wall
execute in minecraft:overworld run setblock 75980 100 -20 minecraft:lantern
execute in minecraft:overworld run setblock 75982 98 -21 minecraft:short_grass
execute in minecraft:overworld run setblock 75978 98 -19 minecraft:allium
execute in minecraft:overworld run setblock 75979 98 -22 minecraft:short_grass
execute in minecraft:overworld run fill 76018 97 -24 76022 97 -24 minecraft:grass_block
execute in minecraft:overworld run fill 76017 97 -23 76023 97 -23 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 -22 76024 97 -22 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 -21 76024 97 -21 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 -20 76024 97 -20 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 -19 76024 97 -19 minecraft:grass_block
execute in minecraft:overworld run fill 76016 97 -18 76024 97 -18 minecraft:grass_block
execute in minecraft:overworld run fill 76017 97 -17 76023 97 -17 minecraft:grass_block
execute in minecraft:overworld run fill 76018 97 -16 76022 97 -16 minecraft:grass_block
execute in minecraft:overworld run fill 76018 96 -24 76022 96 -24 minecraft:dirt
execute in minecraft:overworld run fill 76017 96 -23 76023 96 -23 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 -22 76024 96 -22 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 -21 76024 96 -21 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 -20 76024 96 -20 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 -19 76024 96 -19 minecraft:dirt
execute in minecraft:overworld run fill 76016 96 -18 76024 96 -18 minecraft:dirt
execute in minecraft:overworld run fill 76017 96 -17 76023 96 -17 minecraft:dirt
execute in minecraft:overworld run fill 76018 96 -16 76022 96 -16 minecraft:dirt
execute in minecraft:overworld run fill 76019 95 -23 76021 95 -23 minecraft:stone
execute in minecraft:overworld run fill 76018 95 -22 76022 95 -22 minecraft:stone
execute in minecraft:overworld run fill 76017 95 -21 76023 95 -21 minecraft:stone
execute in minecraft:overworld run fill 76017 95 -20 76023 95 -20 minecraft:stone
execute in minecraft:overworld run fill 76017 95 -19 76023 95 -19 minecraft:stone
execute in minecraft:overworld run fill 76018 95 -18 76022 95 -18 minecraft:stone
execute in minecraft:overworld run fill 76019 95 -17 76021 95 -17 minecraft:stone
execute in minecraft:overworld run fill 76019 94 -22 76021 94 -22 minecraft:tuff
execute in minecraft:overworld run fill 76018 94 -21 76022 94 -21 minecraft:tuff
execute in minecraft:overworld run fill 76018 94 -20 76022 94 -20 minecraft:tuff
execute in minecraft:overworld run fill 76018 94 -19 76022 94 -19 minecraft:tuff
execute in minecraft:overworld run fill 76019 94 -18 76021 94 -18 minecraft:tuff
execute in minecraft:overworld run setblock 76020 93 -20 minecraft:deepslate
execute in minecraft:overworld run setblock 76020 92 -20 minecraft:amethyst_cluster[facing=down]
execute in minecraft:overworld run fill 76020 98 -20 76020 99 -20 minecraft:mossy_stone_brick_wall
execute in minecraft:overworld run setblock 76020 100 -20 minecraft:lantern
execute in minecraft:overworld run setblock 76022 98 -21 minecraft:short_grass
execute in minecraft:overworld run setblock 76018 98 -19 minecraft:allium
execute in minecraft:overworld run setblock 76019 98 -22 minecraft:short_grass
execute in minecraft:overworld run setblock 76002 101 -13 minecraft:poppy
execute in minecraft:overworld run setblock 75991 101 8 minecraft:cornflower
execute in minecraft:overworld run setblock 75992 101 10 minecraft:short_grass
execute in minecraft:overworld run setblock 76005 101 -20 minecraft:azure_bluet
execute in minecraft:overworld run setblock 75998 101 -15 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 76004 101 16 minecraft:azure_bluet
execute in minecraft:overworld run setblock 75993 101 -19 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 76019 101 6 minecraft:azure_bluet
execute in minecraft:overworld run setblock 76013 101 11 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 75991 101 11 minecraft:short_grass
execute in minecraft:overworld run setblock 76008 101 11 minecraft:short_grass
execute in minecraft:overworld run setblock 75981 101 3 minecraft:poppy
execute in minecraft:overworld run setblock 75997 101 16 minecraft:allium
execute in minecraft:overworld run setblock 75990 101 14 minecraft:poppy
execute in minecraft:overworld run setblock 75990 101 -8 minecraft:poppy
execute in minecraft:overworld run setblock 76008 101 18 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 76003 101 13 minecraft:short_grass
execute in minecraft:overworld run setblock 76012 101 -10 minecraft:allium
execute in minecraft:overworld run setblock 75991 101 -3 minecraft:allium
execute in minecraft:overworld run setblock 76013 101 -15 minecraft:allium
execute in minecraft:overworld run setblock 76004 101 10 minecraft:short_grass
execute in minecraft:overworld run setblock 75990 101 -17 minecraft:short_grass
execute in minecraft:overworld run setblock 75998 101 18 minecraft:azure_bluet
execute in minecraft:overworld run setblock 76007 101 -4 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 75983 101 8 minecraft:short_grass
execute in minecraft:overworld run setblock 76004 101 19 minecraft:poppy
execute in minecraft:overworld run setblock 75983 101 9 minecraft:short_grass
execute in minecraft:overworld run setblock 75994 101 15 minecraft:azure_bluet
execute in minecraft:overworld run setblock 75982 101 10 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 75990 101 -5 minecraft:azure_bluet
execute in minecraft:overworld run setblock 75990 101 19 minecraft:short_grass
execute in minecraft:overworld run setblock 75998 101 17 minecraft:azure_bluet
execute in minecraft:overworld run setblock 75981 101 10 minecraft:short_grass
execute in minecraft:overworld run setblock 75996 101 -16 minecraft:short_grass
execute in minecraft:overworld run setblock 76007 101 -16 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 75994 101 18 minecraft:short_grass
execute in minecraft:overworld run setblock 76018 101 10 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 76019 101 -7 minecraft:azure_bluet
execute in minecraft:overworld run setblock 76009 101 -15 minecraft:allium
execute in minecraft:overworld run setblock 76010 101 12 minecraft:allium
execute in minecraft:overworld run setblock 75981 101 -8 minecraft:short_grass
execute in minecraft:overworld run setblock 75997 101 19 minecraft:allium
execute in minecraft:overworld run setblock 76009 101 -4 minecraft:cornflower
execute in minecraft:overworld run setblock 75992 101 -6 minecraft:short_grass
execute in minecraft:overworld run setblock 76013 101 -11 minecraft:short_grass
execute in minecraft:overworld run setblock 75992 101 14 minecraft:short_grass
execute in minecraft:overworld run setblock 75982 101 5 minecraft:allium
execute in minecraft:overworld run setblock 76002 101 -20 minecraft:poppy
execute in minecraft:overworld run setblock 75980 101 -2 minecraft:allium
execute in minecraft:overworld run setblock 75995 101 -12 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 76008 101 16 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 76005 101 19 minecraft:allium
execute in minecraft:overworld run setblock 75989 101 13 minecraft:cornflower
execute in minecraft:overworld run setblock 76003 101 7 minecraft:short_grass
execute in minecraft:overworld run setblock 75981 101 1 minecraft:poppy
execute in minecraft:overworld run setblock 76002 101 13 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 76005 101 16 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 75983 101 -9 minecraft:cornflower
execute in minecraft:overworld run setblock 75988 101 -10 minecraft:cornflower
execute in minecraft:overworld run setblock 75981 101 -2 minecraft:azure_bluet
execute in minecraft:overworld run setblock 76010 101 17 minecraft:short_grass
execute in minecraft:overworld run setblock 76017 101 13 minecraft:short_grass
execute in minecraft:overworld run setblock 76020 101 -6 minecraft:poppy
execute in minecraft:overworld run setblock 75986 101 -11 minecraft:poppy
execute in minecraft:overworld run setblock 75993 101 6 minecraft:allium
execute in minecraft:overworld run setblock 76007 101 -14 minecraft:short_grass
execute in minecraft:overworld run setblock 75992 101 4 minecraft:azure_bluet
execute in minecraft:overworld run setblock 76017 101 -10 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 75980 101 7 minecraft:short_grass
execute in minecraft:overworld run setblock 75996 101 -17 minecraft:cornflower
execute in minecraft:overworld run setblock 76009 101 6 minecraft:cornflower
execute in minecraft:overworld run setblock 75982 101 -8 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 76011 101 16 minecraft:short_grass
execute in minecraft:overworld run setblock 76008 101 10 minecraft:azure_bluet
execute in minecraft:overworld run setblock 75987 101 17 minecraft:allium
execute in minecraft:overworld run setblock 75996 101 -15 minecraft:allium
execute in minecraft:overworld run setblock 75992 101 -16 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 76009 101 7 minecraft:azure_bluet
execute in minecraft:overworld run setblock 76012 101 -15 minecraft:short_grass
execute in minecraft:overworld run setblock 75983 101 -13 minecraft:cornflower
execute in minecraft:overworld run setblock 75981 101 -5 minecraft:short_grass
execute in minecraft:overworld run setblock 76002 101 -12 minecraft:short_grass
execute in minecraft:overworld run setblock 75991 101 -6 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 76008 101 17 minecraft:flowering_azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 76008 101 18 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 75992 101 17 minecraft:flowering_azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 75992 101 18 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 75992 101 -17 minecraft:flowering_azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 75992 101 -16 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 76008 101 -17 minecraft:flowering_azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 76008 101 -16 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run summon minecraft:text_display 76000.5 118.6 0.5 {Tags:["mg_holo","mg_kbffah"],billboard:"center",background:0,shadow:true,text:{"text": "KNOCKBACK-FFA", "color": "light_purple", "italic": false, "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.4f,2.4f,2.4f]}}
execute in minecraft:overworld run summon minecraft:text_display 76000.5 117.8 0.5 {Tags:["mg_holo","mg_kbffah"],billboard:"center",background:0,shadow:true,text:[{"text": "Stoß alle ins Nichts!  ", "color": "white", "italic": false}, {"text": "Kein PvP am Spawn", "color": "gray", "italic": false}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.0f,1.0f,1.0f]}}
execute in minecraft:overworld run summon minecraft:text_display 76000.5 102.2 9.5 {Tags:["mg_holo","mg_kbffah"],billboard:"center",background:0,shadow:true,text:{"text": "⇧ Sprungfeld", "color": "light_purple", "italic": false},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
execute in minecraft:overworld run summon minecraft:text_display 76000.5 102.2 -9.5 {Tags:["mg_holo","mg_kbffah"],billboard:"center",background:0,shadow:true,text:{"text": "⇧ Sprungfeld", "color": "light_purple", "italic": false},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}
