execute in minecraft:overworld run kill @e[type=minecraft:item,x=75960,dx=79,y=33,dy=100,z=-39,dz=78]
execute in minecraft:overworld run kill @e[type=minecraft:ender_pearl,x=75960,dx=79,y=33,dy=100,z=-39,dz=78]
execute in minecraft:overworld run forceload remove 75960 -39 76039 39
scoreboard players set #kbffa mg 0
