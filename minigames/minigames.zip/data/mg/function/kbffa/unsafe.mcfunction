tag @s remove mg_kbffa_safe
tag @s remove mg_kbffa_fresh
effect clear @s minecraft:weakness
attribute @s minecraft:knockback_resistance modifier remove mg:kbffa_safe
execute unless score @s mg_kbffa_pv matches 1.. run effect clear @s minecraft:resistance
playsound minecraft:item.armor.equip_leather master @s ~ ~ ~ 0.7 0.8
