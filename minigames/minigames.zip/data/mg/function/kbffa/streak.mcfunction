execute if score @s mg_kbffa_s matches 3 run effect give @s minecraft:speed 20 0 true
execute if score @s mg_kbffa_s matches 3 run title @s actionbar {"text": "3er-Serie! Tempo für 20 Sekunden", "color": "aqua", "italic": false, "bold": true}
execute if score @s mg_kbffa_s matches 3 run scoreboard players set @s mg_kbffa_hold 40
execute if score @s mg_kbffa_s matches 5 run give @s minecraft:ender_pearl[minecraft:lore=[{"text": "Wird 10 s nach dem Werfen aufgefüllt", "color": "gray", "italic": false}]] 1
execute if score @s mg_kbffa_s matches 5 run function mg:kbffa/coin {n:2}
execute if score @s mg_kbffa_s matches 5 run tellraw @a[tag=mg_kbffa] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " hat eine ", "color": "yellow", "italic": false}, {"text": "5er-Serie", "color": "red", "italic": false, "bold": true}, {"text": "! Extra-Enderperle.", "color": "yellow", "italic": false}]
execute if score @s mg_kbffa_s matches 5 run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
execute if score @s mg_kbffa_s matches 10 run function mg:kbffa/st10
scoreboard players operation #kbffa_m5 mg = @s mg_kbffa_s
scoreboard players operation #kbffa_m5 mg %= #5 mg
execute if score @s mg_kbffa_s matches 15.. if score #kbffa_m5 mg matches 0 run function mg:kbffa/st15
