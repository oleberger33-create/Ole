tag @s add mg_kbffa_rsp
execute in minecraft:overworld run execute as @e[type=minecraft:ender_pearl,x=75960,dx=79,y=33,dy=100,z=-39,dz=78] at @s on origin if entity @s[tag=mg_kbffa_rsp] run kill @e[type=minecraft:ender_pearl,distance=..0.5,limit=1,sort=nearest]
tag @s remove mg_kbffa_rsp
tag @s remove mg_kbffa_rech
tag @s add mg_kbffa_fresh
scoreboard players set @s mg_kbffa_s 0
scoreboard players set @s mg_kbffa_lt 0
scoreboard players set @s mg_kbffa_lh 0
scoreboard players set @s mg_kbffa_pc 0
scoreboard players set @s mg_kbffa_sp 0
scoreboard players set @s mg_kbffa_dd 0
scoreboard players set @s mg_kbffa_dt 0
scoreboard players set @s mg_deaths 0
scoreboard players set @s mg_kbffa_pv 40
effect clear @s
effect give @s minecraft:instant_health 1 5 true
effect give @s minecraft:saturation infinite 0 true
effect give @s minecraft:resistance 2 4 true
effect give @s minecraft:weakness 2 100 true
function mg:kbffa/kit
function mg:kbffa/tp_spawn
execute at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1.4
execute at @s run particle minecraft:reverse_portal ~ ~1 ~ 0.3 0.6 0.3 0.05 30
