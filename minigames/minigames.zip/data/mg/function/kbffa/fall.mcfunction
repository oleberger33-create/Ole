scoreboard players add @s mg_kbffa_d 1
scoreboard players set #kbffa_lh mg 0
execute if score @s mg_kbffa_lt matches 1.. run scoreboard players operation #kbffa_lh mg = @s mg_kbffa_lh
scoreboard players operation #kbffa_vs mg = @s mg_kbffa_s
scoreboard players set #kbffa_kf mg 0
tag @s add mg_kbffa_vic
scoreboard players operation #kbffa_vid mg = @s mg_kbffa_pid
execute if score #kbffa_lh mg matches 1.. as @a[tag=mg_kbffa,tag=!mg_kbffa_vic,tag=!mg_kbffa_wait] if score @s mg_kbffa_id = #kbffa_lh mg at @s run function mg:kbffa/kill
execute if score #kbffa_kf mg matches 0 run tellraw @a[tag=mg_kbffa] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist ins Nichts gestürzt.", "color": "gray", "italic": false}]
execute if score #kbffa_kf mg matches 0 if score #kbffa_vs mg matches 3.. run tellraw @a[tag=mg_kbffa] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die ", "color": "gray", "italic": false}, {"score": {"name": "#kbffa_vs", "objective": "mg"}, "color": "red", "bold": true}, {"text": "er-Serie von ", "color": "gray", "italic": false}, {"selector": "@s", "color": "white"}, {"text": " ist vorbei.", "color": "gray", "italic": false}]
execute if score #kbffa_kf mg matches 0 run title @s times 0 25 8
execute if score #kbffa_kf mg matches 0 run title @s title {"text": "Abgestürzt!", "color": "red", "italic": false, "bold": true}
execute if score #kbffa_kf mg matches 0 run title @s subtitle {"text": "Pass auf die Kante auf", "color": "gray", "italic": false}
execute at @s run playsound minecraft:entity.player.hurt_on_fire master @s ~ ~ ~ 0.5 0.6
tag @s remove mg_kbffa_vic
function mg:kbffa/respawn
