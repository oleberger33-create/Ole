function mg:kbffa/build
scoreboard players set #kbffa mg 2
scoreboard players set #kbffa_t mg 0
execute as @a[tag=mg_kbffa_wait] at @s run function mg:kbffa/enter
