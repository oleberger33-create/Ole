clear @s
item replace entity @s hotbar.0 with minecraft:stick[minecraft:enchantments={"minecraft:knockback":2},minecraft:custom_name={"text": "Rückstoß-Stock", "color": "gold", "italic": false, "bold": true},minecraft:lore=[{"text": "Rückstoß II – schubs sie ins Nichts!", "color": "gray", "italic": false}],minecraft:custom_data={mg_kbffa_stick:1b},minecraft:tooltip_display={hidden_components:["minecraft:enchantments","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_place_on"]}]
item replace entity @s hotbar.1 with minecraft:sandstone[minecraft:can_place_on={blocks:["minecraft:grass_block","minecraft:moss_block","minecraft:coarse_dirt","minecraft:rooted_dirt","minecraft:dirt","minecraft:stone","minecraft:andesite","minecraft:tuff","minecraft:deepslate","minecraft:stone_bricks","minecraft:mossy_stone_bricks","minecraft:polished_andesite","minecraft:sandstone","minecraft:yellow_terracotta","minecraft:orange_terracotta","minecraft:red_terracotta"]},minecraft:custom_name={"text": "Sandstein", "color": "yellow", "italic": false, "bold": true},minecraft:lore=[{"text": "Zerfällt nach etwa 8 Sekunden", "color": "gray", "italic": false}],minecraft:tooltip_display={hidden_components:["minecraft:enchantments","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_place_on"]}] 64
item replace entity @s hotbar.2 with minecraft:ender_pearl[minecraft:lore=[{"text": "Wird 10 s nach dem Werfen aufgefüllt", "color": "gray", "italic": false}]] 1
item replace entity @s hotbar.8 with minecraft:carrot_on_a_stick[minecraft:item_model="minecraft:barrier",minecraft:custom_name={"text": "Spiel verlassen", "color": "red", "italic": false, "bold": true},minecraft:lore=[{"text": "Rechtsklick: zurück in die Lobby", "color": "gray", "italic": false}],minecraft:custom_data={mg_kbffa_leave:1b},minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:enchantments","minecraft:unbreakable","minecraft:dyed_color","minecraft:can_place_on"]}]
execute if score @s mg_kbffa_col matches 0 run function mg:kbffa/armor0
execute if score @s mg_kbffa_col matches 1 run function mg:kbffa/armor1
execute if score @s mg_kbffa_col matches 2 run function mg:kbffa/armor2
execute if score @s mg_kbffa_col matches 3 run function mg:kbffa/armor3
execute if score @s mg_kbffa_col matches 4 run function mg:kbffa/armor4
execute if score @s mg_kbffa_col matches 5 run function mg:kbffa/armor5
execute if score @s mg_kbffa_col matches 6 run function mg:kbffa/armor6
execute if score @s mg_kbffa_col matches 7 run function mg:kbffa/armor7
