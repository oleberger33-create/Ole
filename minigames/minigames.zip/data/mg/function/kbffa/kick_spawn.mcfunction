title @s actionbar {"text": "Zu lange am Spawn – ab in den Kampf!", "color": "red", "italic": false, "bold": true}
function mg:kbffa/drop
