scoreboard players set @s mg_kbffa_dt 0
scoreboard players set #kbffa_lh mg 0
scoreboard players operation #kbffa_lh mg = @p[tag=mg_kbffa_atk,distance=0.01..8] mg_kbffa_id
execute if score #kbffa_lh mg matches 1.. run scoreboard players operation @s mg_kbffa_lh = #kbffa_lh mg
execute if score #kbffa_lh mg matches 1.. run scoreboard players set @s mg_kbffa_lt 200
