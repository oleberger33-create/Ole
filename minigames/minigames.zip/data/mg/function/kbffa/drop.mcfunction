execute store result score #kbffa_r mg run random value 0..3
execute if score #kbffa_r mg matches 0 in minecraft:overworld run tp @s 76004.5 101 4.5 -45 0
execute if score #kbffa_r mg matches 1 in minecraft:overworld run tp @s 75996.5 101 4.5 45 0
execute if score #kbffa_r mg matches 2 in minecraft:overworld run tp @s 75996.5 101 -4.5 135 0
execute if score #kbffa_r mg matches 3 in minecraft:overworld run tp @s 76004.5 101 -4.5 225 0
scoreboard players set @s mg_kbffa_hold 40
execute at @s run playsound minecraft:entity.breeze.wind_burst master @s ~ ~ ~ 0.8 1
