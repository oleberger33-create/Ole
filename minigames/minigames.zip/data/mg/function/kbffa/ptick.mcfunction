execute if entity @s[y=-64,dy=151] run return run function mg:kbffa/fall
execute unless entity @s[x=75966,dx=68,z=-34,dz=68,y=-64,dy=500] run return run function mg:kbffa/fall
execute if score @s mg_kbffa_lt matches 1.. run scoreboard players remove @s mg_kbffa_lt 1
execute if score @s mg_kbffa_pv matches 1.. run scoreboard players remove @s mg_kbffa_pv 1
execute if score @s mg_kbffa_pad matches 1.. run scoreboard players remove @s mg_kbffa_pad 1
execute if entity @s[x=75993,dx=14,y=109,dy=12,z=-7,dz=14] run function mg:kbffa/zone
execute if entity @s[tag=mg_kbffa_safe] unless entity @s[x=75993,dx=14,y=109,dy=12,z=-7,dz=14] run function mg:kbffa/unsafe
execute if block ~ ~-1 ~ minecraft:purple_glazed_terracotta unless score @s mg_kbffa_pad matches 1.. run function mg:kbffa/pad
execute store result score @s mg_kbffa_n run clear @s minecraft:ender_pearl 0
execute if score @s mg_kbffa_n matches 1.. run scoreboard players set @s mg_kbffa_pc 0
execute if score @s mg_kbffa_n matches 0 run function mg:kbffa/pearl
execute if score @s mg_kbffa_hold matches 1.. run scoreboard players remove @s mg_kbffa_hold 1
execute if score #kbffa_m10 mg matches 0 run function mg:kbffa/hud
