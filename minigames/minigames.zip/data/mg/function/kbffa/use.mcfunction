scoreboard players set @s mg_kbffa_use 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg_kbffa_leave:1b}] run function mg:hub/quit
