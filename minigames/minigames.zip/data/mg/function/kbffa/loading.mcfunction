scoreboard players add #kbffa_lw mg 1
execute in minecraft:overworld run tp @a[tag=mg_kbffa_wait] 76000.5 114 0.5
title @a[tag=mg_kbffa_wait] actionbar {"text": "Arena wird geladen …", "color": "light_purple", "italic": false}
execute in minecraft:overworld if loaded 75960 100 -39 if loaded 76039 100 39 if loaded 75960 100 39 if loaded 76039 100 -39 run function mg:kbffa/ready
execute if score #kbffa_lw mg matches 200.. run execute in minecraft:overworld run forceload add 75960 -39 76039 39
