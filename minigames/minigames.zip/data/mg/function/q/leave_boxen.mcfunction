tag @s remove mg_q_boxen
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Boxen verlassen.", "color": "gray"}]
