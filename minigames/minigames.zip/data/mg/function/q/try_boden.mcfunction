execute store result score #n mg if entity @a[tag=mg_q_boden,tag=mg_hub]
execute if score #n mg matches ..1 run return 0
execute unless score #arenas mg matches 3 run return 0
tag @r[tag=mg_q_boden,tag=mg_hub] add mg_p1
tag @r[tag=mg_q_boden,tag=mg_hub,tag=!mg_p1] add mg_p2
tag @a[tag=mg_p1,tag=mg_q_boden] add mg_duel_boden
tag @a[tag=mg_p2,tag=mg_q_boden] add mg_duel_boden
tag @a[tag=mg_duel_boden] remove mg_q_boden
tag @a[tag=mg_duel_boden] remove mg_hub
tag @a[tag=mg_duel_boden] add mg_duel
scoreboard players set @a[tag=mg_duel_boden] mg_round 0
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_duel_boden,tag=mg_p1,limit=1]", "color": "white"}, {"text": " vs ", "color": "gray"}, {"selector": "@a[tag=mg_duel_boden,tag=mg_p2,limit=1]", "color": "white"}, {"text": "  –  Fallender Boden", "color": "green", "bold": true}]
function mg:boden/round
