function mg:q/leave_all
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du bist in keiner Warteschlange mehr.", "color": "gray"}]
