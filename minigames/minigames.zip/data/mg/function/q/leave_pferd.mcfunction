tag @s remove mg_q_pferd
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Pferderennen verlassen.", "color": "gray"}]
