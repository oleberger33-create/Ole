tag @s remove mg_q_kb
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Knockback-Stock verlassen.", "color": "gray"}]
