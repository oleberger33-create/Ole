tag @s remove mg_q_pfeil
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Ein Pfeil verlassen.", "color": "gray"}]
