tag @s remove mg_q_wind
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Windstoß verlassen.", "color": "gray"}]
