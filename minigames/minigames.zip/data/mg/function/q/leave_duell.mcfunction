tag @s remove mg_q_duell
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Duell verlassen.", "color": "gray"}]
