tag @s remove mg_q_spleef
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Spleef verlassen.", "color": "gray"}]
