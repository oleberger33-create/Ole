execute store result score #n mg if entity @a[tag=mg_q_kolben,tag=mg_hub]
execute if score #n mg matches ..1 run return 0
execute unless score #arenas mg matches 2 run return 0
tag @r[tag=mg_q_kolben,tag=mg_hub] add mg_p1
tag @r[tag=mg_q_kolben,tag=mg_hub,tag=!mg_p1] add mg_p2
tag @a[tag=mg_p1,tag=mg_q_kolben] add mg_duel_kolben
tag @a[tag=mg_p2,tag=mg_q_kolben] add mg_duel_kolben
tag @a[tag=mg_duel_kolben] remove mg_q_kolben
tag @a[tag=mg_duel_kolben] remove mg_hub
tag @a[tag=mg_duel_kolben] add mg_duel
scoreboard players set @a[tag=mg_duel_kolben] mg_round 0
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_duel_kolben,tag=mg_p1,limit=1]", "color": "white"}, {"text": " vs ", "color": "gray"}, {"selector": "@a[tag=mg_duel_kolben,tag=mg_p2,limit=1]", "color": "white"}, {"text": "  –  Streitkolben", "color": "dark_purple", "bold": true}]
function mg:kolben/round
