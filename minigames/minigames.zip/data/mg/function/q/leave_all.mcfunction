tag @s remove mg_q_sumo
tag @s remove mg_q_spleef
tag @s remove mg_q_duell
tag @s remove mg_duel_sumo
tag @s remove mg_duel_spleef
tag @s remove mg_duel_duell
