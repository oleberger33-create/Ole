execute if entity @s[tag=mg_q_kolben] run return run function mg:q/leave_kolben
function mg:q/leave_all
tag @s add mg_q_kolben
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange ", "color": "gray"}, {"text": "Streitkolben", "color": "dark_purple", "bold": true}, {"text": " – sobald ein Gegner dabei ist, geht es los.", "color": "gray"}]
tellraw @a[tag=mg_hub,tag=!mg_q_kolben] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " wartet auf einen Gegner für ", "color": "gray"}, {"text": "Streitkolben", "color": "dark_purple", "bold": true}, {"text": " – ", "color": "gray"}, {"text": "[Annehmen]", "color": "green", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 7"}}]
