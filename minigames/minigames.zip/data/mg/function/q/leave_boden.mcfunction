tag @s remove mg_q_boden
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Fallender Boden verlassen.", "color": "gray"}]
