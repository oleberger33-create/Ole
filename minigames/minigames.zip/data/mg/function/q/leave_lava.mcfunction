tag @s remove mg_q_lava
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Steigende Lava verlassen.", "color": "gray"}]
