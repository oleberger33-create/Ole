tag @s remove mg_q_bruecke
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Brücken-Duell verlassen.", "color": "gray"}]
