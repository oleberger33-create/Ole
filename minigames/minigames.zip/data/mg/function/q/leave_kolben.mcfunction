tag @s remove mg_q_kolben
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Streitkolben verlassen.", "color": "gray"}]
