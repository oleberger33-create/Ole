tag @s remove mg_q_sumo
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Sumo verlassen.", "color": "gray"}]
