tag @s remove mg_q_parkour
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Parkour-Duell verlassen.", "color": "gray"}]
