tag @s remove mg_q_stickbett
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange Stick-Fight Bett verlassen.", "color": "gray"}]
