execute unless entity @a[tag=mg_q_duell,tag=mg_hub] run return 0
execute store result score #n mg if entity @a[tag=mg_q_duell,tag=mg_hub]
execute if score #n mg matches ..1 run return 0
tag @r[tag=mg_q_duell,tag=mg_hub] add mg_p1
tag @r[tag=mg_q_duell,tag=mg_hub,tag=!mg_p1] add mg_p2
tag @a[tag=mg_p1] add mg_duel_duell
tag @a[tag=mg_p2] add mg_duel_duell
tag @a[tag=mg_duel_duell] remove mg_q_duell
tag @a[tag=mg_duel_duell] remove mg_hub
tag @a[tag=mg_duel_duell] add mg_duel
scoreboard players set @a[tag=mg_duel_duell] mg_round 0
scoreboard players set #duell mg 1
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_p1,tag=mg_duel_duell]", "color": "white"}, {"text": " vs ", "color": "gray"}, {"selector": "@a[tag=mg_p2,tag=mg_duel_duell]", "color": "white"}, {"text": "  –  Duell", "color": "red", "bold": true}]
function mg:duell/round
