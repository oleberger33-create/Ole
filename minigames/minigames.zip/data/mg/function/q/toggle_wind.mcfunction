execute if entity @s[tag=mg_q_wind] run return run function mg:q/leave_wind
function mg:q/leave_all
tag @s add mg_q_wind
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Warteschlange ", "color": "gray"}, {"text": "Windstoß", "color": "white", "bold": true}, {"text": " – sobald ein Gegner dabei ist, geht es los.", "color": "gray"}]
tellraw @a[tag=mg_hub,tag=!mg_q_wind] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " wartet auf einen Gegner für ", "color": "gray"}, {"text": "Windstoß", "color": "white", "bold": true}, {"text": " – ", "color": "gray"}, {"text": "[Annehmen]", "color": "green", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 4"}}]
