execute unless score #bruecke mg matches 2 run return 0
scoreboard players add @s mg_round 1
tag @a[tag=mg_duel_bruecke] remove mg_rw
tag @s add mg_rw
execute as @a[tag=mg_duel_bruecke] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if score @s mg_round matches 3.. run return run function mg:bruecke/win
tellraw @a[tag=mg_duel_bruecke] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " trifft ins Tor! ", "color": "blue"}, {"score": {"name": "@a[tag=mg_duel_bruecke,tag=mg_p1,limit=1]", "objective": "mg_round"}, "color": "white"}, {"text": " : ", "color": "gray"}, {"score": {"name": "@a[tag=mg_duel_bruecke,tag=mg_p2,limit=1]", "objective": "mg_round"}, "color": "white"}]
scoreboard players set #bruecke mg 1
function mg:bruecke/round
