execute if score #bruecke_cd mg matches 1.. run scoreboard players remove #bruecke_cd mg 1
execute if score #bruecke mg matches 1 if score #bruecke_cd mg matches 0 run function mg:bruecke/go
execute if score #bruecke mg matches 1 if score #bruecke_cd mg matches 0 run scoreboard players set #bruecke mg 2
execute unless score #bruecke mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_bruecke]
execute if score #n mg matches ..1 run return run function mg:bruecke/forfeit
execute as @a[tag=mg_duel_bruecke,scores={mg_deaths=1..}] run function mg:bruecke/respawn
execute as @a[tag=mg_duel_bruecke] at @s if entity @s[y=-64,dy=156] run function mg:bruecke/respawn
execute as @a[tag=mg_duel_bruecke,tag=mg_p1,limit=1] if entity @s[x=10016,dx=2,y=96,dy=4,z=-1,dz=2] run function mg:bruecke/point
execute as @a[tag=mg_duel_bruecke,tag=mg_p2,limit=1] if entity @s[x=9982,dx=2,y=96,dy=4,z=-1,dz=2] run function mg:bruecke/point
