execute as @a[tag=mg_duel_bruecke] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Brücken-Duell – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_bruecke] mg_wins 1
scoreboard players add @a[tag=mg_duel_bruecke] mg_coins 5
function mg:bruecke/stop
