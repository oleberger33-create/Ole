execute unless score #bruecke mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_bruecke] remove mg_rw
tag @a[tag=mg_duel_bruecke] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_bruecke] mg_round 1
tellraw @a[tag=mg_duel_bruecke] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_bruecke]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "blue"}]
execute as @a[tag=mg_duel_bruecke] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_bruecke,scores={mg_round=3..}] run return run function mg:bruecke/win
scoreboard players set #bruecke mg 1
function mg:bruecke/round
