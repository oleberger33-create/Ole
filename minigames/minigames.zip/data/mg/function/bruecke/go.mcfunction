execute in minecraft:overworld run fill 9989 94 -12 10011 112 12 minecraft:air
execute in minecraft:overworld run fill 9999 100 -1 10001 100 1 minecraft:white_concrete
execute in minecraft:overworld run kill @e[type=minecraft:item,x=9955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=9955,dx=90,y=70,dy=80,z=-45,dz=90]
title @a[tag=mg_duel_bruecke] actionbar {"text": "LOS!", "color": "blue", "bold": true}
execute as @a[tag=mg_duel_bruecke] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
