title @a[tag=mg_duel_bruecke] actionbar {"text": "LOS!", "color": "blue", "bold": true}
execute as @a[tag=mg_duel_bruecke] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
