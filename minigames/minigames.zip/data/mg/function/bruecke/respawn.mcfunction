scoreboard players set @s mg_deaths 0
execute if entity @s[tag=mg_p1] run execute in minecraft:overworld run tp @s 9987 101 0 -90 0
execute if entity @s[tag=mg_p2] run execute in minecraft:overworld run tp @s 10013 101 0 90 0
execute unless items entity @s container.* minecraft:stone_sword run function mg:bruecke/kit
effect clear @s minecraft:slowness
