function mg:bruecke/wipe
execute in minecraft:overworld run fill 9989 94 -12 10011 112 12 minecraft:air
execute in minecraft:overworld run fill 9999 100 -1 10001 100 1 minecraft:white_concrete
execute in minecraft:overworld run kill @e[type=minecraft:item,x=9955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=9955,dx=90,y=70,dy=80,z=-45,dz=90]
execute as @a[tag=mg_duel_bruecke] run function mg:bruecke/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_bruecke,tag=mg_p1,limit=1] 9987 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_bruecke,tag=mg_p2,limit=1] 10013 101 0 90 0
execute as @a[tag=mg_duel_bruecke,tag=mg_p1,limit=1] run execute in minecraft:overworld run spawnpoint @s 9987 101 0
execute as @a[tag=mg_duel_bruecke,tag=mg_p2,limit=1] run execute in minecraft:overworld run spawnpoint @s 10013 101 0
kill @e[type=minecraft:horse,tag=mg_horse_bruecke]
scoreboard players set #bruecke_cd mg 60
scoreboard players set #bruecke mg 1
title @a[tag=mg_duel_bruecke] times 0 30 10
title @a[tag=mg_duel_bruecke] title {"text": "Brücken-Duell", "color": "blue", "bold": true}
title @a[tag=mg_duel_bruecke] subtitle [{"score":{"name":"@a[tag=mg_duel_bruecke,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_bruecke,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
scoreboard players add #bruecke_r mg 1
