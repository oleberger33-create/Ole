execute in minecraft:overworld run fill 9969 90 -23 9978 122 23 minecraft:air replace minecraft:white_wool
execute in minecraft:overworld run fill 9979 90 -23 9988 122 23 minecraft:air replace minecraft:white_wool
execute in minecraft:overworld run fill 9989 90 -23 9998 122 23 minecraft:air replace minecraft:white_wool
execute in minecraft:overworld run fill 9999 90 -23 10008 122 23 minecraft:air replace minecraft:white_wool
execute in minecraft:overworld run fill 10009 90 -23 10018 122 23 minecraft:air replace minecraft:white_wool
execute in minecraft:overworld run fill 10019 90 -23 10028 122 23 minecraft:air replace minecraft:white_wool
execute in minecraft:overworld run fill 10029 90 -23 10031 122 23 minecraft:air replace minecraft:white_wool
