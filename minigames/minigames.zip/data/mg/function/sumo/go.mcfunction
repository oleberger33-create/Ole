title @a[tag=mg_duel_sumo] actionbar {"text": "LOS!", "color": "yellow", "bold": true}
execute as @a[tag=mg_duel_sumo] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
