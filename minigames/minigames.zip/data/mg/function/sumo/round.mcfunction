execute as @a[tag=mg_duel_sumo] run function mg:sumo/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_sumo,tag=mg_p1,limit=1] 2997 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_sumo,tag=mg_p2,limit=1] 3003 101 0 90 0
execute as @a[tag=mg_duel_sumo] run execute in minecraft:overworld run spawnpoint @s 0 101 0
kill @e[type=minecraft:horse,tag=mg_horse_sumo]
scoreboard players set #sumo_cd mg 60
scoreboard players set #sumo mg 1
title @a[tag=mg_duel_sumo] times 0 30 10
title @a[tag=mg_duel_sumo] title {"text": "Sumo", "color": "yellow", "bold": true}
title @a[tag=mg_duel_sumo] subtitle [{"score":{"name":"@a[tag=mg_duel_sumo,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_sumo,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
