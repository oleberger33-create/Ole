execute as @a[tag=mg_duel_sumo] run function mg:sumo/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_sumo,tag=mg_p1] 2997 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_sumo,tag=mg_p2] 3003 101 0 90 0
scoreboard players set #sumo_cd mg 60
scoreboard players set #sumo mg 1
title @a[tag=mg_duel_sumo] times 0 30 10
title @a[tag=mg_duel_sumo] title {"text": "Runde", "color": "yellow", "bold": true}
title @a[tag=mg_duel_sumo] subtitle [{"score":{"name":"@a[tag=mg_p1,tag=mg_duel_sumo]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_p2,tag=mg_duel_sumo]","objective":"mg_round"},"color":"white"}]
