execute as @a[tag=mg_duel_sumo] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Sumo – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_sumo] mg_wins 1
scoreboard players add @a[tag=mg_duel_sumo] mg_coins 5
function mg:sumo/stop
