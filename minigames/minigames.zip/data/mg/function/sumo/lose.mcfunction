execute if score #sumo mg matches ..1 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_sumo] remove mg_rw
tag @a[tag=mg_duel_sumo] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_sumo] mg_round 1
tellraw @a[tag=mg_duel_sumo] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_sumo]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "yellow"}]
execute as @a[tag=mg_duel_sumo] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_sumo,scores={mg_round=2..}] run return run function mg:sumo/win
scoreboard players set #sumo mg 1
function mg:sumo/round
