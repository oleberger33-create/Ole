execute if score #sumo_cd mg matches 1.. run scoreboard players remove #sumo_cd mg 1
execute if score #sumo_cd mg matches 1.. run return 0
execute if score #sumo mg matches 1 run title @a[tag=mg_duel_sumo] actionbar {"text": "LOS!", "color": "yellow", "bold": true}
scoreboard players set #sumo mg 2
execute store result score #n mg if entity @a[tag=mg_duel_sumo]
execute if score #n mg matches ..1 run return run function mg:sumo/forfeit
execute as @a[tag=mg_duel_sumo,scores={mg_deaths=1..}] run function mg:sumo/lose
execute as @a[tag=mg_duel_sumo] at @s if entity @s[y=-64,dy=160] run function mg:sumo/lose
