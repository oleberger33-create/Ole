execute if score #sumo_cd mg matches 1.. run scoreboard players remove #sumo_cd mg 1
execute if score #sumo mg matches 1 if score #sumo_cd mg matches 0 run function mg:sumo/go
execute if score #sumo mg matches 1 if score #sumo_cd mg matches 0 run scoreboard players set #sumo mg 2
execute if score #sumo mg matches 1 run execute in minecraft:overworld run kill @e[type=#mg:projectiles,x=2955,dx=90,y=70,dy=80,z=-45,dz=90]
execute unless score #sumo mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_sumo]
execute if score #n mg matches ..1 run return run function mg:sumo/forfeit
execute as @a[tag=mg_duel_sumo] at @s if entity @s[y=-64,dy=160] run function mg:sumo/lose
execute as @e[type=minecraft:player,tag=mg_duel_sumo,scores={mg_deaths=1..}] run function mg:sumo/lose
