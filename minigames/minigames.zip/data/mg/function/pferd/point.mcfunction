execute unless score #pferd mg matches 2 run return 0
scoreboard players add @s mg_round 1
tag @a[tag=mg_duel_pferd] remove mg_rw
tag @s add mg_rw
execute as @a[tag=mg_duel_pferd] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if score @s mg_round matches 1.. run return run function mg:pferd/win
