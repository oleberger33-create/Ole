scoreboard players set #pferd mg 0
kill @e[type=minecraft:horse,tag=mg_horse_pferd]
execute as @a[tag=mg_duel_pferd] run function mg:hub/enter
tag @a remove mg_duel_pferd
tag @a[tag=mg_hub] remove mg_rw
execute in minecraft:overworld run kill @e[type=minecraft:item,x=13955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=13955,dx=90,y=70,dy=80,z=-45,dz=90]
