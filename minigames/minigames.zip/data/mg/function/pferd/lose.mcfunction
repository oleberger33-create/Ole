execute unless score #pferd mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_pferd] remove mg_rw
tag @a[tag=mg_duel_pferd] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_pferd] mg_round 1
tellraw @a[tag=mg_duel_pferd] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_pferd]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "gold"}]
execute as @a[tag=mg_duel_pferd] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_pferd,scores={mg_round=1..}] run return run function mg:pferd/win
scoreboard players set #pferd mg 1
function mg:pferd/round
