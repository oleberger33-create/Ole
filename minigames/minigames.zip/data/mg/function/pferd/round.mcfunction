execute as @a[tag=mg_duel_pferd] run function mg:pferd/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_pferd,tag=mg_p1,limit=1] 14020 101 -3 0 0
execute in minecraft:overworld run tp @a[tag=mg_duel_pferd,tag=mg_p2,limit=1] 14024 101 -3 0 0
execute as @a[tag=mg_duel_pferd] run execute in minecraft:overworld run spawnpoint @s 0 101 0
kill @e[type=minecraft:horse,tag=mg_horse_pferd]
scoreboard players set #pferd_cd mg 60
scoreboard players set #pferd mg 1
title @a[tag=mg_duel_pferd] times 0 30 10
title @a[tag=mg_duel_pferd] title {"text": "Pferderennen", "color": "gold", "bold": true}
title @a[tag=mg_duel_pferd] subtitle [{"score":{"name":"@a[tag=mg_duel_pferd,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_pferd,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
