execute in minecraft:overworld run summon minecraft:horse 14020 101 -3 {Tags:["mg_horse_pferd","mg_h1"],Tame:1b,PersistenceRequired:1b,Invulnerable:1b,Rotation:[0f,0f],attributes:[{id:"minecraft:movement_speed",base:0.34d},{id:"minecraft:jump_strength",base:0.6d},{id:"minecraft:max_health",base:30d}],equipment:{saddle:{id:"minecraft:saddle",count:1}}}
ride @a[tag=mg_duel_pferd,tag=mg_p1,limit=1] mount @e[type=minecraft:horse,tag=mg_h1,limit=1]
execute in minecraft:overworld run summon minecraft:horse 14024 101 -3 {Tags:["mg_horse_pferd","mg_h2"],Tame:1b,PersistenceRequired:1b,Invulnerable:1b,Rotation:[0f,0f],attributes:[{id:"minecraft:movement_speed",base:0.34d},{id:"minecraft:jump_strength",base:0.6d},{id:"minecraft:max_health",base:30d}],equipment:{saddle:{id:"minecraft:saddle",count:1}}}
ride @a[tag=mg_duel_pferd,tag=mg_p2,limit=1] mount @e[type=minecraft:horse,tag=mg_h2,limit=1]
title @a[tag=mg_duel_pferd] actionbar {"text": "LOS!", "color": "gold", "bold": true}
execute as @a[tag=mg_duel_pferd] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
