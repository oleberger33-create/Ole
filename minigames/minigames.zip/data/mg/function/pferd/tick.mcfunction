execute if score #pferd_cd mg matches 1.. run scoreboard players remove #pferd_cd mg 1
execute if score #pferd mg matches 1 if score #pferd_cd mg matches 0 run function mg:pferd/go
execute if score #pferd mg matches 1 if score #pferd_cd mg matches 0 run scoreboard players set #pferd mg 2
execute unless score #pferd mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_pferd]
execute if score #n mg matches ..1 run return run function mg:pferd/forfeit
execute as @a[tag=mg_duel_pferd,scores={mg_gate=0}] if entity @s[x=13999,dx=2,y=100,dy=4,z=17,dz=10] run function mg:pferd/gate
execute as @a[tag=mg_duel_pferd,scores={mg_gate=1}] if entity @s[x=13973,dx=10,y=100,dy=4,z=-1,dz=2] run function mg:pferd/gate
execute as @a[tag=mg_duel_pferd,scores={mg_gate=2}] if entity @s[x=13999,dx=2,y=100,dy=4,z=-27,dz=10] run function mg:pferd/gate
execute as @a[tag=mg_duel_pferd,scores={mg_gate=3}] if entity @s[x=14017,dx=10,y=100,dy=4,z=0,dz=2] run function mg:pferd/gate
execute as @a[tag=mg_duel_pferd] run title @s actionbar [{"text":"Runde ","color":"gray"},{"score":{"name":"@s","objective":"mg_lap"},"color":"white","bold":true},{"text":"/2","color":"gray"}]
