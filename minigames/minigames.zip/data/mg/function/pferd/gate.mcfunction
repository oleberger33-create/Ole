scoreboard players add @s mg_gate 1
execute if score @s mg_gate matches 4.. run scoreboard players add @s mg_lap 1
execute if score @s mg_gate matches 4.. run scoreboard players set @s mg_gate 0
execute at @s run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1.4
execute if score @s mg_lap matches 2.. run function mg:pferd/point
