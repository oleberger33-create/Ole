execute if score #pferd_r mg matches 2.. as @a[tag=mg_duel_pferd] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Pferderennen – Gegner ist weg.", "color": "white"}]
execute if score #pferd_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_pferd] mg_wins 1
execute if score #pferd_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_pferd] mg_coins 5
execute if score #pferd_r mg matches ..1 run tellraw @a[tag=mg_duel_pferd] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dein Gegner ist weg, bevor eine Runde fertig war – keine Wertung.", "color": "gray"}]
function mg:pferd/stop
