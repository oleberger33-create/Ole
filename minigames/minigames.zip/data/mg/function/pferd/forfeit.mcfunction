execute as @a[tag=mg_duel_pferd] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Pferderennen – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_pferd] mg_wins 1
scoreboard players add @a[tag=mg_duel_pferd] mg_coins 5
function mg:pferd/stop
