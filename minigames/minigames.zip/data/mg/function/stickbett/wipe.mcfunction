execute in minecraft:overworld run fill 15969 90 -23 15978 122 23 minecraft:air replace minecraft:sandstone
execute in minecraft:overworld run fill 15979 90 -23 15988 122 23 minecraft:air replace minecraft:sandstone
execute in minecraft:overworld run fill 15989 90 -23 15998 122 23 minecraft:air replace minecraft:sandstone
execute in minecraft:overworld run fill 15999 90 -23 16008 122 23 minecraft:air replace minecraft:sandstone
execute in minecraft:overworld run fill 16009 90 -23 16018 122 23 minecraft:air replace minecraft:sandstone
execute in minecraft:overworld run fill 16019 90 -23 16028 122 23 minecraft:air replace minecraft:sandstone
execute in minecraft:overworld run fill 16029 90 -23 16031 122 23 minecraft:air replace minecraft:sandstone
