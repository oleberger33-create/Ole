execute unless score #stickbett mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_stickbett] remove mg_rw
tag @a[tag=mg_duel_stickbett] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_stickbett] mg_round 1
tellraw @a[tag=mg_duel_stickbett] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_stickbett]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "yellow"}]
execute as @a[tag=mg_duel_stickbett] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_stickbett,scores={mg_round=5..}] run return run function mg:stickbett/win
scoreboard players set #stickbett mg 1
function mg:stickbett/round
