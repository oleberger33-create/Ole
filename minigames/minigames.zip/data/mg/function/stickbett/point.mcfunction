execute unless score #stickbett mg matches 2 run return 0
scoreboard players add @s mg_round 1
tag @a[tag=mg_duel_stickbett] remove mg_rw
tag @s add mg_rw
execute as @a[tag=mg_duel_stickbett] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if score @s mg_round matches 5.. run return run function mg:stickbett/win
tellraw @a[tag=mg_duel_stickbett] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " zerstört das Bett! ", "color": "yellow"}, {"score": {"name": "@a[tag=mg_duel_stickbett,tag=mg_p1,limit=1]", "objective": "mg_round"}, "color": "white"}, {"text": " : ", "color": "gray"}, {"score": {"name": "@a[tag=mg_duel_stickbett,tag=mg_p2,limit=1]", "objective": "mg_round"}, "color": "white"}]
scoreboard players set #stickbett mg 1
function mg:stickbett/round
