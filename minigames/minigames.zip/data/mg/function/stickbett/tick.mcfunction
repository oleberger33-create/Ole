execute if score #stickbett_cd mg matches 1.. run scoreboard players remove #stickbett_cd mg 1
execute if score #stickbett mg matches 1 if score #stickbett_cd mg matches 0 run function mg:stickbett/go
execute if score #stickbett mg matches 1 if score #stickbett_cd mg matches 0 run scoreboard players set #stickbett mg 2
execute unless score #stickbett mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_stickbett]
execute if score #n mg matches ..1 run return run function mg:stickbett/forfeit
execute as @e[type=minecraft:player,tag=mg_duel_stickbett,scores={mg_deaths=1..}] run function mg:stickbett/respawn
execute as @a[tag=mg_duel_stickbett] at @s if entity @s[y=-64,dy=156] run function mg:stickbett/respawn
execute in minecraft:overworld unless block 15986 101 0 minecraft:red_bed as @a[tag=mg_duel_stickbett,tag=mg_p2,limit=1] run function mg:stickbett/point
execute in minecraft:overworld unless block 16014 101 0 minecraft:blue_bed as @a[tag=mg_duel_stickbett,tag=mg_p1,limit=1] run function mg:stickbett/point
execute in minecraft:overworld run kill @e[type=minecraft:item,x=15970,dx=60,y=80,dy=60,z=-30,dz=60,nbt={Age:100s}]
