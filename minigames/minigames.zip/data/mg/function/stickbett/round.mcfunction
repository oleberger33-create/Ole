execute as @a[tag=mg_duel_stickbett] run function mg:stickbett/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_stickbett,tag=mg_p1,limit=1] 15989 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_stickbett,tag=mg_p2,limit=1] 16011 101 0 90 0
execute as @a[tag=mg_duel_stickbett,tag=mg_p1,limit=1] run execute in minecraft:overworld run spawnpoint @s 15989 101 0
execute as @a[tag=mg_duel_stickbett,tag=mg_p2,limit=1] run execute in minecraft:overworld run spawnpoint @s 16011 101 0
kill @e[type=minecraft:horse,tag=mg_horse_stickbett]
scoreboard players set #stickbett_cd mg 60
scoreboard players set #stickbett mg 1
title @a[tag=mg_duel_stickbett] times 0 30 10
title @a[tag=mg_duel_stickbett] title {"text": "Stick-Fight Bett", "color": "yellow", "bold": true}
title @a[tag=mg_duel_stickbett] subtitle [{"score":{"name":"@a[tag=mg_duel_stickbett,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_stickbett,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
