execute in minecraft:overworld run fill 15983 94 -6 16017 107 6 minecraft:air replace minecraft:sandstone
execute in minecraft:overworld run setblock 15986 101 0 minecraft:red_bed[facing=west,part=foot]
execute in minecraft:overworld run setblock 15985 101 0 minecraft:red_bed[facing=west,part=head]
execute in minecraft:overworld run setblock 16014 101 0 minecraft:blue_bed[facing=east,part=foot]
execute in minecraft:overworld run setblock 16015 101 0 minecraft:blue_bed[facing=east,part=head]
title @a[tag=mg_duel_stickbett] actionbar {"text": "LOS!", "color": "yellow", "bold": true}
execute as @a[tag=mg_duel_stickbett] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
