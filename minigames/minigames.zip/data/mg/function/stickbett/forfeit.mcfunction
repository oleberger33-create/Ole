execute as @a[tag=mg_duel_stickbett] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Stick-Fight Bett – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_stickbett] mg_wins 1
function mg:stickbett/stop
