scoreboard players set @s mg_deaths 0
execute if entity @s[tag=mg_p1] run execute in minecraft:overworld run tp @s 15989 101 0 -90 0
execute if entity @s[tag=mg_p2] run execute in minecraft:overworld run tp @s 16011 101 0 90 0
execute unless items entity @s container.* minecraft:stick run function mg:stickbett/kit
effect clear @s minecraft:slowness
