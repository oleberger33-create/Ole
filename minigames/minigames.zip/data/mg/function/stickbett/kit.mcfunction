clear @s
effect clear @s
attribute @s minecraft:max_health base set 20
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
scoreboard players set @s mg_deaths 0
scoreboard players set @s mg_dmg 0
scoreboard players set @s mg_lap 0
scoreboard players set @s mg_gate 0
effect give @s minecraft:slowness 3 255 true
effect give @s minecraft:resistance 3 4 true
give @s minecraft:stick[minecraft:enchantments={"minecraft:knockback":1},minecraft:enchantment_glint_override=true]
execute if entity @s[tag=mg_p1] run give @s minecraft:wooden_pickaxe[minecraft:can_break={blocks:["minecraft:white_wool","minecraft:red_wool","minecraft:blue_wool","minecraft:lime_wool","minecraft:yellow_wool","minecraft:end_stone","minecraft:oak_planks","minecraft:sandstone","minecraft:cobblestone","minecraft:blue_bed","minecraft:lime_bed","minecraft:yellow_bed"]},minecraft:unbreakable={}]
execute if entity @s[tag=mg_p2] run give @s minecraft:wooden_pickaxe[minecraft:can_break={blocks:["minecraft:white_wool","minecraft:red_wool","minecraft:blue_wool","minecraft:lime_wool","minecraft:yellow_wool","minecraft:end_stone","minecraft:oak_planks","minecraft:sandstone","minecraft:cobblestone","minecraft:red_bed","minecraft:lime_bed","minecraft:yellow_bed"]},minecraft:unbreakable={}]
give @s minecraft:sandstone[minecraft:can_place_on={blocks:["minecraft:white_wool","minecraft:red_wool","minecraft:blue_wool","minecraft:lime_wool","minecraft:yellow_wool","minecraft:end_stone","minecraft:oak_planks","minecraft:sandstone","minecraft:cobblestone","minecraft:stone_bricks","minecraft:grass_block","minecraft:dirt","minecraft:stone","minecraft:smooth_stone","minecraft:quartz_block","minecraft:polished_andesite","minecraft:red_concrete","minecraft:blue_concrete","minecraft:lime_concrete","minecraft:yellow_concrete","minecraft:oak_log","minecraft:andesite","minecraft:glass","minecraft:mossy_cobblestone","minecraft:cut_sandstone"]}] 64
give @s minecraft:sandstone[minecraft:can_place_on={blocks:["minecraft:white_wool","minecraft:red_wool","minecraft:blue_wool","minecraft:lime_wool","minecraft:yellow_wool","minecraft:end_stone","minecraft:oak_planks","minecraft:sandstone","minecraft:cobblestone","minecraft:stone_bricks","minecraft:grass_block","minecraft:dirt","minecraft:stone","minecraft:smooth_stone","minecraft:quartz_block","minecraft:polished_andesite","minecraft:red_concrete","minecraft:blue_concrete","minecraft:lime_concrete","minecraft:yellow_concrete","minecraft:oak_log","minecraft:andesite","minecraft:glass","minecraft:mossy_cobblestone","minecraft:cut_sandstone"]}] 64
give @s minecraft:sandstone[minecraft:can_place_on={blocks:["minecraft:white_wool","minecraft:red_wool","minecraft:blue_wool","minecraft:lime_wool","minecraft:yellow_wool","minecraft:end_stone","minecraft:oak_planks","minecraft:sandstone","minecraft:cobblestone","minecraft:stone_bricks","minecraft:grass_block","minecraft:dirt","minecraft:stone","minecraft:smooth_stone","minecraft:quartz_block","minecraft:polished_andesite","minecraft:red_concrete","minecraft:blue_concrete","minecraft:lime_concrete","minecraft:yellow_concrete","minecraft:oak_log","minecraft:andesite","minecraft:glass","minecraft:mossy_cobblestone","minecraft:cut_sandstone"]}] 64
