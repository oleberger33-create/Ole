scoreboard players set #stickbett mg 0
kill @e[type=minecraft:horse,tag=mg_horse_stickbett]
execute as @a[tag=mg_duel_stickbett] run function mg:hub/enter
tag @a remove mg_duel_stickbett
tag @a[tag=mg_hub] remove mg_rw
execute in minecraft:overworld run kill @e[type=minecraft:item,x=15955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=15955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run fill 15983 94 -6 16017 107 6 minecraft:air replace minecraft:sandstone
