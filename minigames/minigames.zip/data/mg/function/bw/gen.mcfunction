execute store result score #c mg if entity @e[type=minecraft:item,distance=..2]
execute if score #c mg matches 40.. run return 0
$summon minecraft:item ~ ~ ~ {Item:{id:"minecraft:$(item)",count:1},PickupDelay:0,Motion:[0d,0.1d,0d]}
