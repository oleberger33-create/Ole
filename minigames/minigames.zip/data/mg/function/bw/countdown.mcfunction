execute store result score #n mg if entity @a[tag=mg_q_bw,tag=mg_hub]
execute if score #n mg matches ..1 run execute in minecraft:overworld run forceload remove 49944 -56 50056 56
execute if score #n mg matches ..1 run tellraw @a[tag=mg_q_bw] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zu wenig Spieler – BedWars abgebrochen.", "color": "red"}]
execute if score #n mg matches ..1 run return run scoreboard players set #bw mg 0
scoreboard players remove #bw_cd mg 1
scoreboard players operation #s mg = #bw_cd mg
scoreboard players operation #s mg /= #20 mg
execute as @a[tag=mg_q_bw] run title @s actionbar [{"text":"BedWars startet in ","color":"red"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true},{"text":" s","color":"red"}]
execute if score #bw_cd mg matches ..0 in minecraft:overworld if loaded 49952 100 -48 if loaded 50048 100 48 if loaded 49952 100 48 if loaded 50048 100 -48 run function mg:bw/start
