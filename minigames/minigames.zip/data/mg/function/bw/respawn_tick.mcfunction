scoreboard players remove @s mg_rt 1
execute unless score @s mg_rt matches 0 run return 0
gamemode adventure @s
execute if score @s mg_bwt matches 1 in minecraft:overworld run tp @s 50000.5 101 -37.5
execute if score @s mg_bwt matches 2 in minecraft:overworld run tp @s 50038.5 101 0.5
execute if score @s mg_bwt matches 3 in minecraft:overworld run tp @s 50000.5 101 38.5
execute if score @s mg_bwt matches 4 in minecraft:overworld run tp @s 49962.5 101 0.5
function mg:bw/kit
effect give @s minecraft:resistance 3 4 true
effect give @s minecraft:glowing 3 0 true
