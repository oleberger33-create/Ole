execute store result score #n mg if entity @a[tag=mg_q_bw,tag=mg_hub]
execute if score #n mg matches 2.. run scoreboard players set #bw_cd mg 300
execute if score #n mg matches 2.. run execute in minecraft:overworld run forceload add 49944 -56 50056 56
execute if score #n mg matches 2.. run tellraw @a[tag=mg_q_bw] [{"text": "» ", "color": "gold", "bold": true}, {"text": "BedWars startet in 15 Sekunden!", "color": "red"}]
execute if score #n mg matches 2.. run scoreboard players set #bw mg 1
