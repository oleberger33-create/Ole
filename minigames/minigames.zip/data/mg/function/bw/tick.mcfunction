execute if score #bw mg matches 0 run return run function mg:bw/idle
execute if score #bw mg matches 1 run return run function mg:bw/countdown
execute if score #bw mg matches 2 run return run function mg:bw/game
