scoreboard players set @s mg_deaths 0
execute if score @s mg_bwt matches 1 if score #bed1 mg matches 0 run return run function mg:bw/final
execute if score @s mg_bwt matches 2 if score #bed2 mg matches 0 run return run function mg:bw/final
execute if score @s mg_bwt matches 3 if score #bed3 mg matches 0 run return run function mg:bw/final
execute if score @s mg_bwt matches 4 if score #bed4 mg matches 0 run return run function mg:bw/final
scoreboard players set @s mg_rt 100
gamemode spectator @s
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du respawnst in 5 Sekunden.", "color": "gray"}]
