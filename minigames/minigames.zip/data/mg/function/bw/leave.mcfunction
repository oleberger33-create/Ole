tag @s remove mg_q_bw
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "BedWars-Warteschlange verlassen.", "color": "gray"}]
