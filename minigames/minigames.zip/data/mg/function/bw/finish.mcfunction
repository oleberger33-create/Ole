execute as @a[tag=mg_bw] run function mg:hub/enter
tag @a remove mg_bw
scoreboard players set #bw mg 0
team leave @a[team=mg_bw1]
team leave @a[team=mg_bw2]
team leave @a[team=mg_bw3]
team leave @a[team=mg_bw4]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=49944,dx=112,y=60,dy=80,z=-56,dz=112]
