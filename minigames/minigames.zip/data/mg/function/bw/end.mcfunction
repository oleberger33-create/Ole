execute as @a[tag=mg_bw,tag=mg_alive] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt BedWars!", "color": "white"}]
scoreboard players add @a[tag=mg_bw,tag=mg_alive] mg_wins 1
title @a[tag=mg_bw] title {"text": "Spiel vorbei!", "color": "red", "bold": true}
execute as @a[tag=mg_bw,tag=mg_alive] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16711680],has_twinkle:true}]}}}}
scoreboard players set #bw mg 3
schedule function mg:bw/finish 100t
