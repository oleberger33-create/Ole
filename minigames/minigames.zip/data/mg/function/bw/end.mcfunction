scoreboard players set #wt mg 0
execute as @a[tag=mg_al_bw,limit=1] run scoreboard players operation #wt mg = @s mg_bwt
execute if score #tl mg matches 1 as @a[tag=mg_bw,tag=!mg_al_bw] if score @s mg_bwt = #wt mg run tag @s add mg_al_bw
execute as @a[tag=mg_bw,tag=mg_al_bw] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt BedWars!", "color": "white"}]
scoreboard players add @a[tag=mg_bw,tag=mg_al_bw] mg_wins 1
scoreboard players add @a[tag=mg_bw,tag=mg_al_bw] mg_coins 10
title @a[tag=mg_bw] title {"text": "Spiel vorbei!", "color": "red", "bold": true}
execute as @a[tag=mg_bw,tag=mg_al_bw] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16711680],has_twinkle:true}]}}}}
scoreboard players set #bw mg 3
schedule function mg:bw/finish 100t
