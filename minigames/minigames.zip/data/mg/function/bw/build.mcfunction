kill @e[type=minecraft:villager,tag=mg_shop]
kill @e[type=minecraft:text_display,tag=mg_bwh]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=49940,dx=120,y=60,dy=90,z=-60,dz=120]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=49940,dx=120,y=60,dy=90,z=-60,dz=120]
execute in minecraft:overworld run kill @e[type=minecraft:ender_pearl,x=49940,dx=120,y=60,dy=90,z=-60,dz=120]
execute in minecraft:overworld run fill 49950 94 -50 49955 116 50 minecraft:air
execute in minecraft:overworld run fill 49956 94 -50 49961 116 50 minecraft:air
execute in minecraft:overworld run fill 49962 94 -50 49967 116 50 minecraft:air
execute in minecraft:overworld run fill 49968 94 -50 49973 116 50 minecraft:air
execute in minecraft:overworld run fill 49974 94 -50 49979 116 50 minecraft:air
execute in minecraft:overworld run fill 49980 94 -50 49985 116 50 minecraft:air
execute in minecraft:overworld run fill 49986 94 -50 49991 116 50 minecraft:air
execute in minecraft:overworld run fill 49992 94 -50 49997 116 50 minecraft:air
execute in minecraft:overworld run fill 49998 94 -50 50003 116 50 minecraft:air
execute in minecraft:overworld run fill 50004 94 -50 50009 116 50 minecraft:air
execute in minecraft:overworld run fill 50010 94 -50 50015 116 50 minecraft:air
execute in minecraft:overworld run fill 50016 94 -50 50021 116 50 minecraft:air
execute in minecraft:overworld run fill 50022 94 -50 50027 116 50 minecraft:air
execute in minecraft:overworld run fill 50028 94 -50 50033 116 50 minecraft:air
execute in minecraft:overworld run fill 50034 94 -50 50039 116 50 minecraft:air
execute in minecraft:overworld run fill 50040 94 -50 50045 116 50 minecraft:air
execute in minecraft:overworld run fill 50046 94 -50 50050 116 50 minecraft:air
execute in minecraft:overworld run fill 49998 100 -43 50002 100 -43 minecraft:red_concrete
execute in minecraft:overworld run fill 49997 100 -42 50003 100 -42 minecraft:red_concrete
execute in minecraft:overworld run fill 49996 100 -41 50004 100 -41 minecraft:red_concrete
execute in minecraft:overworld run fill 49995 100 -40 50005 100 -40 minecraft:red_concrete
execute in minecraft:overworld run fill 49995 100 -39 50005 100 -39 minecraft:red_concrete
execute in minecraft:overworld run fill 49995 100 -38 50005 100 -38 minecraft:red_concrete
execute in minecraft:overworld run fill 49995 100 -37 50005 100 -37 minecraft:red_concrete
execute in minecraft:overworld run fill 49995 100 -36 50005 100 -36 minecraft:red_concrete
execute in minecraft:overworld run fill 49996 100 -35 50004 100 -35 minecraft:red_concrete
execute in minecraft:overworld run fill 49997 100 -34 50003 100 -34 minecraft:red_concrete
execute in minecraft:overworld run fill 49998 100 -33 50002 100 -33 minecraft:red_concrete
execute in minecraft:overworld run fill 49998 100 -42 50002 100 -42 minecraft:stone_bricks
execute in minecraft:overworld run fill 49997 100 -41 50003 100 -41 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 -40 50004 100 -40 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 -39 50004 100 -39 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 -38 50004 100 -38 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 -37 50004 100 -37 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 -36 50004 100 -36 minecraft:stone_bricks
execute in minecraft:overworld run fill 49997 100 -35 50003 100 -35 minecraft:stone_bricks
execute in minecraft:overworld run fill 49998 100 -34 50002 100 -34 minecraft:stone_bricks
execute in minecraft:overworld run fill 49998 99 -42 50002 99 -42 minecraft:stone
execute in minecraft:overworld run fill 49997 99 -41 50003 99 -41 minecraft:stone
execute in minecraft:overworld run fill 49996 99 -40 50004 99 -40 minecraft:stone
execute in minecraft:overworld run fill 49996 99 -39 50004 99 -39 minecraft:stone
execute in minecraft:overworld run fill 49996 99 -38 50004 99 -38 minecraft:stone
execute in minecraft:overworld run fill 49996 99 -37 50004 99 -37 minecraft:stone
execute in minecraft:overworld run fill 49996 99 -36 50004 99 -36 minecraft:stone
execute in minecraft:overworld run fill 49997 99 -35 50003 99 -35 minecraft:stone
execute in minecraft:overworld run fill 49998 99 -34 50002 99 -34 minecraft:stone
execute in minecraft:overworld run fill 49999 98 -40 50001 98 -40 minecraft:stone
execute in minecraft:overworld run fill 49998 98 -39 50002 98 -39 minecraft:stone
execute in minecraft:overworld run fill 49998 98 -38 50002 98 -38 minecraft:stone
execute in minecraft:overworld run fill 49998 98 -37 50002 98 -37 minecraft:stone
execute in minecraft:overworld run fill 49999 98 -36 50001 98 -36 minecraft:stone
execute in minecraft:overworld run setblock 50000 101 -36 minecraft:red_bed[facing=south,part=foot]
execute in minecraft:overworld run setblock 50000 101 -35 minecraft:red_bed[facing=south,part=head]
execute in minecraft:overworld run setblock 50000 100 -41 minecraft:iron_block
execute in minecraft:overworld run setblock 49998 100 -41 minecraft:gold_block
execute in minecraft:overworld run summon minecraft:villager 49996.5 101 -37.5 {Tags:["mg_shop"],NoAI:1b,Invulnerable:1b,Silent:1b,PersistenceRequired:1b,CustomName:{"text": "Shop Rot", "color": "red", "bold": true},CustomNameVisible:1b,VillagerData:{profession:"minecraft:weaponsmith",level:5,type:"minecraft:plains"},Offers:{"Recipes": [{"buy": {"id": "minecraft:iron_ingot", "count": 4}, "sell": {"id": "minecraft:red_wool", "count": 16, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 24}, "sell": {"id": "minecraft:end_stone", "count": 12, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 4}, "sell": {"id": "minecraft:oak_planks", "count": 16, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 10}, "sell": {"id": "minecraft:stone_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 7}, "sell": {"id": "minecraft:iron_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 4}, "sell": {"id": "minecraft:diamond_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 24}, "sell": {"id": "minecraft:chainmail_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 12}, "sell": {"id": "minecraft:iron_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 6}, "sell": {"id": "minecraft:diamond_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 10}, "sell": {"id": "minecraft:stone_pickaxe", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:blue_bed", "minecraft:lime_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 3}, "sell": {"id": "minecraft:iron_pickaxe", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:blue_bed", "minecraft:lime_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 20}, "sell": {"id": "minecraft:shears", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:blue_bed", "minecraft:lime_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 3}, "sell": {"id": "minecraft:golden_apple", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 12}, "sell": {"id": "minecraft:bow", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 2}, "sell": {"id": "minecraft:arrow", "count": 8}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 4}, "sell": {"id": "minecraft:ender_pearl", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 4}, "sell": {"id": "minecraft:cooked_beef", "count": 3}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 2}, "sell": {"id": "minecraft:stick", "count": 1, "components": {"minecraft:enchantments": {"minecraft:knockback": 1}}}, "maxUses": 99999, "rewardExp": 0b}]}}
execute in minecraft:overworld run summon minecraft:text_display 50000 104 -38 {Tags:["mg_holo","mg_bwh"],billboard:"center",background:0,shadow:true,text:{"text": "Team Rot", "color": "red", "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.0f,2.0f,2.0f]}}
execute in minecraft:overworld run fill 50036 100 -5 50040 100 -5 minecraft:blue_concrete
execute in minecraft:overworld run fill 50035 100 -4 50041 100 -4 minecraft:blue_concrete
execute in minecraft:overworld run fill 50034 100 -3 50042 100 -3 minecraft:blue_concrete
execute in minecraft:overworld run fill 50033 100 -2 50043 100 -2 minecraft:blue_concrete
execute in minecraft:overworld run fill 50033 100 -1 50043 100 -1 minecraft:blue_concrete
execute in minecraft:overworld run fill 50033 100 0 50043 100 0 minecraft:blue_concrete
execute in minecraft:overworld run fill 50033 100 1 50043 100 1 minecraft:blue_concrete
execute in minecraft:overworld run fill 50033 100 2 50043 100 2 minecraft:blue_concrete
execute in minecraft:overworld run fill 50034 100 3 50042 100 3 minecraft:blue_concrete
execute in minecraft:overworld run fill 50035 100 4 50041 100 4 minecraft:blue_concrete
execute in minecraft:overworld run fill 50036 100 5 50040 100 5 minecraft:blue_concrete
execute in minecraft:overworld run fill 50036 100 -4 50040 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run fill 50035 100 -3 50041 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run fill 50034 100 -2 50042 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run fill 50034 100 -1 50042 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run fill 50034 100 0 50042 100 0 minecraft:stone_bricks
execute in minecraft:overworld run fill 50034 100 1 50042 100 1 minecraft:stone_bricks
execute in minecraft:overworld run fill 50034 100 2 50042 100 2 minecraft:stone_bricks
execute in minecraft:overworld run fill 50035 100 3 50041 100 3 minecraft:stone_bricks
execute in minecraft:overworld run fill 50036 100 4 50040 100 4 minecraft:stone_bricks
execute in minecraft:overworld run fill 50036 99 -4 50040 99 -4 minecraft:stone
execute in minecraft:overworld run fill 50035 99 -3 50041 99 -3 minecraft:stone
execute in minecraft:overworld run fill 50034 99 -2 50042 99 -2 minecraft:stone
execute in minecraft:overworld run fill 50034 99 -1 50042 99 -1 minecraft:stone
execute in minecraft:overworld run fill 50034 99 0 50042 99 0 minecraft:stone
execute in minecraft:overworld run fill 50034 99 1 50042 99 1 minecraft:stone
execute in minecraft:overworld run fill 50034 99 2 50042 99 2 minecraft:stone
execute in minecraft:overworld run fill 50035 99 3 50041 99 3 minecraft:stone
execute in minecraft:overworld run fill 50036 99 4 50040 99 4 minecraft:stone
execute in minecraft:overworld run fill 50037 98 -2 50039 98 -2 minecraft:stone
execute in minecraft:overworld run fill 50036 98 -1 50040 98 -1 minecraft:stone
execute in minecraft:overworld run fill 50036 98 0 50040 98 0 minecraft:stone
execute in minecraft:overworld run fill 50036 98 1 50040 98 1 minecraft:stone
execute in minecraft:overworld run fill 50037 98 2 50039 98 2 minecraft:stone
execute in minecraft:overworld run setblock 50036 101 0 minecraft:blue_bed[facing=west,part=foot]
execute in minecraft:overworld run setblock 50035 101 0 minecraft:blue_bed[facing=west,part=head]
execute in minecraft:overworld run setblock 50041 100 0 minecraft:iron_block
execute in minecraft:overworld run setblock 50041 100 2 minecraft:gold_block
execute in minecraft:overworld run summon minecraft:villager 50038.5 101 4.5 {Tags:["mg_shop"],NoAI:1b,Invulnerable:1b,Silent:1b,PersistenceRequired:1b,CustomName:{"text": "Shop Blau", "color": "blue", "bold": true},CustomNameVisible:1b,VillagerData:{profession:"minecraft:weaponsmith",level:5,type:"minecraft:plains"},Offers:{"Recipes": [{"buy": {"id": "minecraft:iron_ingot", "count": 4}, "sell": {"id": "minecraft:blue_wool", "count": 16, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 24}, "sell": {"id": "minecraft:end_stone", "count": 12, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 4}, "sell": {"id": "minecraft:oak_planks", "count": 16, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 10}, "sell": {"id": "minecraft:stone_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 7}, "sell": {"id": "minecraft:iron_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 4}, "sell": {"id": "minecraft:diamond_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 24}, "sell": {"id": "minecraft:chainmail_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 12}, "sell": {"id": "minecraft:iron_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 6}, "sell": {"id": "minecraft:diamond_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 10}, "sell": {"id": "minecraft:stone_pickaxe", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:lime_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 3}, "sell": {"id": "minecraft:iron_pickaxe", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:lime_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 20}, "sell": {"id": "minecraft:shears", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:lime_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 3}, "sell": {"id": "minecraft:golden_apple", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 12}, "sell": {"id": "minecraft:bow", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 2}, "sell": {"id": "minecraft:arrow", "count": 8}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 4}, "sell": {"id": "minecraft:ender_pearl", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 4}, "sell": {"id": "minecraft:cooked_beef", "count": 3}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 2}, "sell": {"id": "minecraft:stick", "count": 1, "components": {"minecraft:enchantments": {"minecraft:knockback": 1}}}, "maxUses": 99999, "rewardExp": 0b}]}}
execute in minecraft:overworld run summon minecraft:text_display 50038 104 0 {Tags:["mg_holo","mg_bwh"],billboard:"center",background:0,shadow:true,text:{"text": "Team Blau", "color": "blue", "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.0f,2.0f,2.0f]}}
execute in minecraft:overworld run fill 49998 100 33 50002 100 33 minecraft:lime_concrete
execute in minecraft:overworld run fill 49997 100 34 50003 100 34 minecraft:lime_concrete
execute in minecraft:overworld run fill 49996 100 35 50004 100 35 minecraft:lime_concrete
execute in minecraft:overworld run fill 49995 100 36 50005 100 36 minecraft:lime_concrete
execute in minecraft:overworld run fill 49995 100 37 50005 100 37 minecraft:lime_concrete
execute in minecraft:overworld run fill 49995 100 38 50005 100 38 minecraft:lime_concrete
execute in minecraft:overworld run fill 49995 100 39 50005 100 39 minecraft:lime_concrete
execute in minecraft:overworld run fill 49995 100 40 50005 100 40 minecraft:lime_concrete
execute in minecraft:overworld run fill 49996 100 41 50004 100 41 minecraft:lime_concrete
execute in minecraft:overworld run fill 49997 100 42 50003 100 42 minecraft:lime_concrete
execute in minecraft:overworld run fill 49998 100 43 50002 100 43 minecraft:lime_concrete
execute in minecraft:overworld run fill 49998 100 34 50002 100 34 minecraft:stone_bricks
execute in minecraft:overworld run fill 49997 100 35 50003 100 35 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 36 50004 100 36 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 37 50004 100 37 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 38 50004 100 38 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 39 50004 100 39 minecraft:stone_bricks
execute in minecraft:overworld run fill 49996 100 40 50004 100 40 minecraft:stone_bricks
execute in minecraft:overworld run fill 49997 100 41 50003 100 41 minecraft:stone_bricks
execute in minecraft:overworld run fill 49998 100 42 50002 100 42 minecraft:stone_bricks
execute in minecraft:overworld run fill 49998 99 34 50002 99 34 minecraft:stone
execute in minecraft:overworld run fill 49997 99 35 50003 99 35 minecraft:stone
execute in minecraft:overworld run fill 49996 99 36 50004 99 36 minecraft:stone
execute in minecraft:overworld run fill 49996 99 37 50004 99 37 minecraft:stone
execute in minecraft:overworld run fill 49996 99 38 50004 99 38 minecraft:stone
execute in minecraft:overworld run fill 49996 99 39 50004 99 39 minecraft:stone
execute in minecraft:overworld run fill 49996 99 40 50004 99 40 minecraft:stone
execute in minecraft:overworld run fill 49997 99 41 50003 99 41 minecraft:stone
execute in minecraft:overworld run fill 49998 99 42 50002 99 42 minecraft:stone
execute in minecraft:overworld run fill 49999 98 36 50001 98 36 minecraft:stone
execute in minecraft:overworld run fill 49998 98 37 50002 98 37 minecraft:stone
execute in minecraft:overworld run fill 49998 98 38 50002 98 38 minecraft:stone
execute in minecraft:overworld run fill 49998 98 39 50002 98 39 minecraft:stone
execute in minecraft:overworld run fill 49999 98 40 50001 98 40 minecraft:stone
execute in minecraft:overworld run setblock 50000 101 36 minecraft:lime_bed[facing=north,part=foot]
execute in minecraft:overworld run setblock 50000 101 35 minecraft:lime_bed[facing=north,part=head]
execute in minecraft:overworld run setblock 50000 100 41 minecraft:iron_block
execute in minecraft:overworld run setblock 50002 100 41 minecraft:gold_block
execute in minecraft:overworld run summon minecraft:villager 50004.5 101 38.5 {Tags:["mg_shop"],NoAI:1b,Invulnerable:1b,Silent:1b,PersistenceRequired:1b,CustomName:{"text": "Shop Grün", "color": "green", "bold": true},CustomNameVisible:1b,VillagerData:{profession:"minecraft:weaponsmith",level:5,type:"minecraft:plains"},Offers:{"Recipes": [{"buy": {"id": "minecraft:iron_ingot", "count": 4}, "sell": {"id": "minecraft:lime_wool", "count": 16, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 24}, "sell": {"id": "minecraft:end_stone", "count": 12, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 4}, "sell": {"id": "minecraft:oak_planks", "count": 16, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 10}, "sell": {"id": "minecraft:stone_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 7}, "sell": {"id": "minecraft:iron_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 4}, "sell": {"id": "minecraft:diamond_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 24}, "sell": {"id": "minecraft:chainmail_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 12}, "sell": {"id": "minecraft:iron_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 6}, "sell": {"id": "minecraft:diamond_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 10}, "sell": {"id": "minecraft:stone_pickaxe", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:blue_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 3}, "sell": {"id": "minecraft:iron_pickaxe", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:blue_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 20}, "sell": {"id": "minecraft:shears", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:blue_bed", "minecraft:yellow_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 3}, "sell": {"id": "minecraft:golden_apple", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 12}, "sell": {"id": "minecraft:bow", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 2}, "sell": {"id": "minecraft:arrow", "count": 8}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 4}, "sell": {"id": "minecraft:ender_pearl", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 4}, "sell": {"id": "minecraft:cooked_beef", "count": 3}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 2}, "sell": {"id": "minecraft:stick", "count": 1, "components": {"minecraft:enchantments": {"minecraft:knockback": 1}}}, "maxUses": 99999, "rewardExp": 0b}]}}
execute in minecraft:overworld run summon minecraft:text_display 50000 104 38 {Tags:["mg_holo","mg_bwh"],billboard:"center",background:0,shadow:true,text:{"text": "Team Grün", "color": "green", "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.0f,2.0f,2.0f]}}
execute in minecraft:overworld run fill 49960 100 -5 49964 100 -5 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49959 100 -4 49965 100 -4 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49958 100 -3 49966 100 -3 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49957 100 -2 49967 100 -2 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49957 100 -1 49967 100 -1 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49957 100 0 49967 100 0 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49957 100 1 49967 100 1 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49957 100 2 49967 100 2 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49958 100 3 49966 100 3 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49959 100 4 49965 100 4 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49960 100 5 49964 100 5 minecraft:yellow_concrete
execute in minecraft:overworld run fill 49960 100 -4 49964 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run fill 49959 100 -3 49965 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run fill 49958 100 -2 49966 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run fill 49958 100 -1 49966 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run fill 49958 100 0 49966 100 0 minecraft:stone_bricks
execute in minecraft:overworld run fill 49958 100 1 49966 100 1 minecraft:stone_bricks
execute in minecraft:overworld run fill 49958 100 2 49966 100 2 minecraft:stone_bricks
execute in minecraft:overworld run fill 49959 100 3 49965 100 3 minecraft:stone_bricks
execute in minecraft:overworld run fill 49960 100 4 49964 100 4 minecraft:stone_bricks
execute in minecraft:overworld run fill 49960 99 -4 49964 99 -4 minecraft:stone
execute in minecraft:overworld run fill 49959 99 -3 49965 99 -3 minecraft:stone
execute in minecraft:overworld run fill 49958 99 -2 49966 99 -2 minecraft:stone
execute in minecraft:overworld run fill 49958 99 -1 49966 99 -1 minecraft:stone
execute in minecraft:overworld run fill 49958 99 0 49966 99 0 minecraft:stone
execute in minecraft:overworld run fill 49958 99 1 49966 99 1 minecraft:stone
execute in minecraft:overworld run fill 49958 99 2 49966 99 2 minecraft:stone
execute in minecraft:overworld run fill 49959 99 3 49965 99 3 minecraft:stone
execute in minecraft:overworld run fill 49960 99 4 49964 99 4 minecraft:stone
execute in minecraft:overworld run fill 49961 98 -2 49963 98 -2 minecraft:stone
execute in minecraft:overworld run fill 49960 98 -1 49964 98 -1 minecraft:stone
execute in minecraft:overworld run fill 49960 98 0 49964 98 0 minecraft:stone
execute in minecraft:overworld run fill 49960 98 1 49964 98 1 minecraft:stone
execute in minecraft:overworld run fill 49961 98 2 49963 98 2 minecraft:stone
execute in minecraft:overworld run setblock 49964 101 0 minecraft:yellow_bed[facing=east,part=foot]
execute in minecraft:overworld run setblock 49965 101 0 minecraft:yellow_bed[facing=east,part=head]
execute in minecraft:overworld run setblock 49959 100 0 minecraft:iron_block
execute in minecraft:overworld run setblock 49959 100 -2 minecraft:gold_block
execute in minecraft:overworld run summon minecraft:villager 49962.5 101 -3.5 {Tags:["mg_shop"],NoAI:1b,Invulnerable:1b,Silent:1b,PersistenceRequired:1b,CustomName:{"text": "Shop Gelb", "color": "yellow", "bold": true},CustomNameVisible:1b,VillagerData:{profession:"minecraft:weaponsmith",level:5,type:"minecraft:plains"},Offers:{"Recipes": [{"buy": {"id": "minecraft:iron_ingot", "count": 4}, "sell": {"id": "minecraft:yellow_wool", "count": 16, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 24}, "sell": {"id": "minecraft:end_stone", "count": 12, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 4}, "sell": {"id": "minecraft:oak_planks", "count": 16, "components": {"minecraft:can_place_on": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:stone_bricks", "minecraft:grass_block", "minecraft:dirt", "minecraft:stone", "minecraft:smooth_stone", "minecraft:quartz_block", "minecraft:polished_andesite", "minecraft:red_concrete", "minecraft:blue_concrete", "minecraft:lime_concrete", "minecraft:yellow_concrete", "minecraft:oak_log", "minecraft:andesite", "minecraft:glass", "minecraft:mossy_cobblestone", "minecraft:cut_sandstone"]}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 10}, "sell": {"id": "minecraft:stone_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 7}, "sell": {"id": "minecraft:iron_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 4}, "sell": {"id": "minecraft:diamond_sword", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 24}, "sell": {"id": "minecraft:chainmail_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 12}, "sell": {"id": "minecraft:iron_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 6}, "sell": {"id": "minecraft:diamond_chestplate", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 10}, "sell": {"id": "minecraft:stone_pickaxe", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:blue_bed", "minecraft:lime_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 3}, "sell": {"id": "minecraft:iron_pickaxe", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:blue_bed", "minecraft:lime_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 20}, "sell": {"id": "minecraft:shears", "count": 1, "components": {"minecraft:can_break": {"blocks": ["minecraft:white_wool", "minecraft:red_wool", "minecraft:blue_wool", "minecraft:lime_wool", "minecraft:yellow_wool", "minecraft:end_stone", "minecraft:oak_planks", "minecraft:sandstone", "minecraft:cobblestone", "minecraft:red_bed", "minecraft:blue_bed", "minecraft:lime_bed"]}, "minecraft:unbreakable": {}}}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 3}, "sell": {"id": "minecraft:golden_apple", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 12}, "sell": {"id": "minecraft:bow", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:gold_ingot", "count": 2}, "sell": {"id": "minecraft:arrow", "count": 8}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 4}, "sell": {"id": "minecraft:ender_pearl", "count": 1}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:iron_ingot", "count": 4}, "sell": {"id": "minecraft:cooked_beef", "count": 3}, "maxUses": 99999, "rewardExp": 0b}, {"buy": {"id": "minecraft:emerald", "count": 2}, "sell": {"id": "minecraft:stick", "count": 1, "components": {"minecraft:enchantments": {"minecraft:knockback": 1}}}, "maxUses": 99999, "rewardExp": 0b}]}}
execute in minecraft:overworld run summon minecraft:text_display 49962 104 0 {Tags:["mg_holo","mg_bwh"],billboard:"center",background:0,shadow:true,text:{"text": "Team Gelb", "color": "yellow", "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.0f,2.0f,2.0f]}}
execute in minecraft:overworld run fill 50025 100 24 50027 100 24 minecraft:grass_block
execute in minecraft:overworld run fill 50024 100 25 50028 100 25 minecraft:grass_block
execute in minecraft:overworld run fill 50024 100 26 50028 100 26 minecraft:grass_block
execute in minecraft:overworld run fill 50024 100 27 50028 100 27 minecraft:grass_block
execute in minecraft:overworld run fill 50025 100 28 50027 100 28 minecraft:grass_block
execute in minecraft:overworld run fill 50025 99 24 50027 99 24 minecraft:dirt
execute in minecraft:overworld run fill 50024 99 25 50028 99 25 minecraft:dirt
execute in minecraft:overworld run fill 50024 99 26 50028 99 26 minecraft:dirt
execute in minecraft:overworld run fill 50024 99 27 50028 99 27 minecraft:dirt
execute in minecraft:overworld run fill 50025 99 28 50027 99 28 minecraft:dirt
execute in minecraft:overworld run fill 50025 98 25 50027 98 25 minecraft:stone
execute in minecraft:overworld run fill 50025 98 26 50027 98 26 minecraft:stone
execute in minecraft:overworld run fill 50025 98 27 50027 98 27 minecraft:stone
execute in minecraft:overworld run fill 50025 97 25 50027 97 25 minecraft:stone
execute in minecraft:overworld run fill 50025 97 26 50027 97 26 minecraft:stone
execute in minecraft:overworld run fill 50025 97 27 50027 97 27 minecraft:stone
execute in minecraft:overworld run setblock 50026 100 26 minecraft:diamond_block
execute in minecraft:overworld run fill 49973 100 24 49975 100 24 minecraft:grass_block
execute in minecraft:overworld run fill 49972 100 25 49976 100 25 minecraft:grass_block
execute in minecraft:overworld run fill 49972 100 26 49976 100 26 minecraft:grass_block
execute in minecraft:overworld run fill 49972 100 27 49976 100 27 minecraft:grass_block
execute in minecraft:overworld run fill 49973 100 28 49975 100 28 minecraft:grass_block
execute in minecraft:overworld run fill 49973 99 24 49975 99 24 minecraft:dirt
execute in minecraft:overworld run fill 49972 99 25 49976 99 25 minecraft:dirt
execute in minecraft:overworld run fill 49972 99 26 49976 99 26 minecraft:dirt
execute in minecraft:overworld run fill 49972 99 27 49976 99 27 minecraft:dirt
execute in minecraft:overworld run fill 49973 99 28 49975 99 28 minecraft:dirt
execute in minecraft:overworld run fill 49973 98 25 49975 98 25 minecraft:stone
execute in minecraft:overworld run fill 49973 98 26 49975 98 26 minecraft:stone
execute in minecraft:overworld run fill 49973 98 27 49975 98 27 minecraft:stone
execute in minecraft:overworld run fill 49973 97 25 49975 97 25 minecraft:stone
execute in minecraft:overworld run fill 49973 97 26 49975 97 26 minecraft:stone
execute in minecraft:overworld run fill 49973 97 27 49975 97 27 minecraft:stone
execute in minecraft:overworld run setblock 49974 100 26 minecraft:diamond_block
execute in minecraft:overworld run fill 50025 100 -28 50027 100 -28 minecraft:grass_block
execute in minecraft:overworld run fill 50024 100 -27 50028 100 -27 minecraft:grass_block
execute in minecraft:overworld run fill 50024 100 -26 50028 100 -26 minecraft:grass_block
execute in minecraft:overworld run fill 50024 100 -25 50028 100 -25 minecraft:grass_block
execute in minecraft:overworld run fill 50025 100 -24 50027 100 -24 minecraft:grass_block
execute in minecraft:overworld run fill 50025 99 -28 50027 99 -28 minecraft:dirt
execute in minecraft:overworld run fill 50024 99 -27 50028 99 -27 minecraft:dirt
execute in minecraft:overworld run fill 50024 99 -26 50028 99 -26 minecraft:dirt
execute in minecraft:overworld run fill 50024 99 -25 50028 99 -25 minecraft:dirt
execute in minecraft:overworld run fill 50025 99 -24 50027 99 -24 minecraft:dirt
execute in minecraft:overworld run fill 50025 98 -27 50027 98 -27 minecraft:stone
execute in minecraft:overworld run fill 50025 98 -26 50027 98 -26 minecraft:stone
execute in minecraft:overworld run fill 50025 98 -25 50027 98 -25 minecraft:stone
execute in minecraft:overworld run fill 50025 97 -27 50027 97 -27 minecraft:stone
execute in minecraft:overworld run fill 50025 97 -26 50027 97 -26 minecraft:stone
execute in minecraft:overworld run fill 50025 97 -25 50027 97 -25 minecraft:stone
execute in minecraft:overworld run setblock 50026 100 -26 minecraft:diamond_block
execute in minecraft:overworld run fill 49973 100 -28 49975 100 -28 minecraft:grass_block
execute in minecraft:overworld run fill 49972 100 -27 49976 100 -27 minecraft:grass_block
execute in minecraft:overworld run fill 49972 100 -26 49976 100 -26 minecraft:grass_block
execute in minecraft:overworld run fill 49972 100 -25 49976 100 -25 minecraft:grass_block
execute in minecraft:overworld run fill 49973 100 -24 49975 100 -24 minecraft:grass_block
execute in minecraft:overworld run fill 49973 99 -28 49975 99 -28 minecraft:dirt
execute in minecraft:overworld run fill 49972 99 -27 49976 99 -27 minecraft:dirt
execute in minecraft:overworld run fill 49972 99 -26 49976 99 -26 minecraft:dirt
execute in minecraft:overworld run fill 49972 99 -25 49976 99 -25 minecraft:dirt
execute in minecraft:overworld run fill 49973 99 -24 49975 99 -24 minecraft:dirt
execute in minecraft:overworld run fill 49973 98 -27 49975 98 -27 minecraft:stone
execute in minecraft:overworld run fill 49973 98 -26 49975 98 -26 minecraft:stone
execute in minecraft:overworld run fill 49973 98 -25 49975 98 -25 minecraft:stone
execute in minecraft:overworld run fill 49973 97 -27 49975 97 -27 minecraft:stone
execute in minecraft:overworld run fill 49973 97 -26 49975 97 -26 minecraft:stone
execute in minecraft:overworld run fill 49973 97 -25 49975 97 -25 minecraft:stone
execute in minecraft:overworld run setblock 49974 100 -26 minecraft:diamond_block
execute in minecraft:overworld run fill 49998 100 -6 50002 100 -6 minecraft:quartz_block
execute in minecraft:overworld run fill 49996 100 -5 50004 100 -5 minecraft:quartz_block
execute in minecraft:overworld run fill 49995 100 -4 50005 100 -4 minecraft:quartz_block
execute in minecraft:overworld run fill 49995 100 -3 50005 100 -3 minecraft:quartz_block
execute in minecraft:overworld run fill 49994 100 -2 50006 100 -2 minecraft:quartz_block
execute in minecraft:overworld run fill 49994 100 -1 50006 100 -1 minecraft:quartz_block
execute in minecraft:overworld run fill 49994 100 0 50006 100 0 minecraft:quartz_block
execute in minecraft:overworld run fill 49994 100 1 50006 100 1 minecraft:quartz_block
execute in minecraft:overworld run fill 49994 100 2 50006 100 2 minecraft:quartz_block
execute in minecraft:overworld run fill 49995 100 3 50005 100 3 minecraft:quartz_block
execute in minecraft:overworld run fill 49995 100 4 50005 100 4 minecraft:quartz_block
execute in minecraft:overworld run fill 49996 100 5 50004 100 5 minecraft:quartz_block
execute in minecraft:overworld run fill 49998 100 6 50002 100 6 minecraft:quartz_block
execute in minecraft:overworld run fill 49998 99 -5 50002 99 -5 minecraft:stone
execute in minecraft:overworld run fill 49997 99 -4 50003 99 -4 minecraft:stone
execute in minecraft:overworld run fill 49996 99 -3 50004 99 -3 minecraft:stone
execute in minecraft:overworld run fill 49995 99 -2 50005 99 -2 minecraft:stone
execute in minecraft:overworld run fill 49995 99 -1 50005 99 -1 minecraft:stone
execute in minecraft:overworld run fill 49995 99 0 50005 99 0 minecraft:stone
execute in minecraft:overworld run fill 49995 99 1 50005 99 1 minecraft:stone
execute in minecraft:overworld run fill 49995 99 2 50005 99 2 minecraft:stone
execute in minecraft:overworld run fill 49996 99 3 50004 99 3 minecraft:stone
execute in minecraft:overworld run fill 49997 99 4 50003 99 4 minecraft:stone
execute in minecraft:overworld run fill 49998 99 5 50002 99 5 minecraft:stone
execute in minecraft:overworld run fill 49999 98 -3 50001 98 -3 minecraft:stone
execute in minecraft:overworld run fill 49998 98 -2 50002 98 -2 minecraft:stone
execute in minecraft:overworld run fill 49997 98 -1 50003 98 -1 minecraft:stone
execute in minecraft:overworld run fill 49997 98 0 50003 98 0 minecraft:stone
execute in minecraft:overworld run fill 49997 98 1 50003 98 1 minecraft:stone
execute in minecraft:overworld run fill 49998 98 2 50002 98 2 minecraft:stone
execute in minecraft:overworld run fill 49999 98 3 50001 98 3 minecraft:stone
execute in minecraft:overworld run setblock 50002 100 0 minecraft:emerald_block
execute in minecraft:overworld run setblock 49998 100 0 minecraft:emerald_block
execute in minecraft:overworld run summon minecraft:text_display 50000 105 0 {Tags:["mg_holo","mg_bwh"],billboard:"center",background:0,shadow:true,text:{"text": "BEDWARS", "color": "red", "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[3.0f,3.0f,3.0f]}}
