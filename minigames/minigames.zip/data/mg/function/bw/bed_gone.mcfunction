$scoreboard players set #bed$(t) mg 0
$tellraw @a[tag=mg_bw] [{"text":"» ","color":"gold","bold":true},{"text":"Das Bett von Team $(n) wurde zerstört!","color":"$(c)","bold":true}]
$title @a[tag=mg_bw,scores={mg_bwt=$(t)}] title {"text":"BETT ZERSTÖRT!","color":"red","bold":true}
$title @a[tag=mg_bw,scores={mg_bwt=$(t)}] subtitle {"text":"Du kannst nicht mehr respawnen","color":"gray"}
execute as @a[tag=mg_bw] at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.4 1.4
