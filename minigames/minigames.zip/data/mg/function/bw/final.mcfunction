tag @s remove mg_alive
gamemode spectator @s
tellraw @a[tag=mg_bw] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist endgültig raus!", "color": "red", "bold": true}]
