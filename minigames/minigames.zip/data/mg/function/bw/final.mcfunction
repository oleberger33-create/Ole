tag @s remove mg_al_bw
gamemode spectator @s
tellraw @s [{"text": "  "}, {"text": "[Zurück zur Lobby]", "color": "aqua", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 99"}}, {"text": " oder weiter zuschauen", "color": "gray"}]
tellraw @a[tag=mg_bw] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist endgültig raus!", "color": "red", "bold": true}]
