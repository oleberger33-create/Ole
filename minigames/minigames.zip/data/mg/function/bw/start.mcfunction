function mg:bw/build
execute in minecraft:overworld run forceload remove 49944 -56 50056 56
tag @a[tag=mg_q_bw,tag=mg_hub,limit=16] add mg_bw
tag @a[tag=mg_bw] remove mg_q_bw
tag @a[tag=mg_bw] remove mg_hub
execute as @a[tag=mg_bw] run function mg:q/leave_all
execute store result score #n mg if entity @a[tag=mg_bw]
scoreboard players operation #teams mg = #n mg
execute if score #n mg matches 5.. run scoreboard players add #teams mg 1
execute if score #n mg matches 5.. run scoreboard players operation #teams mg /= #2 mg
execute if score #teams mg matches 5.. run scoreboard players set #teams mg 4
scoreboard players set #bw_t mg 0
scoreboard players set #k mg 0
scoreboard players set @a[tag=mg_bw] mg_bwt 0
execute as @a[tag=mg_bw,sort=random] run function mg:bw/assign
clear @a[tag=mg_bw]
effect clear @a[tag=mg_bw]
gamemode adventure @a[tag=mg_bw]
tag @a[tag=mg_bw] add mg_al_bw
scoreboard players set @a[tag=mg_bw] mg_deaths 0
scoreboard players set @a[tag=mg_bw] mg_rt 0
scoreboard players set #gi mg 0
scoreboard players set #gg mg 0
scoreboard players set #gd mg 0
scoreboard players set #ge mg 0
execute if entity @a[tag=mg_bw,scores={mg_bwt=1}] run scoreboard players set #bed1 mg 1
execute unless entity @a[tag=mg_bw,scores={mg_bwt=1}] run scoreboard players set #bed1 mg 0
execute as @a[tag=mg_bw,scores={mg_bwt=1}] run execute in minecraft:overworld run spawnpoint @s 50000 101 -38
execute in minecraft:overworld run tp @a[tag=mg_bw,scores={mg_bwt=1}] 50000.5 101 -37.5 facing 50000.5 101 0.5
team join mg_bw1 @a[tag=mg_bw,scores={mg_bwt=1}]
execute if entity @a[tag=mg_bw,scores={mg_bwt=2}] run scoreboard players set #bed2 mg 1
execute unless entity @a[tag=mg_bw,scores={mg_bwt=2}] run scoreboard players set #bed2 mg 0
execute as @a[tag=mg_bw,scores={mg_bwt=2}] run execute in minecraft:overworld run spawnpoint @s 50038 101 0
execute in minecraft:overworld run tp @a[tag=mg_bw,scores={mg_bwt=2}] 50038.5 101 0.5 facing 50000.5 101 0.5
team join mg_bw2 @a[tag=mg_bw,scores={mg_bwt=2}]
execute if entity @a[tag=mg_bw,scores={mg_bwt=3}] run scoreboard players set #bed3 mg 1
execute unless entity @a[tag=mg_bw,scores={mg_bwt=3}] run scoreboard players set #bed3 mg 0
execute as @a[tag=mg_bw,scores={mg_bwt=3}] run execute in minecraft:overworld run spawnpoint @s 50000 101 38
execute in minecraft:overworld run tp @a[tag=mg_bw,scores={mg_bwt=3}] 50000.5 101 38.5 facing 50000.5 101 0.5
team join mg_bw3 @a[tag=mg_bw,scores={mg_bwt=3}]
execute if entity @a[tag=mg_bw,scores={mg_bwt=4}] run scoreboard players set #bed4 mg 1
execute unless entity @a[tag=mg_bw,scores={mg_bwt=4}] run scoreboard players set #bed4 mg 0
execute as @a[tag=mg_bw,scores={mg_bwt=4}] run execute in minecraft:overworld run spawnpoint @s 49962 101 0
execute in minecraft:overworld run tp @a[tag=mg_bw,scores={mg_bwt=4}] 49962.5 101 0.5 facing 50000.5 101 0.5
team join mg_bw4 @a[tag=mg_bw,scores={mg_bwt=4}]
execute as @a[tag=mg_bw] run function mg:bw/kit
scoreboard players set #bw mg 2
title @a[tag=mg_bw] title {"text": "BEDWARS", "color": "red", "bold": true}
title @a[tag=mg_bw] subtitle {"text": "Schütze dein Bett – zerstöre die anderen!", "color": "white"}
tellraw @a[tag=mg_bw] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Eisen & Gold kommen am Team-Generator, Diamanten auf den Ecken-Inseln, Smaragde in der Mitte. Einkaufen beim Dorfbewohner.", "color": "gray"}]
