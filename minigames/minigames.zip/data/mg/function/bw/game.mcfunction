scoreboard players add #gi mg 1
scoreboard players add #gg mg 1
scoreboard players add #gd mg 1
scoreboard players add #ge mg 1
execute if score #gi mg matches 20.. if entity @a[tag=mg_bw,scores={mg_bwt=1}] in minecraft:overworld positioned 50000.5 101 -41.5 run function mg:bw/gen {item:"iron_ingot"}
execute if score #gg mg matches 120.. if entity @a[tag=mg_bw,scores={mg_bwt=1}] in minecraft:overworld positioned 49998.5 101 -41.5 run function mg:bw/gen {item:"gold_ingot"}
execute if score #gi mg matches 20.. if entity @a[tag=mg_bw,scores={mg_bwt=2}] in minecraft:overworld positioned 50041.5 101 0.5 run function mg:bw/gen {item:"iron_ingot"}
execute if score #gg mg matches 120.. if entity @a[tag=mg_bw,scores={mg_bwt=2}] in minecraft:overworld positioned 50041.5 101 2.5 run function mg:bw/gen {item:"gold_ingot"}
execute if score #gi mg matches 20.. if entity @a[tag=mg_bw,scores={mg_bwt=3}] in minecraft:overworld positioned 50000.5 101 41.5 run function mg:bw/gen {item:"iron_ingot"}
execute if score #gg mg matches 120.. if entity @a[tag=mg_bw,scores={mg_bwt=3}] in minecraft:overworld positioned 50002.5 101 41.5 run function mg:bw/gen {item:"gold_ingot"}
execute if score #gi mg matches 20.. if entity @a[tag=mg_bw,scores={mg_bwt=4}] in minecraft:overworld positioned 49959.5 101 0.5 run function mg:bw/gen {item:"iron_ingot"}
execute if score #gg mg matches 120.. if entity @a[tag=mg_bw,scores={mg_bwt=4}] in minecraft:overworld positioned 49959.5 101 -2.5 run function mg:bw/gen {item:"gold_ingot"}
execute if score #gd mg matches 600.. in minecraft:overworld positioned 50026.5 101 26.5 run function mg:bw/gen {item:"diamond"}
execute if score #gd mg matches 600.. in minecraft:overworld positioned 49974.5 101 26.5 run function mg:bw/gen {item:"diamond"}
execute if score #gd mg matches 600.. in minecraft:overworld positioned 50026.5 101 -26.5 run function mg:bw/gen {item:"diamond"}
execute if score #gd mg matches 600.. in minecraft:overworld positioned 49974.5 101 -26.5 run function mg:bw/gen {item:"diamond"}
execute if score #ge mg matches 1200.. in minecraft:overworld positioned 50002.5 101 0.5 run function mg:bw/gen {item:"emerald"}
execute if score #ge mg matches 1200.. in minecraft:overworld positioned 49998.5 101 0.5 run function mg:bw/gen {item:"emerald"}
execute if score #gi mg matches 20.. run scoreboard players set #gi mg 0
execute if score #gg mg matches 120.. run scoreboard players set #gg mg 0
execute if score #gd mg matches 600.. run scoreboard players set #gd mg 0
execute if score #ge mg matches 1200.. run scoreboard players set #ge mg 0
execute as @a[tag=mg_bw,tag=mg_alive] at @s if entity @s[y=-64,dy=139] run kill @s
execute if score #bed1 mg matches 1 in minecraft:overworld unless block 50000 101 -36 minecraft:red_bed run function mg:bw/bed_gone {t:1,n:"Rot",c:"red"}
execute if score #bed2 mg matches 1 in minecraft:overworld unless block 50036 101 0 minecraft:blue_bed run function mg:bw/bed_gone {t:2,n:"Blau",c:"blue"}
execute if score #bed3 mg matches 1 in minecraft:overworld unless block 50000 101 36 minecraft:lime_bed run function mg:bw/bed_gone {t:3,n:"Grün",c:"green"}
execute if score #bed4 mg matches 1 in minecraft:overworld unless block 49964 101 0 minecraft:yellow_bed run function mg:bw/bed_gone {t:4,n:"Gelb",c:"yellow"}
execute as @a[tag=mg_bw,tag=mg_alive,scores={mg_deaths=1..}] run function mg:bw/died
execute as @a[tag=mg_bw,tag=mg_alive,scores={mg_rt=1..}] run function mg:bw/respawn_tick
scoreboard players set #tl mg 0
execute if entity @a[tag=mg_bw,tag=mg_alive,scores={mg_bwt=1}] run scoreboard players add #tl mg 1
execute if entity @a[tag=mg_bw,tag=mg_alive,scores={mg_bwt=2}] run scoreboard players add #tl mg 1
execute if entity @a[tag=mg_bw,tag=mg_alive,scores={mg_bwt=3}] run scoreboard players add #tl mg 1
execute if entity @a[tag=mg_bw,tag=mg_alive,scores={mg_bwt=4}] run scoreboard players add #tl mg 1
execute if score #tl mg matches ..1 run function mg:bw/end
