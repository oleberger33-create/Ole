execute in minecraft:overworld run setblock 50000 101 -36 minecraft:air
execute in minecraft:overworld run setblock 50036 101 0 minecraft:air
execute in minecraft:overworld run setblock 50000 101 36 minecraft:air
execute in minecraft:overworld run setblock 49964 101 0 minecraft:air
title @a[tag=mg_bw] title {"text": "SUDDEN DEATH", "color": "red", "bold": true}
title @a[tag=mg_bw] subtitle {"text": "Alle Betten sind weg – kein Respawn mehr", "color": "white"}
