scoreboard players add #k mg 1
execute if score #k mg > #teams mg run scoreboard players set #k mg 1
scoreboard players operation @s mg_bwt = #k mg
