execute if entity @s[tag=mg_q_bw] run return run function mg:bw/leave
function mg:q/leave_all
tag @s add mg_q_bw
tellraw @a[tag=mg_hub] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " wartet auf ", "color": "gray"}, {"text": "BedWars", "color": "red", "bold": true}, {"text": " – ", "color": "gray"}, {"text": "[Mitspielen]", "color": "green", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 51"}}]
