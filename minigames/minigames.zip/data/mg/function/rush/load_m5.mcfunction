execute in minecraft:overworld run forceload add 984 1160 1147 1240
