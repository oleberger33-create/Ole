$scoreboard players set @s mg_cp $(n)
scoreboard players operation @s mg_prog = @s mg_cp
$scoreboard players set @s mg_cx $(cx)
$scoreboard players set @s mg_cy $(cy)
scoreboard players operation @s mg_cz = @s mg_lane
scoreboard players operation @s mg_cz *= #1000 mg
$scoreboard players add @s mg_cz $(cz)
$execute positioned ~$(r) ~1 ~$(r) run spawnpoint @s ~ ~ ~
$setblock ~$(ax) ~$(ay) ~$(az) minecraft:chest[facing=west]{LootTable:"mg:$(tier)"}
execute if score @s mg_cp matches 24 run return run function mg:rush/finish_player
$title @s actionbar [{"text":"Insel $(n)/24 ✔ ","color":"yellow","bold":true},{"text":"Truhe geöffnet für dich bereit","color":"gold","bold":false}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
scoreboard players operation #m6 mg = @s mg_cp
scoreboard players operation #m6 mg %= #6 mg
$execute if score #m6 mg matches 0 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist auf Insel $(n)/24!", "color": "yellow"}]
