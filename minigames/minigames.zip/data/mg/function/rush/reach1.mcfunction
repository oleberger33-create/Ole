$scoreboard players set @s mg_cp $(n)
scoreboard players operation @s mg_prog = @s mg_cp
execute store result score @s mg_cx run data get entity @s Pos[0]
execute store result score @s mg_cy run data get entity @s Pos[1]
execute store result score @s mg_cz run data get entity @s Pos[2]
execute at @s run spawnpoint @s ~ ~ ~
$setblock ~$(ax) ~$(ay) ~$(az) minecraft:chest[facing=west]{LootTable:"mg:$(tier)"}
execute if score @s mg_cp matches 24 run return run function mg:rush/finish_player
$title @s actionbar [{"text":"Insel $(n)/24 ✔ ","color":"yellow","bold":true},{"text":"Truhe geöffnet für dich bereit","color":"gold","bold":false}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
scoreboard players operation #m6 mg = @s mg_cp
scoreboard players operation #m6 mg %= #6 mg
$execute if score #m6 mg matches 0 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist auf Insel $(n)/24!", "color": "yellow"}]
