execute in minecraft:overworld run forceload add 9984 1960 10307 2040
