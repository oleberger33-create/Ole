scoreboard players add #cdt mg 1
execute if score #cdt mg matches 20.. run scoreboard players remove #cd mg 1
execute if score #cdt mg matches 20.. run scoreboard players set #cdt mg 0
execute if score #cd mg matches 0 run return run function mg:rush/start
execute if score #cdt mg matches 0 run function mg:rush/cd_show
