execute as @a[tag=mg_rush,scores={mg_cp=..0}] at @s if entity @s[x=1029,dx=4,y=100,dy=3,z=599,dz=4] run function mg:rush/cp {n:1,tier:"tier1",x:1031,y:101,z:601}
execute as @a[tag=mg_rush,scores={mg_cp=..1}] at @s if entity @s[x=1071,dx=4,y=98,dy=3,z=594,dz=4] run function mg:rush/cp {n:2,tier:"tier2",x:1073,y:99,z:596}
execute as @a[tag=mg_rush,scores={mg_cp=..2}] at @s if entity @s[x=1117,dx=4,y=96,dy=3,z=589,dz=4] run function mg:rush/cp {n:3,tier:"finish",x:1119,y:97,z:591}
