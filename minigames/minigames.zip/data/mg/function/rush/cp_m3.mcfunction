execute if score @s mg_cp matches ..0 positioned ~42 ~3 ~-2 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:1}
execute if score @s mg_cp matches ..1 positioned ~112 ~10 ~-2 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:2}
execute if score @s mg_cp matches ..2 positioned ~197 ~14 ~-2 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:3}
execute if score @s mg_cp matches ..3 positioned ~273 ~8 ~-3 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:4}
