execute in minecraft:overworld run forceload remove 984 1160 1147 1240
