execute in minecraft:overworld run forceload add 9984 4960 10307 5040
