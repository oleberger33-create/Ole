execute if score @s mg_cp matches 0 run execute in minecraft:overworld run tp @s 1000 101 600 -90 0
execute if score @s mg_cp matches 1 run execute in minecraft:overworld run tp @s 1031 101 601 -90 0
execute if score @s mg_cp matches 2 run execute in minecraft:overworld run tp @s 1073 99 596 -90 0
execute if score @s mg_cp matches 3 run execute in minecraft:overworld run tp @s 1119 97 591 -90 0
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1
