execute if score @s mg_cp matches ..0 positioned ~49 ~9 ~-4 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:1}
execute if score @s mg_cp matches ..1 positioned ~98 ~15 ~-3 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:2}
execute if score @s mg_cp matches ..2 positioned ~158 ~16 ~-9 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:3}
execute if score @s mg_cp matches ..3 positioned ~224 ~19 ~-10 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:4}
