execute in minecraft:overworld run forceload add 9984 7960 10307 8040
