execute in minecraft:overworld run forceload remove 9984 1960 10307 2040
