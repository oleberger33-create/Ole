execute in minecraft:overworld run forceload remove 9984 2960 10307 3040
