execute as @a[tag=mg_rush,scores={mg_cp=..0}] at @s if entity @s[x=1027,dx=4,y=100,dy=3,z=304,dz=4] run function mg:rush/cp {n:1,tier:"tier1",x:1029,y:101,z:306}
execute as @a[tag=mg_rush,scores={mg_cp=..1}] at @s if entity @s[x=1069,dx=4,y=104,dy=3,z=303,dz=4] run function mg:rush/cp {n:2,tier:"tier2",x:1071,y:105,z:305}
execute as @a[tag=mg_rush,scores={mg_cp=..2}] at @s if entity @s[x=1119,dx=4,y=104,dy=3,z=305,dz=4] run function mg:rush/cp {n:3,tier:"finish",x:1121,y:105,z:307}
