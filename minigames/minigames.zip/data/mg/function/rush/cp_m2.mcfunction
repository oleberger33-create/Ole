execute if score @s mg_cp matches ..0 positioned ~39 ~3 ~2 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:1}
execute if score @s mg_cp matches ..1 positioned ~97 ~9 ~0 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:2}
execute if score @s mg_cp matches ..2 positioned ~161 ~13 ~0 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:3}
execute if score @s mg_cp matches ..3 positioned ~228 ~16 ~1 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:4}
