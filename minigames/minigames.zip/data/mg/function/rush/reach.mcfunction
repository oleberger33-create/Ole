$scoreboard players set @s mg_cp $(n)
execute store result score @s mg_cx run data get entity @s Pos[0]
execute store result score @s mg_cy run data get entity @s Pos[1]
execute store result score @s mg_cz run data get entity @s Pos[2]
execute at @s run spawnpoint @s ~ ~ ~
execute if score @s mg_cp matches 4 run return run function mg:rush/finish_player
$title @s actionbar [{"text":"Checkpoint $(n) ✔ ","color":"yellow","bold":true},{"text":"Truhe nicht vergessen!","color":"gold","bold":false}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
