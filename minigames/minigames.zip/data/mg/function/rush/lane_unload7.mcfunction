execute in minecraft:overworld run forceload remove 9984 6960 10307 7040
