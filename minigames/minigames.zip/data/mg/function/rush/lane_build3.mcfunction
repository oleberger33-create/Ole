execute if score #map mg matches 1 in minecraft:overworld positioned 10000 100 3000 run function mg:build/lane_m1
execute if score #map mg matches 2 in minecraft:overworld positioned 10000 100 3000 run function mg:build/lane_m2
execute if score #map mg matches 3 in minecraft:overworld positioned 10000 100 3000 run function mg:build/lane_m3
execute if score #map mg matches 4 in minecraft:overworld positioned 10000 100 3000 run function mg:build/lane_m4
execute if score #map mg matches 5 in minecraft:overworld positioned 10000 100 3000 run function mg:build/lane_m5
