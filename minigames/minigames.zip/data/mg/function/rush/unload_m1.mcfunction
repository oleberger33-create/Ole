execute in minecraft:overworld run forceload remove 984 -40 1147 40
