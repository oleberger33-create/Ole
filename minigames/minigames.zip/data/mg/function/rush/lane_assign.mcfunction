scoreboard players add #L mg 1
scoreboard players operation @s mg_lane = #L mg
scoreboard players remove @s mg_lane 1
scoreboard players operation @s mg_lane %= #6 mg
scoreboard players add @s mg_lane 1
