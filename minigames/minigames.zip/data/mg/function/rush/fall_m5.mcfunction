execute if score @s mg_cp matches 0 run execute in minecraft:overworld run tp @s 1000 101 1200 -90 0
execute if score @s mg_cp matches 1 run execute in minecraft:overworld run tp @s 1032 101 1198 -90 0
execute if score @s mg_cp matches 2 run execute in minecraft:overworld run tp @s 1074 104 1201 -90 0
execute if score @s mg_cp matches 3 run execute in minecraft:overworld run tp @s 1123 103 1206 -90 0
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1
