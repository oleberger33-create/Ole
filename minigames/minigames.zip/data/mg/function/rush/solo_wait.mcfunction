scoreboard players add #rush_et mg 1
execute unless entity @a[tag=mg_rush] run return run function mg:rush/stop
execute if score #rush_et mg matches 100.. run function mg:rush/stop
