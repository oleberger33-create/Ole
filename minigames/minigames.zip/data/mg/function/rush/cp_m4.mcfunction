execute as @a[tag=mg_rush,scores={mg_cp=..0}] at @s if entity @s[x=1029,dx=4,y=100,dy=3,z=898,dz=4] run function mg:rush/cp {n:1,tier:"tier1",x:1031,y:101,z:900}
execute as @a[tag=mg_rush,scores={mg_cp=..1}] at @s if entity @s[x=1071,dx=4,y=100,dy=3,z=897,dz=4] run function mg:rush/cp {n:2,tier:"tier2",x:1073,y:101,z:899}
execute as @a[tag=mg_rush,scores={mg_cp=..2}] at @s if entity @s[x=1119,dx=4,y=96,dy=3,z=903,dz=4] run function mg:rush/cp {n:3,tier:"finish",x:1121,y:97,z:905}
