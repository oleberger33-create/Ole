execute if score @s mg_cp matches ..0 positioned ~44 ~3 ~-1 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:1}
execute if score @s mg_cp matches ..1 positioned ~95 ~-2 ~-3 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:2}
execute if score @s mg_cp matches ..2 positioned ~155 ~11 ~-2 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:3}
execute if score @s mg_cp matches ..3 positioned ~210 ~14 ~-1 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:4}
