execute in minecraft:overworld run forceload remove 9984 960 10307 1040
