scoreboard players set #ok mg 1
execute if score #L mg matches 1.. in minecraft:overworld unless loaded 10000 100 1000 run scoreboard players set #ok mg 0
execute if score #L mg matches 1.. in minecraft:overworld unless loaded 10145 100 1000 run scoreboard players set #ok mg 0
execute if score #L mg matches 1.. in minecraft:overworld unless loaded 10291 100 1000 run scoreboard players set #ok mg 0
execute if score #L mg matches 2.. in minecraft:overworld unless loaded 10000 100 2000 run scoreboard players set #ok mg 0
execute if score #L mg matches 2.. in minecraft:overworld unless loaded 10145 100 2000 run scoreboard players set #ok mg 0
execute if score #L mg matches 2.. in minecraft:overworld unless loaded 10291 100 2000 run scoreboard players set #ok mg 0
execute if score #L mg matches 3.. in minecraft:overworld unless loaded 10000 100 3000 run scoreboard players set #ok mg 0
execute if score #L mg matches 3.. in minecraft:overworld unless loaded 10145 100 3000 run scoreboard players set #ok mg 0
execute if score #L mg matches 3.. in minecraft:overworld unless loaded 10291 100 3000 run scoreboard players set #ok mg 0
execute if score #L mg matches 4.. in minecraft:overworld unless loaded 10000 100 4000 run scoreboard players set #ok mg 0
execute if score #L mg matches 4.. in minecraft:overworld unless loaded 10145 100 4000 run scoreboard players set #ok mg 0
execute if score #L mg matches 4.. in minecraft:overworld unless loaded 10291 100 4000 run scoreboard players set #ok mg 0
execute if score #L mg matches 5.. in minecraft:overworld unless loaded 10000 100 5000 run scoreboard players set #ok mg 0
execute if score #L mg matches 5.. in minecraft:overworld unless loaded 10145 100 5000 run scoreboard players set #ok mg 0
execute if score #L mg matches 5.. in minecraft:overworld unless loaded 10291 100 5000 run scoreboard players set #ok mg 0
execute if score #L mg matches 6.. in minecraft:overworld unless loaded 10000 100 6000 run scoreboard players set #ok mg 0
execute if score #L mg matches 6.. in minecraft:overworld unless loaded 10145 100 6000 run scoreboard players set #ok mg 0
execute if score #L mg matches 6.. in minecraft:overworld unless loaded 10291 100 6000 run scoreboard players set #ok mg 0
execute if score #L mg matches 7.. in minecraft:overworld unless loaded 10000 100 7000 run scoreboard players set #ok mg 0
execute if score #L mg matches 7.. in minecraft:overworld unless loaded 10145 100 7000 run scoreboard players set #ok mg 0
execute if score #L mg matches 7.. in minecraft:overworld unless loaded 10291 100 7000 run scoreboard players set #ok mg 0
execute if score #L mg matches 8.. in minecraft:overworld unless loaded 10000 100 8000 run scoreboard players set #ok mg 0
execute if score #L mg matches 8.. in minecraft:overworld unless loaded 10145 100 8000 run scoreboard players set #ok mg 0
execute if score #L mg matches 8.. in minecraft:overworld unless loaded 10291 100 8000 run scoreboard players set #ok mg 0
scoreboard players add #wait mg 1
execute if score #ok mg matches 0 if score #wait mg matches ..200 run return 0
function mg:rush/start
