$scoreboard players set @s mg_cp $(n)
$execute in minecraft:overworld run spawnpoint @s $(x) $(y) $(z)
$loot give @s loot mg:rush_$(tier)
$title @s actionbar [{"text":"Checkpoint $(n) ✔ ","color":"yellow","bold":true},{"text":"Loot erhalten","color":"gold","bold":false}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if score @s mg_cp matches 3 run function mg:rush/finish_player
