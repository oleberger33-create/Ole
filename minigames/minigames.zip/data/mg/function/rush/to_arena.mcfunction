execute in minecraft:overworld run kill @e[type=minecraft:ender_pearl,x=29980,dx=4652,y=60,dy=110,z=940,dz=5120]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=29980,dx=4652,y=60,dy=110,z=940,dz=5120]
execute store result score #fighters mg if entity @a[tag=mg_rush]
scoreboard players set #arena_t mg 0
scoreboard players set #rush mg 3
scoreboard players set #grace mg 100
effect clear @a[tag=mg_rush] minecraft:resistance
effect clear @a[tag=mg_rush] minecraft:saturation
tag @a[tag=mg_rush] add mg_fight
execute in minecraft:overworld run tp @a[tag=mg_fight] 2000 101 0
execute in minecraft:overworld run spreadplayers 2000 0 6 13 under 103 false @a[tag=mg_fight]
execute as @a[tag=mg_fight] run execute in minecraft:overworld run spawnpoint @s 0 101 17
scoreboard players operation @a[tag=mg_fight] mg_deaths = #zero mg
effect give @a[tag=mg_fight] minecraft:resistance 5 4 true
effect give @a[tag=mg_fight] minecraft:instant_health 1 10 true
bossbar set mg:rush name {"text": "ARENA – wer zuletzt steht, gewinnt!", "color": "red", "bold": true}
bossbar set mg:rush color red
bossbar set mg:rush value 900
title @a[tag=mg_fight] times 5 40 10
title @a[tag=mg_fight] title {"text": "ARENA!", "color": "red", "bold": true}
title @a[tag=mg_fight] subtitle {"text": "5 Sekunden Schutz, dann kämpfen", "color": "white"}
execute as @a[tag=mg_fight] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.7 1.2
