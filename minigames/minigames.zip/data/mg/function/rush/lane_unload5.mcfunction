execute in minecraft:overworld run forceload remove 9984 4960 10307 5040
