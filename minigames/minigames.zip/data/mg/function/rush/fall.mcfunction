execute if score @s mg_cp matches 0 run execute in minecraft:overworld run tp @s 1000 101 0 -90 0
execute if score @s mg_cp matches 1 run execute in minecraft:overworld run tp @s 1029 101 4 -90 0
execute if score @s mg_cp matches 2 run execute in minecraft:overworld run tp @s 1071 100 7 -90 0
execute if score @s mg_cp matches 3 run execute in minecraft:overworld run tp @s 1118 100 0 -90 0
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1
