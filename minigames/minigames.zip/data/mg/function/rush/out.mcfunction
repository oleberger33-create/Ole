scoreboard players set @s mg_deaths 0
tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist raus!", "color": "red"}]
tag @s remove mg_fight
function mg:hub/enter
