scoreboard players set @s mg_deaths 0
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist in der Parkour-Rush-Arena raus!", "color": "red"}]
tag @s remove mg_fight
function mg:hub/enter
