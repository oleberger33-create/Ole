title @a[tag=mg_hub] times 0 25 5
title @a[tag=mg_hub] title {"score": {"name": "#cd", "objective": "mg"}, "color": "green", "bold": true}
title @a[tag=mg_hub] subtitle {"text": "Parkour-Rush", "color": "gray"}
execute as @a[tag=mg_hub] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
