execute in minecraft:overworld run forceload add 9984 2960 10307 3040
