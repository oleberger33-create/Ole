execute in minecraft:overworld run forceload remove 9984 7960 10307 8040
