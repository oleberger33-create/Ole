tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "aqua", "bold": true}, {"text": " ist im Ziel!", "color": "white"}]
title @s title {"text":"ZIEL!","color":"aqua","bold":true}
execute if score #finished mg matches 0 if score #left mg matches 21.. run scoreboard players set #left mg 20
scoreboard players set #finished mg 1
execute if score #finished mg matches 1 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Arena in ", "color": "gray"}, {"score": {"name": "#left", "objective": "mg"}, "color": "red"}, {"text": " Sekunden!", "color": "gray"}]
