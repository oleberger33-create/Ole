execute if score #rush_np mg matches ..1 run return run function mg:rush/solo_finish
title @s times 5 40 10
title @s title {"text": "ZIEL!", "color": "aqua", "bold": true}
title @s subtitle {"text": "Hol dir die 2 Truhen!", "color": "gold"}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute if score #finished mg matches 0 if score #left mg matches 31.. run scoreboard players set #left mg 30
scoreboard players set #finished mg 1
tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "aqua", "bold": true}, {"text": " ist im Ziel! ", "color": "white"}, {"text": "Arena in ", "color": "gray"}, {"score": {"name": "#left", "objective": "mg"}, "color": "red"}, {"text": " Sekunden!", "color": "gray"}]
