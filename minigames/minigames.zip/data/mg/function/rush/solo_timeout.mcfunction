scoreboard players set #rush mg 4
scoreboard players set #rush_et mg 0
title @a[tag=mg_rush] times 5 60 15
title @a[tag=mg_rush] title {"text": "Zeit um!", "color": "red", "bold": true}
execute as @a[tag=mg_rush] run title @s subtitle [{"text":"Insel ","color":"gray"},{"score":{"name":"@s","objective":"mg_cp"},"color":"yellow","bold":true},{"text":"/24 erreicht","color":"gray"}]
execute as @a[tag=mg_rush] run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zeit um! Du hast Insel ", "color": "gray"}, {"score": {"name": "@s", "objective": "mg_cp"}, "color": "yellow", "bold": true}, {"text": "/24 erreicht. Für eine Bestzeit musst du alle 24 Inseln schaffen.", "color": "gray"}]
bossbar set mg:rush name {"text": "Solo-Zeitrennen vorbei", "color": "red", "bold": true}
bossbar set mg:rush color red
execute as @a[tag=mg_rush] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.7
