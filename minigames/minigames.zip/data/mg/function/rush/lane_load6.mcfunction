execute in minecraft:overworld run forceload add 9984 5960 10307 6040
