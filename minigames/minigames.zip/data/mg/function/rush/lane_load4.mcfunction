execute in minecraft:overworld run forceload add 9984 3960 10307 4040
