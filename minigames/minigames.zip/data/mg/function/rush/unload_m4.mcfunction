execute in minecraft:overworld run forceload remove 984 860 1147 940
