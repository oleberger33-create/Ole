scoreboard players remove #grace mg 1
execute as @a[tag=mg_fight,scores={mg_deaths=1..}] run function mg:rush/out
execute as @a[tag=mg_fight] at @s if entity @s[y=-64,dy=158] run function mg:rush/out_fall
scoreboard players set #alive mg 0
execute as @a[tag=mg_fight] run scoreboard players add #alive mg 1
execute if score #alive mg matches ..1 run function mg:rush/end
