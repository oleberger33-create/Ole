scoreboard players remove #grace mg 1
scoreboard players add #arena_t mg 1
bossbar set mg:rush players @a[tag=mg_fight]
execute as @a[tag=mg_fight] unless entity @s[x=1974,dx=52,y=92,dy=40,z=-26,dz=52] run function mg:rush/out_fall
execute if score #arena_t mg matches 2400 run effect give @a[tag=mg_fight] minecraft:glowing infinite 0 true
execute if score #arena_t mg matches 2400 run tellraw @a[tag=mg_fight] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 1 Minute – danach teilen sich alle Überlebenden den Sieg.", "color": "red"}]
execute if score #arena_t mg matches 3600.. run return run function mg:rush/end
execute as @a[tag=mg_fight,scores={mg_deaths=1..}] run function mg:rush/out
execute as @a[tag=mg_fight] at @s if entity @s[y=-64,dy=158] run function mg:rush/out_fall
scoreboard players set #alive mg 0
execute as @a[tag=mg_fight] run scoreboard players add #alive mg 1
execute if score #alive mg matches ..1 run function mg:rush/end
