execute in minecraft:overworld run forceload add 984 260 1147 340
