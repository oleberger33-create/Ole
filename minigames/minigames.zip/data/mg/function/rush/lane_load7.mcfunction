execute in minecraft:overworld run forceload add 9984 6960 10307 7040
