execute in minecraft:overworld run forceload add 9984 960 10307 1040
