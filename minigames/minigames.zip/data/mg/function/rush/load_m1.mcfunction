execute in minecraft:overworld run forceload add 984 -40 1147 40
