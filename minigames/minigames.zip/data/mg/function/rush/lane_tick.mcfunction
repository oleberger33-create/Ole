execute if score #map mg matches 1 run function mg:rush/cp_m1
execute if score #map mg matches 2 run function mg:rush/cp_m2
execute if score #map mg matches 3 run function mg:rush/cp_m3
execute if score #map mg matches 4 run function mg:rush/cp_m4
execute if score #map mg matches 5 run function mg:rush/cp_m5
