execute as @a[tag=mg_fight] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Parkour-Rush!", "color": "white"}]
execute if score #fighters mg matches 2.. run scoreboard players add @a[tag=mg_fight] mg_wins 1
execute if score #fighters mg matches 2.. run scoreboard players add @a[tag=mg_fight] mg_coins 10
title @a[tag=mg_rush] times 10 60 20
execute as @a[tag=mg_fight] run title @a[tag=mg_rush] title [{"selector":"@s","color":"gold","bold":true}]
title @a[tag=mg_rush] subtitle {"text": "gewinnt Parkour-Rush!", "color": "white"}
execute as @a[tag=mg_fight] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720,5635925],has_twinkle:true}]}}}}
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
function mg:rush/stop
