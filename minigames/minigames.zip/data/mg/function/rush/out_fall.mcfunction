clear @s
function mg:rush/out
