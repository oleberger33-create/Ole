execute if score @s mg_cp matches 0 run execute in minecraft:overworld run tp @s 1000 101 300 -90 0
execute if score @s mg_cp matches 1 run execute in minecraft:overworld run tp @s 1029 101 306 -90 0
execute if score @s mg_cp matches 2 run execute in minecraft:overworld run tp @s 1071 105 305 -90 0
execute if score @s mg_cp matches 3 run execute in minecraft:overworld run tp @s 1121 105 307 -90 0
playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1
