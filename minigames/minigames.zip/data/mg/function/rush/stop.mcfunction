scoreboard players set #rush mg 0
bossbar set mg:rush visible false
bossbar set mg:rush color green
execute as @a[tag=mg_rush] run function mg:hub/enter
execute in minecraft:overworld run kill @e[type=minecraft:item,x=1970,dx=60,y=90,dy=40,z=-30,dz=60]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=990,dx=161,y=80,dy=50,z=-45,dz=1300]
