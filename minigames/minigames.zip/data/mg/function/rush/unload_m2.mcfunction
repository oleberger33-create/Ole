execute in minecraft:overworld run forceload remove 984 260 1147 340
