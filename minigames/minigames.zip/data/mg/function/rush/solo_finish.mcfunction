scoreboard players set #rush mg 4
scoreboard players set #rush_et mg 0
scoreboard players operation #pbv mg = #rush_tt mg
scoreboard players operation #rz_d mg = #rush_tt mg
scoreboard players operation #rz_d mg /= #2 mg
scoreboard players operation #rz_s1 mg = #rz_d mg
scoreboard players operation #rz_s1 mg /= #10 mg
scoreboard players operation #rz_m mg = #rz_s1 mg
scoreboard players operation #rz_m mg /= #60 mg
scoreboard players operation #rz_s1 mg %= #60 mg
scoreboard players operation #rz_s10 mg = #rz_s1 mg
scoreboard players operation #rz_s10 mg /= #10 mg
scoreboard players operation #rz_s1 mg %= #10 mg
scoreboard players operation #rz_d mg %= #10 mg
title @s times 5 70 15
title @s title {"text": "ZIEL!", "color": "aqua", "bold": true}
title @s subtitle [{"text": "Zeit: ", "color": "gray"}, {"score": {"name": "#rz_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#rz_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#rz_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#rz_d", "objective": "mg"}, "color": "yellow", "bold": true}]
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Geschafft! Alle 24 Inseln in ", "color": "gray"}, {"score": {"name": "#rz_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#rz_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#rz_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#rz_d", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "gray"}]
function mg:rush/pb
scoreboard players add @s mg_coins 3
execute if score #pbn mg matches 1 run scoreboard players add @s mg_coins 5
execute if score #pbn mg matches 0 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "+3 Münzen", "color": "yellow"}]
execute if score #pbn mg matches 1 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "+3 Münzen, +5 Rekord-Bonus", "color": "yellow"}]
bossbar set mg:rush name {"text": "Solo-Zeitrennen geschafft!", "color": "aqua", "bold": true}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
