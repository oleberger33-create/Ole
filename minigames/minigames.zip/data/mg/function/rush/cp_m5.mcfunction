execute if score @s mg_cp matches ..0 positioned ~47 ~6 ~1 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:1}
execute if score @s mg_cp matches ..1 positioned ~105 ~14 ~1 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:2}
execute if score @s mg_cp matches ..2 positioned ~168 ~17 ~-1 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:3}
execute if score @s mg_cp matches ..3 positioned ~234 ~14 ~-5 if entity @s[dx=4,dy=3,dz=4] run function mg:rush/reach {n:4}
