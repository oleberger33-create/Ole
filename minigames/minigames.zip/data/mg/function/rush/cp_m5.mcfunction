execute as @a[tag=mg_rush,scores={mg_cp=..0}] at @s if entity @s[x=1030,dx=4,y=100,dy=3,z=1196,dz=4] run function mg:rush/cp {n:1,tier:"tier1",x:1032,y:101,z:1198}
execute as @a[tag=mg_rush,scores={mg_cp=..1}] at @s if entity @s[x=1072,dx=4,y=103,dy=3,z=1199,dz=4] run function mg:rush/cp {n:2,tier:"tier2",x:1074,y:104,z:1201}
execute as @a[tag=mg_rush,scores={mg_cp=..2}] at @s if entity @s[x=1121,dx=4,y=102,dy=3,z=1204,dz=4] run function mg:rush/cp {n:3,tier:"finish",x:1123,y:103,z:1206}
