execute in minecraft:overworld run forceload remove 9984 3960 10307 4040
