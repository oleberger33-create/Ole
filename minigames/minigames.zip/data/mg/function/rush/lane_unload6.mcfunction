execute in minecraft:overworld run forceload remove 9984 5960 10307 6040
