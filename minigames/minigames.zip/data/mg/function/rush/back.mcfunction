execute store result storage mg:tmp p.x int 1 run scoreboard players get @s mg_cx
execute store result storage mg:tmp p.y int 1 run scoreboard players get @s mg_cy
execute store result storage mg:tmp p.z int 1 run scoreboard players get @s mg_cz
function mg:rush/back_tp with storage mg:tmp p
execute at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1
