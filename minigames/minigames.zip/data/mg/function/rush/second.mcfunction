scoreboard players set #t mg 0
scoreboard players remove #left mg 1
scoreboard players operation #lm mg = #left mg
scoreboard players operation #lm mg /= #60 mg
scoreboard players operation #ls mg = #left mg
scoreboard players operation #ls mg %= #60 mg
execute if score #ls mg matches 10.. run bossbar set mg:rush name [{"text": "Parkour-Rush", "color": "green", "bold": true}, {"text": "   Arena in ", "color": "white"}, {"score": {"name": "#lm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#ls", "objective": "mg"}, "color": "white"}]
execute if score #ls mg matches ..9 run bossbar set mg:rush name [{"text": "Parkour-Rush", "color": "green", "bold": true}, {"text": "   Arena in ", "color": "white"}, {"score": {"name": "#lm", "objective": "mg"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#ls", "objective": "mg"}, "color": "white"}]
execute store result bossbar mg:rush value run scoreboard players get #left mg
bossbar set mg:rush players @a[tag=mg_rush]
execute as @a[tag=mg_rush,scores={mg_cp=..3}] run title @s actionbar [{"text":"Checkpoint ","color":"gray"},{"score":{"name":"@s","objective":"mg_cp"},"color":"yellow","bold":true},{"text":"/3","color":"gray"},{"text":"  ·  Ziel danach","color":"dark_gray"}]
execute if score #left mg matches 1..5 as @a[tag=mg_rush] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
execute unless entity @a[tag=mg_rush] run return run function mg:rush/stop
execute if score #left mg matches ..0 run function mg:rush/to_arena
