scoreboard players set #t mg 0
scoreboard players remove #left mg 1
scoreboard players operation #lm mg = #left mg
scoreboard players operation #lm mg /= #60 mg
scoreboard players operation #ls mg = #left mg
scoreboard players operation #ls mg %= #60 mg
execute if score #ls mg matches 10.. run bossbar set mg:rush name [{"text": "Parkour-Rush", "color": "green", "bold": true}, {"text": "   Arena in ", "color": "white"}, {"score": {"name": "#lm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#ls", "objective": "mg"}, "color": "white"}]
execute if score #ls mg matches ..9 run bossbar set mg:rush name [{"text": "Parkour-Rush", "color": "green", "bold": true}, {"text": "   Arena in ", "color": "white"}, {"score": {"name": "#lm", "objective": "mg"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#ls", "objective": "mg"}, "color": "white"}]
execute store result bossbar mg:rush value run scoreboard players get #left mg
bossbar set mg:rush players @a[tag=mg_rush]
execute as @a[tag=mg_rush,scores={mg_cp=..23}] run title @s actionbar [{"text":"Insel ","color":"gray"},{"score":{"name":"@s","objective":"mg_cp"},"color":"yellow","bold":true},{"text":"/24","color":"gray"}]
execute if score #left mg matches 1..5 as @a[tag=mg_rush] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
execute if score #left mg matches 60 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 1 Minute bis zur Arena!", "color": "red", "bold": true}]
execute unless entity @a[tag=mg_rush] run return run function mg:rush/stop
execute if score #left mg matches ..0 run function mg:rush/to_arena
