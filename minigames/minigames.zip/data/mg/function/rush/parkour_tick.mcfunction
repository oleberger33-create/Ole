execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 30000 100 1000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 30000 100 2000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 30000 100 3000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 30000 100 4000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 30000 100 5000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 30000 100 6000 run function mg:rush/cp_m1
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 31000 100 1000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 31000 100 2000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 31000 100 3000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 31000 100 4000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 31000 100 5000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 31000 100 6000 run function mg:rush/cp_m2
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 32000 100 1000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 32000 100 2000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 32000 100 3000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 32000 100 4000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 32000 100 5000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 32000 100 6000 run function mg:rush/cp_m3
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 33000 100 1000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 33000 100 2000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 33000 100 3000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 33000 100 4000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 33000 100 5000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 33000 100 6000 run function mg:rush/cp_m4
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 34000 100 1000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 34000 100 2000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 34000 100 3000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 34000 100 4000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 34000 100 5000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 34000 100 6000 run function mg:rush/cp_m5
execute if score #map mg matches 1 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=151] run function mg:rush/back
execute if score #map mg matches 2 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=154] run function mg:rush/back
execute if score #map mg matches 3 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=154] run function mg:rush/back
execute if score #map mg matches 4 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=154] run function mg:rush/back
execute if score #map mg matches 5 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=154] run function mg:rush/back
execute as @a[tag=mg_rush] at @s if block ~ ~-1 ~ minecraft:emerald_block run effect give @s minecraft:jump_boost 8 1 true
execute as @a[tag=mg_rush] at @s if block ~ ~-1 ~ minecraft:redstone_block run effect give @s minecraft:speed 6 1 true
scoreboard players add #t mg 1
scoreboard players add #rush_tt mg 1
execute if score #t mg matches 20.. run function mg:rush/second
