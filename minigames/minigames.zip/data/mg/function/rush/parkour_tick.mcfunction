execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 20000 100 1000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 20000 100 2000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 20000 100 3000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 20000 100 4000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 20000 100 5000 run function mg:rush/cp_m1
execute if score #map mg matches 1 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 20000 100 6000 run function mg:rush/cp_m1
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 21000 100 1000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 21000 100 2000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 21000 100 3000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 21000 100 4000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 21000 100 5000 run function mg:rush/cp_m2
execute if score #map mg matches 2 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 21000 100 6000 run function mg:rush/cp_m2
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 22000 100 1000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 22000 100 2000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 22000 100 3000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 22000 100 4000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 22000 100 5000 run function mg:rush/cp_m3
execute if score #map mg matches 3 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 22000 100 6000 run function mg:rush/cp_m3
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 23000 100 1000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 23000 100 2000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 23000 100 3000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 23000 100 4000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 23000 100 5000 run function mg:rush/cp_m4
execute if score #map mg matches 4 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 23000 100 6000 run function mg:rush/cp_m4
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=1}] in minecraft:overworld positioned 24000 100 1000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=2}] in minecraft:overworld positioned 24000 100 2000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=3}] in minecraft:overworld positioned 24000 100 3000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=4}] in minecraft:overworld positioned 24000 100 4000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=5}] in minecraft:overworld positioned 24000 100 5000 run function mg:rush/cp_m5
execute if score #map mg matches 5 as @a[tag=mg_rush,scores={mg_lane=6}] in minecraft:overworld positioned 24000 100 6000 run function mg:rush/cp_m5
execute if score #map mg matches 1 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=154] run function mg:rush/back
execute if score #map mg matches 2 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=154] run function mg:rush/back
execute if score #map mg matches 3 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=154] run function mg:rush/back
execute if score #map mg matches 4 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=152] run function mg:rush/back
execute if score #map mg matches 5 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=154] run function mg:rush/back
scoreboard players add #t mg 1
execute if score #t mg matches 20.. run function mg:rush/second
