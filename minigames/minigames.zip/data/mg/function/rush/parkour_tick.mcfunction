execute if score #map mg matches 1 run function mg:rush/cp_m1
execute if score #map mg matches 2 run function mg:rush/cp_m2
execute if score #map mg matches 3 run function mg:rush/cp_m3
execute if score #map mg matches 4 run function mg:rush/cp_m4
execute if score #map mg matches 5 run function mg:rush/cp_m5
execute if score #map mg matches 1 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=156] run function mg:rush/fall_m1
execute if score #map mg matches 2 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=156] run function mg:rush/fall_m2
execute if score #map mg matches 3 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=156] run function mg:rush/fall_m3
execute if score #map mg matches 4 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=156] run function mg:rush/fall_m4
execute if score #map mg matches 5 as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=156] run function mg:rush/fall_m5
scoreboard players add #t mg 1
execute if score #t mg matches 20.. run function mg:rush/second
