execute as @a[tag=mg_rush,scores={mg_cp=..0}] at @s if entity @s[x=1027,dx=4,y=100,dy=3,z=2,dz=4] run function mg:rush/cp {n:1,tier:"tier1",x:1029,y:101,z:4}
execute as @a[tag=mg_rush,scores={mg_cp=..1}] at @s if entity @s[x=1069,dx=4,y=99,dy=3,z=5,dz=4] run function mg:rush/cp {n:2,tier:"tier2",x:1071,y:100,z:7}
execute as @a[tag=mg_rush,scores={mg_cp=..2}] at @s if entity @s[x=1116,dx=4,y=99,dy=3,z=-2,dz=4] run function mg:rush/cp {n:3,tier:"finish",x:1118,y:100,z:0}
execute as @a[tag=mg_rush] at @s if entity @s[y=-64,dy=156] run function mg:rush/fall
scoreboard players add #t mg 1
execute if score #t mg matches 20.. run function mg:rush/second
