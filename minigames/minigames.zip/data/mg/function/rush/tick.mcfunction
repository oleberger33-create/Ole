execute if score #rush mg matches 1 run function mg:rush/cd_tick
execute unless score #rush mg matches 2.. run return 0
execute if score #rush mg matches 2 run function mg:rush/parkour_tick
execute if score #rush mg matches 3 run function mg:rush/arena_tick
execute if score #rush mg matches 4 run function mg:rush/solo_wait
