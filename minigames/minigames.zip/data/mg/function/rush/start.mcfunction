tag @a[tag=mg_hub,scores={mg_lane=1..}] add mg_rush
tag @a[tag=mg_rush] remove mg_hub
execute as @a[tag=mg_rush] run function mg:q/leave_all
clear @a[tag=mg_rush]
effect clear @a[tag=mg_rush]
gamemode adventure @a[tag=mg_rush]
scoreboard players set @a[tag=mg_rush] mg_cp 0
execute store result score #map mg run random value 1..5
kill @e[type=minecraft:text_display,tag=mg_lh]
execute if score #L mg matches 1.. run function mg:rush/lane_build1
execute if score #L mg matches 2.. run function mg:rush/lane_build2
execute if score #L mg matches 3.. run function mg:rush/lane_build3
execute if score #L mg matches 4.. run function mg:rush/lane_build4
execute if score #L mg matches 5.. run function mg:rush/lane_build5
execute if score #L mg matches 6.. run function mg:rush/lane_build6
execute if score #L mg matches 7.. run function mg:rush/lane_build7
execute if score #L mg matches 8.. run function mg:rush/lane_build8
execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=1}] 10000 101 1000 -90 0
execute as @a[tag=mg_rush,scores={mg_lane=1}] run execute in minecraft:overworld run spawnpoint @s 10000 101 1000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cx 10000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cy 101
scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cz 1000
execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=2}] 10000 101 2000 -90 0
execute as @a[tag=mg_rush,scores={mg_lane=2}] run execute in minecraft:overworld run spawnpoint @s 10000 101 2000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cx 10000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cy 101
scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cz 2000
execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=3}] 10000 101 3000 -90 0
execute as @a[tag=mg_rush,scores={mg_lane=3}] run execute in minecraft:overworld run spawnpoint @s 10000 101 3000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cx 10000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cy 101
scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cz 3000
execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=4}] 10000 101 4000 -90 0
execute as @a[tag=mg_rush,scores={mg_lane=4}] run execute in minecraft:overworld run spawnpoint @s 10000 101 4000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cx 10000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cy 101
scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cz 4000
execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=5}] 10000 101 5000 -90 0
execute as @a[tag=mg_rush,scores={mg_lane=5}] run execute in minecraft:overworld run spawnpoint @s 10000 101 5000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cx 10000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cy 101
scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cz 5000
execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=6}] 10000 101 6000 -90 0
execute as @a[tag=mg_rush,scores={mg_lane=6}] run execute in minecraft:overworld run spawnpoint @s 10000 101 6000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cx 10000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cy 101
scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cz 6000
execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=7}] 10000 101 7000 -90 0
execute as @a[tag=mg_rush,scores={mg_lane=7}] run execute in minecraft:overworld run spawnpoint @s 10000 101 7000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=7}] mg_cx 10000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=7}] mg_cy 101
scoreboard players set @a[tag=mg_rush,scores={mg_lane=7}] mg_cz 7000
execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=8}] 10000 101 8000 -90 0
execute as @a[tag=mg_rush,scores={mg_lane=8}] run execute in minecraft:overworld run spawnpoint @s 10000 101 8000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=8}] mg_cx 10000
scoreboard players set @a[tag=mg_rush,scores={mg_lane=8}] mg_cy 101
scoreboard players set @a[tag=mg_rush,scores={mg_lane=8}] mg_cz 8000
execute if score #L mg matches 1.. run function mg:rush/lane_unload1
execute if score #L mg matches 2.. run function mg:rush/lane_unload2
execute if score #L mg matches 3.. run function mg:rush/lane_unload3
execute if score #L mg matches 4.. run function mg:rush/lane_unload4
execute if score #L mg matches 5.. run function mg:rush/lane_unload5
execute if score #L mg matches 6.. run function mg:rush/lane_unload6
execute if score #L mg matches 7.. run function mg:rush/lane_unload7
execute if score #L mg matches 8.. run function mg:rush/lane_unload8
effect give @a[tag=mg_rush] minecraft:saturation infinite 0 true
effect give @a[tag=mg_rush] minecraft:resistance infinite 4 true
scoreboard players set #rush mg 2
scoreboard players set #t mg 0
scoreboard players set #left mg 360
scoreboard players set #finished mg 0
bossbar set mg:rush players @a[tag=mg_rush]
bossbar set mg:rush visible true
bossbar set mg:rush max 360
title @a[tag=mg_rush] times 5 50 10
title @a[tag=mg_rush] title {"text": "LOS!", "color": "green", "bold": true}
execute if score #map mg matches 1 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Himmel", "color": "aqua", "bold": true}, {"text": " · Truhen plündern!", "color": "white"}]
execute if score #map mg matches 2 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Nether", "color": "red", "bold": true}, {"text": " · Truhen plündern!", "color": "white"}]
execute if score #map mg matches 3 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Eis", "color": "aqua", "bold": true}, {"text": " · Truhen plündern!", "color": "white"}]
execute if score #map mg matches 4 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Dschungel", "color": "green", "bold": true}, {"text": " · Truhen plündern!", "color": "white"}]
execute if score #map mg matches 5 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "End", "color": "light_purple", "bold": true}, {"text": " · Truhen plündern!", "color": "white"}]
execute if score #map mg matches 1 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Himmel", "color": "aqua", "bold": true}, {"text": " – du bist allein auf deiner Strecke. Loot gibt es in den Truhen.", "color": "gray"}]
execute if score #map mg matches 2 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Nether", "color": "red", "bold": true}, {"text": " – du bist allein auf deiner Strecke. Loot gibt es in den Truhen.", "color": "gray"}]
execute if score #map mg matches 3 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Eis", "color": "aqua", "bold": true}, {"text": " – du bist allein auf deiner Strecke. Loot gibt es in den Truhen.", "color": "gray"}]
execute if score #map mg matches 4 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Dschungel", "color": "green", "bold": true}, {"text": " – du bist allein auf deiner Strecke. Loot gibt es in den Truhen.", "color": "gray"}]
execute if score #map mg matches 5 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "End", "color": "light_purple", "bold": true}, {"text": " – du bist allein auf deiner Strecke. Loot gibt es in den Truhen.", "color": "gray"}]
execute as @a[tag=mg_rush] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
