tag @a[tag=mg_hub] add mg_rush
tag @a[tag=mg_rush] remove mg_hub
execute as @a[tag=mg_rush] run function mg:q/leave_all
clear @a[tag=mg_rush]
effect clear @a[tag=mg_rush]
gamemode adventure @a[tag=mg_rush]
scoreboard players set @a[tag=mg_rush] mg_cp 0
scoreboard players set @a[tag=mg_rush] mg_loot 0
execute store result score #map mg run random value 1..5
execute if score #map mg matches 1 run execute in minecraft:overworld run tp @a[tag=mg_rush] 1000 101 0 -90 0
execute if score #map mg matches 2 run execute in minecraft:overworld run tp @a[tag=mg_rush] 1000 101 300 -90 0
execute if score #map mg matches 3 run execute in minecraft:overworld run tp @a[tag=mg_rush] 1000 101 600 -90 0
execute if score #map mg matches 4 run execute in minecraft:overworld run tp @a[tag=mg_rush] 1000 101 900 -90 0
execute if score #map mg matches 5 run execute in minecraft:overworld run tp @a[tag=mg_rush] 1000 101 1200 -90 0
execute if score #map mg matches 1 as @a[tag=mg_rush] run execute in minecraft:overworld run spawnpoint @s 1000 101 0
execute if score #map mg matches 2 as @a[tag=mg_rush] run execute in minecraft:overworld run spawnpoint @s 1000 101 300
execute if score #map mg matches 3 as @a[tag=mg_rush] run execute in minecraft:overworld run spawnpoint @s 1000 101 600
execute if score #map mg matches 4 as @a[tag=mg_rush] run execute in minecraft:overworld run spawnpoint @s 1000 101 900
execute if score #map mg matches 5 as @a[tag=mg_rush] run execute in minecraft:overworld run spawnpoint @s 1000 101 1200
execute if score #map mg matches 1 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Himmel", "color": "aqua", "bold": true}]
execute if score #map mg matches 2 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Nether", "color": "red", "bold": true}]
execute if score #map mg matches 3 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Eis", "color": "aqua", "bold": true}]
execute if score #map mg matches 4 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Dschungel", "color": "green", "bold": true}]
execute if score #map mg matches 5 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "End", "color": "light_purple", "bold": true}]
effect give @a[tag=mg_rush] minecraft:saturation infinite 0 true
effect give @a[tag=mg_rush] minecraft:resistance infinite 4 true
scoreboard players set #rush mg 2
scoreboard players set #t mg 0
scoreboard players set #left mg 240
scoreboard players set #finished mg 0
bossbar set mg:rush players @a[tag=mg_rush]
bossbar set mg:rush visible true
bossbar set mg:rush max 240
title @a[tag=mg_rush] times 5 40 10
title @a[tag=mg_rush] title {"text": "LOS!", "color": "green", "bold": true}
execute if score #map mg matches 1 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Himmel", "color": "aqua", "bold": true}, {"text": " · Loot auf den goldenen Blöcken", "color": "white"}]
execute if score #map mg matches 2 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Nether", "color": "red", "bold": true}, {"text": " · Loot auf den goldenen Blöcken", "color": "white"}]
execute if score #map mg matches 3 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Eis", "color": "aqua", "bold": true}, {"text": " · Loot auf den goldenen Blöcken", "color": "white"}]
execute if score #map mg matches 4 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Dschungel", "color": "green", "bold": true}, {"text": " · Loot auf den goldenen Blöcken", "color": "white"}]
execute if score #map mg matches 5 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "End", "color": "light_purple", "bold": true}, {"text": " · Loot auf den goldenen Blöcken", "color": "white"}]
execute as @a[tag=mg_rush] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
