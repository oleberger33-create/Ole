tag @a[tag=mg_hub] add mg_rush
tag @a[tag=mg_rush] remove mg_hub
execute as @a[tag=mg_rush] run function mg:q/leave_all
clear @a[tag=mg_rush]
effect clear @a[tag=mg_rush]
gamemode adventure @a[tag=mg_rush]
scoreboard players set @a[tag=mg_rush] mg_cp 0
scoreboard players set @a[tag=mg_rush] mg_loot 0
execute in minecraft:overworld run tp @a[tag=mg_rush] 1000 101 0 -90 0
execute as @a[tag=mg_rush] run execute in minecraft:overworld run spawnpoint @s 1000 101 0
effect give @a[tag=mg_rush] minecraft:saturation infinite 0 true
effect give @a[tag=mg_rush] minecraft:resistance infinite 4 true
scoreboard players set #rush mg 2
scoreboard players set #t mg 0
scoreboard players set #left mg 240
scoreboard players set #finished mg 0
bossbar set mg:rush players @a[tag=mg_rush]
bossbar set mg:rush visible true
bossbar set mg:rush max 240
title @a[tag=mg_rush] times 5 40 10
title @a[tag=mg_rush] title {"text": "LOS!", "color": "green", "bold": true}
title @a[tag=mg_rush] subtitle {"text": "Springen, Loot auf den goldenen Blöcken holen", "color": "white"}
execute as @a[tag=mg_rush] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
