execute as @a[tag=mg_hub,scores={mg_lane=0}] unless function mg:q/inq run function mg:rush/lane_assign
tag @a[tag=mg_hub,scores={mg_lane=1..}] add mg_rush
tag @a[tag=mg_rush] remove mg_hub
execute as @a[tag=mg_rush] run function mg:q/leave_all
clear @a[tag=mg_rush]
effect clear @a[tag=mg_rush]
gamemode adventure @a[tag=mg_rush]
scoreboard players set @a[tag=mg_rush] mg_cp 0
execute store result score #map mg run random value 1..5
scoreboard players reset * mg_prog
scoreboard players set @a[tag=mg_rush] mg_prog 0
scoreboard objectives setdisplay sidebar mg_prog
execute if score #map mg matches 1 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=1}] 30000 101 1000 -90 0
execute if score #map mg matches 1 run execute as @a[tag=mg_rush,scores={mg_lane=1}] run execute in minecraft:overworld run spawnpoint @s 30000 101 1000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cx 30000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cz 1000
execute if score #map mg matches 1 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=2}] 30000 101 2000 -90 0
execute if score #map mg matches 1 run execute as @a[tag=mg_rush,scores={mg_lane=2}] run execute in minecraft:overworld run spawnpoint @s 30000 101 2000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cx 30000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cz 2000
execute if score #map mg matches 1 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=3}] 30000 101 3000 -90 0
execute if score #map mg matches 1 run execute as @a[tag=mg_rush,scores={mg_lane=3}] run execute in minecraft:overworld run spawnpoint @s 30000 101 3000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cx 30000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cz 3000
execute if score #map mg matches 1 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=4}] 30000 101 4000 -90 0
execute if score #map mg matches 1 run execute as @a[tag=mg_rush,scores={mg_lane=4}] run execute in minecraft:overworld run spawnpoint @s 30000 101 4000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cx 30000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cz 4000
execute if score #map mg matches 1 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=5}] 30000 101 5000 -90 0
execute if score #map mg matches 1 run execute as @a[tag=mg_rush,scores={mg_lane=5}] run execute in minecraft:overworld run spawnpoint @s 30000 101 5000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cx 30000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cz 5000
execute if score #map mg matches 1 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=6}] 30000 101 6000 -90 0
execute if score #map mg matches 1 run execute as @a[tag=mg_rush,scores={mg_lane=6}] run execute in minecraft:overworld run spawnpoint @s 30000 101 6000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cx 30000
execute if score #map mg matches 1 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cz 6000
execute if score #map mg matches 2 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=1}] 31000 101 1000 -90 0
execute if score #map mg matches 2 run execute as @a[tag=mg_rush,scores={mg_lane=1}] run execute in minecraft:overworld run spawnpoint @s 31000 101 1000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cx 31000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cz 1000
execute if score #map mg matches 2 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=2}] 31000 101 2000 -90 0
execute if score #map mg matches 2 run execute as @a[tag=mg_rush,scores={mg_lane=2}] run execute in minecraft:overworld run spawnpoint @s 31000 101 2000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cx 31000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cz 2000
execute if score #map mg matches 2 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=3}] 31000 101 3000 -90 0
execute if score #map mg matches 2 run execute as @a[tag=mg_rush,scores={mg_lane=3}] run execute in minecraft:overworld run spawnpoint @s 31000 101 3000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cx 31000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cz 3000
execute if score #map mg matches 2 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=4}] 31000 101 4000 -90 0
execute if score #map mg matches 2 run execute as @a[tag=mg_rush,scores={mg_lane=4}] run execute in minecraft:overworld run spawnpoint @s 31000 101 4000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cx 31000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cz 4000
execute if score #map mg matches 2 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=5}] 31000 101 5000 -90 0
execute if score #map mg matches 2 run execute as @a[tag=mg_rush,scores={mg_lane=5}] run execute in minecraft:overworld run spawnpoint @s 31000 101 5000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cx 31000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cz 5000
execute if score #map mg matches 2 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=6}] 31000 101 6000 -90 0
execute if score #map mg matches 2 run execute as @a[tag=mg_rush,scores={mg_lane=6}] run execute in minecraft:overworld run spawnpoint @s 31000 101 6000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cx 31000
execute if score #map mg matches 2 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cz 6000
execute if score #map mg matches 3 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=1}] 32000 101 1000 -90 0
execute if score #map mg matches 3 run execute as @a[tag=mg_rush,scores={mg_lane=1}] run execute in minecraft:overworld run spawnpoint @s 32000 101 1000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cx 32000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cz 1000
execute if score #map mg matches 3 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=2}] 32000 101 2000 -90 0
execute if score #map mg matches 3 run execute as @a[tag=mg_rush,scores={mg_lane=2}] run execute in minecraft:overworld run spawnpoint @s 32000 101 2000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cx 32000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cz 2000
execute if score #map mg matches 3 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=3}] 32000 101 3000 -90 0
execute if score #map mg matches 3 run execute as @a[tag=mg_rush,scores={mg_lane=3}] run execute in minecraft:overworld run spawnpoint @s 32000 101 3000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cx 32000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cz 3000
execute if score #map mg matches 3 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=4}] 32000 101 4000 -90 0
execute if score #map mg matches 3 run execute as @a[tag=mg_rush,scores={mg_lane=4}] run execute in minecraft:overworld run spawnpoint @s 32000 101 4000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cx 32000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cz 4000
execute if score #map mg matches 3 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=5}] 32000 101 5000 -90 0
execute if score #map mg matches 3 run execute as @a[tag=mg_rush,scores={mg_lane=5}] run execute in minecraft:overworld run spawnpoint @s 32000 101 5000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cx 32000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cz 5000
execute if score #map mg matches 3 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=6}] 32000 101 6000 -90 0
execute if score #map mg matches 3 run execute as @a[tag=mg_rush,scores={mg_lane=6}] run execute in minecraft:overworld run spawnpoint @s 32000 101 6000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cx 32000
execute if score #map mg matches 3 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cz 6000
execute if score #map mg matches 4 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=1}] 33000 101 1000 -90 0
execute if score #map mg matches 4 run execute as @a[tag=mg_rush,scores={mg_lane=1}] run execute in minecraft:overworld run spawnpoint @s 33000 101 1000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cx 33000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cz 1000
execute if score #map mg matches 4 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=2}] 33000 101 2000 -90 0
execute if score #map mg matches 4 run execute as @a[tag=mg_rush,scores={mg_lane=2}] run execute in minecraft:overworld run spawnpoint @s 33000 101 2000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cx 33000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cz 2000
execute if score #map mg matches 4 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=3}] 33000 101 3000 -90 0
execute if score #map mg matches 4 run execute as @a[tag=mg_rush,scores={mg_lane=3}] run execute in minecraft:overworld run spawnpoint @s 33000 101 3000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cx 33000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cz 3000
execute if score #map mg matches 4 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=4}] 33000 101 4000 -90 0
execute if score #map mg matches 4 run execute as @a[tag=mg_rush,scores={mg_lane=4}] run execute in minecraft:overworld run spawnpoint @s 33000 101 4000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cx 33000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cz 4000
execute if score #map mg matches 4 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=5}] 33000 101 5000 -90 0
execute if score #map mg matches 4 run execute as @a[tag=mg_rush,scores={mg_lane=5}] run execute in minecraft:overworld run spawnpoint @s 33000 101 5000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cx 33000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cz 5000
execute if score #map mg matches 4 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=6}] 33000 101 6000 -90 0
execute if score #map mg matches 4 run execute as @a[tag=mg_rush,scores={mg_lane=6}] run execute in minecraft:overworld run spawnpoint @s 33000 101 6000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cx 33000
execute if score #map mg matches 4 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cz 6000
execute if score #map mg matches 5 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=1}] 34000 101 1000 -90 0
execute if score #map mg matches 5 run execute as @a[tag=mg_rush,scores={mg_lane=1}] run execute in minecraft:overworld run spawnpoint @s 34000 101 1000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cx 34000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=1}] mg_cz 1000
execute if score #map mg matches 5 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=2}] 34000 101 2000 -90 0
execute if score #map mg matches 5 run execute as @a[tag=mg_rush,scores={mg_lane=2}] run execute in minecraft:overworld run spawnpoint @s 34000 101 2000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cx 34000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=2}] mg_cz 2000
execute if score #map mg matches 5 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=3}] 34000 101 3000 -90 0
execute if score #map mg matches 5 run execute as @a[tag=mg_rush,scores={mg_lane=3}] run execute in minecraft:overworld run spawnpoint @s 34000 101 3000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cx 34000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=3}] mg_cz 3000
execute if score #map mg matches 5 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=4}] 34000 101 4000 -90 0
execute if score #map mg matches 5 run execute as @a[tag=mg_rush,scores={mg_lane=4}] run execute in minecraft:overworld run spawnpoint @s 34000 101 4000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cx 34000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=4}] mg_cz 4000
execute if score #map mg matches 5 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=5}] 34000 101 5000 -90 0
execute if score #map mg matches 5 run execute as @a[tag=mg_rush,scores={mg_lane=5}] run execute in minecraft:overworld run spawnpoint @s 34000 101 5000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cx 34000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=5}] mg_cz 5000
execute if score #map mg matches 5 run execute in minecraft:overworld run tp @a[tag=mg_rush,scores={mg_lane=6}] 34000 101 6000 -90 0
execute if score #map mg matches 5 run execute as @a[tag=mg_rush,scores={mg_lane=6}] run execute in minecraft:overworld run spawnpoint @s 34000 101 6000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cx 34000
execute if score #map mg matches 5 run scoreboard players set @a[tag=mg_rush,scores={mg_lane=6}] mg_cz 6000
scoreboard players set @a[tag=mg_rush] mg_cy 101
effect give @a[tag=mg_rush] minecraft:saturation infinite 0 true
effect give @a[tag=mg_rush] minecraft:resistance infinite 4 true
scoreboard players set #rush mg 2
scoreboard players set #t mg 0
scoreboard players set #left mg 900
scoreboard players set #finished mg 0
bossbar set mg:rush players @a[tag=mg_rush]
bossbar set mg:rush visible true
bossbar set mg:rush max 900
title @a[tag=mg_rush] times 5 50 10
title @a[tag=mg_rush] title {"text": "LOS!", "color": "green", "bold": true}
execute if score #map mg matches 1 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Himmel", "color": "aqua", "bold": true}, {"text": " · 24 Inseln", "color": "white"}]
execute if score #map mg matches 2 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Nether", "color": "red", "bold": true}, {"text": " · 24 Inseln", "color": "white"}]
execute if score #map mg matches 3 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Eis", "color": "aqua", "bold": true}, {"text": " · 24 Inseln", "color": "white"}]
execute if score #map mg matches 4 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "Dschungel", "color": "green", "bold": true}, {"text": " · 24 Inseln", "color": "white"}]
execute if score #map mg matches 5 run title @a[tag=mg_rush] subtitle [{"text": "Map: ", "color": "gray"}, {"text": "End", "color": "light_purple", "bold": true}, {"text": " · 24 Inseln", "color": "white"}]
execute if score #map mg matches 1 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Himmel", "color": "aqua", "bold": true}, {"text": " – jeder hat seine eigene Strecke. Auf jeder Insel wartet eine Truhe, je weiter du kommst, desto besser der Loot. Rechts siehst du, wie weit die anderen sind.", "color": "gray"}]
execute if score #map mg matches 2 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Nether", "color": "red", "bold": true}, {"text": " – jeder hat seine eigene Strecke. Auf jeder Insel wartet eine Truhe, je weiter du kommst, desto besser der Loot. Rechts siehst du, wie weit die anderen sind.", "color": "gray"}]
execute if score #map mg matches 3 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Eis", "color": "aqua", "bold": true}, {"text": " – jeder hat seine eigene Strecke. Auf jeder Insel wartet eine Truhe, je weiter du kommst, desto besser der Loot. Rechts siehst du, wie weit die anderen sind.", "color": "gray"}]
execute if score #map mg matches 4 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "Dschungel", "color": "green", "bold": true}, {"text": " – jeder hat seine eigene Strecke. Auf jeder Insel wartet eine Truhe, je weiter du kommst, desto besser der Loot. Rechts siehst du, wie weit die anderen sind.", "color": "gray"}]
execute if score #map mg matches 5 run tellraw @a[tag=mg_rush] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Map: ", "color": "gray"}, {"text": "End", "color": "light_purple", "bold": true}, {"text": " – jeder hat seine eigene Strecke. Auf jeder Insel wartet eine Truhe, je weiter du kommst, desto besser der Loot. Rechts siehst du, wie weit die anderen sind.", "color": "gray"}]
execute as @a[tag=mg_rush] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
