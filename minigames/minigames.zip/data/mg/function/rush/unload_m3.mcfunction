execute in minecraft:overworld run forceload remove 984 560 1147 640
