scoreboard players set #n mg 0
execute as @a[tag=mg_hub] unless function mg:q/inq run scoreboard players add #n mg 1
execute if score #n mg matches ..1 run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Für Parkour-Rush braucht ihr mindestens 2 Spieler in der Lobby.", "color": "red"}]
execute unless score #lanes mg matches 6 run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die Strecken werden noch gebaut (", "color": "red"}, {"score": {"name": "#lanes_done", "objective": "mg"}, "color": "white"}, {"text": "/30). Gleich fertig!", "color": "red"}]
execute if score #rush mg matches 1.. run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Parkour-Rush läuft schon.", "color": "red"}]
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " startet ", "color": "gray"}, {"text": "PARKOUR-RUSH", "color": "green", "bold": true}, {"text": " für alle in der Lobby!", "color": "gray"}]
scoreboard players set #rush mg 1
scoreboard players set #cd mg 5
scoreboard players set #cdt mg 0
scoreboard players set #L mg 0
scoreboard players set @a mg_lane 0
execute as @a[tag=mg_hub] unless function mg:q/inq run function mg:rush/lane_assign
execute as @a[tag=mg_hub] if function mg:q/inq run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du bist in einer Warteschlange und bleibst deshalb draußen. Verlass sie mit dem Barriere-Item, um mitzumachen.", "color": "gray"}]
function mg:rush/cd_show
