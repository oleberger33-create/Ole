execute if score #rush mg matches 1.. run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Parkour-Rush läuft schon.", "color": "red"}]
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " startet ", "color": "gray"}, {"text": "PARKOUR-RUSH", "color": "green", "bold": true}, {"text": " für alle in der Lobby!", "color": "gray"}]
scoreboard players set #rush mg 1
scoreboard players set #cd mg 5
scoreboard players set #cdt mg 0
function mg:rush/cd_show
