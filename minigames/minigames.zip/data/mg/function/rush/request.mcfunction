execute if score #rush mg matches 1.. run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Parkour-Rush läuft schon.", "color": "red"}]
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " startet ", "color": "gray"}, {"text": "PARKOUR-RUSH", "color": "green", "bold": true}, {"text": " für alle in der Lobby!", "color": "gray"}]
scoreboard players set #rush mg 1
scoreboard players set #cd mg 5
scoreboard players set #cdt mg 0
scoreboard players set #wait mg 0
scoreboard players set #L mg 0
scoreboard players set @a mg_lane 0
execute as @a[tag=mg_hub] run function mg:rush/lane_assign
execute if score #L mg matches 1.. run function mg:rush/lane_load1
execute if score #L mg matches 2.. run function mg:rush/lane_load2
execute if score #L mg matches 3.. run function mg:rush/lane_load3
execute if score #L mg matches 4.. run function mg:rush/lane_load4
execute if score #L mg matches 5.. run function mg:rush/lane_load5
execute if score #L mg matches 6.. run function mg:rush/lane_load6
execute if score #L mg matches 7.. run function mg:rush/lane_load7
execute if score #L mg matches 8.. run function mg:rush/lane_load8
function mg:rush/cd_show
