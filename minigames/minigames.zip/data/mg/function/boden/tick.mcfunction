execute if score #boden_cd mg matches 1.. run scoreboard players remove #boden_cd mg 1
execute if score #boden mg matches 1 if score #boden_cd mg matches 0 run function mg:boden/go
execute if score #boden mg matches 1 if score #boden_cd mg matches 0 run scoreboard players set #boden mg 2
execute unless score #boden mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_boden]
execute if score #n mg matches ..1 run return run function mg:boden/forfeit
execute as @a[tag=mg_duel_boden] at @s if entity @s[y=-64,dy=144] run function mg:boden/lose
execute as @e[type=minecraft:player,tag=mg_duel_boden,scores={mg_deaths=1..}] run function mg:boden/lose
execute as @a[tag=mg_duel_boden] at @s if block ~ ~-1 ~ minecraft:lime_concrete run setblock ~ ~-1 ~ minecraft:red_concrete
execute as @a[tag=mg_duel_boden] at @s if block ~ ~-1 ~ minecraft:yellow_concrete run setblock ~ ~-1 ~ minecraft:red_concrete
execute as @a[tag=mg_duel_boden] at @s if block ~ ~-1 ~ minecraft:orange_concrete run setblock ~ ~-1 ~ minecraft:red_concrete
scoreboard players add #boden_t mg 1
execute if score #boden_t mg matches 8.. run execute in minecraft:overworld run fill 11992 86 -8 12008 100 8 minecraft:air replace minecraft:red_concrete
execute if score #boden_t mg matches 8.. run scoreboard players set #boden_t mg 0
