execute in minecraft:overworld run fill 11992 79 -8 12008 103 8 minecraft:air
execute in minecraft:overworld run fill 11992 100 -8 12008 100 8 minecraft:lime_concrete
execute in minecraft:overworld run fill 11992 93 -8 12008 93 8 minecraft:yellow_concrete
execute in minecraft:overworld run fill 11992 86 -8 12008 86 8 minecraft:orange_concrete
title @a[tag=mg_duel_boden] actionbar {"text": "LOS!", "color": "green", "bold": true}
execute as @a[tag=mg_duel_boden] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
