title @a[tag=mg_duel_boden] actionbar {"text": "LOS!", "color": "green", "bold": true}
execute as @a[tag=mg_duel_boden] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
