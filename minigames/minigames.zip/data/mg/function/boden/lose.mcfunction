execute unless score #boden mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_boden] remove mg_rw
tag @a[tag=mg_duel_boden] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_boden] mg_round 1
tellraw @a[tag=mg_duel_boden] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_boden]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "green"}]
execute as @a[tag=mg_duel_boden] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_boden,scores={mg_round=2..}] run return run function mg:boden/win
scoreboard players set #boden mg 1
function mg:boden/round
