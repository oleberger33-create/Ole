execute as @a[tag=mg_duel_boden] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Fallender Boden – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_boden] mg_wins 1
scoreboard players add @a[tag=mg_duel_boden] mg_coins 5
function mg:boden/stop
