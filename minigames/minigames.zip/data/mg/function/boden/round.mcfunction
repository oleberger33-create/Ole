execute as @a[tag=mg_duel_boden] run function mg:boden/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_boden,tag=mg_p1,limit=1] 11995 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_boden,tag=mg_p2,limit=1] 12005 101 0 90 0
execute as @a[tag=mg_duel_boden] run execute in minecraft:overworld run spawnpoint @s 0 101 0
kill @e[type=minecraft:horse,tag=mg_horse_boden]
scoreboard players set #boden_cd mg 60
scoreboard players set #boden mg 1
title @a[tag=mg_duel_boden] times 0 30 10
title @a[tag=mg_duel_boden] title {"text": "Fallender Boden", "color": "green", "bold": true}
title @a[tag=mg_duel_boden] subtitle [{"score":{"name":"@a[tag=mg_duel_boden,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_boden,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
