execute if score @s mg_aktion matches 1 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_sumo] run function mg:q/toggle_sumo
execute if score @s mg_aktion matches 2 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_spleef] run function mg:q/toggle_spleef
execute if score @s mg_aktion matches 3 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_duell] run function mg:q/toggle_duell
scoreboard players set @s mg_aktion 0
