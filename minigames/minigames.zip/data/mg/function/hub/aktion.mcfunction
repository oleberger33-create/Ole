execute if score @s mg_aktion matches 1 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_sumo] run function mg:q/toggle_sumo
execute if score @s mg_aktion matches 2 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_spleef] run function mg:q/toggle_spleef
execute if score @s mg_aktion matches 3 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_duell] run function mg:q/toggle_duell
execute if score @s mg_aktion matches 4 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_wind] run function mg:q/toggle_wind
execute if score @s mg_aktion matches 5 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_kb] run function mg:q/toggle_kb
execute if score @s mg_aktion matches 6 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_pfeil] run function mg:q/toggle_pfeil
execute if score @s mg_aktion matches 7 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_kolben] run function mg:q/toggle_kolben
execute if score @s mg_aktion matches 8 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_bruecke] run function mg:q/toggle_bruecke
execute if score @s mg_aktion matches 9 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_lava] run function mg:q/toggle_lava
execute if score @s mg_aktion matches 10 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_boden] run function mg:q/toggle_boden
execute if score @s mg_aktion matches 11 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_boxen] run function mg:q/toggle_boxen
execute if score @s mg_aktion matches 12 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_pferd] run function mg:q/toggle_pferd
execute if score @s mg_aktion matches 13 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_parkour] run function mg:q/toggle_parkour
execute if score @s mg_aktion matches 14 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_stickbett] run function mg:q/toggle_stickbett
execute if score @s mg_aktion matches 50 if entity @s[tag=mg_hub] run function mg:rush/request
execute if score @s mg_aktion matches 51 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_bw] run function mg:bw/toggle
execute if score @s mg_aktion matches 52 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_sw] run function mg:sw/toggle
execute if score @s mg_aktion matches 54 if entity @s[tag=mg_hub] run function mg:q/menu
execute if score @s mg_aktion matches 69 if entity @s[tag=mg_hub] run function mg:bot/menu
execute if score @s mg_aktion matches 64 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_ctf] run function mg:ctf/toggle
execute if score @s mg_aktion matches 67 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_dropper] run function mg:dropper/toggle
execute if score @s mg_aktion matches 65 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_elytra] run function mg:elytra/toggle
execute if score @s mg_aktion matches 61 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_farben] run function mg:farben/toggle
execute if score @s mg_aktion matches 63 if entity @s[tag=mg_hub] run function mg:kbffa/join
execute if score @s mg_aktion matches 62 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_murder] run function mg:murder/toggle
execute if score @s mg_aktion matches 68 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_oitc] run function mg:oitc/toggle
execute if score @s mg_aktion matches 60 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_tntrun] run function mg:tntrun/toggle
execute if score @s mg_aktion matches 66 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_verstecken] run function mg:verstecken/toggle
execute if score @s mg_aktion matches 97 if entity @s[tag=mg_hub] run function mg:cos/menu
execute if score @s mg_aktion matches 70 if entity @s[tag=mg_hub] run function mg:cos/trail_off
execute if score @s mg_aktion matches 80 if entity @s[tag=mg_hub] run function mg:cos/hat_off
execute if score @s mg_aktion matches 71 if entity @s[tag=mg_hub] run function mg:cos/t1
execute if score @s mg_aktion matches 72 if entity @s[tag=mg_hub] run function mg:cos/t2
execute if score @s mg_aktion matches 73 if entity @s[tag=mg_hub] run function mg:cos/t3
execute if score @s mg_aktion matches 74 if entity @s[tag=mg_hub] run function mg:cos/t4
execute if score @s mg_aktion matches 75 if entity @s[tag=mg_hub] run function mg:cos/t5
execute if score @s mg_aktion matches 76 if entity @s[tag=mg_hub] run function mg:cos/t6
execute if score @s mg_aktion matches 77 if entity @s[tag=mg_hub] run function mg:cos/t7
execute if score @s mg_aktion matches 81 if entity @s[tag=mg_hub] run function mg:cos/h1
execute if score @s mg_aktion matches 82 if entity @s[tag=mg_hub] run function mg:cos/h2
execute if score @s mg_aktion matches 83 if entity @s[tag=mg_hub] run function mg:cos/h3
execute if score @s mg_aktion matches 84 if entity @s[tag=mg_hub] run function mg:cos/h4
execute if score @s mg_aktion matches 211..254 if entity @s[tag=mg_bot,scores={mg_bot_st=3}] run function mg:hub/enter
execute if score @s mg_aktion matches 69 if entity @s[tag=mg_bot,scores={mg_bot_st=3}] run function mg:bot/menu
execute if score @s mg_aktion matches 211..254 if entity @s[tag=mg_hub] run function mg:bot/pick
execute if score @s mg_aktion matches 98 if entity @s[tag=mg_hub] run function mg:hub/games
execute if score @s mg_aktion matches 99 unless entity @s[tag=mg_hub] run function mg:hub/quit
scoreboard players set @s mg_aktion 0
