execute if score @s mg_aktion matches 1 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_sumo] run function mg:q/toggle_sumo
execute if score @s mg_aktion matches 2 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_spleef] run function mg:q/toggle_spleef
execute if score @s mg_aktion matches 3 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_duell] run function mg:q/toggle_duell
execute if score @s mg_aktion matches 4 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_wind] run function mg:q/toggle_wind
execute if score @s mg_aktion matches 5 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_kb] run function mg:q/toggle_kb
execute if score @s mg_aktion matches 6 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_pfeil] run function mg:q/toggle_pfeil
execute if score @s mg_aktion matches 7 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_kolben] run function mg:q/toggle_kolben
execute if score @s mg_aktion matches 8 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_bruecke] run function mg:q/toggle_bruecke
execute if score @s mg_aktion matches 9 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_lava] run function mg:q/toggle_lava
execute if score @s mg_aktion matches 10 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_boden] run function mg:q/toggle_boden
execute if score @s mg_aktion matches 11 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_boxen] run function mg:q/toggle_boxen
execute if score @s mg_aktion matches 12 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_pferd] run function mg:q/toggle_pferd
execute if score @s mg_aktion matches 13 if entity @s[tag=mg_hub] unless entity @s[tag=mg_q_parkour] run function mg:q/toggle_parkour
scoreboard players set @s mg_aktion 0
