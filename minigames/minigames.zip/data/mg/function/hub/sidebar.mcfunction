scoreboard players reset * mg_side
scoreboard players set a1 mg_side 8
scoreboard players display name a1 mg_side {"text": " "}
scoreboard players set a2 mg_side 7
scoreboard players display name a2 mg_side [{"text": "Rechtsklick auf die Items", "color": "gray"}]
scoreboard players set a3 mg_side 6
scoreboard players display name a3 mg_side [{"text": "1 ", "color": "dark_gray"}, {"text": "Parkour-Rush", "color": "green"}]
scoreboard players set a4 mg_side 5
scoreboard players display name a4 mg_side [{"text": "3 ", "color": "dark_gray"}, {"text": "1v1-Modi (13)", "color": "red"}]
scoreboard players set a5 mg_side 4
scoreboard players display name a5 mg_side [{"text": "5 ", "color": "dark_gray"}, {"text": "Warteschlange raus", "color": "gray"}]
scoreboard players set a6 mg_side 3
scoreboard players display name a6 mg_side [{"text": "9 ", "color": "dark_gray"}, {"text": "Spielregeln", "color": "white"}]
scoreboard players set a7 mg_side 2
scoreboard players display name a7 mg_side {"text": "  "}
scoreboard players set a8 mg_side 1
scoreboard players display name a8 mg_side [{"text": "Siege: ", "color": "dark_gray"}, {"text": "Tab-Liste", "color": "gray"}]
