scoreboard players set #itick mg 0
execute as @e[type=minecraft:item] if items entity @s contents *[minecraft:custom_data~{mg_item:1b}] run kill @s
clear @a[tag=!mg_hub] *[minecraft:custom_data~{mg_item:1b}]
execute as @e[type=minecraft:item] if items entity @s contents *[minecraft:custom_data~{mg_hat:1b}] run kill @s
clear @a[tag=!mg_hub] *[minecraft:custom_data~{mg_hat:1b}]
function mg:hub/watchdog
