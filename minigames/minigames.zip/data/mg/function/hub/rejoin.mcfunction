scoreboard players set @s mg_leave 0
function mg:q/leave_all
function mg:hub/enter
