tag @s remove mg_rush
tag @s remove mg_fight
tag @s remove mg_duel
tag @s remove mg_p1
tag @s remove mg_p2
tag @s remove mg_sw
tag @s remove mg_bw
tag @s remove mg_al_sw
tag @s remove mg_al_bw
tag @s remove mg_rw
team leave @s
scoreboard players set @s mg_rt 0
tag @s remove mg_ctf_r
tag @s remove mg_ctf_b
tag @s remove mg_ctf_c
tag @s remove mg_ctf_kl
tag @s remove mg_ctf_cam
scoreboard players set @s mg_ctf_rs 0
tag @s remove mg_ctf
tag @s remove mg_al_ctf
tag @s remove mg_dropper_win
attribute @s minecraft:gravity base reset
tag @s remove mg_dropper
tag @s remove mg_al_dropper
tag @s remove mg_elytra_fin
tag @s remove mg_elytra_win
tag @s remove mg_elytra_lead
tag @s remove mg_elytra
tag @s remove mg_al_elytra
tag @s remove mg_farben_fell
tag @s remove mg_farben_rev
tag @s remove mg_farben
tag @s remove mg_al_farben
execute if entity @s[tag=mg_kbffa] run function mg:kbffa/bye
tag @s remove mg_kbffa
tag @s remove mg_kbffa_wait
tag @s remove mg_kbffa_safe
tag @s remove mg_kbffa_vic
tag @s remove mg_kbffa_klr
tag @s remove mg_kbffa_rsp
tag @s remove mg_kbffa_atk
tag @s remove mg_kbffa_rech
tag @s remove mg_kbffa_fresh
attribute @s minecraft:fall_damage_multiplier base reset
attribute @s minecraft:knockback_resistance modifier remove mg:kbffa_safe
tag @s remove mg_murder_m
tag @s remove mg_murder_d
tag @s remove mg_murder_i
tag @s remove mg_murder_bad
tag @s remove mg_murder_hero
tag @s remove mg_murder
tag @s remove mg_al_murder
tag @s remove mg_oitc_dead
tag @s remove mg_oitc_me
tag @s remove mg_oitc_kl
tag @s remove mg_oitc_lead
tag @s remove mg_oitc_w
attribute @s minecraft:fall_damage_multiplier base reset
scoreboard players set @s mg_oitc_st 0
tag @s remove mg_oitc
tag @s remove mg_al_oitc
tag @s remove mg_tntrun
tag @s remove mg_al_tntrun
tag @s remove mg_verstecken_hid
tag @s remove mg_verstecken_see
tag @s remove mg_verstecken_orig
tag @s remove mg_verstecken_fd
tag @s remove mg_verstecken_new
tag @s remove mg_verstecken
tag @s remove mg_al_verstecken
tag @s add mg_hub
ride @s dismount
attribute @s minecraft:max_health base set 20
clear @s
effect clear @s
experience set @s 0 levels
experience set @s 0 points
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
function mg:hub/tp
execute in minecraft:overworld run spawnpoint @s 0 101 17
function mg:hub/hotbar
