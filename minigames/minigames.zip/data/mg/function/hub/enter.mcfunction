tag @s remove mg_rush
tag @s remove mg_fight
tag @s remove mg_duel
tag @s remove mg_p1
tag @s remove mg_p2
tag @s remove mg_sw
tag @s remove mg_bw
tag @s remove mg_alive
team leave @s
scoreboard players set @s mg_rt 0
tag @s add mg_hub
ride @s dismount
attribute @s minecraft:max_health base set 20
clear @s
effect clear @s
experience set @s 0 levels
experience set @s 0 points
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
function mg:hub/tp
execute in minecraft:overworld run spawnpoint @s 0 101 9
function mg:hub/hotbar
