tag @s remove mg_rush
tag @s remove mg_fight
tag @s remove mg_duel
tag @s remove mg_p1
tag @s remove mg_p2
tag @s add mg_hub
clear @s
effect clear @s
experience set @s 0 levels
experience set @s 0 points
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
function mg:hub/tp
execute in minecraft:overworld run spawnpoint @s 0 101 0
function mg:hub/hotbar
