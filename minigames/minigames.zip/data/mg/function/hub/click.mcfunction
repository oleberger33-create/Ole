scoreboard players set @s mg_click 0
execute unless entity @s[tag=mg_hub] run return 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"rush"}] run return run function mg:rush/request
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"games"}] run return run function mg:hub/games
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"onevone"}] run return run function mg:q/menu
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"leave"}] run return run function mg:q/leave_cmd
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"info"}] run return run function mg:hub/info
