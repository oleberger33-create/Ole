scoreboard players set @s mg_click 0
execute unless entity @s[tag=mg_hub] run return 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"rush"}] run return run function mg:rush/request
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"sumo"}] run return run function mg:q/toggle_sumo
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"spleef"}] run return run function mg:q/toggle_spleef
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"duell"}] run return run function mg:q/toggle_duell
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{mg:"info"}] run return run function mg:hub/info
