effect give @s minecraft:resistance infinite 4 true
effect give @s minecraft:saturation infinite 0 true
execute unless entity @s[gamemode=adventure] unless entity @s[gamemode=creative] unless entity @s[gamemode=spectator] run gamemode adventure @s
execute at @s unless entity @s[x=-30,dx=60,y=94,dy=40,z=-30,dz=60] run function mg:hub/tp
execute unless items entity @s hotbar.0 *[minecraft:custom_data~{mg:"rush"}] run return run function mg:hub/hotbar
execute unless items entity @s hotbar.2 *[minecraft:custom_data~{mg:"onevone"}] run return run function mg:hub/hotbar
execute unless items entity @s hotbar.4 *[minecraft:custom_data~{mg:"leave"}] run return run function mg:hub/hotbar
execute unless items entity @s hotbar.8 *[minecraft:custom_data~{mg:"info"}] run return run function mg:hub/hotbar
