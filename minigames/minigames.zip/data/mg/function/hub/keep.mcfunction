execute at @s if block ~ ~-1 ~ minecraft:cyan_glazed_terracotta run function mg:hub/pad
execute if entity @s[tag=!mg_halo,y=118,dy=3] at @s if block ~ ~-1 ~ minecraft:light_blue_stained_glass run function mg:hub/halo
execute if score @s mg_hat matches 1.. unless items entity @s armor.head * run function mg:cos/hat_put
effect give @s minecraft:resistance infinite 4 true
effect give @s minecraft:saturation infinite 0 true
execute unless entity @s[gamemode=adventure] unless entity @s[gamemode=creative] unless entity @s[gamemode=spectator] run gamemode adventure @s
execute at @s unless entity @s[x=-46,dx=92,y=92,dy=50,z=-46,dz=92] run function mg:hub/tp
execute unless items entity @s hotbar.0 *[minecraft:custom_data~{mg:"rush"}] run return run function mg:hub/hotbar
execute unless items entity @s hotbar.1 *[minecraft:custom_data~{mg:"games"}] run return run function mg:hub/hotbar
execute unless items entity @s hotbar.2 *[minecraft:custom_data~{mg:"onevone"}] run return run function mg:hub/hotbar
execute unless items entity @s hotbar.4 *[minecraft:custom_data~{mg:"leave"}] run return run function mg:hub/hotbar
execute unless items entity @s hotbar.8 *[minecraft:custom_data~{mg:"info"}] run return run function mg:hub/hotbar
