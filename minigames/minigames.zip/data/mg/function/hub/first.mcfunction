tag @s add mg_seen
function mg:hub/enter
title @s times 10 50 15
title @s title [{"text": "OLE GAMES ", "color": "gold", "bold": true}, {"text": "PVP", "color": "red", "bold": true}]
title @s subtitle {"text": "Rechtsklick auf die Items in deiner Hotbar", "color": "gray"}
