tag @s add mg_seen
function mg:hub/enter
title @s times 10 50 15
title @s title {"text": "MINIGAMES", "color": "gold", "bold": true}
title @s subtitle {"text": "Rechtsklick auf die Items in deiner Hotbar", "color": "gray"}
