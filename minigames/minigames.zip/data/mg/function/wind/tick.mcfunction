execute if score #wind_cd mg matches 1.. run scoreboard players remove #wind_cd mg 1
execute if score #wind mg matches 1 if score #wind_cd mg matches 0 run function mg:wind/go
execute if score #wind mg matches 1 if score #wind_cd mg matches 0 run scoreboard players set #wind mg 2
execute unless score #wind mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_wind]
execute if score #n mg matches ..1 run return run function mg:wind/forfeit
execute as @a[tag=mg_duel_wind] at @s if entity @s[y=-64,dy=158] run function mg:wind/lose
execute as @a[tag=mg_duel_wind,scores={mg_deaths=1..}] run function mg:wind/lose
