execute if score #wind_r mg matches 2.. as @a[tag=mg_duel_wind] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Windstoß – Gegner ist weg.", "color": "white"}]
execute if score #wind_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_wind] mg_wins 1
execute if score #wind_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_wind] mg_coins 5
execute if score #wind_r mg matches ..1 run tellraw @a[tag=mg_duel_wind] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dein Gegner ist weg, bevor eine Runde fertig war – keine Wertung.", "color": "gray"}]
function mg:wind/stop
