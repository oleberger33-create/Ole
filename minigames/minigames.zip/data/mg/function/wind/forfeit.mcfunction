execute as @a[tag=mg_duel_wind] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Windstoß – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_wind] mg_wins 1
function mg:wind/stop
