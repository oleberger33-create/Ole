execute in minecraft:overworld run kill @e[type=minecraft:item,x=5955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=5955,dx=90,y=70,dy=80,z=-45,dz=90]
execute as @a[tag=mg_duel_wind] run function mg:wind/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_wind,tag=mg_p1,limit=1] 5996 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_wind,tag=mg_p2,limit=1] 6004 101 0 90 0
execute as @a[tag=mg_duel_wind] run execute in minecraft:overworld run spawnpoint @s 0 101 17
kill @e[type=minecraft:horse,tag=mg_horse_wind]
scoreboard players set #wind_cd mg 60
scoreboard players set #wind mg 1
title @a[tag=mg_duel_wind] times 0 30 10
title @a[tag=mg_duel_wind] title {"text": "Windstoß", "color": "white", "bold": true}
title @a[tag=mg_duel_wind] subtitle [{"score":{"name":"@a[tag=mg_duel_wind,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_wind,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
scoreboard players add #wind_r mg 1
