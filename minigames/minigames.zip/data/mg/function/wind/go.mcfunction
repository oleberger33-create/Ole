title @a[tag=mg_duel_wind] actionbar {"text": "LOS!", "color": "white", "bold": true}
execute as @a[tag=mg_duel_wind] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
