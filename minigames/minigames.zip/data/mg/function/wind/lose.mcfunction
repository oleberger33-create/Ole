execute unless score #wind mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_wind] remove mg_rw
tag @a[tag=mg_duel_wind] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_wind] mg_round 1
tellraw @a[tag=mg_duel_wind] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_wind]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "white"}]
execute as @a[tag=mg_duel_wind] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_wind,scores={mg_round=2..}] run return run function mg:wind/win
scoreboard players set #wind mg 1
function mg:wind/round
