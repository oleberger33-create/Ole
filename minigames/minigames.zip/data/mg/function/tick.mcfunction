scoreboard players enable @a mg_aktion
execute as @a[scores={mg_aktion=1..}] run function mg:hub/aktion
execute as @a[tag=!mg_seen] run function mg:hub/first
execute as @a[scores={mg_leave=1..}] run function mg:hub/rejoin
execute as @a[scores={mg_click=1..}] run function mg:hub/click
execute as @a[tag=mg_hub] run function mg:hub/keep
scoreboard players add #itick mg 1
execute if score #itick mg matches 10.. run function mg:hub/sweep
execute if score #rush mg matches 1.. run function mg:rush/tick
execute if score #sumo mg matches 1.. run function mg:sumo/tick
execute if score #spleef mg matches 1.. run function mg:spleef/tick
execute if score #duell mg matches 1.. run function mg:duell/tick
execute if score #sumo mg matches 0 if entity @a[tag=mg_q_sumo] run function mg:q/try_sumo
execute if score #spleef mg matches 0 if entity @a[tag=mg_q_spleef] run function mg:q/try_spleef
execute if score #duell mg matches 0 if entity @a[tag=mg_q_duell] run function mg:q/try_duell
execute if score #wind mg matches 1.. run function mg:wind/tick
execute if score #wind mg matches 0 if entity @a[tag=mg_q_wind] run function mg:q/try_wind
execute if score #kb mg matches 1.. run function mg:kb/tick
execute if score #kb mg matches 0 if entity @a[tag=mg_q_kb] run function mg:q/try_kb
execute if score #pfeil mg matches 1.. run function mg:pfeil/tick
execute if score #pfeil mg matches 0 if entity @a[tag=mg_q_pfeil] run function mg:q/try_pfeil
execute if score #kolben mg matches 1.. run function mg:kolben/tick
execute if score #kolben mg matches 0 if entity @a[tag=mg_q_kolben] run function mg:q/try_kolben
execute if score #bruecke mg matches 1.. run function mg:bruecke/tick
execute if score #bruecke mg matches 0 if entity @a[tag=mg_q_bruecke] run function mg:q/try_bruecke
execute if score #lava mg matches 1.. run function mg:lava/tick
execute if score #lava mg matches 0 if entity @a[tag=mg_q_lava] run function mg:q/try_lava
execute if score #boden mg matches 1.. run function mg:boden/tick
execute if score #boden mg matches 0 if entity @a[tag=mg_q_boden] run function mg:q/try_boden
execute if score #boxen mg matches 1.. run function mg:boxen/tick
execute if score #boxen mg matches 0 if entity @a[tag=mg_q_boxen] run function mg:q/try_boxen
execute if score #pferd mg matches 1.. run function mg:pferd/tick
execute if score #pferd mg matches 0 if entity @a[tag=mg_q_pferd] run function mg:q/try_pferd
execute if score #parkour mg matches 1.. run function mg:parkour/tick
execute if score #parkour mg matches 0 if entity @a[tag=mg_q_parkour] run function mg:q/try_parkour
