scoreboard players enable @a mg_aktion
execute as @a[scores={mg_aktion=1..}] run function mg:hub/aktion
execute as @a[tag=!mg_seen] run function mg:hub/first
execute as @a[scores={mg_leave=1..}] run function mg:hub/rejoin
execute as @a[scores={mg_click=1..}] run function mg:hub/click
execute as @a[tag=mg_hub] run function mg:hub/keep
scoreboard players add #itick mg 1
execute if score #itick mg matches 10.. run function mg:hub/sweep
execute if score #rush mg matches 1.. run function mg:rush/tick
execute if score #sumo mg matches 1.. run function mg:sumo/tick
execute if score #spleef mg matches 1.. run function mg:spleef/tick
execute if score #duell mg matches 1.. run function mg:duell/tick
execute if score #sumo mg matches 0 if entity @a[tag=mg_q_sumo] run function mg:q/try_sumo
execute if score #spleef mg matches 0 if entity @a[tag=mg_q_spleef] run function mg:q/try_spleef
execute if score #duell mg matches 0 if entity @a[tag=mg_q_duell] run function mg:q/try_duell
