scoreboard players enable @a mg_aktion
execute as @a[scores={mg_aktion=1..}] run function mg:hub/aktion
execute as @a[tag=!mg_seen] run function mg:hub/first
execute as @a[scores={mg_leave=1..}] run function mg:hub/rejoin
execute as @a[scores={mg_click=1..}] run function mg:hub/click
execute as @a[tag=mg_hub] run function mg:hub/keep
scoreboard players add #itick mg 1
execute if score #itick mg matches 10.. run function mg:hub/sweep
execute if score #rush mg matches 1.. run function mg:rush/tick
execute if score #sumo mg matches 1.. run function mg:sumo/tick
execute if score #spleef mg matches 1.. run function mg:spleef/tick
execute if score #duell mg matches 1.. run function mg:duell/tick
execute if score #sumo mg matches 0 if entity @a[tag=mg_q_sumo] run function mg:q/try_sumo
execute if score #spleef mg matches 0 if entity @a[tag=mg_q_spleef] run function mg:q/try_spleef
execute if score #duell mg matches 0 if entity @a[tag=mg_q_duell] run function mg:q/try_duell
execute as @e[type=minecraft:player,tag=mg_bot] run function mg:bot/ptick
scoreboard players add #bot_dec mg 1
execute if score #bot_dec mg matches 3600.. run scoreboard players remove @a[scores={mg_bot_cc=1..}] mg_bot_cc 1
execute if score #bot_dec mg matches 3600.. run scoreboard players set #bot_dec mg 0
execute unless score #ctf mg matches 0 run function mg:ctf/tick
execute if score #ctf mg matches 0 if entity @a[tag=mg_q_ctf] run function mg:ctf/idle
execute if score #ctf mg matches 1 run function mg:ctf/countdown
execute unless score #dropper mg matches 0 run function mg:dropper/tick
execute if score #dropper mg matches 0 if entity @a[tag=mg_q_dropper] run function mg:dropper/idle
execute if score #dropper mg matches 1 run function mg:dropper/countdown
execute unless score #elytra mg matches 0 run function mg:elytra/tick
execute if score #elytra mg matches 0 if entity @a[tag=mg_q_elytra] run function mg:elytra/idle
execute if score #elytra mg matches 1 run function mg:elytra/countdown
execute unless score #farben mg matches 0 run function mg:farben/tick
execute if score #farben mg matches 0 if entity @a[tag=mg_q_farben] run function mg:farben/idle
execute if score #farben mg matches 1 run function mg:farben/countdown
execute if score #kbffa mg matches 1.. run function mg:kbffa/tick
scoreboard players add #kbffa_cnt mg 1
execute if score #kbffa_cnt mg matches 1200.. run scoreboard players remove @a[scores={mg_kbffa_cn=1..}] mg_kbffa_cn 1
execute if score #kbffa_cnt mg matches 1200.. run scoreboard players set #kbffa_cnt mg 0
execute unless score #murder mg matches 0 run function mg:murder/tick
execute if score #murder mg matches 0 if entity @a[tag=mg_q_murder] run function mg:murder/idle
execute if score #murder mg matches 1 run function mg:murder/countdown
execute unless score #oitc mg matches 0 run function mg:oitc/tick
execute if score #oitc mg matches 0 if entity @a[tag=mg_q_oitc] run function mg:oitc/idle
execute if score #oitc mg matches 1 run function mg:oitc/countdown
execute unless score #tntrun mg matches 0 run function mg:tntrun/tick
execute if score #tntrun mg matches 0 if entity @a[tag=mg_q_tntrun] run function mg:tntrun/idle
execute if score #tntrun mg matches 1 run function mg:tntrun/countdown
execute unless score #verstecken mg matches 0 run function mg:verstecken/tick
execute if score #verstecken mg matches 0 if entity @a[tag=mg_q_verstecken] run function mg:verstecken/idle
execute if score #verstecken mg matches 1 run function mg:verstecken/countdown
execute if score #itick mg matches 5 run function mg:hub/fx
function mg:cos/tick
scoreboard players add #toptick mg 1
execute if score #toptick mg matches 600.. run function mg:hub/top
execute if score #toptick mg matches 600.. run scoreboard players set #toptick mg 0
function mg:npc/tick
execute unless score #sw mg matches 0 run function mg:sw/tick
execute if score #sw mg matches 0 if entity @a[tag=mg_q_sw] run function mg:sw/idle
execute unless score #bw mg matches 0 run function mg:bw/tick
execute if score #bw mg matches 0 if entity @a[tag=mg_q_bw] run function mg:bw/idle
execute if score #wind mg matches 1.. run function mg:wind/tick
execute if score #wind mg matches 0 if entity @a[tag=mg_q_wind] run function mg:q/try_wind
execute if score #kb mg matches 1.. run function mg:kb/tick
execute if score #kb mg matches 0 if entity @a[tag=mg_q_kb] run function mg:q/try_kb
execute if score #pfeil mg matches 1.. run function mg:pfeil/tick
execute if score #pfeil mg matches 0 if entity @a[tag=mg_q_pfeil] run function mg:q/try_pfeil
execute if score #kolben mg matches 1.. run function mg:kolben/tick
execute if score #kolben mg matches 0 if entity @a[tag=mg_q_kolben] run function mg:q/try_kolben
execute if score #bruecke mg matches 1.. run function mg:bruecke/tick
execute if score #bruecke mg matches 0 if entity @a[tag=mg_q_bruecke] run function mg:q/try_bruecke
execute if score #lava mg matches 1.. run function mg:lava/tick
execute if score #lava mg matches 0 if entity @a[tag=mg_q_lava] run function mg:q/try_lava
execute if score #boden mg matches 1.. run function mg:boden/tick
execute if score #boden mg matches 0 if entity @a[tag=mg_q_boden] run function mg:q/try_boden
execute if score #boxen mg matches 1.. run function mg:boxen/tick
execute if score #boxen mg matches 0 if entity @a[tag=mg_q_boxen] run function mg:q/try_boxen
execute if score #pferd mg matches 1.. run function mg:pferd/tick
execute if score #pferd mg matches 0 if entity @a[tag=mg_q_pferd] run function mg:q/try_pferd
execute if score #parkour mg matches 1.. run function mg:parkour/tick
execute if score #parkour mg matches 0 if entity @a[tag=mg_q_parkour] run function mg:q/try_parkour
execute if score #stickbett mg matches 1.. run function mg:stickbett/tick
execute if score #stickbett mg matches 0 if entity @a[tag=mg_q_stickbett] run function mg:q/try_stickbett
