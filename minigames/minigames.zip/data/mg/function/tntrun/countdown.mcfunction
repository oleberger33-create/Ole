execute store result score #n mg if entity @a[tag=mg_q_tntrun,tag=mg_hub]
execute if score #n mg matches ..1 run execute in minecraft:overworld run forceload remove 69976 -24 70024 24
execute if score #n mg matches ..1 run tellraw @a[tag=mg_q_tntrun] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zu wenig Spieler – TNT-Run abgebrochen.", "color": "red"}]
execute if score #n mg matches ..1 run return run scoreboard players set #tntrun mg 0
scoreboard players remove #tntrun_cd mg 1
scoreboard players operation #s mg = #tntrun_cd mg
scoreboard players operation #s mg /= #20 mg
execute as @a[tag=mg_q_tntrun] run title @s actionbar [{"text":"TNT-Run startet in ","color":"red"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true},{"text":" s","color":"red"}]
execute if score #tntrun_cd mg matches 60 as @a[tag=mg_q_tntrun] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #tntrun_cd mg matches 40 as @a[tag=mg_q_tntrun] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #tntrun_cd mg matches 20 as @a[tag=mg_q_tntrun] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #tntrun_cd mg matches ..0 in minecraft:overworld if loaded 69984 100 -16 if loaded 70016 100 16 run function mg:tntrun/start
