execute store result score #n mg if entity @a[tag=mg_q_tntrun,tag=mg_hub]
execute if score #n mg matches 2.. run scoreboard players set #tntrun_cd mg 300
execute if score #n mg matches 2.. run execute in minecraft:overworld run forceload add 69976 -24 70024 24
execute if score #n mg matches 2.. run tellraw @a[tag=mg_q_tntrun] [{"text": "» ", "color": "gold", "bold": true}, {"text": "TNT-Run startet in 15 Sekunden!", "color": "red"}]
execute if score #n mg matches 2.. run scoreboard players set #tntrun mg 1
