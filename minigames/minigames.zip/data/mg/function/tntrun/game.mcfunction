scoreboard players add #tntrun_t mg 1
execute as @a[tag=mg_al_tntrun] at @s if entity @s[y=-64,dy=140] run kill @s
execute if score #tntrun_t mg matches 60.. as @a[tag=mg_al_tntrun] at @s run fill ~-0.3 ~-1 ~-0.3 ~0.3 ~-1 ~0.3 minecraft:orange_concrete replace #minecraft:wool
execute if score #tntrun_t mg matches 60.. as @a[tag=mg_al_tntrun] at @s run fill ~-0.3 ~-1.6 ~-0.3 ~0.3 ~-1.6 ~0.3 minecraft:orange_concrete replace #minecraft:wool
scoreboard players operation #m mg = #tntrun_t mg
scoreboard players operation #m mg %= #4 mg
execute if score #m mg matches 0 run function mg:tntrun/decay
execute if score #tntrun_t mg matches 60 run title @a[tag=mg_tntrun] actionbar {"text":"Der Boden zerfällt jetzt!","color":"red","bold":true}
execute if score #tntrun_t mg matches 20 run title @a[tag=mg_tntrun] actionbar {"text":"3 Sekunden Schonzeit ...","color":"gray"}
execute store result score #surv mg if entity @a[tag=mg_al_tntrun,scores={mg_deaths=0}]
execute if score #surv mg matches 0 if entity @a[tag=mg_al_tntrun] run return run function mg:tntrun/end
execute as @a[tag=mg_al_tntrun,scores={mg_deaths=1..}] run function mg:tntrun/out
execute store result score #alive mg if entity @a[tag=mg_al_tntrun]
execute if score #alive mg matches ..1 run function mg:tntrun/end
