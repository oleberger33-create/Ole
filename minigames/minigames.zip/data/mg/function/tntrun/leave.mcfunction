tag @s remove mg_q_tntrun
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "TNT-Run-Warteschlange verlassen.", "color": "gray"}]
