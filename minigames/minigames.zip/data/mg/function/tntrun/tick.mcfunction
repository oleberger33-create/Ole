execute if score #tntrun mg matches 2 run function mg:tntrun/game
