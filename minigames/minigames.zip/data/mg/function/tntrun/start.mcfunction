function mg:tntrun/build
tag @a[tag=mg_q_tntrun,tag=mg_hub,limit=16,sort=random] add mg_tntrun
tag @a[tag=mg_tntrun] remove mg_q_tntrun
execute as @a[tag=mg_tntrun] run function mg:q/leave_all
tag @a[tag=mg_tntrun] remove mg_hub
clear @a[tag=mg_tntrun]
effect clear @a[tag=mg_tntrun]
gamemode adventure @a[tag=mg_tntrun]
tag @a[tag=mg_tntrun] add mg_al_tntrun
scoreboard players set @a[tag=mg_tntrun] mg_deaths 0
execute as @a[tag=mg_tntrun] run execute in minecraft:overworld run spawnpoint @s 70000 110 0
scoreboard players set #tntrun_t mg 0
execute in minecraft:overworld run spreadplayers 70000 0 3 11 false @a[tag=mg_tntrun]
effect give @a[tag=mg_tntrun] minecraft:saturation infinite 0 true
effect give @a[tag=mg_tntrun] minecraft:resistance infinite 4 true
execute in minecraft:overworld run forceload remove 69976 -24 70024 24
scoreboard players set #tntrun mg 2
title @a[tag=mg_tntrun] times 5 50 10
title @a[tag=mg_tntrun] title {"text": "TNT-RUN", "color": "red", "bold": true}
title @a[tag=mg_tntrun] subtitle {"text": "Bleib in Bewegung!", "color": "white"}
tellraw @a[tag=mg_tntrun] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Jeder Block, auf den du trittst, zerfällt nach einem Moment. Drei Ebenen übereinander – wer zuletzt noch steht, gewinnt.", "color": "gray"}]
tellraw @a[tag=mg_tntrun] [{"text": "  "}, {"text": "[Spiel verlassen]", "color": "red", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 99"}}]
