execute as @a[tag=mg_tntrun] run function mg:hub/enter
tag @a remove mg_tntrun
tag @a remove mg_al_tntrun
scoreboard players set #tntrun mg 0
execute in minecraft:overworld run kill @e[type=minecraft:item,x=69976,dx=48,y=60,dy=90,z=-24,dz=48]
