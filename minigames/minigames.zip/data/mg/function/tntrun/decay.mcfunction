execute in minecraft:overworld run fill 69986 100 -14 70014 100 14 minecraft:air replace minecraft:red_concrete
execute in minecraft:overworld run fill 69986 100 -14 70014 100 14 minecraft:red_concrete replace minecraft:orange_concrete
execute in minecraft:overworld run fill 69986 92 -14 70014 92 14 minecraft:air replace minecraft:red_concrete
execute in minecraft:overworld run fill 69986 92 -14 70014 92 14 minecraft:red_concrete replace minecraft:orange_concrete
execute in minecraft:overworld run fill 69986 84 -14 70014 84 14 minecraft:air replace minecraft:red_concrete
execute in minecraft:overworld run fill 69986 84 -14 70014 84 14 minecraft:red_concrete replace minecraft:orange_concrete
