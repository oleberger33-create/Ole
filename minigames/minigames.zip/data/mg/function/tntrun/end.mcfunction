execute as @a[tag=mg_al_tntrun] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt TNT-Run!", "color": "white"}]
execute unless entity @a[tag=mg_al_tntrun] run tellraw @a[tag=mg_tntrun] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Unentschieden – niemand hat überlebt.", "color": "gray"}]
scoreboard players add @a[tag=mg_al_tntrun] mg_wins 1
scoreboard players add @a[tag=mg_al_tntrun] mg_coins 10
title @a[tag=mg_tntrun] title {"text": "Spiel vorbei!", "color": "red", "bold": true}
execute as @a[tag=mg_al_tntrun] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720],has_twinkle:true}]}}}}
scoreboard players set #tntrun mg 3
schedule function mg:tntrun/finish 100t
