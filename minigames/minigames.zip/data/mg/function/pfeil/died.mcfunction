scoreboard players set @s mg_deaths 0
tag @s add mg_dead
execute as @a[tag=mg_duel_pfeil,tag=!mg_dead] run give @s minecraft:arrow 1
tellraw @a[tag=mg_duel_pfeil] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_duel_pfeil,tag=!mg_dead]", "color": "white"}, {"text": " erwischt ", "color": "gray"}, {"selector": "@s", "color": "white"}]
execute as @a[tag=mg_duel_pfeil,tag=!mg_dead] run function mg:pfeil/point
execute if score #pfeil mg matches 2 run function mg:pfeil/kit
effect clear @s minecraft:slowness
tag @s remove mg_dead
title @a[tag=mg_duel_pfeil] actionbar [{"text":"Kills  ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_pfeil,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_pfeil,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"},{"text":"  (bis 5)","color":"gray"}]
