title @a[tag=mg_duel_pfeil] actionbar {"text": "LOS!", "color": "dark_aqua", "bold": true}
execute as @a[tag=mg_duel_pfeil] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
