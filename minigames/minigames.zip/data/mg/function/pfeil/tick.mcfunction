execute if score #pfeil_cd mg matches 1.. run scoreboard players remove #pfeil_cd mg 1
execute if score #pfeil mg matches 1 if score #pfeil_cd mg matches 0 run function mg:pfeil/go
execute if score #pfeil mg matches 1 if score #pfeil_cd mg matches 0 run scoreboard players set #pfeil mg 2
execute unless score #pfeil mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_pfeil]
execute if score #n mg matches ..1 run return run function mg:pfeil/forfeit
execute as @a[tag=mg_duel_pfeil,scores={mg_deaths=1..}] run function mg:pfeil/died
execute as @a[tag=mg_duel_pfeil] at @s if entity @s[y=-64,dy=154] run kill @s
