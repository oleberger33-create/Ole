execute if score #pfeil_cd mg matches 1.. run scoreboard players remove #pfeil_cd mg 1
execute if score #pfeil mg matches 1 if score #pfeil_cd mg matches 0 run function mg:pfeil/go
execute if score #pfeil mg matches 1 if score #pfeil_cd mg matches 0 run scoreboard players set #pfeil mg 2
execute if score #pfeil mg matches 1 run execute in minecraft:overworld run kill @e[type=#mg:projectiles,x=7955,dx=90,y=70,dy=80,z=-45,dz=90]
execute unless score #pfeil mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_pfeil]
execute if score #n mg matches ..1 run return run function mg:pfeil/forfeit
execute as @e[type=minecraft:player,tag=mg_duel_pfeil,scores={mg_deaths=1..}] run function mg:pfeil/died
execute as @a[tag=mg_duel_pfeil] at @s if entity @s[y=-64,dy=154] run kill @s
execute in minecraft:overworld as @e[type=minecraft:arrow,x=7970,dx=60,y=80,dy=60,z=-30,dz=60,tag=!mg_np] run data merge entity @s {pickup:0b,Tags:["mg_np"]}
execute in minecraft:overworld run kill @e[type=minecraft:item,x=7970,dx=60,y=80,dy=60,z=-30,dz=60]
