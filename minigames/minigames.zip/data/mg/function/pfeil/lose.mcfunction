execute unless score #pfeil mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_pfeil] remove mg_rw
tag @a[tag=mg_duel_pfeil] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_pfeil] mg_round 1
tellraw @a[tag=mg_duel_pfeil] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_pfeil]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "dark_aqua"}]
execute as @a[tag=mg_duel_pfeil] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_pfeil,scores={mg_round=5..}] run return run function mg:pfeil/win
scoreboard players set #pfeil mg 1
function mg:pfeil/round
