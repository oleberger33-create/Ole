execute in minecraft:overworld run kill @e[type=minecraft:item,x=7955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=7955,dx=90,y=70,dy=80,z=-45,dz=90]
execute as @a[tag=mg_duel_pfeil] run function mg:pfeil/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_pfeil,tag=mg_p1,limit=1] 7990 101 -8 -45 0
execute in minecraft:overworld run tp @a[tag=mg_duel_pfeil,tag=mg_p2,limit=1] 8010 101 8 135 0
execute as @a[tag=mg_duel_pfeil,tag=mg_p1,limit=1] run execute in minecraft:overworld run spawnpoint @s 7990 101 -8
execute as @a[tag=mg_duel_pfeil,tag=mg_p2,limit=1] run execute in minecraft:overworld run spawnpoint @s 8010 101 8
kill @e[type=minecraft:horse,tag=mg_horse_pfeil]
scoreboard players set #pfeil_cd mg 60
scoreboard players set #pfeil mg 1
title @a[tag=mg_duel_pfeil] times 0 30 10
title @a[tag=mg_duel_pfeil] title {"text": "Ein Pfeil", "color": "dark_aqua", "bold": true}
title @a[tag=mg_duel_pfeil] subtitle [{"score":{"name":"@a[tag=mg_duel_pfeil,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_pfeil,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
