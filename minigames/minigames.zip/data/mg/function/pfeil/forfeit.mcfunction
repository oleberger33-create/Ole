execute as @a[tag=mg_duel_pfeil] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Ein Pfeil – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_pfeil] mg_wins 1
scoreboard players add @a[tag=mg_duel_pfeil] mg_coins 5
function mg:pfeil/stop
