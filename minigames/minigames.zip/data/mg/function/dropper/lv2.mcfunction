fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:polished_blackstone_bricks hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:obsidian
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:obsidian
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:obsidian
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:obsidian
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:shroomlight
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:shroomlight
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:shroomlight
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:shroomlight
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:shroomlight
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:shroomlight
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:shroomlight
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:shroomlight
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:shroomlight
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:shroomlight
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:shroomlight
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:shroomlight
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:obsidian
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:obsidian outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:blackstone
fill ~1 ~-3 ~-1 ~6 ~-3 ~4 minecraft:red_nether_bricks
fill ~2 ~-6 ~0 ~5 ~-6 ~3 minecraft:glowstone
fill ~2 ~-5 ~0 ~5 ~-3 ~3 minecraft:water
fill ~-6 ~57 ~-6 ~-2 ~58 ~6 minecraft:nether_bricks
fill ~1 ~57 ~-6 ~2 ~58 ~6 minecraft:nether_bricks
fill ~5 ~57 ~-6 ~6 ~58 ~6 minecraft:nether_bricks
fill ~-6 ~51 ~-6 ~6 ~51 ~-6 minecraft:red_nether_bricks
fill ~-6 ~51 ~-1 ~6 ~51 ~6 minecraft:red_nether_bricks
fill ~-6 ~51 ~-5 ~-2 ~51 ~-2 minecraft:red_nether_bricks
fill ~3 ~51 ~-5 ~6 ~51 ~-2 minecraft:red_nether_bricks
fill ~-6 ~44 ~-6 ~6 ~44 ~-5 minecraft:red_stained_glass
fill ~-6 ~44 ~0 ~6 ~44 ~6 minecraft:red_stained_glass
fill ~-6 ~44 ~-4 ~0 ~44 ~-1 minecraft:red_stained_glass
fill ~5 ~44 ~-4 ~6 ~44 ~-1 minecraft:red_stained_glass
fill ~-6 ~36 ~-6 ~6 ~36 ~-6 minecraft:nether_wart_block
fill ~-6 ~36 ~1 ~6 ~36 ~6 minecraft:nether_wart_block
fill ~-6 ~36 ~-5 ~-1 ~36 ~0 minecraft:nether_wart_block
fill ~6 ~36 ~-5 ~6 ~36 ~0 minecraft:nether_wart_block
fill ~2 ~36 ~-3 ~3 ~36 ~-2 minecraft:nether_wart_block
fill ~-6 ~28 ~-6 ~6 ~28 ~-3 minecraft:warped_wart_block
fill ~-6 ~28 ~2 ~6 ~28 ~6 minecraft:warped_wart_block
fill ~-6 ~28 ~-2 ~2 ~28 ~1 minecraft:warped_wart_block
fill ~-6 ~19 ~-6 ~6 ~19 ~-1 minecraft:red_stained_glass
fill ~-6 ~19 ~4 ~6 ~19 ~6 minecraft:red_stained_glass
fill ~-6 ~19 ~0 ~1 ~19 ~3 minecraft:red_stained_glass
fill ~6 ~19 ~0 ~6 ~19 ~3 minecraft:red_stained_glass
fill ~-6 ~9 ~-6 ~6 ~10 ~-1 minecraft:nether_bricks
fill ~-6 ~9 ~3 ~6 ~10 ~6 minecraft:nether_bricks
fill ~-6 ~9 ~0 ~0 ~10 ~2 minecraft:nether_bricks
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:polished_blackstone
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
