execute store result score #n mg if entity @a[tag=mg_q_dropper,tag=mg_hub]
execute if score #n mg matches ..0 run execute in minecraft:overworld run forceload remove 83886 -114 84114 114
execute if score #n mg matches ..0 run tellraw @a[tag=mg_q_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zu wenig Spieler – Dropper abgebrochen.", "color": "red"}]
execute if score #n mg matches ..0 run return run scoreboard players set #dropper mg 0
scoreboard players remove #dropper_cd mg 1
scoreboard players operation #s mg = #dropper_cd mg
scoreboard players operation #s mg /= #20 mg
execute as @a[tag=mg_q_dropper] run title @s actionbar [{"text":"Dropper startet in ","color":"gold"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true},{"text":" s","color":"gold"}]
execute if score #dropper_cd mg matches 60 as @a[tag=mg_q_dropper] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #dropper_cd mg matches 40 as @a[tag=mg_q_dropper] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #dropper_cd mg matches 20 as @a[tag=mg_q_dropper] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #dropper_cd mg matches ..0 in minecraft:overworld if loaded 83894 100 -106 if loaded 84106 100 106 run function mg:dropper/start
