scoreboard players add #dropper_t mg 1
execute if score #dropper_t mg matches 60 run function mg:dropper/cd3
execute if score #dropper_t mg matches 80 run function mg:dropper/cd2
execute if score #dropper_t mg matches 100 run function mg:dropper/cd1
execute if score #dropper_t mg matches 120 run function mg:dropper/go
execute as @e[type=minecraft:player,tag=mg_al_dropper] at @s run function mg:dropper/pl
execute unless score #dropper mg matches 2 run return 0
scoreboard players operation #dropper_m mg = #dropper_t mg
scoreboard players operation #dropper_m mg %= #4 mg
execute if score #dropper_m mg matches 0 run function mg:dropper/hud
execute if score #dropper_t mg matches 4920 run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 60 Sekunden!", "color": "red", "bold": true}]
execute if score #dropper_t mg matches 4920 as @a[tag=mg_dropper] at @s run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 1 0.6
execute if score #dropper_t mg matches 5520 run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 30 Sekunden!", "color": "red", "bold": true}]
execute if score #dropper_t mg matches 5520 as @a[tag=mg_dropper] at @s run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 1 0.6
execute if score #dropper_t mg matches 5920 run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 10 Sekunden!", "color": "red", "bold": true}]
execute if score #dropper_t mg matches 5920 as @a[tag=mg_dropper] at @s run playsound minecraft:block.note_block.basedrum master @s ~ ~ ~ 1 0.6
execute store result score #dropper_n mg if entity @a[tag=mg_al_dropper]
execute if score #dropper_n mg matches 0 run return run function mg:dropper/end_go
execute if score #dropper_n mg matches 1 if score #dropper_np mg matches 2.. run return run function mg:dropper/end_alone
execute if score #dropper_t mg matches 6120.. run return run function mg:dropper/end_time
