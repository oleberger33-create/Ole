execute in minecraft:overworld run fill 83952 165 -111 83952 168 -99 minecraft:yellow_stained_glass
execute in minecraft:overworld run fill 83952 165 -81 83952 168 -69 minecraft:yellow_stained_glass
execute in minecraft:overworld run fill 83952 165 -51 83952 168 -39 minecraft:yellow_stained_glass
execute in minecraft:overworld run fill 83952 165 -21 83952 168 -9 minecraft:yellow_stained_glass
execute in minecraft:overworld run fill 83952 165 9 83952 168 21 minecraft:yellow_stained_glass
execute in minecraft:overworld run fill 83952 165 39 83952 168 51 minecraft:yellow_stained_glass
execute in minecraft:overworld run fill 83952 165 69 83952 168 81 minecraft:yellow_stained_glass
execute in minecraft:overworld run fill 83952 165 99 83952 168 111 minecraft:yellow_stained_glass
title @a[tag=mg_dropper] times 0 22 4
title @a[tag=mg_dropper] title {"text": "1", "color": "yellow", "bold": true}
title @a[tag=mg_dropper] subtitle {"text": "Gleich öffnet sich die Glaswand ...", "color": "gray"}
execute as @a[tag=mg_dropper] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.0
