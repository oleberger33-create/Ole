scoreboard players set @s mg_deaths 0
attribute @s minecraft:gravity base set 0.04
effect give @s minecraft:saturation infinite 0 true
effect give @s minecraft:resistance infinite 4 true
function mg:dropper/tp
