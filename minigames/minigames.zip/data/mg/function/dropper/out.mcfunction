tag @s remove mg_al_dropper
scoreboard players set @s mg_deaths 0
gamemode spectator @s
clear @s
execute store result score #alive mg if entity @a[tag=mg_al_dropper]
tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " ist raus! ", "color": "red"}, {"text": "Noch ", "color": "gray"}, {"score": {"name": "#alive", "objective": "mg"}, "color": "white"}, {"text": " übrig.", "color": "gray"}]
execute in minecraft:overworld run tp @s 84000 177 0
scoreboard players add @s mg_coins 2
