execute in minecraft:overworld run fill 83952 165 -111 83952 168 -99 minecraft:air
execute in minecraft:overworld run fill 83952 165 -81 83952 168 -69 minecraft:air
execute in minecraft:overworld run fill 83952 165 -51 83952 168 -39 minecraft:air
execute in minecraft:overworld run fill 83952 165 -21 83952 168 -9 minecraft:air
execute in minecraft:overworld run fill 83952 165 9 83952 168 21 minecraft:air
execute in minecraft:overworld run fill 83952 165 39 83952 168 51 minecraft:air
execute in minecraft:overworld run fill 83952 165 69 83952 168 81 minecraft:air
execute in minecraft:overworld run fill 83952 165 99 83952 168 111 minecraft:air
title @a[tag=mg_dropper] times 0 30 10
title @a[tag=mg_dropper] title {"text": "LOS!", "color": "green", "bold": true}
title @a[tag=mg_dropper] subtitle {"text": "Spring in den Schacht und triff das Wasser!", "color": "white"}
execute as @a[tag=mg_dropper] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Tipp: ", "color": "yellow"}, {"text": "Im Schacht fällst du langsamer – steuer schon früh, je tiefer du kommst, desto schneller wirst du. Durch Glas siehst du die nächste Lücke.", "color": "gray"}]
