execute if score #dropper_np mg matches ..1 run return run function mg:dropper/end
tag @a[tag=mg_dropper] remove mg_al_dropper
scoreboard players add @a[tag=mg_dropper,tag=mg_dropper_win] mg_wins 1
scoreboard players add @a[tag=mg_dropper,tag=mg_dropper_win] mg_coins 15
execute as @a[tag=mg_dropper,tag=mg_dropper_win] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Dropper!", "color": "white"}]
execute unless entity @a[tag=mg_dropper,tag=mg_dropper_win] run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Unentschieden – niemand hat ein Level geschafft.", "color": "gray"}]
tellraw @a[tag=mg_dropper] {"text": " Ergebnis:", "color": "gold", "bold": true}
execute as @a[tag=mg_dropper,scores={mg_dropper_l=5}] run tellraw @a[tag=mg_dropper] [{"text": "   ▸ ", "color": "dark_gray"}, {"selector": "@s", "color": "white"}, {"text": "  "}, {"text": "✔ Ziel", "color": "green", "bold": true}, {"text": "  ·  Fehlversuche: ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
execute as @a[tag=mg_dropper,scores={mg_dropper_l=4}] run tellraw @a[tag=mg_dropper] [{"text": "   ▸ ", "color": "dark_gray"}, {"selector": "@s", "color": "white"}, {"text": "  "}, {"text": "Level 4/4", "color": "light_purple"}, {"text": "  ·  Fehlversuche: ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
execute as @a[tag=mg_dropper,scores={mg_dropper_l=3}] run tellraw @a[tag=mg_dropper] [{"text": "   ▸ ", "color": "dark_gray"}, {"selector": "@s", "color": "white"}, {"text": "  "}, {"text": "Level 3/4", "color": "red"}, {"text": "  ·  Fehlversuche: ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
execute as @a[tag=mg_dropper,scores={mg_dropper_l=2}] run tellraw @a[tag=mg_dropper] [{"text": "   ▸ ", "color": "dark_gray"}, {"selector": "@s", "color": "white"}, {"text": "  "}, {"text": "Level 2/4", "color": "aqua"}, {"text": "  ·  Fehlversuche: ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
execute as @a[tag=mg_dropper,scores={mg_dropper_l=1}] run tellraw @a[tag=mg_dropper] [{"text": "   ▸ ", "color": "dark_gray"}, {"selector": "@s", "color": "white"}, {"text": "  "}, {"text": "Level 1/4", "color": "yellow"}, {"text": "  ·  Fehlversuche: ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
execute as @a[tag=mg_dropper,tag=mg_dropper_win] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720],has_twinkle:true}]}}}}
execute as @a[tag=mg_dropper] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1
bossbar set mg:dropper visible false
scoreboard players set #dropper mg 3
schedule function mg:dropper/finish 100t
