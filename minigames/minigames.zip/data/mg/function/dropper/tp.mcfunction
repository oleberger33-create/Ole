execute if score @s mg_dropper_l matches 1 run function mg:dropper/tp1
execute if score @s mg_dropper_l matches 2 run function mg:dropper/tp2
execute if score @s mg_dropper_l matches 3 run function mg:dropper/tp3
execute if score @s mg_dropper_l matches 4 run function mg:dropper/tp4
