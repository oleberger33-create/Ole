scoreboard players add @s mg_dropper_l 1
scoreboard players add @s mg_coins 1
particle minecraft:splash ~ ~1 ~ 0.6 0.4 0.6 0.2 40
execute if score @s mg_dropper_l matches 5.. run return run function mg:dropper/win
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.2
playsound minecraft:entity.generic.splash master @s ~ ~ ~ 0.6 1
function mg:dropper/tp
title @s times 3 35 10
execute if score @s mg_dropper_l matches 2 run title @s title {"text": "Level 2", "color": "aqua", "bold": true}
execute if score @s mg_dropper_l matches 2 run title @s subtitle [{"text": "✔ Geschafft!  ", "color": "green", "bold": true}, {"text": "Weiter: Tiefsee", "color": "white"}]
execute if score @s mg_dropper_l matches 2 run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " hat Level 1 geschafft ", "color": "gray"}, {"text": "(1/4)", "color": "aqua"}]
execute if score @s mg_dropper_l matches 3 run title @s title {"text": "Level 3", "color": "red", "bold": true}
execute if score @s mg_dropper_l matches 3 run title @s subtitle [{"text": "✔ Geschafft!  ", "color": "green", "bold": true}, {"text": "Weiter: Netherschlund", "color": "white"}]
execute if score @s mg_dropper_l matches 3 run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " hat Level 2 geschafft ", "color": "gray"}, {"text": "(2/4)", "color": "red"}]
execute if score @s mg_dropper_l matches 4 run title @s title {"text": "Level 4", "color": "light_purple", "bold": true}
execute if score @s mg_dropper_l matches 4 run title @s subtitle [{"text": "✔ Geschafft!  ", "color": "green", "bold": true}, {"text": "Weiter: Endkern", "color": "white"}]
execute if score @s mg_dropper_l matches 4 run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " hat Level 3 geschafft ", "color": "gray"}, {"text": "(3/4)", "color": "light_purple"}]
execute if score @s mg_dropper_l matches 4 as @a[tag=mg_dropper] unless entity @s[scores={mg_dropper_l=4..}] at @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 0.8 0.8
