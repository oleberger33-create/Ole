scoreboard players operation @s mg_dropper_s = #dropper_n mg
scoreboard players add #dropper_n mg 1
