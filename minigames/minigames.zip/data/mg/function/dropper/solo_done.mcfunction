scoreboard players operation #pbv mg = #dropper_t mg
scoreboard players remove #pbv mg 120
scoreboard players operation #dropper_p_d mg = #pbv mg
scoreboard players operation #dropper_p_d mg /= #2 mg
scoreboard players operation #dropper_p_s1 mg = #dropper_p_d mg
scoreboard players operation #dropper_p_s1 mg /= #10 mg
scoreboard players operation #dropper_p_m mg = #dropper_p_s1 mg
scoreboard players operation #dropper_p_m mg /= #60 mg
scoreboard players operation #dropper_p_s1 mg %= #60 mg
scoreboard players operation #dropper_p_s10 mg = #dropper_p_s1 mg
scoreboard players operation #dropper_p_s10 mg /= #10 mg
scoreboard players operation #dropper_p_s1 mg %= #10 mg
scoreboard players operation #dropper_p_d mg %= #10 mg
title @s subtitle [{"text": "Alle 4 Level in ", "color": "white"}, {"score": {"name": "#dropper_p_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#dropper_p_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#dropper_p_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#dropper_p_d", "objective": "mg"}, "color": "yellow", "bold": true}]
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Ziel! ", "color": "green", "bold": true}, {"text": "Alle 4 Level in ", "color": "white"}, {"score": {"name": "#dropper_p_m", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ":", "color": "yellow", "bold": true}, {"score": {"name": "#dropper_p_s10", "objective": "mg"}, "color": "yellow", "bold": true}, {"score": {"name": "#dropper_p_s1", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": ".", "color": "yellow", "bold": true}, {"score": {"name": "#dropper_p_d", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": "  ·  Fehlversuche: ", "color": "gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "white"}]
function mg:dropper/pb
scoreboard players add @s mg_coins 3
execute if score #pbn mg matches 0 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "+3 Münzen", "color": "yellow"}]
execute if score #pbn mg matches 1 run scoreboard players add @s mg_coins 2
execute if score #pbn mg matches 1 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "+3 Münzen ", "color": "yellow"}, {"text": "(+2 Rekord-Bonus)", "color": "gold"}]
execute at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720],has_twinkle:true}]}}}}
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
