execute as @a[tag=mg_dropper] run function mg:hub/enter
tag @a remove mg_dropper
tag @a remove mg_al_dropper
scoreboard players set #dropper mg 0
execute in minecraft:overworld run fill 83952 165 -111 83952 168 -99 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83952 165 -81 83952 168 -69 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83952 165 -51 83952 168 -39 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83952 165 -21 83952 168 -9 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83952 165 9 83952 168 21 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83952 165 39 83952 168 51 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83952 165 69 83952 168 81 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83952 165 99 83952 168 111 minecraft:light_blue_stained_glass
bossbar set mg:dropper visible false
bossbar set mg:dropper players
tag @a remove mg_dropper_win
execute in minecraft:overworld run kill @e[type=minecraft:item,x=83886,dx=228,y=60,dy=90,z=-114,dz=228]
