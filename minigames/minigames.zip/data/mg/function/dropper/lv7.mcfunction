fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:mushroom_stem hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:brown_mushroom_block replace minecraft:mushroom_stem
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:brown_mushroom_block replace minecraft:mushroom_stem
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:brown_mushroom_block replace minecraft:mushroom_stem
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:brown_mushroom_block replace minecraft:mushroom_stem
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:brown_mushroom_block replace minecraft:mushroom_stem
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:brown_mushroom_block replace minecraft:mushroom_stem
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:brown_mushroom_block replace minecraft:mushroom_stem
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:dark_oak_log
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:dark_oak_log
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:dark_oak_log
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:dark_oak_log
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:shroomlight
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:shroomlight
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:shroomlight
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:shroomlight
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:shroomlight
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:shroomlight
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:shroomlight
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:shroomlight
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:shroomlight
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:shroomlight
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:shroomlight
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:shroomlight
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:dark_oak_log
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:dark_oak_log outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:mycelium
fill ~0 ~-3 ~-5 ~6 ~-3 ~0 minecraft:red_mushroom_block
fill ~1 ~-6 ~-4 ~5 ~-6 ~-1 minecraft:shroomlight
fill ~1 ~-5 ~-4 ~5 ~-3 ~-1 minecraft:water
fill ~-3 ~56 ~-6 ~2 ~57 ~-3 minecraft:red_mushroom_block
fill ~-3 ~56 ~-2 ~6 ~57 ~-1 minecraft:red_mushroom_block
fill ~3 ~56 ~0 ~6 ~57 ~6 minecraft:red_mushroom_block
fill ~-6 ~56 ~1 ~0 ~57 ~6 minecraft:red_mushroom_block
fill ~-6 ~49 ~-6 ~6 ~49 ~1 minecraft:brown_mushroom_block
fill ~-6 ~49 ~6 ~6 ~49 ~6 minecraft:brown_mushroom_block
fill ~-6 ~49 ~2 ~-1 ~49 ~5 minecraft:brown_mushroom_block
fill ~4 ~49 ~2 ~6 ~49 ~5 minecraft:brown_mushroom_block
fill ~-4 ~42 ~-4 ~-3 ~42 ~-3 minecraft:mushroom_stem
fill ~3 ~42 ~-1 ~4 ~42 ~0 minecraft:mushroom_stem
fill ~-2 ~42 ~0 ~-2 ~42 ~0 minecraft:mushroom_stem
fill ~0 ~42 ~3 ~1 ~42 ~4 minecraft:mushroom_stem
fill ~4 ~42 ~4 ~4 ~42 ~4 minecraft:mushroom_stem
fill ~2 ~42 ~6 ~3 ~42 ~6 minecraft:mushroom_stem
fill ~-6 ~34 ~-6 ~6 ~34 ~-1 minecraft:red_mushroom_block
fill ~-6 ~34 ~5 ~6 ~34 ~6 minecraft:red_mushroom_block
fill ~-6 ~34 ~0 ~-4 ~34 ~4 minecraft:red_mushroom_block
fill ~3 ~34 ~0 ~6 ~34 ~4 minecraft:red_mushroom_block
fill ~-1 ~34 ~2 ~-1 ~34 ~2 minecraft:red_mushroom_block
fill ~-6 ~26 ~-6 ~6 ~26 ~-4 minecraft:brown_mushroom_block
fill ~-6 ~26 ~2 ~6 ~26 ~6 minecraft:brown_mushroom_block
fill ~-6 ~26 ~-3 ~-1 ~26 ~-3 minecraft:brown_mushroom_block
fill ~4 ~26 ~-3 ~6 ~26 ~0 minecraft:brown_mushroom_block
fill ~-6 ~26 ~-2 ~-6 ~26 ~1 minecraft:brown_mushroom_block
fill ~-1 ~26 ~-2 ~-1 ~26 ~0 minecraft:brown_mushroom_block
fill ~-1 ~26 ~1 ~6 ~26 ~1 minecraft:brown_mushroom_block
fill ~-6 ~18 ~-6 ~6 ~18 ~-5 minecraft:mushroom_stem
fill ~-6 ~18 ~0 ~6 ~18 ~6 minecraft:mushroom_stem
fill ~-6 ~18 ~-4 ~0 ~18 ~-1 minecraft:mushroom_stem
fill ~5 ~18 ~-4 ~6 ~18 ~-1 minecraft:mushroom_stem
fill ~-6 ~9 ~-6 ~6 ~10 ~-6 minecraft:red_mushroom_block
fill ~-6 ~9 ~0 ~6 ~10 ~6 minecraft:red_mushroom_block
fill ~-6 ~9 ~-5 ~-1 ~10 ~-1 minecraft:red_mushroom_block
fill ~6 ~9 ~-5 ~6 ~10 ~-1 minecraft:red_mushroom_block
fill ~2 ~9 ~-4 ~3 ~10 ~-3 minecraft:red_mushroom_block
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:mycelium
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
