execute store result score #n mg if entity @a[tag=mg_q_dropper,tag=mg_hub]
execute if score #n mg matches 1.. run scoreboard players set #dropper_cd mg 300
execute if score #n mg matches 1.. run execute in minecraft:overworld run forceload add 83886 -114 84114 114
execute if score #n mg matches 1.. run tellraw @a[tag=mg_q_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dropper startet in 15 Sekunden!", "color": "gold"}]
execute if score #n mg matches 1.. run scoreboard players set #dropper mg 1
