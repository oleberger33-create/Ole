execute if score @s mg_dropper_s matches 0 run execute in minecraft:overworld run tp @s 83950.5 165 -104.5 -90 25
execute if score @s mg_dropper_s matches 1 run execute in minecraft:overworld run tp @s 83950.5 165 -74.5 -90 25
execute if score @s mg_dropper_s matches 2 run execute in minecraft:overworld run tp @s 83950.5 165 -44.5 -90 25
execute if score @s mg_dropper_s matches 3 run execute in minecraft:overworld run tp @s 83950.5 165 -14.5 -90 25
execute if score @s mg_dropper_s matches 4 run execute in minecraft:overworld run tp @s 83950.5 165 15.5 -90 25
execute if score @s mg_dropper_s matches 5 run execute in minecraft:overworld run tp @s 83950.5 165 45.5 -90 25
execute if score @s mg_dropper_s matches 6 run execute in minecraft:overworld run tp @s 83950.5 165 75.5 -90 25
execute if score @s mg_dropper_s matches 7 run execute in minecraft:overworld run tp @s 83950.5 165 105.5 -90 25
