fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:deepslate_tiles hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:sculk replace minecraft:deepslate_tiles
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:sculk replace minecraft:deepslate_tiles
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:sculk replace minecraft:deepslate_tiles
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:sculk replace minecraft:deepslate_tiles
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:sculk replace minecraft:deepslate_tiles
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:sculk replace minecraft:deepslate_tiles
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:sculk replace minecraft:deepslate_tiles
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:reinforced_deepslate
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:reinforced_deepslate
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:reinforced_deepslate
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:reinforced_deepslate
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:verdant_froglight
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:verdant_froglight
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:verdant_froglight
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:verdant_froglight
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:verdant_froglight
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:verdant_froglight
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:verdant_froglight
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:verdant_froglight
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:verdant_froglight
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:verdant_froglight
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:verdant_froglight
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:verdant_froglight
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:reinforced_deepslate
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:reinforced_deepslate outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:sculk
fill ~-3 ~-3 ~2 ~1 ~-3 ~6 minecraft:cyan_terracotta
fill ~-2 ~-6 ~3 ~0 ~-6 ~5 minecraft:verdant_froglight
fill ~-2 ~-5 ~3 ~0 ~-3 ~5 minecraft:water
fill ~-6 ~57 ~-6 ~6 ~58 ~1 minecraft:sculk
fill ~-6 ~57 ~5 ~6 ~58 ~6 minecraft:sculk
fill ~-6 ~57 ~2 ~-4 ~58 ~4 minecraft:sculk
fill ~0 ~57 ~2 ~6 ~58 ~4 minecraft:sculk
fill ~-6 ~51 ~-6 ~6 ~51 ~0 minecraft:tinted_glass
fill ~-6 ~51 ~4 ~6 ~51 ~6 minecraft:tinted_glass
fill ~-6 ~51 ~1 ~-3 ~51 ~3 minecraft:tinted_glass
fill ~1 ~51 ~1 ~6 ~51 ~3 minecraft:tinted_glass
fill ~-6 ~45 ~-6 ~6 ~45 ~-1 minecraft:deepslate_tiles
fill ~-6 ~45 ~4 ~6 ~45 ~6 minecraft:deepslate_tiles
fill ~-6 ~45 ~0 ~-2 ~45 ~3 minecraft:deepslate_tiles
fill ~0 ~45 ~0 ~6 ~45 ~3 minecraft:deepslate_tiles
fill ~-6 ~39 ~-6 ~6 ~39 ~-1 minecraft:sculk
fill ~-6 ~39 ~3 ~6 ~39 ~6 minecraft:sculk
fill ~-6 ~39 ~0 ~-3 ~39 ~2 minecraft:sculk
fill ~1 ~39 ~0 ~6 ~39 ~2 minecraft:sculk
fill ~-6 ~33 ~-6 ~6 ~33 ~-5 minecraft:reinforced_deepslate
fill ~-6 ~33 ~5 ~6 ~33 ~6 minecraft:reinforced_deepslate
fill ~-6 ~33 ~-4 ~-4 ~33 ~4 minecraft:reinforced_deepslate
fill ~-2 ~33 ~-4 ~-2 ~33 ~4 minecraft:reinforced_deepslate
fill ~1 ~33 ~-4 ~1 ~33 ~4 minecraft:reinforced_deepslate
fill ~5 ~33 ~-4 ~6 ~33 ~4 minecraft:reinforced_deepslate
fill ~-6 ~27 ~-6 ~6 ~27 ~-4 minecraft:sculk
fill ~-6 ~27 ~0 ~6 ~27 ~1 minecraft:sculk
fill ~-6 ~27 ~5 ~6 ~27 ~6 minecraft:sculk
fill ~-6 ~27 ~-3 ~-2 ~27 ~-1 minecraft:sculk
fill ~-6 ~27 ~2 ~-2 ~27 ~4 minecraft:sculk
fill ~1 ~27 ~-3 ~6 ~27 ~-1 minecraft:sculk
fill ~1 ~27 ~2 ~6 ~27 ~4 minecraft:sculk
fill ~-6 ~21 ~-6 ~6 ~21 ~2 minecraft:cobbled_deepslate
fill ~-6 ~21 ~6 ~6 ~21 ~6 minecraft:cobbled_deepslate
fill ~-6 ~21 ~3 ~-3 ~21 ~5 minecraft:cobbled_deepslate
fill ~1 ~21 ~3 ~6 ~21 ~5 minecraft:cobbled_deepslate
fill ~-6 ~16 ~-6 ~6 ~16 ~3 minecraft:sculk
fill ~-6 ~16 ~5 ~6 ~16 ~6 minecraft:sculk
fill ~-6 ~16 ~4 ~-4 ~16 ~4 minecraft:sculk
fill ~2 ~16 ~4 ~6 ~16 ~4 minecraft:sculk
fill ~-6 ~10 ~-6 ~6 ~10 ~2 minecraft:deepslate_tiles
fill ~-6 ~10 ~6 ~6 ~10 ~6 minecraft:deepslate_tiles
fill ~-6 ~10 ~3 ~-2 ~10 ~5 minecraft:deepslate_tiles
fill ~0 ~10 ~3 ~0 ~10 ~3 minecraft:deepslate_tiles
fill ~2 ~10 ~3 ~6 ~10 ~5 minecraft:deepslate_tiles
fill ~-6 ~4 ~-6 ~6 ~4 ~2 minecraft:sculk
fill ~-6 ~4 ~6 ~6 ~4 ~6 minecraft:sculk
fill ~-6 ~4 ~3 ~-4 ~4 ~5 minecraft:sculk
fill ~2 ~4 ~3 ~6 ~4 ~5 minecraft:sculk
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:polished_deepslate
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
