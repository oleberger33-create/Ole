execute if score #dropper mg matches 2 run function mg:dropper/game
