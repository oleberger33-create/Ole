execute if score #dropper_np mg matches ..1 run return run function mg:dropper/solo_end
execute store result score #elim mg if entity @a[tag=mg_dropper,tag=!mg_al_dropper]
execute if score #elim mg matches 1.. as @a[tag=mg_al_dropper] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Dropper!", "color": "white"}]
execute unless entity @a[tag=mg_al_dropper] run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Unentschieden – niemand hat überlebt.", "color": "gray"}]
execute if score #elim mg matches 1.. run scoreboard players add @a[tag=mg_al_dropper] mg_wins 1
execute if score #elim mg matches 1.. run scoreboard players add @a[tag=mg_al_dropper] mg_coins 0
execute if score #elim mg matches 0 if entity @a[tag=mg_al_dropper] run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Keine Wertung – die anderen haben das Spiel verlassen.", "color": "gray"}]
title @a[tag=mg_dropper] title {"text": "Spiel vorbei!", "color": "gold", "bold": true}
execute as @a[tag=mg_al_dropper] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720],has_twinkle:true}]}}}}
scoreboard players set #dropper mg 3
schedule function mg:dropper/finish 100t
