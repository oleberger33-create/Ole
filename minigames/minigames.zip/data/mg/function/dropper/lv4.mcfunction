fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:calcite hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:white_wool replace minecraft:calcite
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:white_wool replace minecraft:calcite
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:white_wool replace minecraft:calcite
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:white_wool replace minecraft:calcite
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:white_wool replace minecraft:calcite
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:white_wool replace minecraft:calcite
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:white_wool replace minecraft:calcite
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:snow_block
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:snow_block
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:snow_block
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:snow_block
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:sea_lantern
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:sea_lantern
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:sea_lantern
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:sea_lantern
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:sea_lantern
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:sea_lantern
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:sea_lantern
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:sea_lantern
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:sea_lantern
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:sea_lantern
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:sea_lantern
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:sea_lantern
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:snow_block
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:snow_block outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:snow_block
fill ~-3 ~-3 ~-3 ~3 ~-3 ~3 minecraft:light_blue_wool
fill ~-2 ~-6 ~-2 ~2 ~-6 ~2 minecraft:sea_lantern
fill ~-2 ~-5 ~-2 ~2 ~-3 ~2 minecraft:water
fill ~-6 ~57 ~-6 ~6 ~57 ~-4 minecraft:white_stained_glass
fill ~-6 ~57 ~3 ~6 ~57 ~6 minecraft:white_stained_glass
fill ~-6 ~57 ~-3 ~-4 ~57 ~2 minecraft:white_stained_glass
fill ~3 ~57 ~-3 ~6 ~57 ~2 minecraft:white_stained_glass
fill ~-6 ~48 ~-6 ~6 ~49 ~-4 minecraft:white_wool
fill ~-6 ~48 ~4 ~6 ~49 ~6 minecraft:white_wool
fill ~-6 ~48 ~-3 ~-4 ~49 ~3 minecraft:white_wool
fill ~4 ~48 ~-3 ~6 ~49 ~3 minecraft:white_wool
fill ~-1 ~48 ~-1 ~1 ~49 ~1 minecraft:white_wool
fill ~-6 ~41 ~-6 ~6 ~41 ~-1 minecraft:snow_block
fill ~-6 ~41 ~5 ~6 ~41 ~6 minecraft:snow_block
fill ~-6 ~41 ~0 ~-1 ~41 ~4 minecraft:snow_block
fill ~5 ~41 ~0 ~6 ~41 ~4 minecraft:snow_block
fill ~-6 ~33 ~-6 ~6 ~33 ~-2 minecraft:light_blue_stained_glass
fill ~-6 ~33 ~5 ~6 ~33 ~6 minecraft:light_blue_stained_glass
fill ~-6 ~33 ~-1 ~-3 ~33 ~4 minecraft:light_blue_stained_glass
fill ~4 ~33 ~-1 ~6 ~33 ~4 minecraft:light_blue_stained_glass
fill ~0 ~33 ~1 ~1 ~33 ~2 minecraft:light_blue_stained_glass
fill ~-6 ~24 ~-6 ~6 ~24 ~-3 minecraft:white_wool
fill ~-6 ~24 ~3 ~6 ~24 ~6 minecraft:white_wool
fill ~-6 ~24 ~-2 ~-4 ~24 ~2 minecraft:white_wool
fill ~2 ~24 ~-2 ~6 ~24 ~2 minecraft:white_wool
fill ~-6 ~15 ~-6 ~6 ~15 ~-5 minecraft:calcite
fill ~-6 ~15 ~0 ~6 ~15 ~0 minecraft:calcite
fill ~-6 ~15 ~5 ~6 ~15 ~6 minecraft:calcite
fill ~-6 ~15 ~-4 ~-5 ~15 ~-1 minecraft:calcite
fill ~-6 ~15 ~1 ~-5 ~15 ~4 minecraft:calcite
fill ~5 ~15 ~-4 ~6 ~15 ~-1 minecraft:calcite
fill ~5 ~15 ~1 ~6 ~15 ~4 minecraft:calcite
fill ~-6 ~6 ~-6 ~6 ~6 ~-4 minecraft:white_stained_glass
fill ~-6 ~6 ~4 ~6 ~6 ~6 minecraft:white_stained_glass
fill ~-6 ~6 ~-3 ~-4 ~6 ~3 minecraft:white_stained_glass
fill ~4 ~6 ~-3 ~6 ~6 ~3 minecraft:white_stained_glass
fill ~0 ~6 ~0 ~0 ~6 ~0 minecraft:white_stained_glass
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:white_wool
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
