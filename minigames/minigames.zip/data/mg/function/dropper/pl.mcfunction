execute unless score #dropper mg matches 2 run return 0
execute if score @s mg_deaths matches 1.. run return run function mg:dropper/died
execute if entity @s[y=92,dy=8] if block ~ ~ ~ minecraft:water run return run function mg:dropper/done
execute if entity @s[y=92,dy=8] if block ~ ~0.6 ~ minecraft:water run return run function mg:dropper/done
execute unless entity @s[x=83940,y=90,z=-120,dx=120,dy=81,dz=240] run return run function mg:dropper/fail
execute if entity @s[y=164.5,dy=8] run return 0
execute if predicate {type:"minecraft:entity_properties",entity:"this",predicate:{flags:{is_on_ground:true}}} run function mg:dropper/fail
