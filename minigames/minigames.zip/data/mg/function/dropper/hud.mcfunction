scoreboard players set #dropper_rem mg 6120
scoreboard players operation #dropper_rem mg -= #dropper_t mg
scoreboard players operation #dropper_rem mg /= #20 mg
execute if score #dropper_rem mg matches 301.. run scoreboard players set #dropper_rem mg 300
scoreboard players operation #dropper_c mg = #dropper_rem mg
scoreboard players operation #dropper_mm mg = #dropper_c mg
scoreboard players operation #dropper_mm mg /= #60 mg
scoreboard players operation #dropper_s1 mg = #dropper_c mg
scoreboard players operation #dropper_s1 mg %= #60 mg
scoreboard players operation #dropper_s10 mg = #dropper_s1 mg
scoreboard players operation #dropper_s10 mg /= #10 mg
scoreboard players operation #dropper_s1 mg %= #10 mg
execute store result bossbar mg:dropper value run scoreboard players get #dropper_rem mg
bossbar set mg:dropper players @a[tag=mg_dropper]
bossbar set mg:dropper visible true
execute if score #dropper_rem mg matches 31.. run bossbar set mg:dropper name [{"text": "Dropper  ", "color": "gold", "bold": true}, {"text": "⏱ ", "color": "gray"}, {"score": {"name": "#dropper_mm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#dropper_s10", "objective": "mg"}, "color": "white"}, {"score": {"name": "#dropper_s1", "objective": "mg"}, "color": "white"}]
execute if score #dropper_rem mg matches ..30 run bossbar set mg:dropper name [{"text": "Dropper  ", "color": "red", "bold": true}, {"text": "⏱ ", "color": "red"}, {"score": {"name": "#dropper_mm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#dropper_s10", "objective": "mg"}, "color": "white"}, {"score": {"name": "#dropper_s1", "objective": "mg"}, "color": "white"}]
execute if score #dropper_rem mg matches ..30 run bossbar set mg:dropper color red
execute as @a[tag=mg_al_dropper,scores={mg_dropper_l=1}] run title @s actionbar [{"text": "Level 1/4 ", "color": "yellow", "bold": true}, {"text": "Farbschacht", "color": "white"}, {"text": "   ✖ ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
execute as @a[tag=mg_al_dropper,scores={mg_dropper_l=2}] run title @s actionbar [{"text": "Level 2/4 ", "color": "aqua", "bold": true}, {"text": "Tiefsee", "color": "white"}, {"text": "   ✖ ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
execute as @a[tag=mg_al_dropper,scores={mg_dropper_l=3}] run title @s actionbar [{"text": "Level 3/4 ", "color": "red", "bold": true}, {"text": "Netherschlund", "color": "white"}, {"text": "   ✖ ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
execute as @a[tag=mg_al_dropper,scores={mg_dropper_l=4}] run title @s actionbar [{"text": "Level 4/4 ", "color": "light_purple", "bold": true}, {"text": "Endkern", "color": "white"}, {"text": "   ✖ ", "color": "dark_gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "gray"}]
