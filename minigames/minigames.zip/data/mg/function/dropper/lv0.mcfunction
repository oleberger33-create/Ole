fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:white_concrete hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:red_concrete replace minecraft:white_concrete
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:orange_concrete replace minecraft:white_concrete
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:yellow_concrete replace minecraft:white_concrete
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:lime_concrete replace minecraft:white_concrete
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:light_blue_concrete replace minecraft:white_concrete
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:purple_concrete replace minecraft:white_concrete
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:red_concrete replace minecraft:white_concrete
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:quartz_pillar
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:quartz_pillar
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:quartz_pillar
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:quartz_pillar
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:sea_lantern
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:sea_lantern
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:sea_lantern
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:sea_lantern
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:sea_lantern
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:sea_lantern
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:sea_lantern
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:sea_lantern
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:sea_lantern
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:sea_lantern
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:sea_lantern
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:sea_lantern
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:quartz_pillar
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:quartz_pillar outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:white_concrete
fill ~-4 ~-3 ~-4 ~4 ~-3 ~4 minecraft:yellow_concrete
fill ~-3 ~-6 ~-3 ~3 ~-6 ~3 minecraft:sea_lantern
fill ~-3 ~-5 ~-3 ~3 ~-3 ~3 minecraft:water
fill ~-6 ~56 ~-6 ~6 ~56 ~-3 minecraft:red_concrete
fill ~-6 ~56 ~3 ~6 ~56 ~6 minecraft:red_concrete
fill ~-6 ~56 ~-2 ~-4 ~56 ~2 minecraft:red_concrete
fill ~2 ~56 ~-2 ~6 ~56 ~2 minecraft:red_concrete
fill ~-6 ~48 ~-6 ~6 ~48 ~-2 minecraft:orange_concrete
fill ~-6 ~48 ~4 ~6 ~48 ~6 minecraft:orange_concrete
fill ~-6 ~48 ~-1 ~-3 ~48 ~3 minecraft:orange_concrete
fill ~3 ~48 ~-1 ~6 ~48 ~3 minecraft:orange_concrete
fill ~-6 ~40 ~-6 ~6 ~40 ~-4 minecraft:yellow_concrete
fill ~-6 ~40 ~5 ~6 ~40 ~6 minecraft:yellow_concrete
fill ~-6 ~40 ~-3 ~-3 ~40 ~4 minecraft:yellow_concrete
fill ~4 ~40 ~-3 ~6 ~40 ~4 minecraft:yellow_concrete
fill ~0 ~40 ~0 ~1 ~40 ~1 minecraft:yellow_concrete
fill ~-6 ~31 ~-6 ~6 ~31 ~-3 minecraft:lime_concrete
fill ~-6 ~31 ~3 ~6 ~31 ~6 minecraft:lime_concrete
fill ~-6 ~31 ~-2 ~-2 ~31 ~2 minecraft:lime_concrete
fill ~4 ~31 ~-2 ~6 ~31 ~2 minecraft:lime_concrete
fill ~-6 ~22 ~-6 ~6 ~22 ~-4 minecraft:light_blue_concrete
fill ~-6 ~22 ~2 ~6 ~22 ~6 minecraft:light_blue_concrete
fill ~-6 ~22 ~-3 ~-3 ~22 ~1 minecraft:light_blue_concrete
fill ~3 ~22 ~-3 ~6 ~22 ~1 minecraft:light_blue_concrete
fill ~-6 ~12 ~-4 ~6 ~13 ~-3 minecraft:purple_concrete
fill ~-6 ~12 ~2 ~6 ~13 ~3 minecraft:purple_concrete
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:smooth_quartz
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
