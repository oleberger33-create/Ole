fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:prismarine_bricks hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:dark_prismarine replace minecraft:prismarine_bricks
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:dark_prismarine replace minecraft:prismarine_bricks
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:dark_prismarine replace minecraft:prismarine_bricks
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:dark_prismarine replace minecraft:prismarine_bricks
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:dark_prismarine replace minecraft:prismarine_bricks
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:dark_prismarine replace minecraft:prismarine_bricks
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:dark_prismarine replace minecraft:prismarine_bricks
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:dark_prismarine
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:dark_prismarine
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:dark_prismarine
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:dark_prismarine
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:sea_lantern
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:sea_lantern
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:sea_lantern
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:sea_lantern
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:sea_lantern
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:sea_lantern
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:sea_lantern
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:sea_lantern
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:sea_lantern
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:sea_lantern
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:sea_lantern
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:sea_lantern
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:dark_prismarine
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:dark_prismarine outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:prismarine
fill ~0 ~-3 ~-4 ~5 ~-3 ~1 minecraft:light_blue_concrete
fill ~1 ~-6 ~-3 ~4 ~-6 ~0 minecraft:sea_lantern
fill ~1 ~-5 ~-3 ~4 ~-3 ~0 minecraft:water
fill ~-6 ~57 ~-6 ~6 ~57 ~1 minecraft:cyan_stained_glass
fill ~-6 ~57 ~6 ~6 ~57 ~6 minecraft:cyan_stained_glass
fill ~-6 ~57 ~2 ~-3 ~57 ~5 minecraft:cyan_stained_glass
fill ~2 ~57 ~2 ~6 ~57 ~5 minecraft:cyan_stained_glass
fill ~-6 ~49 ~-6 ~6 ~49 ~0 minecraft:prismarine
fill ~-6 ~49 ~5 ~6 ~49 ~6 minecraft:prismarine
fill ~-6 ~49 ~1 ~-2 ~49 ~4 minecraft:prismarine
fill ~3 ~49 ~1 ~6 ~49 ~4 minecraft:prismarine
fill ~-6 ~41 ~-6 ~6 ~41 ~-3 minecraft:light_blue_stained_glass
fill ~-6 ~41 ~6 ~6 ~41 ~6 minecraft:light_blue_stained_glass
fill ~-6 ~41 ~-2 ~-3 ~41 ~5 minecraft:light_blue_stained_glass
fill ~5 ~41 ~-2 ~6 ~41 ~5 minecraft:light_blue_stained_glass
fill ~0 ~41 ~2 ~2 ~41 ~4 minecraft:light_blue_stained_glass
fill ~-6 ~33 ~-6 ~6 ~33 ~-3 minecraft:dark_prismarine
fill ~-6 ~33 ~3 ~6 ~33 ~6 minecraft:dark_prismarine
fill ~-6 ~33 ~-2 ~-1 ~33 ~2 minecraft:dark_prismarine
fill ~4 ~33 ~-2 ~6 ~33 ~2 minecraft:dark_prismarine
fill ~-6 ~24 ~-6 ~6 ~24 ~-4 minecraft:cyan_stained_glass
fill ~-6 ~24 ~1 ~6 ~24 ~6 minecraft:cyan_stained_glass
fill ~-6 ~24 ~-3 ~0 ~24 ~0 minecraft:cyan_stained_glass
fill ~4 ~24 ~-3 ~6 ~24 ~0 minecraft:cyan_stained_glass
fill ~-6 ~15 ~-6 ~6 ~15 ~-5 minecraft:prismarine_bricks
fill ~-6 ~15 ~2 ~6 ~15 ~6 minecraft:prismarine_bricks
fill ~-6 ~15 ~-4 ~-1 ~15 ~1 minecraft:prismarine_bricks
fill ~6 ~15 ~-4 ~6 ~15 ~1 minecraft:prismarine_bricks
fill ~2 ~15 ~-2 ~3 ~15 ~-1 minecraft:prismarine_bricks
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:dark_prismarine
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
