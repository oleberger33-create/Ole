fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:sandstone hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:orange_terracotta replace minecraft:sandstone
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:cut_sandstone replace minecraft:sandstone
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:blue_terracotta replace minecraft:sandstone
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:cut_sandstone replace minecraft:sandstone
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:orange_terracotta replace minecraft:sandstone
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:cut_sandstone replace minecraft:sandstone
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:blue_terracotta replace minecraft:sandstone
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:chiseled_sandstone
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:chiseled_sandstone
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:chiseled_sandstone
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:chiseled_sandstone
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:ochre_froglight
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:ochre_froglight
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:ochre_froglight
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:ochre_froglight
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:ochre_froglight
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:ochre_froglight
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:ochre_froglight
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:ochre_froglight
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:ochre_froglight
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:ochre_froglight
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:ochre_froglight
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:ochre_froglight
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:chiseled_sandstone
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:chiseled_sandstone outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:cut_sandstone
fill ~0 ~-3 ~-5 ~5 ~-3 ~0 minecraft:blue_terracotta
fill ~1 ~-6 ~-4 ~4 ~-6 ~-1 minecraft:ochre_froglight
fill ~1 ~-5 ~-4 ~4 ~-3 ~-1 minecraft:water
fill ~-6 ~58 ~-6 ~6 ~58 ~1 minecraft:cut_sandstone
fill ~-6 ~58 ~6 ~6 ~58 ~6 minecraft:cut_sandstone
fill ~-6 ~58 ~2 ~-4 ~58 ~5 minecraft:cut_sandstone
fill ~1 ~58 ~2 ~6 ~58 ~5 minecraft:cut_sandstone
fill ~-6 ~51 ~-6 ~6 ~51 ~-1 minecraft:orange_terracotta
fill ~-6 ~51 ~4 ~6 ~51 ~6 minecraft:orange_terracotta
fill ~-6 ~51 ~0 ~-2 ~51 ~3 minecraft:orange_terracotta
fill ~3 ~51 ~0 ~6 ~51 ~3 minecraft:orange_terracotta
fill ~-6 ~44 ~-6 ~6 ~44 ~-3 minecraft:smooth_sandstone
fill ~-6 ~44 ~6 ~6 ~44 ~6 minecraft:smooth_sandstone
fill ~-6 ~44 ~-2 ~-4 ~44 ~1 minecraft:smooth_sandstone
fill ~1 ~44 ~-2 ~6 ~44 ~1 minecraft:smooth_sandstone
fill ~-6 ~44 ~2 ~0 ~44 ~5 minecraft:smooth_sandstone
fill ~5 ~44 ~2 ~6 ~44 ~5 minecraft:smooth_sandstone
fill ~-6 ~36 ~-6 ~6 ~36 ~-4 minecraft:blue_terracotta
fill ~-6 ~36 ~1 ~6 ~36 ~6 minecraft:blue_terracotta
fill ~-6 ~36 ~-3 ~-4 ~36 ~0 minecraft:blue_terracotta
fill ~1 ~36 ~-3 ~6 ~36 ~0 minecraft:blue_terracotta
fill ~-6 ~28 ~-3 ~6 ~28 ~-3 minecraft:cut_sandstone
fill ~-6 ~28 ~0 ~6 ~28 ~0 minecraft:cut_sandstone
fill ~-6 ~28 ~3 ~6 ~28 ~3 minecraft:cut_sandstone
fill ~-6 ~20 ~-6 ~6 ~20 ~-2 minecraft:orange_terracotta
fill ~-6 ~20 ~3 ~6 ~20 ~6 minecraft:orange_terracotta
fill ~-6 ~20 ~-1 ~-3 ~20 ~2 minecraft:orange_terracotta
fill ~2 ~20 ~-1 ~6 ~20 ~2 minecraft:orange_terracotta
fill ~-6 ~12 ~-6 ~6 ~12 ~-4 minecraft:smooth_sandstone
fill ~-6 ~12 ~2 ~6 ~12 ~6 minecraft:smooth_sandstone
fill ~-6 ~12 ~-3 ~-1 ~12 ~1 minecraft:smooth_sandstone
fill ~4 ~12 ~-3 ~6 ~12 ~1 minecraft:smooth_sandstone
fill ~1 ~12 ~-1 ~2 ~12 ~-1 minecraft:smooth_sandstone
fill ~-6 ~4 ~-6 ~6 ~4 ~-6 minecraft:chiseled_sandstone
fill ~-6 ~4 ~1 ~6 ~4 ~6 minecraft:chiseled_sandstone
fill ~-6 ~4 ~-5 ~-1 ~4 ~0 minecraft:chiseled_sandstone
fill ~5 ~4 ~-5 ~6 ~4 ~0 minecraft:chiseled_sandstone
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:smooth_sandstone
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
