tag @s remove mg_q_dropper
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dropper-Warteschlange verlassen.", "color": "gray"}]
