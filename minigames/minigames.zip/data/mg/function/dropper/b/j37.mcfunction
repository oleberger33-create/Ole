execute in minecraft:overworld run forceload add 83940 30 83969 59
execute in minecraft:overworld if loaded 83940 100 30 if loaded 83940 100 59 if loaded 83969 100 30 if loaded 83969 100 59 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d37
schedule function mg:dropper/bstep 5t
