execute in minecraft:overworld run forceload add 83880 30 83909 59
execute in minecraft:overworld if loaded 83880 100 30 if loaded 83880 100 59 if loaded 83909 100 30 if loaded 83909 100 59 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d21
schedule function mg:dropper/bstep 5t
