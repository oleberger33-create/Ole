execute in minecraft:overworld run forceload add 83850 -120 83879 -91
execute in minecraft:overworld if loaded 83850 100 -120 if loaded 83850 100 -91 if loaded 83879 100 -120 if loaded 83879 100 -91 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d8
schedule function mg:dropper/bstep 5t
