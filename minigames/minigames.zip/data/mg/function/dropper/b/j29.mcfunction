execute in minecraft:overworld run forceload add 83910 30 83939 59
execute in minecraft:overworld if loaded 83910 100 30 if loaded 83910 100 59 if loaded 83939 100 30 if loaded 83939 100 59 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d29
schedule function mg:dropper/bstep 5t
