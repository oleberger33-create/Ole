execute in minecraft:overworld run forceload add 84000 60 84029 89
execute in minecraft:overworld if loaded 84000 100 60 if loaded 84000 100 89 if loaded 84029 100 60 if loaded 84029 100 89 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d54
schedule function mg:dropper/bstep 5t
