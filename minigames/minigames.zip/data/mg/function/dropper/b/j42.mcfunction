execute in minecraft:overworld run forceload add 83970 -60 83999 -31
execute in minecraft:overworld if loaded 83970 100 -60 if loaded 83970 100 -31 if loaded 83999 100 -60 if loaded 83999 100 -31 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d42
schedule function mg:dropper/bstep 5t
