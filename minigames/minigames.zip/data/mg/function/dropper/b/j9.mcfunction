execute in minecraft:overworld run forceload add 83850 -90 83879 -61
execute in minecraft:overworld if loaded 83850 100 -90 if loaded 83850 100 -61 if loaded 83879 100 -90 if loaded 83879 100 -61 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d9
schedule function mg:dropper/bstep 5t
