execute in minecraft:overworld run forceload add 83910 -60 83939 -31
execute in minecraft:overworld if loaded 83910 100 -60 if loaded 83910 100 -31 if loaded 83939 100 -60 if loaded 83939 100 -31 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d26
schedule function mg:dropper/bstep 5t
