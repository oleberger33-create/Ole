execute in minecraft:overworld run forceload add 83850 -60 83879 -31
execute in minecraft:overworld if loaded 83850 100 -60 if loaded 83850 100 -31 if loaded 83879 100 -60 if loaded 83879 100 -31 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d10
schedule function mg:dropper/bstep 5t
