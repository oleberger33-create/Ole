execute in minecraft:overworld run forceload add 83820 -30 83849 -1
execute in minecraft:overworld if loaded 83820 100 -30 if loaded 83820 100 -1 if loaded 83849 100 -30 if loaded 83849 100 -1 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d3
schedule function mg:dropper/bstep 5t
