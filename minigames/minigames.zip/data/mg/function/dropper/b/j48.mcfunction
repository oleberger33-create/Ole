execute in minecraft:overworld run forceload add 84000 -120 84029 -91
execute in minecraft:overworld if loaded 84000 100 -120 if loaded 84000 100 -91 if loaded 84029 100 -120 if loaded 84029 100 -91 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d48
schedule function mg:dropper/bstep 5t
