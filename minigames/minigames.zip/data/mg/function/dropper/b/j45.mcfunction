execute in minecraft:overworld run forceload add 83970 30 83999 59
execute in minecraft:overworld if loaded 83970 100 30 if loaded 83970 100 59 if loaded 83999 100 30 if loaded 83999 100 59 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d45
schedule function mg:dropper/bstep 5t
