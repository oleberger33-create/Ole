execute in minecraft:overworld run forceload add 83940 90 83969 119
execute in minecraft:overworld if loaded 83940 100 90 if loaded 83940 100 119 if loaded 83969 100 90 if loaded 83969 100 119 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d39
schedule function mg:dropper/bstep 5t
