execute in minecraft:overworld positioned 84015 100 15 run function mg:dropper/lv6
execute in minecraft:overworld run kill @e[type=minecraft:text_display,tag=mg_dropperh,x=84000,y=70,z=0,dx=29,dy=120,dz=29]
execute in minecraft:overworld run summon minecraft:text_display 84010.5 167.5 15.5 {Tags:["mg_dropperh"],billboard:"center",background:0,shadow:true,text:[{"text": "Wüstentempel\n", "color": "gold", "bold": true}, {"text": "★★☆", "color": "gold", "bold": false}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]}}
execute in minecraft:overworld run forceload remove 84000 0 84029 29
scoreboard players set #dropper_bw mg 0
scoreboard players set #dropper_bq mg 53
schedule function mg:dropper/bstep 2t
