execute in minecraft:overworld run forceload add 83820 60 83849 89
execute in minecraft:overworld if loaded 83820 100 60 if loaded 83820 100 89 if loaded 83849 100 60 if loaded 83849 100 89 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d6
schedule function mg:dropper/bstep 5t
