execute in minecraft:overworld run forceload add 83820 -60 83849 -31
execute in minecraft:overworld if loaded 83820 100 -60 if loaded 83820 100 -31 if loaded 83849 100 -60 if loaded 83849 100 -31 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d2
schedule function mg:dropper/bstep 5t
