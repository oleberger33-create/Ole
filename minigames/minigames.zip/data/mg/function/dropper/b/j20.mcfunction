execute in minecraft:overworld run forceload add 83880 0 83909 29
execute in minecraft:overworld if loaded 83880 100 0 if loaded 83880 100 29 if loaded 83909 100 0 if loaded 83909 100 29 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d20
schedule function mg:dropper/bstep 5t
