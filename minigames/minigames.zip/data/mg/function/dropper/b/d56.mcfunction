execute in minecraft:overworld positioned 84045 100 -105 run function mg:dropper/lv7
execute in minecraft:overworld run kill @e[type=minecraft:text_display,tag=mg_dropperh,x=84030,y=70,z=-120,dx=29,dy=120,dz=29]
execute in minecraft:overworld run summon minecraft:text_display 84040.5 167.5 -104.5 {Tags:["mg_dropperh"],billboard:"center",background:0,shadow:true,text:[{"text": "Pilzwald\n", "color": "red", "bold": true}, {"text": "★★☆", "color": "gold", "bold": false}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]}}
execute in minecraft:overworld run summon minecraft:text_display 84045.5 173 -118.5 {Tags:["mg_dropperh"],billboard:"center",background:0,shadow:true,text:[{"text": "Pilzwald\n", "color": "red", "bold": true}, {"text": "★★☆", "color": "gold", "bold": false}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.5f,2.5f,2.5f]}}
execute in minecraft:overworld run forceload remove 84030 -120 84059 -91
scoreboard players set #dropper_bw mg 0
scoreboard players set #dropper_bq mg 57
schedule function mg:dropper/bstep 2t
