execute in minecraft:overworld run forceload add 84030 -90 84059 -61
execute in minecraft:overworld if loaded 84030 100 -90 if loaded 84030 100 -61 if loaded 84059 100 -90 if loaded 84059 100 -61 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d57
schedule function mg:dropper/bstep 5t
