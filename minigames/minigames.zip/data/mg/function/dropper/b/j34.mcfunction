execute in minecraft:overworld run forceload add 83940 -60 83969 -31
execute in minecraft:overworld if loaded 83940 100 -60 if loaded 83940 100 -31 if loaded 83969 100 -60 if loaded 83969 100 -31 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d34
schedule function mg:dropper/bstep 5t
