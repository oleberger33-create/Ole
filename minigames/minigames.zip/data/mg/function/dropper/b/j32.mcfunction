execute in minecraft:overworld run forceload add 83940 -120 83969 -91
execute in minecraft:overworld if loaded 83940 100 -120 if loaded 83940 100 -91 if loaded 83969 100 -120 if loaded 83969 100 -91 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d32
schedule function mg:dropper/bstep 5t
