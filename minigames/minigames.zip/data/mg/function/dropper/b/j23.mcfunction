execute in minecraft:overworld run forceload add 83880 90 83909 119
execute in minecraft:overworld if loaded 83880 100 90 if loaded 83880 100 119 if loaded 83909 100 90 if loaded 83909 100 119 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d23
schedule function mg:dropper/bstep 5t
