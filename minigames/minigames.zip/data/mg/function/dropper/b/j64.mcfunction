execute in minecraft:overworld run forceload add 84060 -120 84089 -91
execute in minecraft:overworld if loaded 84060 100 -120 if loaded 84060 100 -91 if loaded 84089 100 -120 if loaded 84089 100 -91 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d64
schedule function mg:dropper/bstep 5t
