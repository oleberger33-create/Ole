execute in minecraft:overworld run forceload add 83970 90 83999 119
execute in minecraft:overworld if loaded 83970 100 90 if loaded 83970 100 119 if loaded 83999 100 90 if loaded 83999 100 119 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d47
schedule function mg:dropper/bstep 5t
