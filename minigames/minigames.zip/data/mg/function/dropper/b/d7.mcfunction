execute in minecraft:overworld positioned 83835 100 105 run function mg:dropper/lv0
execute in minecraft:overworld run kill @e[type=minecraft:text_display,tag=mg_dropperh,x=83820,y=70,z=90,dx=29,dy=120,dz=29]
execute in minecraft:overworld run summon minecraft:text_display 83830.5 167.5 105.5 {Tags:["mg_dropperh"],billboard:"center",background:0,shadow:true,text:[{"text": "Farbschacht\n", "color": "yellow", "bold": true}, {"text": "★☆☆", "color": "gold", "bold": false}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]}}
execute in minecraft:overworld run forceload remove 83820 90 83849 119
scoreboard players set #dropper_bw mg 0
scoreboard players set #dropper_bq mg 8
schedule function mg:dropper/bstep 2t
