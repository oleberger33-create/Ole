execute in minecraft:overworld run forceload add 84000 -90 84029 -61
execute in minecraft:overworld if loaded 84000 100 -90 if loaded 84000 100 -61 if loaded 84029 100 -90 if loaded 84029 100 -61 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d49
schedule function mg:dropper/bstep 5t
