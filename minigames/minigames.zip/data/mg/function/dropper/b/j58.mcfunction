execute in minecraft:overworld run forceload add 84030 -60 84059 -31
execute in minecraft:overworld if loaded 84030 100 -60 if loaded 84030 100 -31 if loaded 84059 100 -60 if loaded 84059 100 -31 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d58
schedule function mg:dropper/bstep 5t
