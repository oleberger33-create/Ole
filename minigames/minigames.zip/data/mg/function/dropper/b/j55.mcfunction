execute in minecraft:overworld run forceload add 84000 90 84029 119
execute in minecraft:overworld if loaded 84000 100 90 if loaded 84000 100 119 if loaded 84029 100 90 if loaded 84029 100 119 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d55
schedule function mg:dropper/bstep 5t
