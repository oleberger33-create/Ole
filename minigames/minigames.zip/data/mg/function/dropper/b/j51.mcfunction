execute in minecraft:overworld run forceload add 84000 -30 84029 -1
execute in minecraft:overworld if loaded 84000 100 -30 if loaded 84000 100 -1 if loaded 84029 100 -30 if loaded 84029 100 -1 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d51
schedule function mg:dropper/bstep 5t
