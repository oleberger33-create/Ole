execute in minecraft:overworld run forceload add 84000 0 84029 29
execute in minecraft:overworld if loaded 84000 100 0 if loaded 84000 100 29 if loaded 84029 100 0 if loaded 84029 100 29 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d52
schedule function mg:dropper/bstep 5t
