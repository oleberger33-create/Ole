execute in minecraft:overworld positioned 83985 100 15 run function mg:dropper/lv5
execute in minecraft:overworld run kill @e[type=minecraft:text_display,tag=mg_dropperh,x=83970,y=70,z=0,dx=29,dy=120,dz=29]
execute in minecraft:overworld run summon minecraft:text_display 83980.5 167.5 15.5 {Tags:["mg_dropperh"],billboard:"center",background:0,shadow:true,text:[{"text": "Kirschgarten\n", "color": "light_purple", "bold": true}, {"text": "★☆☆", "color": "gold", "bold": false}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.9f,0.9f,0.9f]}}
execute in minecraft:overworld run forceload remove 83970 0 83999 29
scoreboard players set #dropper_bw mg 0
scoreboard players set #dropper_bq mg 45
schedule function mg:dropper/bstep 2t
