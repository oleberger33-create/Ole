execute in minecraft:overworld run forceload add 83910 90 83939 119
execute in minecraft:overworld if loaded 83910 100 90 if loaded 83910 100 119 if loaded 83939 100 90 if loaded 83939 100 119 run scoreboard players add #dropper_bw mg 1
execute if score #dropper_bw mg matches 3.. run return run function mg:dropper/b/d31
schedule function mg:dropper/bstep 5t
