fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:end_stone_bricks hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:purpur_block replace minecraft:end_stone_bricks
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:purpur_block replace minecraft:end_stone_bricks
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:purpur_block replace minecraft:end_stone_bricks
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:purpur_block replace minecraft:end_stone_bricks
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:purpur_block replace minecraft:end_stone_bricks
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:purpur_block replace minecraft:end_stone_bricks
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:purpur_block replace minecraft:end_stone_bricks
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:obsidian
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:obsidian
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:obsidian
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:obsidian
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:pearlescent_froglight
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:pearlescent_froglight
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:pearlescent_froglight
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:pearlescent_froglight
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:pearlescent_froglight
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:pearlescent_froglight
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:pearlescent_froglight
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:pearlescent_froglight
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:pearlescent_froglight
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:pearlescent_froglight
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:pearlescent_froglight
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:pearlescent_froglight
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:obsidian
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:obsidian outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:end_stone
fill ~1 ~-3 ~-1 ~5 ~-3 ~3 minecraft:purpur_pillar
fill ~2 ~-6 ~0 ~4 ~-6 ~2 minecraft:pearlescent_froglight
fill ~2 ~-5 ~0 ~4 ~-3 ~2 minecraft:water
fill ~-6 ~58 ~-6 ~6 ~58 ~2 minecraft:purpur_block
fill ~-6 ~58 ~3 ~-4 ~58 ~6 minecraft:purpur_block
fill ~1 ~58 ~3 ~6 ~58 ~6 minecraft:purpur_block
fill ~-6 ~52 ~-6 ~6 ~52 ~1 minecraft:magenta_stained_glass
fill ~-6 ~52 ~6 ~6 ~52 ~6 minecraft:magenta_stained_glass
fill ~-6 ~52 ~2 ~-3 ~52 ~5 minecraft:magenta_stained_glass
fill ~2 ~52 ~2 ~6 ~52 ~5 minecraft:magenta_stained_glass
fill ~-6 ~45 ~-6 ~6 ~45 ~0 minecraft:obsidian
fill ~-6 ~45 ~4 ~6 ~45 ~6 minecraft:obsidian
fill ~-6 ~45 ~1 ~-1 ~45 ~3 minecraft:obsidian
fill ~3 ~45 ~1 ~6 ~45 ~3 minecraft:obsidian
fill ~-6 ~38 ~-6 ~6 ~38 ~-3 minecraft:end_stone_bricks
fill ~-6 ~38 ~5 ~6 ~38 ~6 minecraft:end_stone_bricks
fill ~-6 ~38 ~-2 ~-3 ~38 ~4 minecraft:end_stone_bricks
fill ~5 ~38 ~-2 ~6 ~38 ~4 minecraft:end_stone_bricks
fill ~0 ~38 ~0 ~2 ~38 ~2 minecraft:end_stone_bricks
fill ~-6 ~30 ~-6 ~6 ~30 ~1 minecraft:purple_stained_glass
fill ~-6 ~30 ~5 ~6 ~30 ~6 minecraft:purple_stained_glass
fill ~-6 ~30 ~2 ~1 ~30 ~4 minecraft:purple_stained_glass
fill ~5 ~30 ~2 ~6 ~30 ~4 minecraft:purple_stained_glass
fill ~-6 ~22 ~-6 ~6 ~22 ~0 minecraft:crying_obsidian
fill ~-6 ~22 ~4 ~6 ~22 ~6 minecraft:crying_obsidian
fill ~-6 ~22 ~1 ~2 ~22 ~3 minecraft:crying_obsidian
fill ~6 ~22 ~1 ~6 ~22 ~3 minecraft:crying_obsidian
fill ~-6 ~14 ~-6 ~6 ~14 ~-1 minecraft:magenta_stained_glass
fill ~-6 ~14 ~3 ~6 ~14 ~6 minecraft:magenta_stained_glass
fill ~-6 ~14 ~0 ~1 ~14 ~2 minecraft:magenta_stained_glass
fill ~5 ~14 ~0 ~6 ~14 ~2 minecraft:magenta_stained_glass
fill ~4 ~6 ~1 ~4 ~6 ~1 minecraft:amethyst_block
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:purpur_block
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
