fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:mossy_stone_bricks hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:moss_block replace minecraft:mossy_stone_bricks
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:moss_block replace minecraft:mossy_stone_bricks
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:moss_block replace minecraft:mossy_stone_bricks
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:moss_block replace minecraft:mossy_stone_bricks
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:moss_block replace minecraft:mossy_stone_bricks
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:moss_block replace minecraft:mossy_stone_bricks
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:moss_block replace minecraft:mossy_stone_bricks
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:mossy_cobblestone
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:mossy_cobblestone
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:mossy_cobblestone
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:mossy_cobblestone
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:verdant_froglight
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:verdant_froglight
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:verdant_froglight
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:verdant_froglight
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:verdant_froglight
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:verdant_froglight
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:verdant_froglight
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:verdant_froglight
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:verdant_froglight
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:verdant_froglight
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:verdant_froglight
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:verdant_froglight
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:mossy_cobblestone
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:mossy_cobblestone outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:moss_block
fill ~-5 ~-3 ~-1 ~1 ~-3 ~5 minecraft:lime_terracotta
fill ~-4 ~-6 ~0 ~0 ~-6 ~4 minecraft:verdant_froglight
fill ~-4 ~-5 ~0 ~0 ~-3 ~4 minecraft:water
fill ~-6 ~58 ~-6 ~6 ~58 ~-5 minecraft:moss_block
fill ~-6 ~58 ~0 ~6 ~58 ~6 minecraft:moss_block
fill ~-6 ~58 ~-4 ~-4 ~58 ~-1 minecraft:moss_block
fill ~1 ~58 ~-4 ~6 ~58 ~-1 minecraft:moss_block
fill ~-6 ~52 ~-6 ~6 ~52 ~-3 minecraft:azalea_leaves[persistent=true]
fill ~-6 ~52 ~2 ~6 ~52 ~6 minecraft:azalea_leaves[persistent=true]
fill ~-6 ~52 ~-2 ~-3 ~52 ~1 minecraft:azalea_leaves[persistent=true]
fill ~2 ~52 ~-2 ~6 ~52 ~1 minecraft:azalea_leaves[persistent=true]
fill ~-6 ~46 ~-6 ~6 ~46 ~-1 minecraft:flowering_azalea_leaves[persistent=true]
fill ~-6 ~46 ~4 ~6 ~46 ~6 minecraft:flowering_azalea_leaves[persistent=true]
fill ~-6 ~46 ~0 ~-2 ~46 ~3 minecraft:flowering_azalea_leaves[persistent=true]
fill ~3 ~46 ~0 ~6 ~46 ~3 minecraft:flowering_azalea_leaves[persistent=true]
fill ~1 ~38 ~-3 ~1 ~38 ~-3 minecraft:ochre_froglight
fill ~-2 ~38 ~-1 ~-2 ~38 ~-1 minecraft:ochre_froglight
fill ~2 ~38 ~-1 ~2 ~38 ~-1 minecraft:ochre_froglight
fill ~0 ~38 ~1 ~0 ~38 ~2 minecraft:ochre_froglight
fill ~3 ~38 ~3 ~3 ~38 ~3 minecraft:ochre_froglight
fill ~-1 ~38 ~4 ~-1 ~38 ~4 minecraft:ochre_froglight
fill ~-6 ~30 ~-6 ~6 ~31 ~-1 minecraft:moss_block
fill ~-6 ~30 ~4 ~6 ~31 ~6 minecraft:moss_block
fill ~-6 ~30 ~0 ~-1 ~31 ~3 minecraft:moss_block
fill ~5 ~30 ~0 ~6 ~31 ~3 minecraft:moss_block
fill ~-6 ~22 ~-6 ~6 ~22 ~-5 minecraft:azalea_leaves[persistent=true]
fill ~-6 ~22 ~0 ~6 ~22 ~0 minecraft:azalea_leaves[persistent=true]
fill ~-6 ~22 ~5 ~6 ~22 ~6 minecraft:azalea_leaves[persistent=true]
fill ~-6 ~22 ~-4 ~1 ~22 ~-1 minecraft:azalea_leaves[persistent=true]
fill ~6 ~22 ~-4 ~6 ~22 ~-1 minecraft:azalea_leaves[persistent=true]
fill ~-6 ~22 ~1 ~-4 ~22 ~4 minecraft:azalea_leaves[persistent=true]
fill ~1 ~22 ~1 ~6 ~22 ~4 minecraft:azalea_leaves[persistent=true]
fill ~-6 ~14 ~-6 ~6 ~14 ~0 minecraft:clay
fill ~-6 ~14 ~5 ~6 ~14 ~6 minecraft:clay
fill ~-6 ~14 ~1 ~-5 ~14 ~4 minecraft:clay
fill ~0 ~14 ~1 ~6 ~14 ~4 minecraft:clay
fill ~-6 ~6 ~-6 ~6 ~6 ~-1 minecraft:green_stained_glass
fill ~-6 ~6 ~5 ~6 ~6 ~6 minecraft:green_stained_glass
fill ~-6 ~6 ~0 ~-5 ~6 ~4 minecraft:green_stained_glass
fill ~1 ~6 ~0 ~6 ~6 ~4 minecraft:green_stained_glass
fill ~-2 ~6 ~2 ~-2 ~6 ~2 minecraft:green_stained_glass
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:moss_block
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
