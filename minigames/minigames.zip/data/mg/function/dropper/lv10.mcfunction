fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:waxed_cut_copper hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:redstone_block replace minecraft:waxed_cut_copper
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:redstone_block replace minecraft:waxed_cut_copper
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:redstone_block replace minecraft:waxed_cut_copper
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:redstone_block replace minecraft:waxed_cut_copper
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:redstone_block replace minecraft:waxed_cut_copper
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:redstone_block replace minecraft:waxed_cut_copper
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:redstone_block replace minecraft:waxed_cut_copper
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:iron_block
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:iron_block
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:iron_block
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:iron_block
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:glowstone
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:glowstone
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:glowstone
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:glowstone
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:glowstone
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:glowstone
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:glowstone
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:glowstone
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:glowstone
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:glowstone
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:glowstone
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:glowstone
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:iron_block
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:iron_block outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:polished_andesite
fill ~1 ~-3 ~-3 ~5 ~-3 ~1 minecraft:redstone_block
fill ~2 ~-6 ~-2 ~4 ~-6 ~0 minecraft:glowstone
fill ~2 ~-5 ~-2 ~4 ~-3 ~0 minecraft:water
fill ~-6 ~58 ~-6 ~6 ~58 ~-6 minecraft:waxed_cut_copper
fill ~-6 ~58 ~-2 ~6 ~58 ~6 minecraft:waxed_cut_copper
fill ~-6 ~58 ~-5 ~-4 ~58 ~-3 minecraft:waxed_cut_copper
fill ~0 ~58 ~-5 ~6 ~58 ~-3 minecraft:waxed_cut_copper
fill ~-4 ~51 ~-6 ~-4 ~51 ~-5 minecraft:redstone_block
fill ~-4 ~51 ~-3 ~-4 ~51 ~-2 minecraft:redstone_block
fill ~-4 ~51 ~0 ~-4 ~51 ~1 minecraft:redstone_block
fill ~-4 ~51 ~3 ~-4 ~51 ~4 minecraft:redstone_block
fill ~-4 ~51 ~6 ~-4 ~51 ~6 minecraft:redstone_block
fill ~-1 ~51 ~-6 ~-1 ~51 ~-5 minecraft:redstone_block
fill ~-1 ~51 ~-3 ~-1 ~51 ~-2 minecraft:redstone_block
fill ~-1 ~51 ~0 ~-1 ~51 ~1 minecraft:redstone_block
fill ~-1 ~51 ~3 ~-1 ~51 ~4 minecraft:redstone_block
fill ~-1 ~51 ~6 ~-1 ~51 ~6 minecraft:redstone_block
fill ~2 ~51 ~-6 ~2 ~51 ~-5 minecraft:redstone_block
fill ~2 ~51 ~-3 ~2 ~51 ~-2 minecraft:redstone_block
fill ~2 ~51 ~0 ~2 ~51 ~1 minecraft:redstone_block
fill ~2 ~51 ~3 ~2 ~51 ~4 minecraft:redstone_block
fill ~2 ~51 ~6 ~2 ~51 ~6 minecraft:redstone_block
fill ~5 ~51 ~-6 ~5 ~51 ~-5 minecraft:redstone_block
fill ~5 ~51 ~-3 ~5 ~51 ~-2 minecraft:redstone_block
fill ~5 ~51 ~0 ~5 ~51 ~1 minecraft:redstone_block
fill ~5 ~51 ~3 ~5 ~51 ~4 minecraft:redstone_block
fill ~5 ~51 ~6 ~5 ~51 ~6 minecraft:redstone_block
fill ~-6 ~51 ~-4 ~6 ~51 ~-4 minecraft:redstone_block
fill ~-6 ~51 ~-1 ~6 ~51 ~-1 minecraft:redstone_block
fill ~-6 ~51 ~2 ~6 ~51 ~2 minecraft:redstone_block
fill ~-6 ~51 ~5 ~6 ~51 ~5 minecraft:redstone_block
fill ~-6 ~45 ~-6 ~6 ~45 ~-3 minecraft:waxed_copper_grate
fill ~-6 ~45 ~1 ~6 ~45 ~6 minecraft:waxed_copper_grate
fill ~-6 ~45 ~-2 ~-3 ~45 ~0 minecraft:waxed_copper_grate
fill ~1 ~45 ~-2 ~6 ~45 ~0 minecraft:waxed_copper_grate
fill ~-6 ~39 ~-6 ~6 ~39 ~-2 minecraft:waxed_oxidized_copper
fill ~-6 ~39 ~2 ~6 ~39 ~6 minecraft:waxed_oxidized_copper
fill ~-6 ~39 ~-1 ~-3 ~39 ~1 minecraft:waxed_oxidized_copper
fill ~1 ~39 ~-1 ~6 ~39 ~1 minecraft:waxed_oxidized_copper
fill ~-6 ~33 ~-6 ~6 ~33 ~-2 minecraft:waxed_exposed_cut_copper
fill ~-6 ~33 ~3 ~6 ~33 ~6 minecraft:waxed_exposed_cut_copper
fill ~-6 ~33 ~-1 ~-4 ~33 ~2 minecraft:waxed_exposed_cut_copper
fill ~-1 ~33 ~-1 ~-1 ~33 ~2 minecraft:waxed_exposed_cut_copper
fill ~2 ~33 ~-1 ~6 ~33 ~2 minecraft:waxed_exposed_cut_copper
fill ~-6 ~26 ~-6 ~6 ~26 ~-3 minecraft:waxed_weathered_copper
fill ~-6 ~26 ~1 ~6 ~26 ~6 minecraft:waxed_weathered_copper
fill ~-6 ~26 ~-2 ~-1 ~26 ~0 minecraft:waxed_weathered_copper
fill ~2 ~26 ~-2 ~6 ~26 ~0 minecraft:waxed_weathered_copper
fill ~-6 ~19 ~-6 ~6 ~19 ~-4 minecraft:iron_block
fill ~-6 ~19 ~0 ~6 ~19 ~0 minecraft:iron_block
fill ~-6 ~19 ~3 ~6 ~19 ~6 minecraft:iron_block
fill ~-6 ~19 ~-3 ~-2 ~19 ~-1 minecraft:iron_block
fill ~-6 ~19 ~1 ~-2 ~19 ~2 minecraft:iron_block
fill ~4 ~19 ~-3 ~6 ~19 ~-1 minecraft:iron_block
fill ~4 ~19 ~1 ~6 ~19 ~2 minecraft:iron_block
fill ~-6 ~12 ~-6 ~6 ~12 ~-4 minecraft:waxed_copper_block
fill ~-6 ~12 ~0 ~6 ~12 ~6 minecraft:waxed_copper_block
fill ~-6 ~12 ~-3 ~0 ~12 ~-1 minecraft:waxed_copper_block
fill ~4 ~12 ~-3 ~6 ~12 ~-1 minecraft:waxed_copper_block
fill ~-6 ~6 ~-6 ~6 ~6 ~-4 minecraft:waxed_copper_grate
fill ~-6 ~6 ~1 ~6 ~6 ~6 minecraft:waxed_copper_grate
fill ~-6 ~6 ~-3 ~0 ~6 ~0 minecraft:waxed_copper_grate
fill ~5 ~6 ~-3 ~6 ~6 ~0 minecraft:waxed_copper_grate
fill ~3 ~6 ~-1 ~3 ~6 ~-1 minecraft:waxed_copper_grate
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:smooth_stone
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
