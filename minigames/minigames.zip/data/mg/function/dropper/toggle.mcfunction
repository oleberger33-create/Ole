execute if entity @s[tag=mg_q_dropper] run return run function mg:dropper/leave
function mg:q/leave_all
tag @s add mg_q_dropper
execute if score #dropper mg matches 1.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dropper läuft gerade – du bist in der Warteschlange für die nächste Runde.", "color": "gray"}]
tellraw @a[tag=mg_hub] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " wartet auf ", "color": "gray"}, {"text": "Dropper", "color": "gold", "bold": true}, {"text": " – ", "color": "gray"}, {"text": "[Mitspielen]", "color": "green", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 67"}}]
