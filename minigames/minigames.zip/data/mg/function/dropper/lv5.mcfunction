fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:cherry_planks hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:stripped_cherry_wood replace minecraft:cherry_planks
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:stripped_cherry_wood replace minecraft:cherry_planks
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:stripped_cherry_wood replace minecraft:cherry_planks
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:stripped_cherry_wood replace minecraft:cherry_planks
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:stripped_cherry_wood replace minecraft:cherry_planks
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:stripped_cherry_wood replace minecraft:cherry_planks
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:stripped_cherry_wood replace minecraft:cherry_planks
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:cherry_log
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:cherry_log
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:cherry_log
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:cherry_log
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:pearlescent_froglight
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:pearlescent_froglight
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:pearlescent_froglight
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:pearlescent_froglight
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:pearlescent_froglight
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:pearlescent_froglight
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:pearlescent_froglight
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:pearlescent_froglight
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:pearlescent_froglight
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:pearlescent_froglight
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:pearlescent_froglight
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:pearlescent_froglight
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:cherry_log
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:cherry_log outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:moss_block
fill ~-4 ~-3 ~-4 ~2 ~-3 ~2 minecraft:pink_concrete
fill ~-3 ~-6 ~-3 ~1 ~-6 ~1 minecraft:pearlescent_froglight
fill ~-3 ~-5 ~-3 ~1 ~-3 ~1 minecraft:water
fill ~-6 ~55 ~-6 ~6 ~56 ~-1 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~55 ~6 ~6 ~56 ~6 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~55 ~0 ~-4 ~56 ~5 minecraft:cherry_leaves[persistent=true]
fill ~3 ~55 ~0 ~6 ~56 ~5 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~47 ~-6 ~6 ~47 ~-3 minecraft:pink_stained_glass
fill ~-6 ~47 ~4 ~6 ~47 ~6 minecraft:pink_stained_glass
fill ~-6 ~47 ~-2 ~-2 ~47 ~3 minecraft:pink_stained_glass
fill ~5 ~47 ~-2 ~6 ~47 ~3 minecraft:pink_stained_glass
fill ~-6 ~39 ~-6 ~-3 ~39 ~6 minecraft:cherry_log[axis=z]
fill ~0 ~39 ~-6 ~0 ~39 ~6 minecraft:cherry_log[axis=z]
fill ~4 ~39 ~-6 ~6 ~39 ~6 minecraft:cherry_log[axis=z]
fill ~-6 ~30 ~-6 ~6 ~31 ~-4 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~30 ~3 ~6 ~31 ~6 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~30 ~-3 ~-1 ~31 ~2 minecraft:cherry_leaves[persistent=true]
fill ~5 ~30 ~-3 ~6 ~31 ~2 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~21 ~-6 ~6 ~21 ~-2 minecraft:pink_wool
fill ~-6 ~21 ~5 ~6 ~21 ~6 minecraft:pink_wool
fill ~-6 ~21 ~-1 ~-4 ~21 ~4 minecraft:pink_wool
fill ~3 ~21 ~-1 ~6 ~21 ~4 minecraft:pink_wool
fill ~-1 ~21 ~1 ~0 ~21 ~2 minecraft:pink_wool
fill ~-6 ~11 ~-6 ~6 ~12 ~-5 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~11 ~2 ~6 ~12 ~6 minecraft:cherry_leaves[persistent=true]
fill ~-6 ~11 ~-4 ~-5 ~12 ~1 minecraft:cherry_leaves[persistent=true]
fill ~2 ~11 ~-4 ~6 ~12 ~1 minecraft:cherry_leaves[persistent=true]
fill ~-1 ~3 ~-1 ~-1 ~3 ~-1 minecraft:pink_wool
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:pink_terracotta
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
