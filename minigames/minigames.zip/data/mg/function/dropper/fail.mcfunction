scoreboard players add @s mg_dropper_f 1
particle minecraft:poof ~ ~0.5 ~ 0.4 0.4 0.4 0.05 20
playsound minecraft:entity.player.big_fall master @s ~ ~ ~ 1 0.7
playsound minecraft:block.note_block.bass master @s ~ ~ ~ 1 0.6
title @s times 0 25 8
title @s title {"text": "✖", "color": "red", "bold": true}
title @s subtitle [{"text": "Berührt! ", "color": "red", "bold": true}, {"text": "Nochmal von oben", "color": "gray"}]
function mg:dropper/tp
execute at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 0.6 1.3
