fill ~-7 ~-7 ~-7 ~7 ~-7 ~7 minecraft:air
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:air
fill ~-7 ~-6 ~-7 ~7 ~69 ~7 minecraft:packed_ice hollow
fill ~-7 ~0 ~-7 ~7 ~0 ~7 minecraft:blue_ice replace minecraft:packed_ice
fill ~-7 ~10 ~-7 ~7 ~10 ~7 minecraft:blue_ice replace minecraft:packed_ice
fill ~-7 ~20 ~-7 ~7 ~20 ~7 minecraft:blue_ice replace minecraft:packed_ice
fill ~-7 ~30 ~-7 ~7 ~30 ~7 minecraft:blue_ice replace minecraft:packed_ice
fill ~-7 ~40 ~-7 ~7 ~40 ~7 minecraft:blue_ice replace minecraft:packed_ice
fill ~-7 ~50 ~-7 ~7 ~50 ~7 minecraft:blue_ice replace minecraft:packed_ice
fill ~-7 ~60 ~-7 ~7 ~60 ~7 minecraft:blue_ice replace minecraft:packed_ice
fill ~-7 ~-6 ~-7 ~-7 ~69 ~-7 minecraft:snow_block
fill ~-7 ~-6 ~7 ~-7 ~69 ~7 minecraft:snow_block
fill ~7 ~-6 ~-7 ~7 ~69 ~-7 minecraft:snow_block
fill ~7 ~-6 ~7 ~7 ~69 ~7 minecraft:snow_block
fill ~0 ~-5 ~-7 ~0 ~68 ~-7 minecraft:sea_lantern
fill ~0 ~-5 ~7 ~0 ~68 ~7 minecraft:sea_lantern
fill ~-7 ~-5 ~0 ~-7 ~68 ~0 minecraft:sea_lantern
fill ~7 ~-5 ~0 ~7 ~68 ~0 minecraft:sea_lantern
fill ~-4 ~-3 ~-7 ~-4 ~60 ~-7 minecraft:sea_lantern
fill ~4 ~-3 ~-7 ~4 ~60 ~-7 minecraft:sea_lantern
fill ~-4 ~-3 ~7 ~-4 ~60 ~7 minecraft:sea_lantern
fill ~4 ~-3 ~7 ~4 ~60 ~7 minecraft:sea_lantern
fill ~-7 ~-3 ~-4 ~-7 ~60 ~-4 minecraft:sea_lantern
fill ~-7 ~-3 ~4 ~-7 ~60 ~4 minecraft:sea_lantern
fill ~7 ~-3 ~-4 ~7 ~60 ~-4 minecraft:sea_lantern
fill ~7 ~-3 ~4 ~7 ~60 ~4 minecraft:sea_lantern
fill ~-6 ~-7 ~-6 ~6 ~-7 ~6 minecraft:snow_block
fill ~-6 ~69 ~-6 ~6 ~69 ~6 minecraft:glass
fill ~-7 ~70 ~-7 ~7 ~70 ~7 minecraft:snow_block outline
fill ~-6 ~70 ~-6 ~6 ~70 ~6 minecraft:air
setblock ~-7 ~71 ~-7 minecraft:end_rod
setblock ~-7 ~71 ~7 minecraft:end_rod
setblock ~7 ~71 ~-7 minecraft:end_rod
setblock ~7 ~71 ~7 minecraft:end_rod
fill ~-6 ~-5 ~-6 ~6 ~-3 ~6 minecraft:snow_block
fill ~-2 ~-3 ~0 ~2 ~-3 ~4 minecraft:blue_ice
fill ~-1 ~-6 ~1 ~1 ~-6 ~3 minecraft:sea_lantern
fill ~-1 ~-5 ~1 ~1 ~-3 ~3 minecraft:water
fill ~-6 ~58 ~-6 ~6 ~58 ~0 minecraft:packed_ice
fill ~-6 ~58 ~4 ~6 ~58 ~6 minecraft:packed_ice
fill ~-6 ~58 ~1 ~-3 ~58 ~3 minecraft:packed_ice
fill ~1 ~58 ~1 ~6 ~58 ~3 minecraft:packed_ice
fill ~-6 ~53 ~-6 ~6 ~53 ~-1 minecraft:light_blue_stained_glass
fill ~-6 ~53 ~3 ~6 ~53 ~6 minecraft:light_blue_stained_glass
fill ~-6 ~53 ~0 ~-2 ~53 ~2 minecraft:light_blue_stained_glass
fill ~2 ~53 ~0 ~6 ~53 ~2 minecraft:light_blue_stained_glass
fill ~-6 ~48 ~-6 ~6 ~48 ~-2 minecraft:blue_ice
fill ~-6 ~48 ~2 ~6 ~48 ~6 minecraft:blue_ice
fill ~-6 ~48 ~-1 ~-1 ~48 ~1 minecraft:blue_ice
fill ~3 ~48 ~-1 ~6 ~48 ~1 minecraft:blue_ice
fill ~-6 ~41 ~-6 ~6 ~41 ~-2 minecraft:packed_ice
fill ~-6 ~41 ~0 ~6 ~41 ~0 minecraft:packed_ice
fill ~-6 ~41 ~2 ~6 ~41 ~2 minecraft:packed_ice
fill ~-6 ~41 ~4 ~6 ~41 ~6 minecraft:packed_ice
fill ~-6 ~41 ~-1 ~-2 ~41 ~-1 minecraft:packed_ice
fill ~-6 ~41 ~1 ~-2 ~41 ~1 minecraft:packed_ice
fill ~-6 ~41 ~3 ~-2 ~41 ~3 minecraft:packed_ice
fill ~5 ~41 ~-1 ~6 ~41 ~-1 minecraft:packed_ice
fill ~5 ~41 ~1 ~6 ~41 ~1 minecraft:packed_ice
fill ~5 ~41 ~3 ~6 ~41 ~3 minecraft:packed_ice
fill ~-6 ~35 ~-6 ~6 ~35 ~-2 minecraft:white_stained_glass
fill ~-6 ~35 ~2 ~6 ~35 ~6 minecraft:white_stained_glass
fill ~-6 ~35 ~-1 ~-1 ~35 ~1 minecraft:white_stained_glass
fill ~3 ~35 ~-1 ~6 ~35 ~1 minecraft:white_stained_glass
fill ~1 ~35 ~0 ~1 ~35 ~0 minecraft:white_stained_glass
fill ~-6 ~28 ~-6 ~6 ~28 ~-1 minecraft:blue_ice
fill ~-6 ~28 ~3 ~6 ~28 ~6 minecraft:blue_ice
fill ~-6 ~28 ~0 ~-3 ~28 ~2 minecraft:blue_ice
fill ~1 ~28 ~0 ~1 ~28 ~2 minecraft:blue_ice
fill ~5 ~28 ~0 ~6 ~28 ~2 minecraft:blue_ice
fill ~-6 ~22 ~-6 ~6 ~22 ~0 minecraft:packed_ice
fill ~-6 ~22 ~4 ~6 ~22 ~6 minecraft:packed_ice
fill ~-6 ~22 ~1 ~-3 ~22 ~3 minecraft:packed_ice
fill ~1 ~22 ~1 ~6 ~22 ~3 minecraft:packed_ice
fill ~-6 ~17 ~-6 ~6 ~17 ~0 minecraft:light_blue_stained_glass
fill ~-6 ~17 ~4 ~6 ~17 ~6 minecraft:light_blue_stained_glass
fill ~-6 ~17 ~1 ~-2 ~17 ~3 minecraft:light_blue_stained_glass
fill ~1 ~17 ~1 ~6 ~17 ~3 minecraft:light_blue_stained_glass
fill ~-6 ~10 ~-6 ~6 ~10 ~0 minecraft:packed_ice
fill ~-6 ~10 ~3 ~6 ~10 ~6 minecraft:packed_ice
fill ~-6 ~10 ~1 ~-2 ~10 ~2 minecraft:packed_ice
fill ~2 ~10 ~1 ~6 ~10 ~2 minecraft:packed_ice
fill ~0 ~3 ~2 ~0 ~3 ~2 minecraft:blue_ice
fill ~-6 ~64 ~-6 ~-4 ~64 ~6 minecraft:snow_block
setblock ~-4 ~64 ~-6 minecraft:yellow_concrete
setblock ~-4 ~64 ~-5 minecraft:black_concrete
setblock ~-4 ~64 ~-4 minecraft:yellow_concrete
setblock ~-4 ~64 ~-3 minecraft:black_concrete
setblock ~-4 ~64 ~-2 minecraft:yellow_concrete
setblock ~-4 ~64 ~-1 minecraft:black_concrete
setblock ~-4 ~64 ~0 minecraft:yellow_concrete
setblock ~-4 ~64 ~1 minecraft:black_concrete
setblock ~-4 ~64 ~2 minecraft:yellow_concrete
setblock ~-4 ~64 ~3 minecraft:black_concrete
setblock ~-4 ~64 ~4 minecraft:yellow_concrete
setblock ~-4 ~64 ~5 minecraft:black_concrete
setblock ~-4 ~64 ~6 minecraft:yellow_concrete
