tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zeit abgelaufen! Wer am weitesten gekommen ist, gewinnt (bei Gleichstand: weniger Fehlversuche).", "color": "red"}]
scoreboard players set #dropper_best mg 0
scoreboard players set #dropper_minf mg 999999
execute as @a[tag=mg_al_dropper] run scoreboard players operation #dropper_best mg > @s mg_dropper_l
execute as @a[tag=mg_al_dropper] if score @s mg_dropper_l = #dropper_best mg run scoreboard players operation #dropper_minf mg < @s mg_dropper_f
execute if score #dropper_best mg matches 2.. as @a[tag=mg_al_dropper] if score @s mg_dropper_l = #dropper_best mg if score @s mg_dropper_f = #dropper_minf mg run tag @s add mg_dropper_win
title @a[tag=mg_dropper] times 5 60 15
title @a[tag=mg_dropper] title {"text": "Zeit um!", "color": "red", "bold": true}
title @a[tag=mg_dropper] subtitle {"text": "", "color": "white"}
function mg:dropper/end_go
