scoreboard players operation #dropper_c mg = @s mg_dropper_l
scoreboard players remove #dropper_c mg 1
title @s subtitle [{"score": {"name": "#dropper_c", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": "/4 Level geschafft", "color": "white"}]
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zeit um! ", "color": "red", "bold": true}, {"text": "Du hast ", "color": "gray"}, {"score": {"name": "#dropper_c", "objective": "mg"}, "color": "yellow", "bold": true}, {"text": "/4 Level geschafft", "color": "gray"}, {"text": "  ·  Fehlversuche: ", "color": "gray"}, {"score": {"name": "@s", "objective": "mg_dropper_f"}, "color": "white"}]
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Für eine Bestzeit musst du alle 4 Level in 5 Minuten schaffen.", "color": "gray"}]
playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.8
