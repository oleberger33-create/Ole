bossbar set mg:dropper visible false
title @a[tag=mg_dropper] times 5 60 15
execute as @a[tag=mg_dropper,tag=mg_dropper_win] at @s run function mg:dropper/solo_done
execute as @a[tag=mg_dropper,tag=!mg_dropper_win] at @s run function mg:dropper/solo_fail
tag @a[tag=mg_dropper] remove mg_al_dropper
title @a[tag=mg_dropper] title {"text": "Solo-Runde vorbei", "color": "gold", "bold": true}
scoreboard players set #dropper mg 3
schedule function mg:dropper/finish 100t
