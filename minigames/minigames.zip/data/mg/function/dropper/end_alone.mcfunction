execute as @a[tag=mg_al_dropper] if score @s mg_dropper_l matches 2.. run tag @s add mg_dropper_win
execute unless entity @a[tag=mg_dropper,tag=mg_dropper_win] run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Alle anderen haben das Spiel verlassen – ohne geschafftes Level gibt es keine Wertung.", "color": "gray"}]
execute if entity @a[tag=mg_dropper,tag=mg_dropper_win] run tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Alle anderen haben das Spiel verlassen – du gewinnst!", "color": "yellow"}]
title @a[tag=mg_dropper] times 5 60 15
title @a[tag=mg_dropper] title {"text": "SIEG!", "color": "gold", "bold": true}
title @a[tag=mg_dropper] subtitle {"text": "Alle anderen sind weg", "color": "white"}
function mg:dropper/end_go
