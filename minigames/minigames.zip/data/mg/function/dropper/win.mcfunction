tag @s add mg_dropper_win
scoreboard players operation #dropper_c mg = #dropper_t mg
scoreboard players remove #dropper_c mg 120
scoreboard players operation #dropper_c mg /= #20 mg
scoreboard players operation #dropper_c mg = #dropper_c mg
scoreboard players operation #dropper_mm mg = #dropper_c mg
scoreboard players operation #dropper_mm mg /= #60 mg
scoreboard players operation #dropper_s1 mg = #dropper_c mg
scoreboard players operation #dropper_s1 mg %= #60 mg
scoreboard players operation #dropper_s10 mg = #dropper_s1 mg
scoreboard players operation #dropper_s10 mg /= #10 mg
scoreboard players operation #dropper_s1 mg %= #10 mg
tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " hat alle 4 Level geschafft! ", "color": "yellow"}, {"text": "⏱ ", "color": "dark_gray"}, {"score": {"name": "#dropper_mm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#dropper_s10", "objective": "mg"}, "color": "white"}, {"score": {"name": "#dropper_s1", "objective": "mg"}, "color": "white"}]
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
title @a[tag=mg_dropper] times 5 60 15
title @s title {"text": "SIEG!", "color": "gold", "bold": true}
title @s subtitle [{"text": "Alle 4 Level in ", "color": "white"}, {"score": {"name": "#dropper_mm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#dropper_s10", "objective": "mg"}, "color": "white"}, {"score": {"name": "#dropper_s1", "objective": "mg"}, "color": "white"}]
title @a[tag=mg_dropper,tag=!mg_dropper_win] title {"text": "Vorbei!", "color": "red", "bold": true}
title @a[tag=mg_dropper,tag=!mg_dropper_win] subtitle [{"selector": "@s", "color": "gold"}, {"text": " war schneller", "color": "white"}]
function mg:dropper/end_go
