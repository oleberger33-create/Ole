execute in minecraft:overworld run fill 83948 93 -112 83962 93 -98 minecraft:air
execute in minecraft:overworld run fill 83948 170 -112 83962 170 -98 minecraft:air
execute in minecraft:overworld run fill 83948 94 -112 83962 169 -98 minecraft:white_concrete hollow
execute in minecraft:overworld run fill 83948 100 -112 83962 100 -98 minecraft:red_concrete replace minecraft:white_concrete
execute in minecraft:overworld run fill 83948 110 -112 83962 110 -98 minecraft:orange_concrete replace minecraft:white_concrete
execute in minecraft:overworld run fill 83948 120 -112 83962 120 -98 minecraft:yellow_concrete replace minecraft:white_concrete
execute in minecraft:overworld run fill 83948 130 -112 83962 130 -98 minecraft:lime_concrete replace minecraft:white_concrete
execute in minecraft:overworld run fill 83948 140 -112 83962 140 -98 minecraft:light_blue_concrete replace minecraft:white_concrete
execute in minecraft:overworld run fill 83948 150 -112 83962 150 -98 minecraft:purple_concrete replace minecraft:white_concrete
execute in minecraft:overworld run fill 83948 160 -112 83962 160 -98 minecraft:red_concrete replace minecraft:white_concrete
execute in minecraft:overworld run fill 83948 94 -112 83948 169 -112 minecraft:quartz_pillar
execute in minecraft:overworld run fill 83948 94 -98 83948 169 -98 minecraft:quartz_pillar
execute in minecraft:overworld run fill 83962 94 -112 83962 169 -112 minecraft:quartz_pillar
execute in minecraft:overworld run fill 83962 94 -98 83962 169 -98 minecraft:quartz_pillar
execute in minecraft:overworld run fill 83955 95 -112 83955 168 -112 minecraft:sea_lantern
execute in minecraft:overworld run fill 83955 95 -98 83955 168 -98 minecraft:sea_lantern
execute in minecraft:overworld run fill 83948 95 -105 83948 168 -105 minecraft:sea_lantern
execute in minecraft:overworld run fill 83962 95 -105 83962 168 -105 minecraft:sea_lantern
execute in minecraft:overworld run fill 83951 97 -112 83951 160 -112 minecraft:sea_lantern
execute in minecraft:overworld run fill 83959 97 -112 83959 160 -112 minecraft:sea_lantern
execute in minecraft:overworld run fill 83951 97 -98 83951 160 -98 minecraft:sea_lantern
execute in minecraft:overworld run fill 83959 97 -98 83959 160 -98 minecraft:sea_lantern
execute in minecraft:overworld run fill 83948 97 -109 83948 160 -109 minecraft:sea_lantern
execute in minecraft:overworld run fill 83948 97 -101 83948 160 -101 minecraft:sea_lantern
execute in minecraft:overworld run fill 83962 97 -109 83962 160 -109 minecraft:sea_lantern
execute in minecraft:overworld run fill 83962 97 -101 83962 160 -101 minecraft:sea_lantern
execute in minecraft:overworld run fill 83949 93 -111 83961 93 -99 minecraft:quartz_pillar
execute in minecraft:overworld run fill 83949 169 -111 83961 169 -99 minecraft:glass
execute in minecraft:overworld run fill 83948 170 -112 83962 170 -98 minecraft:quartz_pillar outline
execute in minecraft:overworld run fill 83949 170 -111 83961 170 -99 minecraft:air
execute in minecraft:overworld run setblock 83948 171 -112 minecraft:end_rod
execute in minecraft:overworld run setblock 83948 171 -98 minecraft:end_rod
execute in minecraft:overworld run setblock 83962 171 -112 minecraft:end_rod
execute in minecraft:overworld run setblock 83962 171 -98 minecraft:end_rod
execute in minecraft:overworld run fill 83949 95 -111 83961 97 -99 minecraft:white_concrete
execute in minecraft:overworld run fill 83951 97 -109 83959 97 -101 minecraft:yellow_concrete
execute in minecraft:overworld run fill 83952 94 -108 83958 94 -102 minecraft:sea_lantern
execute in minecraft:overworld run fill 83952 95 -108 83958 97 -102 minecraft:water
execute in minecraft:overworld run fill 83949 156 -111 83961 156 -108 minecraft:red_concrete
execute in minecraft:overworld run fill 83949 156 -102 83961 156 -99 minecraft:red_concrete
execute in minecraft:overworld run fill 83949 156 -107 83951 156 -103 minecraft:red_concrete
execute in minecraft:overworld run fill 83957 156 -107 83961 156 -103 minecraft:red_concrete
execute in minecraft:overworld run fill 83949 148 -111 83961 148 -107 minecraft:orange_concrete
execute in minecraft:overworld run fill 83949 148 -101 83961 148 -99 minecraft:orange_concrete
execute in minecraft:overworld run fill 83949 148 -106 83952 148 -102 minecraft:orange_concrete
execute in minecraft:overworld run fill 83958 148 -106 83961 148 -102 minecraft:orange_concrete
execute in minecraft:overworld run fill 83949 140 -111 83961 140 -109 minecraft:yellow_concrete
execute in minecraft:overworld run fill 83949 140 -100 83961 140 -99 minecraft:yellow_concrete
execute in minecraft:overworld run fill 83949 140 -108 83952 140 -101 minecraft:yellow_concrete
execute in minecraft:overworld run fill 83959 140 -108 83961 140 -101 minecraft:yellow_concrete
execute in minecraft:overworld run fill 83955 140 -105 83956 140 -104 minecraft:yellow_concrete
execute in minecraft:overworld run fill 83949 131 -111 83961 131 -108 minecraft:lime_concrete
execute in minecraft:overworld run fill 83949 131 -102 83961 131 -99 minecraft:lime_concrete
execute in minecraft:overworld run fill 83949 131 -107 83953 131 -103 minecraft:lime_concrete
execute in minecraft:overworld run fill 83959 131 -107 83961 131 -103 minecraft:lime_concrete
execute in minecraft:overworld run fill 83949 122 -111 83961 122 -109 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 83949 122 -103 83961 122 -99 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 83949 122 -108 83952 122 -104 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 83958 122 -108 83961 122 -104 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 83949 112 -109 83961 113 -108 minecraft:purple_concrete
execute in minecraft:overworld run fill 83949 112 -103 83961 113 -102 minecraft:purple_concrete
execute in minecraft:overworld run fill 83949 164 -111 83951 164 -99 minecraft:smooth_quartz
execute in minecraft:overworld run setblock 83951 164 -111 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83951 164 -110 minecraft:black_concrete
execute in minecraft:overworld run setblock 83951 164 -109 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83951 164 -108 minecraft:black_concrete
execute in minecraft:overworld run setblock 83951 164 -107 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83951 164 -106 minecraft:black_concrete
execute in minecraft:overworld run setblock 83951 164 -105 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83951 164 -104 minecraft:black_concrete
execute in minecraft:overworld run setblock 83951 164 -103 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83951 164 -102 minecraft:black_concrete
execute in minecraft:overworld run setblock 83951 164 -101 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83951 164 -100 minecraft:black_concrete
execute in minecraft:overworld run setblock 83951 164 -99 minecraft:yellow_concrete
execute in minecraft:overworld run fill 83978 93 -112 83992 93 -98 minecraft:air
execute in minecraft:overworld run fill 83978 170 -112 83992 170 -98 minecraft:air
execute in minecraft:overworld run fill 83978 94 -112 83992 169 -98 minecraft:prismarine_bricks hollow
execute in minecraft:overworld run fill 83978 100 -112 83992 100 -98 minecraft:dark_prismarine replace minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83978 110 -112 83992 110 -98 minecraft:dark_prismarine replace minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83978 120 -112 83992 120 -98 minecraft:dark_prismarine replace minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83978 130 -112 83992 130 -98 minecraft:dark_prismarine replace minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83978 140 -112 83992 140 -98 minecraft:dark_prismarine replace minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83978 150 -112 83992 150 -98 minecraft:dark_prismarine replace minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83978 160 -112 83992 160 -98 minecraft:dark_prismarine replace minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83978 94 -112 83978 169 -112 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83978 94 -98 83978 169 -98 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83992 94 -112 83992 169 -112 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83992 94 -98 83992 169 -98 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83985 95 -112 83985 168 -112 minecraft:sea_lantern
execute in minecraft:overworld run fill 83985 95 -98 83985 168 -98 minecraft:sea_lantern
execute in minecraft:overworld run fill 83978 95 -105 83978 168 -105 minecraft:sea_lantern
execute in minecraft:overworld run fill 83992 95 -105 83992 168 -105 minecraft:sea_lantern
execute in minecraft:overworld run fill 83981 97 -112 83981 160 -112 minecraft:sea_lantern
execute in minecraft:overworld run fill 83989 97 -112 83989 160 -112 minecraft:sea_lantern
execute in minecraft:overworld run fill 83981 97 -98 83981 160 -98 minecraft:sea_lantern
execute in minecraft:overworld run fill 83989 97 -98 83989 160 -98 minecraft:sea_lantern
execute in minecraft:overworld run fill 83978 97 -109 83978 160 -109 minecraft:sea_lantern
execute in minecraft:overworld run fill 83978 97 -101 83978 160 -101 minecraft:sea_lantern
execute in minecraft:overworld run fill 83992 97 -109 83992 160 -109 minecraft:sea_lantern
execute in minecraft:overworld run fill 83992 97 -101 83992 160 -101 minecraft:sea_lantern
execute in minecraft:overworld run fill 83979 93 -111 83991 93 -99 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83979 169 -111 83991 169 -99 minecraft:glass
execute in minecraft:overworld run fill 83978 170 -112 83992 170 -98 minecraft:dark_prismarine outline
execute in minecraft:overworld run fill 83979 170 -111 83991 170 -99 minecraft:air
execute in minecraft:overworld run setblock 83978 171 -112 minecraft:end_rod
execute in minecraft:overworld run setblock 83978 171 -98 minecraft:end_rod
execute in minecraft:overworld run setblock 83992 171 -112 minecraft:end_rod
execute in minecraft:overworld run setblock 83992 171 -98 minecraft:end_rod
execute in minecraft:overworld run fill 83979 95 -111 83991 97 -99 minecraft:prismarine
execute in minecraft:overworld run fill 83985 97 -109 83990 97 -104 minecraft:light_blue_concrete
execute in minecraft:overworld run fill 83986 94 -108 83989 94 -105 minecraft:sea_lantern
execute in minecraft:overworld run fill 83986 95 -108 83989 97 -105 minecraft:water
execute in minecraft:overworld run fill 83979 157 -111 83991 157 -104 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 83979 157 -99 83991 157 -99 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 83979 157 -103 83982 157 -100 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 83987 157 -103 83991 157 -100 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 83979 149 -111 83991 149 -105 minecraft:prismarine
execute in minecraft:overworld run fill 83979 149 -100 83991 149 -99 minecraft:prismarine
execute in minecraft:overworld run fill 83979 149 -104 83983 149 -101 minecraft:prismarine
execute in minecraft:overworld run fill 83988 149 -104 83991 149 -101 minecraft:prismarine
execute in minecraft:overworld run fill 83979 141 -111 83991 141 -108 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83979 141 -99 83991 141 -99 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83979 141 -107 83982 141 -100 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83990 141 -107 83991 141 -100 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83985 141 -103 83987 141 -101 minecraft:light_blue_stained_glass
execute in minecraft:overworld run fill 83979 133 -111 83991 133 -108 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83979 133 -102 83991 133 -99 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83979 133 -107 83984 133 -103 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83989 133 -107 83991 133 -103 minecraft:dark_prismarine
execute in minecraft:overworld run fill 83979 124 -111 83991 124 -109 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 83979 124 -104 83991 124 -99 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 83979 124 -108 83985 124 -105 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 83989 124 -108 83991 124 -105 minecraft:cyan_stained_glass
execute in minecraft:overworld run fill 83979 115 -111 83991 115 -110 minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83979 115 -103 83991 115 -99 minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83979 115 -109 83984 115 -104 minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83991 115 -109 83991 115 -104 minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83987 115 -107 83988 115 -106 minecraft:prismarine_bricks
execute in minecraft:overworld run fill 83979 164 -111 83981 164 -99 minecraft:dark_prismarine
execute in minecraft:overworld run setblock 83981 164 -111 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83981 164 -110 minecraft:black_concrete
execute in minecraft:overworld run setblock 83981 164 -109 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83981 164 -108 minecraft:black_concrete
execute in minecraft:overworld run setblock 83981 164 -107 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83981 164 -106 minecraft:black_concrete
execute in minecraft:overworld run setblock 83981 164 -105 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83981 164 -104 minecraft:black_concrete
execute in minecraft:overworld run setblock 83981 164 -103 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83981 164 -102 minecraft:black_concrete
execute in minecraft:overworld run setblock 83981 164 -101 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 83981 164 -100 minecraft:black_concrete
execute in minecraft:overworld run setblock 83981 164 -99 minecraft:yellow_concrete
execute in minecraft:overworld run fill 84008 93 -112 84022 93 -98 minecraft:air
execute in minecraft:overworld run fill 84008 170 -112 84022 170 -98 minecraft:air
execute in minecraft:overworld run fill 84008 94 -112 84022 169 -98 minecraft:polished_blackstone_bricks hollow
execute in minecraft:overworld run fill 84008 100 -112 84022 100 -98 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 84008 110 -112 84022 110 -98 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 84008 120 -112 84022 120 -98 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 84008 130 -112 84022 130 -98 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 84008 140 -112 84022 140 -98 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 84008 150 -112 84022 150 -98 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 84008 160 -112 84022 160 -98 minecraft:gilded_blackstone replace minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 84008 94 -112 84008 169 -112 minecraft:obsidian
execute in minecraft:overworld run fill 84008 94 -98 84008 169 -98 minecraft:obsidian
execute in minecraft:overworld run fill 84022 94 -112 84022 169 -112 minecraft:obsidian
execute in minecraft:overworld run fill 84022 94 -98 84022 169 -98 minecraft:obsidian
execute in minecraft:overworld run fill 84015 95 -112 84015 168 -112 minecraft:shroomlight
execute in minecraft:overworld run fill 84015 95 -98 84015 168 -98 minecraft:shroomlight
execute in minecraft:overworld run fill 84008 95 -105 84008 168 -105 minecraft:shroomlight
execute in minecraft:overworld run fill 84022 95 -105 84022 168 -105 minecraft:shroomlight
execute in minecraft:overworld run fill 84011 97 -112 84011 160 -112 minecraft:shroomlight
execute in minecraft:overworld run fill 84019 97 -112 84019 160 -112 minecraft:shroomlight
execute in minecraft:overworld run fill 84011 97 -98 84011 160 -98 minecraft:shroomlight
execute in minecraft:overworld run fill 84019 97 -98 84019 160 -98 minecraft:shroomlight
execute in minecraft:overworld run fill 84008 97 -109 84008 160 -109 minecraft:shroomlight
execute in minecraft:overworld run fill 84008 97 -101 84008 160 -101 minecraft:shroomlight
execute in minecraft:overworld run fill 84022 97 -109 84022 160 -109 minecraft:shroomlight
execute in minecraft:overworld run fill 84022 97 -101 84022 160 -101 minecraft:shroomlight
execute in minecraft:overworld run fill 84009 93 -111 84021 93 -99 minecraft:obsidian
execute in minecraft:overworld run fill 84009 169 -111 84021 169 -99 minecraft:glass
execute in minecraft:overworld run fill 84008 170 -112 84022 170 -98 minecraft:obsidian outline
execute in minecraft:overworld run fill 84009 170 -111 84021 170 -99 minecraft:air
execute in minecraft:overworld run setblock 84008 171 -112 minecraft:end_rod
execute in minecraft:overworld run setblock 84008 171 -98 minecraft:end_rod
execute in minecraft:overworld run setblock 84022 171 -112 minecraft:end_rod
execute in minecraft:overworld run setblock 84022 171 -98 minecraft:end_rod
execute in minecraft:overworld run fill 84009 95 -111 84021 97 -99 minecraft:blackstone
execute in minecraft:overworld run fill 84016 97 -106 84021 97 -101 minecraft:red_nether_bricks
execute in minecraft:overworld run fill 84017 94 -105 84020 94 -102 minecraft:glowstone
execute in minecraft:overworld run fill 84017 95 -105 84020 97 -102 minecraft:water
execute in minecraft:overworld run fill 84009 157 -111 84013 158 -99 minecraft:nether_bricks
execute in minecraft:overworld run fill 84016 157 -111 84017 158 -99 minecraft:nether_bricks
execute in minecraft:overworld run fill 84020 157 -111 84021 158 -99 minecraft:nether_bricks
execute in minecraft:overworld run fill 84009 151 -111 84021 151 -111 minecraft:red_nether_bricks
execute in minecraft:overworld run fill 84009 151 -106 84021 151 -99 minecraft:red_nether_bricks
execute in minecraft:overworld run fill 84009 151 -110 84013 151 -107 minecraft:red_nether_bricks
execute in minecraft:overworld run fill 84018 151 -110 84021 151 -107 minecraft:red_nether_bricks
execute in minecraft:overworld run fill 84009 144 -111 84021 144 -110 minecraft:red_stained_glass
execute in minecraft:overworld run fill 84009 144 -105 84021 144 -99 minecraft:red_stained_glass
execute in minecraft:overworld run fill 84009 144 -109 84015 144 -106 minecraft:red_stained_glass
execute in minecraft:overworld run fill 84020 144 -109 84021 144 -106 minecraft:red_stained_glass
execute in minecraft:overworld run fill 84009 136 -111 84021 136 -111 minecraft:nether_wart_block
execute in minecraft:overworld run fill 84009 136 -104 84021 136 -99 minecraft:nether_wart_block
execute in minecraft:overworld run fill 84009 136 -110 84014 136 -105 minecraft:nether_wart_block
execute in minecraft:overworld run fill 84021 136 -110 84021 136 -105 minecraft:nether_wart_block
execute in minecraft:overworld run fill 84017 136 -108 84018 136 -107 minecraft:nether_wart_block
execute in minecraft:overworld run fill 84009 128 -111 84021 128 -108 minecraft:warped_wart_block
execute in minecraft:overworld run fill 84009 128 -103 84021 128 -99 minecraft:warped_wart_block
execute in minecraft:overworld run fill 84009 128 -107 84017 128 -104 minecraft:warped_wart_block
execute in minecraft:overworld run fill 84009 119 -111 84021 119 -106 minecraft:red_stained_glass
execute in minecraft:overworld run fill 84009 119 -101 84021 119 -99 minecraft:red_stained_glass
execute in minecraft:overworld run fill 84009 119 -105 84016 119 -102 minecraft:red_stained_glass
execute in minecraft:overworld run fill 84021 119 -105 84021 119 -102 minecraft:red_stained_glass
execute in minecraft:overworld run fill 84009 109 -111 84021 110 -106 minecraft:nether_bricks
execute in minecraft:overworld run fill 84009 109 -102 84021 110 -99 minecraft:nether_bricks
execute in minecraft:overworld run fill 84009 109 -105 84015 110 -103 minecraft:nether_bricks
execute in minecraft:overworld run fill 84009 164 -111 84011 164 -99 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 84011 164 -111 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84011 164 -110 minecraft:black_concrete
execute in minecraft:overworld run setblock 84011 164 -109 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84011 164 -108 minecraft:black_concrete
execute in minecraft:overworld run setblock 84011 164 -107 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84011 164 -106 minecraft:black_concrete
execute in minecraft:overworld run setblock 84011 164 -105 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84011 164 -104 minecraft:black_concrete
execute in minecraft:overworld run setblock 84011 164 -103 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84011 164 -102 minecraft:black_concrete
execute in minecraft:overworld run setblock 84011 164 -101 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84011 164 -100 minecraft:black_concrete
execute in minecraft:overworld run setblock 84011 164 -99 minecraft:yellow_concrete
execute in minecraft:overworld run fill 84038 93 -112 84052 93 -98 minecraft:air
execute in minecraft:overworld run fill 84038 170 -112 84052 170 -98 minecraft:air
execute in minecraft:overworld run fill 84038 94 -112 84052 169 -98 minecraft:end_stone_bricks hollow
execute in minecraft:overworld run fill 84038 100 -112 84052 100 -98 minecraft:purpur_block replace minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84038 110 -112 84052 110 -98 minecraft:purpur_block replace minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84038 120 -112 84052 120 -98 minecraft:purpur_block replace minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84038 130 -112 84052 130 -98 minecraft:purpur_block replace minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84038 140 -112 84052 140 -98 minecraft:purpur_block replace minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84038 150 -112 84052 150 -98 minecraft:purpur_block replace minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84038 160 -112 84052 160 -98 minecraft:purpur_block replace minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84038 94 -112 84038 169 -112 minecraft:obsidian
execute in minecraft:overworld run fill 84038 94 -98 84038 169 -98 minecraft:obsidian
execute in minecraft:overworld run fill 84052 94 -112 84052 169 -112 minecraft:obsidian
execute in minecraft:overworld run fill 84052 94 -98 84052 169 -98 minecraft:obsidian
execute in minecraft:overworld run fill 84045 95 -112 84045 168 -112 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84045 95 -98 84045 168 -98 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84038 95 -105 84038 168 -105 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84052 95 -105 84052 168 -105 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84041 97 -112 84041 160 -112 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84049 97 -112 84049 160 -112 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84041 97 -98 84041 160 -98 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84049 97 -98 84049 160 -98 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84038 97 -109 84038 160 -109 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84038 97 -101 84038 160 -101 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84052 97 -109 84052 160 -109 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84052 97 -101 84052 160 -101 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84039 93 -111 84051 93 -99 minecraft:obsidian
execute in minecraft:overworld run fill 84039 169 -111 84051 169 -99 minecraft:glass
execute in minecraft:overworld run fill 84038 170 -112 84052 170 -98 minecraft:obsidian outline
execute in minecraft:overworld run fill 84039 170 -111 84051 170 -99 minecraft:air
execute in minecraft:overworld run setblock 84038 171 -112 minecraft:end_rod
execute in minecraft:overworld run setblock 84038 171 -98 minecraft:end_rod
execute in minecraft:overworld run setblock 84052 171 -112 minecraft:end_rod
execute in minecraft:overworld run setblock 84052 171 -98 minecraft:end_rod
execute in minecraft:overworld run fill 84039 95 -111 84051 97 -99 minecraft:end_stone
execute in minecraft:overworld run fill 84046 97 -106 84050 97 -102 minecraft:purpur_pillar
execute in minecraft:overworld run fill 84047 94 -105 84049 94 -103 minecraft:pearlescent_froglight
execute in minecraft:overworld run fill 84047 95 -105 84049 97 -103 minecraft:water
execute in minecraft:overworld run fill 84039 158 -111 84051 158 -103 minecraft:purpur_block
execute in minecraft:overworld run fill 84039 158 -102 84041 158 -99 minecraft:purpur_block
execute in minecraft:overworld run fill 84046 158 -102 84051 158 -99 minecraft:purpur_block
execute in minecraft:overworld run fill 84039 152 -111 84051 152 -104 minecraft:magenta_stained_glass
execute in minecraft:overworld run fill 84039 152 -99 84051 152 -99 minecraft:magenta_stained_glass
execute in minecraft:overworld run fill 84039 152 -103 84042 152 -100 minecraft:magenta_stained_glass
execute in minecraft:overworld run fill 84047 152 -103 84051 152 -100 minecraft:magenta_stained_glass
execute in minecraft:overworld run fill 84039 145 -111 84051 145 -105 minecraft:obsidian
execute in minecraft:overworld run fill 84039 145 -101 84051 145 -99 minecraft:obsidian
execute in minecraft:overworld run fill 84039 145 -104 84044 145 -102 minecraft:obsidian
execute in minecraft:overworld run fill 84048 145 -104 84051 145 -102 minecraft:obsidian
execute in minecraft:overworld run fill 84039 138 -111 84051 138 -108 minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84039 138 -100 84051 138 -99 minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84039 138 -107 84042 138 -101 minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84050 138 -107 84051 138 -101 minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84045 138 -105 84047 138 -103 minecraft:end_stone_bricks
execute in minecraft:overworld run fill 84039 130 -111 84051 130 -104 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 84039 130 -100 84051 130 -99 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 84039 130 -103 84046 130 -101 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 84050 130 -103 84051 130 -101 minecraft:purple_stained_glass
execute in minecraft:overworld run fill 84039 122 -111 84051 122 -105 minecraft:crying_obsidian
execute in minecraft:overworld run fill 84039 122 -101 84051 122 -99 minecraft:crying_obsidian
execute in minecraft:overworld run fill 84039 122 -104 84047 122 -102 minecraft:crying_obsidian
execute in minecraft:overworld run fill 84051 122 -104 84051 122 -102 minecraft:crying_obsidian
execute in minecraft:overworld run fill 84039 114 -111 84051 114 -106 minecraft:magenta_stained_glass
execute in minecraft:overworld run fill 84039 114 -102 84051 114 -99 minecraft:magenta_stained_glass
execute in minecraft:overworld run fill 84039 114 -105 84046 114 -103 minecraft:magenta_stained_glass
execute in minecraft:overworld run fill 84050 114 -105 84051 114 -103 minecraft:magenta_stained_glass
execute in minecraft:overworld run fill 84049 106 -104 84049 106 -104 minecraft:amethyst_block
execute in minecraft:overworld run fill 84039 164 -111 84041 164 -99 minecraft:purpur_block
execute in minecraft:overworld run setblock 84041 164 -111 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84041 164 -110 minecraft:black_concrete
execute in minecraft:overworld run setblock 84041 164 -109 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84041 164 -108 minecraft:black_concrete
execute in minecraft:overworld run setblock 84041 164 -107 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84041 164 -106 minecraft:black_concrete
execute in minecraft:overworld run setblock 84041 164 -105 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84041 164 -104 minecraft:black_concrete
execute in minecraft:overworld run setblock 84041 164 -103 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84041 164 -102 minecraft:black_concrete
execute in minecraft:overworld run setblock 84041 164 -101 minecraft:yellow_concrete
execute in minecraft:overworld run setblock 84041 164 -100 minecraft:black_concrete
execute in minecraft:overworld run setblock 84041 164 -99 minecraft:yellow_concrete
execute in minecraft:overworld run clone 83948 93 -112 83962 171 -98 83948 93 -82
execute in minecraft:overworld run clone 83948 93 -112 83962 171 -98 83948 93 -52
execute in minecraft:overworld run clone 83948 93 -112 83962 171 -98 83948 93 -22
execute in minecraft:overworld run clone 83948 93 -112 83962 171 -98 83948 93 8
execute in minecraft:overworld run clone 83948 93 -112 83962 171 -98 83948 93 38
execute in minecraft:overworld run clone 83948 93 -112 83962 171 -98 83948 93 68
execute in minecraft:overworld run clone 83948 93 -112 83962 171 -98 83948 93 98
execute in minecraft:overworld run clone 83978 93 -112 83992 171 -98 83978 93 -82
execute in minecraft:overworld run clone 83978 93 -112 83992 171 -98 83978 93 -52
execute in minecraft:overworld run clone 83978 93 -112 83992 171 -98 83978 93 -22
execute in minecraft:overworld run clone 83978 93 -112 83992 171 -98 83978 93 8
execute in minecraft:overworld run clone 83978 93 -112 83992 171 -98 83978 93 38
execute in minecraft:overworld run clone 83978 93 -112 83992 171 -98 83978 93 68
execute in minecraft:overworld run clone 83978 93 -112 83992 171 -98 83978 93 98
execute in minecraft:overworld run clone 84008 93 -112 84022 171 -98 84008 93 -82
execute in minecraft:overworld run clone 84008 93 -112 84022 171 -98 84008 93 -52
execute in minecraft:overworld run clone 84008 93 -112 84022 171 -98 84008 93 -22
execute in minecraft:overworld run clone 84008 93 -112 84022 171 -98 84008 93 8
execute in minecraft:overworld run clone 84008 93 -112 84022 171 -98 84008 93 38
execute in minecraft:overworld run clone 84008 93 -112 84022 171 -98 84008 93 68
execute in minecraft:overworld run clone 84008 93 -112 84022 171 -98 84008 93 98
execute in minecraft:overworld run clone 84038 93 -112 84052 171 -98 84038 93 -82
execute in minecraft:overworld run clone 84038 93 -112 84052 171 -98 84038 93 -52
execute in minecraft:overworld run clone 84038 93 -112 84052 171 -98 84038 93 -22
execute in minecraft:overworld run clone 84038 93 -112 84052 171 -98 84038 93 8
execute in minecraft:overworld run clone 84038 93 -112 84052 171 -98 84038 93 38
execute in minecraft:overworld run clone 84038 93 -112 84052 171 -98 84038 93 68
execute in minecraft:overworld run clone 84038 93 -112 84052 171 -98 84038 93 98
scoreboard players set #dropper_v mg 2
