function mg:dropper/build
tag @a[tag=mg_q_dropper,tag=mg_hub,limit=8,sort=random] add mg_dropper
tag @a[tag=mg_dropper] remove mg_q_dropper
execute as @a[tag=mg_dropper] run function mg:q/leave_all
tag @a[tag=mg_dropper] remove mg_hub
clear @a[tag=mg_dropper]
effect clear @a[tag=mg_dropper]
gamemode adventure @a[tag=mg_dropper]
tag @a[tag=mg_dropper] add mg_al_dropper
scoreboard players set @a[tag=mg_dropper] mg_deaths 0
execute as @a[tag=mg_dropper] run execute in minecraft:overworld run spawnpoint @s 84000 177 0
scoreboard players set #dropper_t mg 0
execute store result score #dropper_np mg if entity @a[tag=mg_dropper]
tag @a remove mg_dropper_win
scoreboard players set #dropper_n mg 0
execute as @a[tag=mg_dropper] run function mg:dropper/assign
scoreboard players set @a[tag=mg_dropper] mg_dropper_l 1
scoreboard players set @a[tag=mg_dropper] mg_dropper_f 0
execute as @a[tag=mg_dropper] run function mg:dropper/tp
effect give @a[tag=mg_dropper] minecraft:saturation infinite 0 true
effect give @a[tag=mg_dropper] minecraft:resistance infinite 4 true
execute as @a[tag=mg_dropper] run attribute @s minecraft:gravity base set 0.04
bossbar set mg:dropper max 300
bossbar set mg:dropper value 300
bossbar set mg:dropper color yellow
bossbar set mg:dropper players @a[tag=mg_dropper]
bossbar set mg:dropper visible true
execute in minecraft:overworld run forceload remove 83886 -114 84114 114
scoreboard players set #dropper mg 2
title @a[tag=mg_dropper] times 5 50 10
title @a[tag=mg_dropper] title {"text": "DROPPER", "color": "gold", "bold": true}
title @a[tag=mg_dropper] subtitle {"text": "Triff das Wasser!", "color": "white"}
execute if score #dropper_np mg matches ..1 run title @a[tag=mg_dropper] subtitle [{"text": "Solo-Runde · ", "color": "aqua"}, {"text": "Triff das Wasser!", "color": "white"}]
tellraw @a[tag=mg_dropper] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Spring in den Schacht und weich im Fallen allen Hindernissen aus. Landest du auf einem Block, geht es zurück nach oben. Triffst du das Wasser unten, kommt das nächste Level. Wer zuerst alle 4 Level schafft, gewinnt – Zeitlimit 5 Minuten! Alleine spielst du gegen die Uhr und jagst deine Bestzeit.", "color": "gray"}]
tellraw @a[tag=mg_dropper] [{"text": "  "}, {"text": "[Spiel verlassen]", "color": "red", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 99"}}]
