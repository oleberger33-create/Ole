execute unless score #kolben mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_kolben] remove mg_rw
tag @a[tag=mg_duel_kolben] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_kolben] mg_round 1
tellraw @a[tag=mg_duel_kolben] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_kolben]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "dark_purple"}]
execute as @a[tag=mg_duel_kolben] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_kolben,scores={mg_round=2..}] run return run function mg:kolben/win
scoreboard players set #kolben mg 1
function mg:kolben/round
