clear @s
effect clear @s
attribute @s minecraft:max_health base set 20
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
scoreboard players set @s mg_deaths 0
scoreboard players set @s mg_dmg 0
scoreboard players set @s mg_lap 0
scoreboard players set @s mg_gate 0
effect give @s minecraft:slowness 3 255 true
effect give @s minecraft:resistance 3 4 true
give @s minecraft:mace
give @s minecraft:wind_charge 12
give @s minecraft:cooked_beef 6
item replace entity @s armor.head with minecraft:iron_helmet
item replace entity @s armor.chest with minecraft:iron_chestplate
item replace entity @s armor.legs with minecraft:iron_leggings
item replace entity @s armor.feet with minecraft:iron_boots
