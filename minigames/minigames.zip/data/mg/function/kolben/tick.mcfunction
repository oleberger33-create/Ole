execute if score #kolben_cd mg matches 1.. run scoreboard players remove #kolben_cd mg 1
execute if score #kolben mg matches 1 if score #kolben_cd mg matches 0 run function mg:kolben/go
execute if score #kolben mg matches 1 if score #kolben_cd mg matches 0 run scoreboard players set #kolben mg 2
execute unless score #kolben mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_kolben]
execute if score #n mg matches ..1 run return run function mg:kolben/forfeit
execute as @e[type=minecraft:player,tag=mg_duel_kolben,scores={mg_deaths=1..}] run function mg:kolben/lose
execute as @a[tag=mg_duel_kolben] at @s if entity @s[y=-64,dy=154] run function mg:kolben/lose
execute as @a[tag=mg_duel_kolben] at @s if entity @s[y=-64,dy=154] run kill @s
