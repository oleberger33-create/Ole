execute as @a[tag=mg_duel_kolben] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Streitkolben – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_kolben] mg_wins 1
scoreboard players add @a[tag=mg_duel_kolben] mg_coins 5
function mg:kolben/stop
