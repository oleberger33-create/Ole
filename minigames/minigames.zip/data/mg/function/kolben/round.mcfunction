execute as @a[tag=mg_duel_kolben] run function mg:kolben/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_kolben,tag=mg_p1,limit=1] 8992 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_kolben,tag=mg_p2,limit=1] 9008 101 0 90 0
execute as @a[tag=mg_duel_kolben] run execute in minecraft:overworld run spawnpoint @s 0 101 0
kill @e[type=minecraft:horse,tag=mg_horse_kolben]
scoreboard players set #kolben_cd mg 60
scoreboard players set #kolben mg 1
title @a[tag=mg_duel_kolben] times 0 30 10
title @a[tag=mg_duel_kolben] title {"text": "Streitkolben", "color": "dark_purple", "bold": true}
title @a[tag=mg_duel_kolben] subtitle [{"score":{"name":"@a[tag=mg_duel_kolben,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_kolben,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
