title @a[tag=mg_duel_kolben] actionbar {"text": "LOS!", "color": "dark_purple", "bold": true}
execute as @a[tag=mg_duel_kolben] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
