kill @e[type=minecraft:text_display,tag=mg_ctfh]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=77956,y=94,z=-20,dx=88,dy=34,dz=40]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=77956,y=94,z=-20,dx=88,dy=34,dz=40]
execute in minecraft:overworld run fill 77956 97 -20 77961 116 20 minecraft:air
execute in minecraft:overworld run fill 77962 97 -20 77967 116 20 minecraft:air
execute in minecraft:overworld run fill 77968 97 -20 77973 116 20 minecraft:air
execute in minecraft:overworld run fill 77974 97 -20 77979 116 20 minecraft:air
execute in minecraft:overworld run fill 77980 97 -20 77985 116 20 minecraft:air
execute in minecraft:overworld run fill 77986 97 -20 77991 116 20 minecraft:air
execute in minecraft:overworld run fill 77992 97 -20 77997 116 20 minecraft:air
execute in minecraft:overworld run fill 77998 97 -20 78003 116 20 minecraft:air
execute in minecraft:overworld run fill 78004 97 -20 78009 116 20 minecraft:air
execute in minecraft:overworld run fill 78010 97 -20 78015 116 20 minecraft:air
execute in minecraft:overworld run fill 78016 97 -20 78021 116 20 minecraft:air
execute in minecraft:overworld run fill 78022 97 -20 78027 116 20 minecraft:air
execute in minecraft:overworld run fill 78028 97 -20 78033 116 20 minecraft:air
execute in minecraft:overworld run fill 78034 97 -20 78039 116 20 minecraft:air
execute in minecraft:overworld run fill 78040 97 -20 78044 116 20 minecraft:air
execute in minecraft:overworld run fill 77958 97 -18 78042 98 18 minecraft:stone
execute in minecraft:overworld run fill 77958 99 -18 78042 99 18 minecraft:dirt
execute in minecraft:overworld run fill 77958 100 -18 78042 100 18 minecraft:grass_block
execute in minecraft:overworld run fill 77958 101 -18 78042 102 -18 minecraft:stone_bricks
execute in minecraft:overworld run fill 77958 103 -18 78042 114 -18 minecraft:barrier
execute in minecraft:overworld run fill 77958 101 18 78042 102 18 minecraft:stone_bricks
execute in minecraft:overworld run fill 77958 103 18 78042 114 18 minecraft:barrier
execute in minecraft:overworld run fill 77958 101 -18 77958 102 18 minecraft:stone_bricks
execute in minecraft:overworld run fill 77958 103 -18 77958 114 18 minecraft:barrier
execute in minecraft:overworld run fill 78042 101 -18 78042 102 18 minecraft:stone_bricks
execute in minecraft:overworld run fill 78042 103 -18 78042 114 18 minecraft:barrier
execute in minecraft:overworld run setblock 78040 102 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78003 101 18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77993 102 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78031 102 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78004 102 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78021 101 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77972 101 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77988 101 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77987 102 18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78024 102 18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77966 102 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78032 102 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77987 101 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78033 101 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78007 101 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77959 101 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77975 101 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78022 101 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78039 101 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77976 102 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78000 101 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77979 102 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78013 101 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78022 101 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77961 101 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78037 101 18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78024 101 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78035 102 18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78041 102 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77967 102 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78040 101 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77973 102 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77978 102 -18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77986 101 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78023 101 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78030 102 18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77994 102 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78014 101 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78006 102 -18 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77963 101 18 minecraft:cracked_stone_bricks
execute in minecraft:overworld run fill 77999 98 -17 78001 98 17 minecraft:sand
execute in minecraft:overworld run fill 77999 99 -17 78001 100 17 minecraft:water
execute in minecraft:overworld run fill 77998 100 -17 77998 100 17 minecraft:mud_bricks
execute in minecraft:overworld run fill 78002 100 -17 78002 100 17 minecraft:mud_bricks
execute in minecraft:overworld run setblock 78001 99 -16 minecraft:seagrass
execute in minecraft:overworld run setblock 78001 99 -11 minecraft:seagrass
execute in minecraft:overworld run setblock 78001 99 -6 minecraft:seagrass
execute in minecraft:overworld run setblock 78000 99 -1 minecraft:seagrass
execute in minecraft:overworld run setblock 77999 99 4 minecraft:seagrass
execute in minecraft:overworld run setblock 78000 99 9 minecraft:seagrass
execute in minecraft:overworld run setblock 78000 99 14 minecraft:seagrass
execute in minecraft:overworld run fill 77998 100 -13 78002 100 -9 minecraft:spruce_planks
execute in minecraft:overworld run fill 77998 101 -13 78002 101 -13 minecraft:spruce_fence
execute in minecraft:overworld run fill 77998 101 -9 78002 101 -9 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77998 102 -13 minecraft:lantern
execute in minecraft:overworld run setblock 78002 102 -9 minecraft:lantern
execute in minecraft:overworld run setblock 78002 102 -13 minecraft:lantern
execute in minecraft:overworld run setblock 77998 102 -9 minecraft:lantern
execute in minecraft:overworld run fill 77998 100 9 78002 100 13 minecraft:spruce_planks
execute in minecraft:overworld run fill 77998 101 9 78002 101 9 minecraft:spruce_fence
execute in minecraft:overworld run fill 77998 101 13 78002 101 13 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77998 102 9 minecraft:lantern
execute in minecraft:overworld run setblock 78002 102 13 minecraft:lantern
execute in minecraft:overworld run setblock 78002 102 9 minecraft:lantern
execute in minecraft:overworld run setblock 77998 102 13 minecraft:lantern
execute in minecraft:overworld run fill 77998 100 -7 78002 100 -7 minecraft:stone_bricks
execute in minecraft:overworld run fill 77996 100 -6 78004 100 -6 minecraft:stone_bricks
execute in minecraft:overworld run fill 77995 100 -5 78005 100 -5 minecraft:stone_bricks
execute in minecraft:overworld run fill 77994 100 -4 78006 100 -4 minecraft:stone_bricks
execute in minecraft:overworld run fill 77994 100 -3 78006 100 -3 minecraft:stone_bricks
execute in minecraft:overworld run fill 77993 100 -2 78007 100 -2 minecraft:stone_bricks
execute in minecraft:overworld run fill 77993 100 -1 78007 100 -1 minecraft:stone_bricks
execute in minecraft:overworld run fill 77993 100 0 78007 100 0 minecraft:stone_bricks
execute in minecraft:overworld run fill 77993 100 1 78007 100 1 minecraft:stone_bricks
execute in minecraft:overworld run fill 77993 100 2 78007 100 2 minecraft:stone_bricks
execute in minecraft:overworld run fill 77994 100 3 78006 100 3 minecraft:stone_bricks
execute in minecraft:overworld run fill 77994 100 4 78006 100 4 minecraft:stone_bricks
execute in minecraft:overworld run fill 77995 100 5 78005 100 5 minecraft:stone_bricks
execute in minecraft:overworld run fill 77996 100 6 78004 100 6 minecraft:stone_bricks
execute in minecraft:overworld run fill 77998 100 7 78002 100 7 minecraft:stone_bricks
execute in minecraft:overworld run fill 77998 101 -6 78002 101 -6 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77996 101 -5 78004 101 -5 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77995 101 -4 78005 101 -4 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77995 101 -3 78005 101 -3 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77994 101 -2 78006 101 -2 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77994 101 -1 78006 101 -1 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77994 101 0 78006 101 0 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77994 101 1 78006 101 1 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77994 101 2 78006 101 2 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77995 101 3 78005 101 3 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77995 101 4 78005 101 4 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77996 101 5 78004 101 5 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77998 101 6 78002 101 6 minecraft:andesite_slab[type=bottom]
execute in minecraft:overworld run fill 77998 101 -5 78002 101 -5 minecraft:polished_andesite
execute in minecraft:overworld run fill 77997 101 -4 78003 101 -4 minecraft:polished_andesite
execute in minecraft:overworld run fill 77996 101 -3 78004 101 -3 minecraft:polished_andesite
execute in minecraft:overworld run fill 77995 101 -2 78005 101 -2 minecraft:polished_andesite
execute in minecraft:overworld run fill 77995 101 -1 78005 101 -1 minecraft:polished_andesite
execute in minecraft:overworld run fill 77995 101 0 78005 101 0 minecraft:polished_andesite
execute in minecraft:overworld run fill 77995 101 1 78005 101 1 minecraft:polished_andesite
execute in minecraft:overworld run fill 77995 101 2 78005 101 2 minecraft:polished_andesite
execute in minecraft:overworld run fill 77996 101 3 78004 101 3 minecraft:polished_andesite
execute in minecraft:overworld run fill 77997 101 4 78003 101 4 minecraft:polished_andesite
execute in minecraft:overworld run fill 77998 101 5 78002 101 5 minecraft:polished_andesite
execute in minecraft:overworld run fill 77999 101 -2 78001 101 -2 minecraft:chiseled_stone_bricks
execute in minecraft:overworld run fill 77998 101 -1 78002 101 -1 minecraft:chiseled_stone_bricks
execute in minecraft:overworld run fill 77998 101 0 78002 101 0 minecraft:chiseled_stone_bricks
execute in minecraft:overworld run fill 77998 101 1 78002 101 1 minecraft:chiseled_stone_bricks
execute in minecraft:overworld run fill 77999 101 2 78001 101 2 minecraft:chiseled_stone_bricks
execute in minecraft:overworld run fill 78000 102 0 78000 105 0 minecraft:quartz_pillar
execute in minecraft:overworld run setblock 78000 106 0 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78000 107 0 minecraft:end_rod
execute in minecraft:overworld run setblock 77999 102 0 minecraft:quartz_stairs[facing=east]
execute in minecraft:overworld run setblock 78001 102 0 minecraft:quartz_stairs[facing=west]
execute in minecraft:overworld run setblock 78000 102 -1 minecraft:quartz_stairs[facing=south]
execute in minecraft:overworld run setblock 78000 102 1 minecraft:quartz_stairs[facing=north]
execute in minecraft:overworld run fill 77996 102 -4 77996 103 -4 minecraft:andesite_wall
execute in minecraft:overworld run setblock 77996 104 -4 minecraft:lantern
execute in minecraft:overworld run fill 77996 102 4 77996 103 4 minecraft:andesite_wall
execute in minecraft:overworld run setblock 77996 104 4 minecraft:lantern
execute in minecraft:overworld run fill 78004 102 -4 78004 103 -4 minecraft:andesite_wall
execute in minecraft:overworld run setblock 78004 104 -4 minecraft:lantern
execute in minecraft:overworld run fill 78004 102 4 78004 103 4 minecraft:andesite_wall
execute in minecraft:overworld run setblock 78004 104 4 minecraft:lantern
execute in minecraft:overworld run summon minecraft:text_display 78000.5 109.5 0.5 {Tags:["mg_holo","mg_ctfh"],billboard:"center",background:0,shadow:true,text:[{"text": "Burg Zwiestein", "color": "gold", "bold": true}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[2.0f,2.0f,2.0f]}}
execute in minecraft:overworld run fill 77997 100 -1 77974 100 1 minecraft:dirt_path
execute in minecraft:overworld run fill 77992 100 -1 77991 100 1 minecraft:coarse_dirt
execute in minecraft:overworld run fill 77981 100 -1 77980 100 1 minecraft:coarse_dirt
execute in minecraft:overworld run fill 77991 101 -3 77991 102 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77991 103 -4 minecraft:mossy_stone_brick_slab[type=bottom]
execute in minecraft:overworld run setblock 77991 103 -5 minecraft:mossy_stone_brick_slab[type=bottom]
execute in minecraft:overworld run fill 77991 101 -7 77989 101 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 77980 101 -6 77980 104 -6 minecraft:stone_bricks
execute in minecraft:overworld run fill 77980 101 -10 77980 104 -10 minecraft:stone_bricks
execute in minecraft:overworld run fill 77980 105 -6 77980 105 -10 minecraft:stone_brick_slab[type=bottom]
execute in minecraft:overworld run setblock 77980 104 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 77980 104 -7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 77980 104 -9 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77980 102 -10 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77980 103 -6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 77989 101 -13 77988 101 -13 minecraft:hay_block[axis=x]
execute in minecraft:overworld run setblock 77989 102 -13 minecraft:hay_block[axis=x]
execute in minecraft:overworld run setblock 77988 101 -14 minecraft:hay_block[axis=z]
execute in minecraft:overworld run fill 77984 101 -15 77983 102 -16 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 77983 101 -14 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 77995 101 -3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77995 102 -3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77995 103 -3 minecraft:lantern
execute in minecraft:overworld run setblock 77976 101 -3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77976 102 -3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77976 103 -3 minecraft:lantern
execute in minecraft:overworld run fill 77991 101 3 77991 102 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 77991 103 4 minecraft:mossy_stone_brick_slab[type=bottom]
execute in minecraft:overworld run setblock 77991 103 5 minecraft:mossy_stone_brick_slab[type=bottom]
execute in minecraft:overworld run fill 77991 101 7 77989 101 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 77980 101 6 77980 104 6 minecraft:stone_bricks
execute in minecraft:overworld run fill 77980 101 10 77980 104 10 minecraft:stone_bricks
execute in minecraft:overworld run fill 77980 105 6 77980 105 10 minecraft:stone_brick_slab[type=bottom]
execute in minecraft:overworld run setblock 77980 104 8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 77980 104 7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 77980 104 9 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77980 102 10 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 77980 103 6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 77989 101 13 77988 101 13 minecraft:hay_block[axis=x]
execute in minecraft:overworld run setblock 77989 102 13 minecraft:hay_block[axis=x]
execute in minecraft:overworld run setblock 77988 101 14 minecraft:hay_block[axis=z]
execute in minecraft:overworld run fill 77984 101 15 77983 102 16 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 77983 101 14 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 77995 101 3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77995 102 3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77995 103 3 minecraft:lantern
execute in minecraft:overworld run setblock 77976 101 3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77976 102 3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 77976 103 3 minecraft:lantern
execute in minecraft:overworld run fill 77985 101 -1 77984 102 0 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 77985 101 1 minecraft:spruce_planks
execute in minecraft:overworld run setblock 77984 101 1 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 77985 103 -1 minecraft:spruce_slab[type=bottom]
execute in minecraft:overworld run fill 77991 103 12 77995 104 16 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77992 105 13 77994 105 15 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 77993 106 14 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77993 101 14 77993 105 14 minecraft:oak_log
execute in minecraft:overworld run fill 77991 103 -16 77995 104 -12 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77992 105 -15 77994 105 -13 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 77993 106 -14 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77993 101 -14 77993 105 -14 minecraft:oak_log
execute in minecraft:overworld run fill 77976 103 13 77980 104 17 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77977 105 14 77979 105 16 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 77978 106 15 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77978 101 15 77978 105 15 minecraft:oak_log
execute in minecraft:overworld run fill 77976 103 -17 77980 104 -13 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77977 105 -16 77979 105 -14 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 77978 106 -15 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77978 101 -15 77978 105 -15 minecraft:oak_log
execute in minecraft:overworld run fill 77985 103 -11 77989 104 -7 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77986 105 -10 77988 105 -8 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 77987 106 -9 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77987 101 -9 77987 105 -9 minecraft:oak_log
execute in minecraft:overworld run fill 77985 103 7 77989 104 11 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77986 105 8 77988 105 10 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 77987 106 9 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 77987 101 9 77987 105 9 minecraft:oak_log
execute in minecraft:overworld run fill 77972 100 -11 77959 100 11 minecraft:stone_bricks
execute in minecraft:overworld run fill 77972 100 -1 77959 100 1 minecraft:red_concrete
execute in minecraft:overworld run fill 77972 99 -11 77959 99 11 minecraft:stone
execute in minecraft:overworld run setblock 77970 100 -7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 77970 100 7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 77967 100 -7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 77967 100 7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 77963 100 -7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 77963 100 7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 77960 100 -7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 77960 100 7 minecraft:sea_lantern
execute in minecraft:overworld run fill 77973 101 -11 77973 103 11 minecraft:deepslate_bricks
execute in minecraft:overworld run fill 77973 104 -11 77973 104 11 minecraft:red_concrete
execute in minecraft:overworld run setblock 77973 105 -11 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 -9 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 -7 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 -5 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 -3 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 -1 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 1 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 3 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 5 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 7 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 9 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77973 105 11 minecraft:deepslate_brick_wall
execute in minecraft:overworld run fill 77973 101 -1 77973 103 1 minecraft:air
execute in minecraft:overworld run fill 77973 101 6 77973 103 7 minecraft:air
execute in minecraft:overworld run fill 77973 101 -7 77973 103 -6 minecraft:air
execute in minecraft:overworld run fill 77973 102 -9 77973 103 -9 minecraft:red_stained_glass
execute in minecraft:overworld run fill 77973 102 -3 77973 103 -3 minecraft:red_stained_glass
execute in minecraft:overworld run fill 77973 102 3 77973 103 3 minecraft:red_stained_glass
execute in minecraft:overworld run fill 77973 102 9 77973 103 9 minecraft:red_stained_glass
execute in minecraft:overworld run setblock 77974 103 -4 minecraft:red_wall_banner[facing=east]
execute in minecraft:overworld run setblock 77974 103 4 minecraft:red_wall_banner[facing=east]
execute in minecraft:overworld run fill 77972 101 -12 77959 103 -12 minecraft:deepslate_bricks
execute in minecraft:overworld run fill 77972 104 -12 77959 104 -12 minecraft:red_concrete
execute in minecraft:overworld run fill 77967 101 -12 77965 103 -12 minecraft:air
execute in minecraft:overworld run fill 77970 102 -12 77970 103 -12 minecraft:red_stained_glass
execute in minecraft:overworld run fill 77962 102 -12 77962 103 -12 minecraft:red_stained_glass
execute in minecraft:overworld run setblock 77971 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77969 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77967 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77965 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77963 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77961 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77959 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run fill 77972 101 12 77959 103 12 minecraft:deepslate_bricks
execute in minecraft:overworld run fill 77972 104 12 77959 104 12 minecraft:red_concrete
execute in minecraft:overworld run fill 77967 101 12 77965 103 12 minecraft:air
execute in minecraft:overworld run fill 77970 102 12 77970 103 12 minecraft:red_stained_glass
execute in minecraft:overworld run fill 77962 102 12 77962 103 12 minecraft:red_stained_glass
execute in minecraft:overworld run setblock 77971 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77969 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77967 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77965 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77963 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77961 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 77959 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run fill 77975 101 -12 77973 107 -14 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 77974 101 -13 77974 107 -13 minecraft:air
execute in minecraft:overworld run fill 77973 101 -13 77973 102 -13 minecraft:air
execute in minecraft:overworld run fill 77975 104 -13 77975 104 -13 minecraft:red_stained_glass
execute in minecraft:overworld run fill 77976 108 -11 77972 108 -15 minecraft:polished_deepslate
execute in minecraft:overworld run fill 77975 107 -12 77973 107 -14 minecraft:red_concrete
execute in minecraft:overworld run fill 77974 107 -13 77974 108 -13 minecraft:air
execute in minecraft:overworld run setblock 77976 109 -14 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77976 109 -12 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77975 109 -15 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77975 109 -11 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77973 109 -15 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77973 109 -11 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77972 109 -14 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77972 109 -12 minecraft:deepslate_tile_wall
execute in minecraft:overworld run fill 77974 101 -13 77974 108 -13 minecraft:ladder[facing=south]
execute in minecraft:overworld run setblock 77973 110 -11 minecraft:red_banner[rotation=12]
execute in minecraft:overworld run fill 77975 101 12 77973 107 14 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 77974 101 13 77974 107 13 minecraft:air
execute in minecraft:overworld run fill 77973 101 13 77973 102 13 minecraft:air
execute in minecraft:overworld run fill 77975 104 13 77975 104 13 minecraft:red_stained_glass
execute in minecraft:overworld run fill 77976 108 11 77972 108 15 minecraft:polished_deepslate
execute in minecraft:overworld run fill 77975 107 12 77973 107 14 minecraft:red_concrete
execute in minecraft:overworld run fill 77974 107 13 77974 108 13 minecraft:air
execute in minecraft:overworld run setblock 77976 109 12 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77976 109 14 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77975 109 11 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77975 109 15 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77973 109 11 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77973 109 15 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77972 109 12 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 77972 109 14 minecraft:deepslate_tile_wall
execute in minecraft:overworld run fill 77974 101 13 77974 108 13 minecraft:ladder[facing=north]
execute in minecraft:overworld run setblock 77973 110 11 minecraft:red_banner[rotation=12]
execute in minecraft:overworld run fill 77964 100 -2 77966 100 -2 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 77963 100 -1 77967 100 -1 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 77963 100 0 77967 100 0 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 77963 100 1 77967 100 1 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 77964 100 2 77966 100 2 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 77966 99 -1 77964 99 1 minecraft:iron_block
execute in minecraft:overworld run setblock 77965 100 0 minecraft:beacon
execute in minecraft:overworld run setblock 77965 101 0 minecraft:red_stained_glass
execute in minecraft:overworld run setblock 77967 101 -2 minecraft:polished_blackstone_wall
execute in minecraft:overworld run setblock 77967 102 -2 minecraft:soul_lantern
execute in minecraft:overworld run setblock 77967 101 2 minecraft:polished_blackstone_wall
execute in minecraft:overworld run setblock 77967 102 2 minecraft:soul_lantern
execute in minecraft:overworld run setblock 77963 101 -2 minecraft:polished_blackstone_wall
execute in minecraft:overworld run setblock 77963 102 -2 minecraft:soul_lantern
execute in minecraft:overworld run setblock 77963 101 2 minecraft:polished_blackstone_wall
execute in minecraft:overworld run setblock 77963 102 2 minecraft:soul_lantern
execute in minecraft:overworld run fill 77961 100 -1 77959 100 1 minecraft:red_glazed_terracotta
execute in minecraft:overworld run setblock 77960 100 0 minecraft:sea_lantern
execute in minecraft:overworld run setblock 77959 102 -8 minecraft:red_wall_banner[facing=east]
execute in minecraft:overworld run setblock 77959 102 -5 minecraft:red_wall_banner[facing=east]
execute in minecraft:overworld run setblock 77959 102 5 minecraft:red_wall_banner[facing=east]
execute in minecraft:overworld run setblock 77959 102 8 minecraft:red_wall_banner[facing=east]
execute in minecraft:overworld run fill 77969 101 15 77968 101 16 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run fill 77969 101 -16 77968 101 -15 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 77962 101 16 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 77962 101 -16 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 77988 101 3 minecraft:poppy keep
execute in minecraft:overworld run setblock 77989 101 -5 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77987 101 13 minecraft:poppy keep
execute in minecraft:overworld run setblock 77992 101 15 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77988 101 -16 minecraft:azure_bluet keep
execute in minecraft:overworld run setblock 77991 101 -5 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77991 101 4 minecraft:cornflower keep
execute in minecraft:overworld run setblock 77993 101 -12 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77979 101 13 minecraft:poppy keep
execute in minecraft:overworld run setblock 77989 101 -5 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77979 101 11 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77986 101 -12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77978 101 12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77979 101 -11 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77982 101 -10 minecraft:cornflower keep
execute in minecraft:overworld run setblock 77980 101 -14 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77978 101 16 minecraft:poppy keep
execute in minecraft:overworld run setblock 77989 101 13 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77996 101 -15 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77981 101 -15 minecraft:cornflower keep
execute in minecraft:overworld run setblock 77983 101 -10 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77980 101 14 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77976 101 13 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77980 101 -12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77981 101 5 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77978 101 -17 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77981 101 -8 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77994 101 12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77984 101 13 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77988 101 -4 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77991 101 -7 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77996 101 -14 minecraft:poppy keep
execute in minecraft:overworld run setblock 77975 101 15 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77978 101 9 minecraft:azure_bluet keep
execute in minecraft:overworld run setblock 77977 101 -11 minecraft:azure_bluet keep
execute in minecraft:overworld run setblock 77977 101 9 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77987 101 12 minecraft:poppy keep
execute in minecraft:overworld run setblock 77996 101 14 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77995 101 -16 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77996 101 -12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77980 101 -4 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77983 101 -7 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77975 101 7 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77982 101 14 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77990 101 10 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77987 101 -12 minecraft:cornflower keep
execute in minecraft:overworld run setblock 77986 101 -5 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77985 101 13 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77980 101 17 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77988 101 7 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77975 101 -11 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77978 101 -14 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77978 101 -10 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77988 101 -7 minecraft:cornflower keep
execute in minecraft:overworld run setblock 77995 101 16 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77982 101 -17 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77982 101 -8 minecraft:azure_bluet keep
execute in minecraft:overworld run setblock 77984 101 17 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77983 101 -17 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77992 101 -15 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77976 101 -6 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77994 101 -15 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77980 101 -13 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77981 101 -4 minecraft:cornflower keep
execute in minecraft:overworld run setblock 77986 101 13 minecraft:poppy keep
execute in minecraft:overworld run setblock 77990 101 14 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 77978 101 7 minecraft:poppy keep
execute in minecraft:overworld run setblock 77984 101 -11 minecraft:poppy keep
execute in minecraft:overworld run setblock 77976 101 4 minecraft:cornflower keep
execute in minecraft:overworld run setblock 77976 101 10 minecraft:poppy keep
execute in minecraft:overworld run setblock 77980 101 15 minecraft:cornflower keep
execute in minecraft:overworld run setblock 77976 101 -4 minecraft:dandelion keep
execute in minecraft:overworld run setblock 77985 101 -3 minecraft:short_grass keep
execute in minecraft:overworld run setblock 77985 101 -8 minecraft:dandelion keep
execute in minecraft:overworld run summon minecraft:text_display 77965.5 104.3 0.5 {Tags:["mg_holo","mg_ctfh","mg_ctfh_r"],billboard:"center",background:0,shadow:true,text:{"text": "⚑ Flagge Rot", "color": "red", "italic": false, "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
execute in minecraft:overworld run setblock 77965 102 0 minecraft:red_banner[rotation=12]{patterns:[{pattern:"minecraft:rhombus",color:"white"},{pattern:"minecraft:border",color:"black"}]}
execute in minecraft:overworld run fill 78003 100 -1 78026 100 1 minecraft:dirt_path
execute in minecraft:overworld run fill 78008 100 -1 78009 100 1 minecraft:coarse_dirt
execute in minecraft:overworld run fill 78019 100 -1 78020 100 1 minecraft:coarse_dirt
execute in minecraft:overworld run fill 78009 101 -3 78009 102 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78009 103 -4 minecraft:mossy_stone_brick_slab[type=bottom]
execute in minecraft:overworld run setblock 78009 103 -5 minecraft:mossy_stone_brick_slab[type=bottom]
execute in minecraft:overworld run fill 78009 101 -7 78011 101 -7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 78020 101 -6 78020 104 -6 minecraft:stone_bricks
execute in minecraft:overworld run fill 78020 101 -10 78020 104 -10 minecraft:stone_bricks
execute in minecraft:overworld run fill 78020 105 -6 78020 105 -10 minecraft:stone_brick_slab[type=bottom]
execute in minecraft:overworld run setblock 78020 104 -8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 78020 104 -7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 78020 104 -9 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78020 102 -10 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78020 103 -6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 78011 101 -13 78012 101 -13 minecraft:hay_block[axis=x]
execute in minecraft:overworld run setblock 78011 102 -13 minecraft:hay_block[axis=x]
execute in minecraft:overworld run setblock 78012 101 -14 minecraft:hay_block[axis=z]
execute in minecraft:overworld run fill 78016 101 -15 78017 102 -16 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 78017 101 -14 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 78005 101 -3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 78005 102 -3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 78005 103 -3 minecraft:lantern
execute in minecraft:overworld run setblock 78024 101 -3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 78024 102 -3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 78024 103 -3 minecraft:lantern
execute in minecraft:overworld run fill 78009 101 3 78009 102 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run setblock 78009 103 4 minecraft:mossy_stone_brick_slab[type=bottom]
execute in minecraft:overworld run setblock 78009 103 5 minecraft:mossy_stone_brick_slab[type=bottom]
execute in minecraft:overworld run fill 78009 101 7 78011 101 7 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 78020 101 6 78020 104 6 minecraft:stone_bricks
execute in minecraft:overworld run fill 78020 101 10 78020 104 10 minecraft:stone_bricks
execute in minecraft:overworld run fill 78020 105 6 78020 105 10 minecraft:stone_brick_slab[type=bottom]
execute in minecraft:overworld run setblock 78020 104 8 minecraft:stone_bricks
execute in minecraft:overworld run setblock 78020 104 7 minecraft:stone_bricks
execute in minecraft:overworld run setblock 78020 104 9 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78020 102 10 minecraft:cracked_stone_bricks
execute in minecraft:overworld run setblock 78020 103 6 minecraft:mossy_stone_bricks
execute in minecraft:overworld run fill 78011 101 13 78012 101 13 minecraft:hay_block[axis=x]
execute in minecraft:overworld run setblock 78011 102 13 minecraft:hay_block[axis=x]
execute in minecraft:overworld run setblock 78012 101 14 minecraft:hay_block[axis=z]
execute in minecraft:overworld run fill 78016 101 15 78017 102 16 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 78017 101 14 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 78005 101 3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 78005 102 3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 78005 103 3 minecraft:lantern
execute in minecraft:overworld run setblock 78024 101 3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 78024 102 3 minecraft:spruce_fence
execute in minecraft:overworld run setblock 78024 103 3 minecraft:lantern
execute in minecraft:overworld run fill 78015 101 -1 78016 102 0 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 78015 101 1 minecraft:spruce_planks
execute in minecraft:overworld run setblock 78016 101 1 minecraft:barrel[facing=up]
execute in minecraft:overworld run setblock 78015 103 -1 minecraft:spruce_slab[type=bottom]
execute in minecraft:overworld run fill 78005 103 12 78009 104 16 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78006 105 13 78008 105 15 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 78007 106 14 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78007 101 14 78007 105 14 minecraft:oak_log
execute in minecraft:overworld run fill 78005 103 -16 78009 104 -12 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78006 105 -15 78008 105 -13 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 78007 106 -14 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78007 101 -14 78007 105 -14 minecraft:oak_log
execute in minecraft:overworld run fill 78020 103 13 78024 104 17 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78021 105 14 78023 105 16 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 78022 106 15 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78022 101 15 78022 105 15 minecraft:oak_log
execute in minecraft:overworld run fill 78020 103 -17 78024 104 -13 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78021 105 -16 78023 105 -14 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 78022 106 -15 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78022 101 -15 78022 105 -15 minecraft:oak_log
execute in minecraft:overworld run fill 78011 103 -11 78015 104 -7 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78012 105 -10 78014 105 -8 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 78013 106 -9 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78013 101 -9 78013 105 -9 minecraft:oak_log
execute in minecraft:overworld run fill 78011 103 7 78015 104 11 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78012 105 8 78014 105 10 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run setblock 78013 106 9 minecraft:oak_leaves[persistent=true] keep
execute in minecraft:overworld run fill 78013 101 9 78013 105 9 minecraft:oak_log
execute in minecraft:overworld run fill 78028 100 -11 78041 100 11 minecraft:stone_bricks
execute in minecraft:overworld run fill 78028 100 -1 78041 100 1 minecraft:blue_concrete
execute in minecraft:overworld run fill 78028 99 -11 78041 99 11 minecraft:stone
execute in minecraft:overworld run setblock 78030 100 -7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78030 100 7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78033 100 -7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78033 100 7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78037 100 -7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78037 100 7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78040 100 -7 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78040 100 7 minecraft:sea_lantern
execute in minecraft:overworld run fill 78027 101 -11 78027 103 11 minecraft:deepslate_bricks
execute in minecraft:overworld run fill 78027 104 -11 78027 104 11 minecraft:blue_concrete
execute in minecraft:overworld run setblock 78027 105 -11 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 -9 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 -7 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 -5 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 -3 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 -1 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 1 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 3 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 5 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 7 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 9 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78027 105 11 minecraft:deepslate_brick_wall
execute in minecraft:overworld run fill 78027 101 -1 78027 103 1 minecraft:air
execute in minecraft:overworld run fill 78027 101 6 78027 103 7 minecraft:air
execute in minecraft:overworld run fill 78027 101 -7 78027 103 -6 minecraft:air
execute in minecraft:overworld run fill 78027 102 -9 78027 103 -9 minecraft:blue_stained_glass
execute in minecraft:overworld run fill 78027 102 -3 78027 103 -3 minecraft:blue_stained_glass
execute in minecraft:overworld run fill 78027 102 3 78027 103 3 minecraft:blue_stained_glass
execute in minecraft:overworld run fill 78027 102 9 78027 103 9 minecraft:blue_stained_glass
execute in minecraft:overworld run setblock 78026 103 -4 minecraft:blue_wall_banner[facing=west]
execute in minecraft:overworld run setblock 78026 103 4 minecraft:blue_wall_banner[facing=west]
execute in minecraft:overworld run fill 78028 101 -12 78041 103 -12 minecraft:deepslate_bricks
execute in minecraft:overworld run fill 78028 104 -12 78041 104 -12 minecraft:blue_concrete
execute in minecraft:overworld run fill 78033 101 -12 78035 103 -12 minecraft:air
execute in minecraft:overworld run fill 78030 102 -12 78030 103 -12 minecraft:blue_stained_glass
execute in minecraft:overworld run fill 78038 102 -12 78038 103 -12 minecraft:blue_stained_glass
execute in minecraft:overworld run setblock 78029 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78031 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78033 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78035 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78037 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78039 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78041 105 -12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run fill 78028 101 12 78041 103 12 minecraft:deepslate_bricks
execute in minecraft:overworld run fill 78028 104 12 78041 104 12 minecraft:blue_concrete
execute in minecraft:overworld run fill 78033 101 12 78035 103 12 minecraft:air
execute in minecraft:overworld run fill 78030 102 12 78030 103 12 minecraft:blue_stained_glass
execute in minecraft:overworld run fill 78038 102 12 78038 103 12 minecraft:blue_stained_glass
execute in minecraft:overworld run setblock 78029 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78031 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78033 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78035 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78037 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78039 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run setblock 78041 105 12 minecraft:deepslate_brick_wall
execute in minecraft:overworld run fill 78025 101 -12 78027 107 -14 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 78026 101 -13 78026 107 -13 minecraft:air
execute in minecraft:overworld run fill 78027 101 -13 78027 102 -13 minecraft:air
execute in minecraft:overworld run fill 78025 104 -13 78025 104 -13 minecraft:blue_stained_glass
execute in minecraft:overworld run fill 78024 108 -11 78028 108 -15 minecraft:polished_deepslate
execute in minecraft:overworld run fill 78025 107 -12 78027 107 -14 minecraft:blue_concrete
execute in minecraft:overworld run fill 78026 107 -13 78026 108 -13 minecraft:air
execute in minecraft:overworld run setblock 78024 109 -14 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78024 109 -12 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78025 109 -15 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78025 109 -11 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78027 109 -15 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78027 109 -11 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78028 109 -14 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78028 109 -12 minecraft:deepslate_tile_wall
execute in minecraft:overworld run fill 78026 101 -13 78026 108 -13 minecraft:ladder[facing=south]
execute in minecraft:overworld run setblock 78027 110 -11 minecraft:blue_banner[rotation=4]
execute in minecraft:overworld run fill 78025 101 12 78027 107 14 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 78026 101 13 78026 107 13 minecraft:air
execute in minecraft:overworld run fill 78027 101 13 78027 102 13 minecraft:air
execute in minecraft:overworld run fill 78025 104 13 78025 104 13 minecraft:blue_stained_glass
execute in minecraft:overworld run fill 78024 108 11 78028 108 15 minecraft:polished_deepslate
execute in minecraft:overworld run fill 78025 107 12 78027 107 14 minecraft:blue_concrete
execute in minecraft:overworld run fill 78026 107 13 78026 108 13 minecraft:air
execute in minecraft:overworld run setblock 78024 109 12 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78024 109 14 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78025 109 11 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78025 109 15 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78027 109 11 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78027 109 15 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78028 109 12 minecraft:deepslate_tile_wall
execute in minecraft:overworld run setblock 78028 109 14 minecraft:deepslate_tile_wall
execute in minecraft:overworld run fill 78026 101 13 78026 108 13 minecraft:ladder[facing=north]
execute in minecraft:overworld run setblock 78027 110 11 minecraft:blue_banner[rotation=4]
execute in minecraft:overworld run fill 78034 100 -2 78036 100 -2 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 78033 100 -1 78037 100 -1 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 78033 100 0 78037 100 0 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 78033 100 1 78037 100 1 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 78034 100 2 78036 100 2 minecraft:polished_blackstone_bricks
execute in minecraft:overworld run fill 78034 99 -1 78036 99 1 minecraft:iron_block
execute in minecraft:overworld run setblock 78035 100 0 minecraft:beacon
execute in minecraft:overworld run setblock 78035 101 0 minecraft:blue_stained_glass
execute in minecraft:overworld run setblock 78033 101 -2 minecraft:polished_blackstone_wall
execute in minecraft:overworld run setblock 78033 102 -2 minecraft:soul_lantern
execute in minecraft:overworld run setblock 78033 101 2 minecraft:polished_blackstone_wall
execute in minecraft:overworld run setblock 78033 102 2 minecraft:soul_lantern
execute in minecraft:overworld run setblock 78037 101 -2 minecraft:polished_blackstone_wall
execute in minecraft:overworld run setblock 78037 102 -2 minecraft:soul_lantern
execute in minecraft:overworld run setblock 78037 101 2 minecraft:polished_blackstone_wall
execute in minecraft:overworld run setblock 78037 102 2 minecraft:soul_lantern
execute in minecraft:overworld run fill 78039 100 -1 78041 100 1 minecraft:blue_glazed_terracotta
execute in minecraft:overworld run setblock 78040 100 0 minecraft:sea_lantern
execute in minecraft:overworld run setblock 78041 102 -8 minecraft:blue_wall_banner[facing=west]
execute in minecraft:overworld run setblock 78041 102 -5 minecraft:blue_wall_banner[facing=west]
execute in minecraft:overworld run setblock 78041 102 5 minecraft:blue_wall_banner[facing=west]
execute in minecraft:overworld run setblock 78041 102 8 minecraft:blue_wall_banner[facing=west]
execute in minecraft:overworld run fill 78031 101 15 78032 101 16 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run fill 78031 101 -16 78032 101 -15 minecraft:azalea_leaves[persistent=true]
execute in minecraft:overworld run setblock 78038 101 16 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 78038 101 -16 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 78012 101 3 minecraft:poppy keep
execute in minecraft:overworld run setblock 78011 101 -5 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78013 101 13 minecraft:poppy keep
execute in minecraft:overworld run setblock 78008 101 15 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78012 101 -16 minecraft:azure_bluet keep
execute in minecraft:overworld run setblock 78009 101 -5 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78009 101 4 minecraft:cornflower keep
execute in minecraft:overworld run setblock 78007 101 -12 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78021 101 13 minecraft:poppy keep
execute in minecraft:overworld run setblock 78011 101 -5 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78021 101 11 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78014 101 -12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78022 101 12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78021 101 -11 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78018 101 -10 minecraft:cornflower keep
execute in minecraft:overworld run setblock 78020 101 -14 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78022 101 16 minecraft:poppy keep
execute in minecraft:overworld run setblock 78011 101 13 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78004 101 -15 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78019 101 -15 minecraft:cornflower keep
execute in minecraft:overworld run setblock 78017 101 -10 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78020 101 14 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78024 101 13 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78020 101 -12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78019 101 5 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78022 101 -17 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78019 101 -8 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78006 101 12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78016 101 13 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78012 101 -4 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78009 101 -7 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78004 101 -14 minecraft:poppy keep
execute in minecraft:overworld run setblock 78025 101 15 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78022 101 9 minecraft:azure_bluet keep
execute in minecraft:overworld run setblock 78023 101 -11 minecraft:azure_bluet keep
execute in minecraft:overworld run setblock 78023 101 9 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78013 101 12 minecraft:poppy keep
execute in minecraft:overworld run setblock 78004 101 14 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78005 101 -16 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78004 101 -12 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78020 101 -4 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78017 101 -7 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78025 101 7 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78018 101 14 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78010 101 10 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78013 101 -12 minecraft:cornflower keep
execute in minecraft:overworld run setblock 78014 101 -5 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78015 101 13 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78020 101 17 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78012 101 7 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78025 101 -11 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78022 101 -14 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78022 101 -10 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78012 101 -7 minecraft:cornflower keep
execute in minecraft:overworld run setblock 78005 101 16 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78018 101 -17 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78018 101 -8 minecraft:azure_bluet keep
execute in minecraft:overworld run setblock 78016 101 17 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78017 101 -17 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78008 101 -15 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78024 101 -6 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78006 101 -15 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78020 101 -13 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78019 101 -4 minecraft:cornflower keep
execute in minecraft:overworld run setblock 78014 101 13 minecraft:poppy keep
execute in minecraft:overworld run setblock 78010 101 14 minecraft:oxeye_daisy keep
execute in minecraft:overworld run setblock 78022 101 7 minecraft:poppy keep
execute in minecraft:overworld run setblock 78016 101 -11 minecraft:poppy keep
execute in minecraft:overworld run setblock 78024 101 4 minecraft:cornflower keep
execute in minecraft:overworld run setblock 78024 101 10 minecraft:poppy keep
execute in minecraft:overworld run setblock 78020 101 15 minecraft:cornflower keep
execute in minecraft:overworld run setblock 78024 101 -4 minecraft:dandelion keep
execute in minecraft:overworld run setblock 78015 101 -3 minecraft:short_grass keep
execute in minecraft:overworld run setblock 78015 101 -8 minecraft:dandelion keep
execute in minecraft:overworld run summon minecraft:text_display 78035.5 104.3 0.5 {Tags:["mg_holo","mg_ctfh","mg_ctfh_b"],billboard:"center",background:0,shadow:true,text:{"text": "⚑ Flagge Blau", "color": "blue", "italic": false, "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.3f,1.3f,1.3f]}}
execute in minecraft:overworld run setblock 78035 102 0 minecraft:blue_banner[rotation=4]{patterns:[{pattern:"minecraft:rhombus",color:"white"},{pattern:"minecraft:border",color:"black"}]}
execute in minecraft:overworld run kill @e[type=minecraft:item,x=77956,y=94,z=-20,dx=88,dy=34,dz=40]
