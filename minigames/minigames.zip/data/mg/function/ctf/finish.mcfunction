execute as @a[tag=mg_ctf] run function mg:hub/enter
tag @a remove mg_ctf
tag @a remove mg_al_ctf
scoreboard players set #ctf mg 0
bossbar set mg:ctf players
bossbar set mg:ctf visible false
tag @a remove mg_ctf_r
tag @a remove mg_ctf_b
tag @a remove mg_ctf_c
tag @a remove mg_ctf_kl
tag @a remove mg_ctf_cam
team empty mg_ctf_rot
team empty mg_ctf_blau
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=77956,y=94,z=-20,dx=88,dy=34,dz=40]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=77952,dx=96,y=60,dy=90,z=-48,dz=96]
