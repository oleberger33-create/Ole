execute unless score #ctf_fr mg matches 0 run return 0
scoreboard players add #ctf_sr mg 1
function mg:ctf/home_b
tag @s remove mg_ctf_c
effect clear @s minecraft:glowing
item replace entity @s armor.head with minecraft:leather_helmet[minecraft:dyed_color=11546150,minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:dyed_color","minecraft:unbreakable"]}]
scoreboard players add @s mg_coins 3
scoreboard players add @s mg_ctf_cap 1
tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s"}, {"text": " hat die Flagge erobert! ", "color": "gold", "italic": false, "bold": true}, {"text": "Rot ", "color": "red", "italic": false, "bold": true}, {"score": {"name": "#ctf_sr", "objective": "mg"}, "color": "white", "bold": true}, {"text": " : ", "color": "gray", "italic": false}, {"score": {"name": "#ctf_sb", "objective": "mg"}, "color": "white", "bold": true}, {"text": " Blau", "color": "blue", "italic": false, "bold": true}]
title @a[tag=mg_ctf] times 5 40 15
title @a[tag=mg_ctf] subtitle {"text": "", "color": "gray", "italic": false}
title @a[tag=mg_ctf] title {"text": "TEAM ROT PUNKTET!", "color": "red", "italic": false, "bold": true}
title @a[tag=mg_ctf] subtitle [{"text": "Rot ", "color": "red", "italic": false, "bold": true}, {"score": {"name": "#ctf_sr", "objective": "mg"}, "color": "white", "bold": true}, {"text": " : ", "color": "gray", "italic": false}, {"score": {"name": "#ctf_sb", "objective": "mg"}, "color": "white", "bold": true}, {"text": " Blau", "color": "blue", "italic": false, "bold": true}]
execute as @a[tag=mg_ctf,tag=mg_ctf_r] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1.2
execute as @a[tag=mg_ctf,tag=mg_ctf_b] at @s run playsound minecraft:entity.wither.ambient master @s ~ ~ ~ 0.5 1.5
execute in minecraft:overworld run summon minecraft:firework_rocket 77965.5 103 0.5 {LifeTime:25,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"star",colors:[I;11546150],fade_colors:[I;16777215],has_twinkle:true}]}}}}
