tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Das gegnerische Team hat das Spiel verlassen.", "color": "yellow", "italic": false}]
execute if entity @a[tag=mg_al_ctf,tag=mg_ctf_r] run return run function mg:ctf/win_r
execute if entity @a[tag=mg_al_ctf,tag=mg_ctf_b] run return run function mg:ctf/win_b
function mg:ctf/end
