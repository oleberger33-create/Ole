execute as @a[tag=mg_al_ctf,gamemode=adventure] store result score @s mg_ctf_a run clear @s minecraft:stone_sword 0
give @a[tag=mg_al_ctf,gamemode=adventure,scores={mg_ctf_a=0}] minecraft:stone_sword[minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:unbreakable"]}]
execute as @a[tag=mg_al_ctf,gamemode=adventure] store result score @s mg_ctf_a run clear @s minecraft:bow 0
give @a[tag=mg_al_ctf,gamemode=adventure,scores={mg_ctf_a=0}] minecraft:bow[minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:unbreakable"]}]
