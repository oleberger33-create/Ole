tag @s remove mg_q_ctf
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Capture the Flag-Warteschlange verlassen.", "color": "gray"}]
