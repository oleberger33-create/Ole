scoreboard players set #ctf_fr mg 1
execute in minecraft:overworld run setblock 77965 102 0 minecraft:air
tag @s add mg_ctf_c
item replace entity @s armor.head with minecraft:red_banner[minecraft:banner_patterns=[{pattern:"minecraft:rhombus",color:"white"},{pattern:"minecraft:border",color:"black"}],minecraft:enchantments={"minecraft:binding_curse":1},minecraft:custom_name={"text": "Flagge Rot", "color": "red", "italic": false, "bold": true}]
effect give @s minecraft:glowing infinite 0 true
data merge entity @e[type=minecraft:text_display,tag=mg_ctfh_r,limit=1] {text:{"text": "⚑ Flagge gestohlen!", "color": "gold", "italic": false, "bold": true}}
tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s"}, {"text": " hat die Flagge von ", "color": "white", "italic": false}, {"text": "Team Rot", "color": "red", "italic": false, "bold": true}, {"text": " gestohlen!", "color": "white", "italic": false}]
title @a[tag=mg_ctf,tag=mg_ctf_r] times 5 40 15
title @a[tag=mg_ctf,tag=mg_ctf_r] subtitle {"text": "Schnappt euch den leuchtenden Dieb!", "color": "gray", "italic": false}
title @a[tag=mg_ctf,tag=mg_ctf_r] title {"text": "FLAGGE GESTOHLEN!", "color": "red", "italic": false, "bold": true}
title @s times 5 40 15
title @s subtitle {"text": "Bring sie zu deiner Basis!", "color": "yellow", "italic": false}
title @s title {"text": "DU HAST DIE FLAGGE!", "color": "gold", "italic": false, "bold": true}
execute as @a[tag=mg_ctf,tag=mg_ctf_r] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 1 0.6
execute as @a[tag=mg_ctf,tag=mg_ctf_b] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.6
execute at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.4
