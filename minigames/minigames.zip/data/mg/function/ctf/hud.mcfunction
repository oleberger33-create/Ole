scoreboard players operation #ctf_rem mg = #ctf_len mg
execute if score #ctf_sd mg matches 1 run scoreboard players set #ctf_rem mg 12000
scoreboard players operation #ctf_rem mg -= #ctf_t mg
execute if score #ctf_rem mg matches ..0 run scoreboard players set #ctf_rem mg 0
scoreboard players operation #ctf_s mg = #ctf_rem mg
scoreboard players add #ctf_s mg 19
scoreboard players operation #ctf_s mg /= #20 mg
scoreboard players operation #ctf_mm mg = #ctf_s mg
scoreboard players operation #ctf_mm mg /= #60 mg
scoreboard players operation #ctf_ss mg = #ctf_s mg
scoreboard players operation #ctf_ss mg %= #60 mg
scoreboard players operation #ctf_s10 mg = #ctf_ss mg
scoreboard players operation #ctf_s10 mg /= #10 mg
scoreboard players operation #ctf_s1 mg = #ctf_ss mg
scoreboard players operation #ctf_s1 mg %= #10 mg
execute store result bossbar mg:ctf value run scoreboard players get #ctf_rem mg
execute if score #ctf_sd mg matches 0 run bossbar set mg:ctf name [{"text": "Rot ", "color": "red", "italic": false, "bold": true}, {"score": {"name": "#ctf_sr", "objective": "mg"}, "color": "white", "bold": true}, {"text": " : ", "color": "gray", "italic": false}, {"score": {"name": "#ctf_sb", "objective": "mg"}, "color": "white", "bold": true}, {"text": " Blau", "color": "blue", "italic": false, "bold": true}, {"text": "     ⌛ ", "color": "gray", "italic": false}, {"score": {"name": "#ctf_mm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white", "italic": false}, {"score": {"name": "#ctf_s10", "objective": "mg"}, "color": "white"}, {"score": {"name": "#ctf_s1", "objective": "mg"}, "color": "white"}]
execute if score #ctf_sd mg matches 1 run bossbar set mg:ctf name [{"text": "Rot ", "color": "red", "italic": false, "bold": true}, {"score": {"name": "#ctf_sr", "objective": "mg"}, "color": "white", "bold": true}, {"text": " : ", "color": "gray", "italic": false}, {"score": {"name": "#ctf_sb", "objective": "mg"}, "color": "white", "bold": true}, {"text": " Blau", "color": "blue", "italic": false, "bold": true}, {"text": "     VERLÄNGERUNG – nächste Eroberung gewinnt!  ⌛ ", "color": "light_purple", "italic": false, "bold": true}, {"score": {"name": "#ctf_mm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white", "italic": false}, {"score": {"name": "#ctf_s10", "objective": "mg"}, "color": "white"}, {"score": {"name": "#ctf_s1", "objective": "mg"}, "color": "white"}]
bossbar set mg:ctf players @a[tag=mg_ctf]
execute if score #ctf_fr mg matches 0 run title @a[tag=mg_al_ctf,tag=mg_ctf_r,gamemode=adventure,tag=mg_ctf_c] actionbar {"text": "⚑ Du hast die Flagge! Lauf zu deiner Basis!", "color": "gold", "italic": false, "bold": true}
execute if score #ctf_fr mg matches 1 run title @a[tag=mg_al_ctf,tag=mg_ctf_r,gamemode=adventure,tag=mg_ctf_c] actionbar {"text": "⚑ Eure Flagge ist weg – erst zurückholen, dann punkten!", "color": "red", "italic": false, "bold": true}
execute if score #ctf_fr mg matches 1 run title @a[tag=mg_al_ctf,tag=mg_ctf_r,gamemode=adventure,tag=!mg_ctf_c] actionbar {"text": "Eure Flagge wurde gestohlen! Jagt den leuchtenden Dieb!", "color": "red", "italic": false, "bold": true}
execute if score #ctf_fr mg matches 0 if score #ctf_fb mg matches 1 run title @a[tag=mg_al_ctf,tag=mg_ctf_r,gamemode=adventure,tag=!mg_ctf_c] actionbar {"text": "Ein Teamkollege hat die Flagge – gib ihm Deckung!", "color": "green", "italic": false}
execute if score #ctf_fr mg matches 0 if score #ctf_fb mg matches 0 run title @a[tag=mg_al_ctf,tag=mg_ctf_r,gamemode=adventure,tag=!mg_ctf_c] actionbar {"text": "Hol die Flagge von Team Blau!", "color": "blue", "italic": false}
execute if score #ctf_fb mg matches 0 run title @a[tag=mg_al_ctf,tag=mg_ctf_b,gamemode=adventure,tag=mg_ctf_c] actionbar {"text": "⚑ Du hast die Flagge! Lauf zu deiner Basis!", "color": "gold", "italic": false, "bold": true}
execute if score #ctf_fb mg matches 1 run title @a[tag=mg_al_ctf,tag=mg_ctf_b,gamemode=adventure,tag=mg_ctf_c] actionbar {"text": "⚑ Eure Flagge ist weg – erst zurückholen, dann punkten!", "color": "red", "italic": false, "bold": true}
execute if score #ctf_fb mg matches 1 run title @a[tag=mg_al_ctf,tag=mg_ctf_b,gamemode=adventure,tag=!mg_ctf_c] actionbar {"text": "Eure Flagge wurde gestohlen! Jagt den leuchtenden Dieb!", "color": "red", "italic": false, "bold": true}
execute if score #ctf_fb mg matches 0 if score #ctf_fr mg matches 1 run title @a[tag=mg_al_ctf,tag=mg_ctf_b,gamemode=adventure,tag=!mg_ctf_c] actionbar {"text": "Ein Teamkollege hat die Flagge – gib ihm Deckung!", "color": "green", "italic": false}
execute if score #ctf_fb mg matches 0 if score #ctf_fr mg matches 0 run title @a[tag=mg_al_ctf,tag=mg_ctf_b,gamemode=adventure,tag=!mg_ctf_c] actionbar {"text": "Hol die Flagge von Team Rot!", "color": "red", "italic": false}
