execute store result score #n mg if entity @a[tag=mg_q_ctf,tag=mg_hub]
execute if score #n mg matches ..1 run execute in minecraft:overworld run forceload remove 77952 -48 78048 48
execute if score #n mg matches ..1 run tellraw @a[tag=mg_q_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zu wenig Spieler – Capture the Flag abgebrochen.", "color": "red"}]
execute if score #n mg matches ..1 run return run scoreboard players set #ctf mg 0
scoreboard players remove #ctf_cd mg 1
scoreboard players operation #s mg = #ctf_cd mg
scoreboard players operation #s mg /= #20 mg
execute as @a[tag=mg_q_ctf] run title @s actionbar [{"text":"Capture the Flag startet in ","color":"blue"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true},{"text":" s","color":"blue"}]
execute if score #ctf_cd mg matches 60 as @a[tag=mg_q_ctf] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #ctf_cd mg matches 40 as @a[tag=mg_q_ctf] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #ctf_cd mg matches 20 as @a[tag=mg_q_ctf] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #ctf_cd mg matches ..0 in minecraft:overworld if loaded 77960 100 -40 if loaded 78040 100 40 run function mg:ctf/start
