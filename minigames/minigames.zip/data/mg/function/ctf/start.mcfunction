function mg:ctf/build
tag @a[tag=mg_q_ctf,tag=mg_hub,limit=16,sort=random] add mg_ctf
tag @a[tag=mg_ctf] remove mg_q_ctf
execute as @a[tag=mg_ctf] run function mg:q/leave_all
tag @a[tag=mg_ctf] remove mg_hub
clear @a[tag=mg_ctf]
effect clear @a[tag=mg_ctf]
gamemode adventure @a[tag=mg_ctf]
tag @a[tag=mg_ctf] add mg_al_ctf
scoreboard players set @a[tag=mg_ctf] mg_deaths 0
execute as @a[tag=mg_ctf] run execute in minecraft:overworld run spawnpoint @s 78000 122 30
scoreboard players set #ctf_t mg 0
scoreboard players set #ctf_fr mg 0
scoreboard players set #ctf_fb mg 0
scoreboard players set #ctf_sr mg 0
scoreboard players set #ctf_sb mg 0
scoreboard players set #ctf_sd mg 0
tag @a[tag=mg_ctf] remove mg_ctf_r
tag @a[tag=mg_ctf] remove mg_ctf_b
tag @a[tag=mg_ctf] remove mg_ctf_c
tag @a[tag=mg_ctf] remove mg_ctf_kl
tag @a[tag=mg_ctf] remove mg_ctf_cam
scoreboard players set @a[tag=mg_ctf] mg_ctf_rs 0
scoreboard players set @a[tag=mg_ctf] mg_ctf_k 0
scoreboard players set @a[tag=mg_ctf] mg_ctf_cap 0
scoreboard players set @a[tag=mg_ctf] mg_ctf_cn 0
execute as @a[tag=mg_ctf,sort=random] run function mg:ctf/assign
execute as @a[tag=mg_ctf,tag=mg_ctf_r] run function mg:ctf/spawn_r
execute as @a[tag=mg_ctf,tag=mg_ctf_b] run function mg:ctf/spawn_b
bossbar set mg:ctf color yellow
bossbar set mg:ctf max 9600
bossbar set mg:ctf value 9600
bossbar set mg:ctf players @a[tag=mg_ctf]
bossbar set mg:ctf visible true
function mg:ctf/hud
execute in minecraft:overworld run forceload remove 77952 -48 78048 48
scoreboard players set #ctf mg 2
title @a[tag=mg_ctf] times 5 50 10
title @a[tag=mg_ctf] title {"text": "CAPTURE THE FLAG", "color": "blue", "bold": true}
title @a[tag=mg_ctf] subtitle {"text": "Klau die Flagge!", "color": "white"}
tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Team Rot gegen Team Blau. Lauf zur gegnerischen Burg und tritt auf ihr Flaggen-Podest, um die Flagge zu klauen. Bring sie zu deiner eigenen Flagge – das zählt nur, wenn deine Flagge zuhause ist! Der Träger leuchtet; stirbt er, fliegt die Flagge zurück. Wer zuerst 3 Flaggen erobert, gewinnt – sonst zählt der Stand nach 8 Minuten. Du respawnst nach 3 Sekunden in deiner Basis.", "color": "gray"}]
tellraw @a[tag=mg_ctf] [{"text": "  "}, {"text": "[Spiel verlassen]", "color": "red", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 99"}}]
