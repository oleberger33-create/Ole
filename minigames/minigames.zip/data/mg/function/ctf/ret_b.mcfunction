function mg:ctf/home_b
tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die Flagge von ", "color": "gray", "italic": false}, {"text": "Team Blau", "color": "blue", "italic": false, "bold": true}, {"text": " ist zurück in der Basis.", "color": "gray", "italic": false}]
title @a[tag=mg_ctf,tag=mg_ctf_b] actionbar {"text": "Eure Flagge ist wieder zuhause!", "color": "green", "italic": false, "bold": true}
execute as @a[tag=mg_ctf] at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 0.8 1.3
