tag @a[tag=mg_ctf] remove mg_al_ctf
tag @a[tag=mg_ctf,tag=mg_ctf_b] add mg_al_ctf
tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Team Blau gewinnt! ", "color": "blue", "italic": false, "bold": true}, {"text": "Rot ", "color": "red", "italic": false, "bold": true}, {"score": {"name": "#ctf_sr", "objective": "mg"}, "color": "white", "bold": true}, {"text": " : ", "color": "gray", "italic": false}, {"score": {"name": "#ctf_sb", "objective": "mg"}, "color": "white", "bold": true}, {"text": " Blau", "color": "blue", "italic": false, "bold": true}]
title @a[tag=mg_ctf] subtitle {"text": "Team Blau gewinnt!", "color": "blue", "italic": false, "bold": true}
execute as @a[tag=mg_ctf,tag=mg_ctf_b] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
execute as @a[tag=mg_ctf,tag=!mg_ctf_b] at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.4 1.2
function mg:ctf/end
