execute store result score #elim mg if entity @a[tag=mg_ctf,tag=!mg_al_ctf]
execute if score #elim mg matches 1.. as @a[tag=mg_al_ctf] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Capture the Flag!", "color": "white"}]
execute unless entity @a[tag=mg_al_ctf] run tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Unentschieden – niemand hat überlebt.", "color": "gray"}]
execute if score #elim mg matches 1.. run scoreboard players add @a[tag=mg_al_ctf] mg_wins 1
execute if score #elim mg matches 1.. run scoreboard players add @a[tag=mg_al_ctf] mg_coins 10
execute if score #elim mg matches 0 if entity @a[tag=mg_al_ctf] run tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Keine Wertung – die anderen haben das Spiel verlassen.", "color": "gray"}]
title @a[tag=mg_ctf] title {"text": "Spiel vorbei!", "color": "blue", "bold": true}
execute as @a[tag=mg_al_ctf] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720],has_twinkle:true}]}}}}
scoreboard players set #ctf mg 3
schedule function mg:ctf/finish 100t
