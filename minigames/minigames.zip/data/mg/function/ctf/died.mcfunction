scoreboard players set @s mg_deaths 0
execute if entity @s[tag=mg_ctf_c] run tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s"}, {"text": " hat die Flagge verloren!", "color": "yellow", "italic": false}]
tag @s remove mg_ctf_c
execute if entity @a[tag=mg_ctf_kl] run tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "☠ ", "color": "dark_red", "italic": false}, {"selector": "@s"}, {"text": " wurde von ", "color": "gray", "italic": false}, {"selector": "@a[tag=mg_ctf_kl,limit=1]"}, {"text": " erledigt.", "color": "gray", "italic": false}]
execute unless entity @a[tag=mg_ctf_kl] run tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "☠ ", "color": "dark_red", "italic": false}, {"selector": "@s"}, {"text": " ist gestorben.", "color": "gray", "italic": false}]
execute if entity @s[tag=mg_ctf_r] run function mg:ctf/dead_r
execute if entity @s[tag=mg_ctf_b] run function mg:ctf/dead_b
