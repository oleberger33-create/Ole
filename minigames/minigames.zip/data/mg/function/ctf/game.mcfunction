scoreboard players add #ctf_t mg 1
scoreboard players operation #m mg = #ctf_t mg
scoreboard players operation #m mg %= #20 mg
scoreboard players operation #m5 mg = #ctf_t mg
scoreboard players operation #m5 mg %= #5 mg
execute as @a[tag=mg_al_ctf,scores={mg_ctf_k=1..}] run tag @s add mg_ctf_kl
execute as @a[tag=mg_al_ctf,scores={mg_ctf_k=1..}] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 0.8
scoreboard players add @a[tag=mg_al_ctf,scores={mg_ctf_k=1..,mg_ctf_cn=..9}] mg_coins 1
scoreboard players add @a[tag=mg_al_ctf,scores={mg_ctf_k=1..}] mg_ctf_cn 1
execute as @a[tag=mg_al_ctf,scores={mg_deaths=1..}] run function mg:ctf/died
tag @a[tag=mg_ctf_kl] remove mg_ctf_kl
scoreboard players set @a[tag=mg_ctf,scores={mg_ctf_k=1..}] mg_ctf_k 0
execute as @a[tag=mg_al_ctf,scores={mg_ctf_rs=1..}] run function mg:ctf/rs
execute as @a[tag=mg_al_ctf,gamemode=adventure] at @s if entity @s[y=-64,dy=158] run kill @s
execute if score #ctf_fr mg matches 1 unless entity @a[tag=mg_al_ctf,tag=mg_ctf_b,tag=mg_ctf_c] run function mg:ctf/ret_r
execute if score #ctf_fr mg matches 0 in minecraft:overworld positioned 77965.5 102 0.5 as @a[tag=mg_al_ctf,tag=mg_ctf_b,tag=!mg_ctf_c,gamemode=adventure,distance=..1.6,sort=nearest,limit=1] run function mg:ctf/take_r
execute in minecraft:overworld positioned 77965.5 102 0.5 as @a[tag=mg_al_ctf,tag=mg_ctf_r,tag=mg_ctf_c,gamemode=adventure,distance=..2.6,limit=1] run function mg:ctf/cap_r
execute if score #ctf_fb mg matches 1 unless entity @a[tag=mg_al_ctf,tag=mg_ctf_r,tag=mg_ctf_c] run function mg:ctf/ret_b
execute if score #ctf_fb mg matches 0 in minecraft:overworld positioned 78035.5 102 0.5 as @a[tag=mg_al_ctf,tag=mg_ctf_r,tag=!mg_ctf_c,gamemode=adventure,distance=..1.6,sort=nearest,limit=1] run function mg:ctf/take_b
execute in minecraft:overworld positioned 78035.5 102 0.5 as @a[tag=mg_al_ctf,tag=mg_ctf_b,tag=mg_ctf_c,gamemode=adventure,distance=..2.6,limit=1] run function mg:ctf/cap_b
execute if score #m5 mg matches 0 run function mg:ctf/slow
execute if score #m mg matches 0 run execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=77956,y=94,z=-20,dx=88,dy=34,dz=40,nbt={inGround:1b}]
execute if score #m mg matches 0 run function mg:ctf/hud
execute if score #m mg matches 10 run function mg:ctf/hud
scoreboard players operation #m100 mg = #ctf_t mg
scoreboard players operation #m100 mg %= #100 mg
execute if score #m100 mg matches 50 run function mg:ctf/arrows
execute if score #ctf_t mg matches 8400 run tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 1 Minute!", "color": "yellow", "italic": false, "bold": true}]
execute if score #ctf_t mg matches 8400 run bossbar set mg:ctf color red
execute if score #ctf_t mg matches 9400.. if score #ctf_t mg matches ..9599 if score #m mg matches 0 as @a[tag=mg_ctf] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1.5
execute if score #ctf_t mg matches 11800.. if score #ctf_t mg matches ..11999 if score #m mg matches 0 as @a[tag=mg_ctf] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1.5
execute if score #m mg matches 5 run function mg:ctf/kitchk
execute if score #ctf_sr mg matches 3.. run return run function mg:ctf/win_r
execute if score #ctf_sb mg matches 3.. run return run function mg:ctf/win_b
execute if score #ctf_sd mg matches 1 if score #ctf_sr mg > #ctf_sb mg run return run function mg:ctf/win_r
execute if score #ctf_sd mg matches 1 if score #ctf_sb mg > #ctf_sr mg run return run function mg:ctf/win_b
execute unless entity @a[tag=mg_al_ctf,tag=mg_ctf_r] run return run function mg:ctf/left
execute unless entity @a[tag=mg_al_ctf,tag=mg_ctf_b] run return run function mg:ctf/left
execute if score #ctf_t mg matches 9600 run return run function mg:ctf/timeup
execute if score #ctf_t mg matches 12000.. run return run function mg:ctf/draw
