execute if score #ctf_sr mg > #ctf_sb mg run tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die Zeit ist um!", "color": "yellow", "italic": false, "bold": true}]
execute if score #ctf_sr mg > #ctf_sb mg run return run function mg:ctf/win_r
execute if score #ctf_sb mg > #ctf_sr mg run tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die Zeit ist um!", "color": "yellow", "italic": false, "bold": true}]
execute if score #ctf_sb mg > #ctf_sr mg run return run function mg:ctf/win_b
scoreboard players set #ctf_sd mg 1
bossbar set mg:ctf color purple
bossbar set mg:ctf max 2400
bossbar set mg:ctf value 2400
tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Gleichstand! ", "color": "light_purple", "italic": false, "bold": true}, {"text": "Verlängerung: Die nächste Eroberung gewinnt – du hast 2 Minuten!", "color": "white", "italic": false}]
title @a[tag=mg_ctf] times 5 40 15
title @a[tag=mg_ctf] subtitle {"text": "Die nächste Eroberung gewinnt", "color": "gray", "italic": false}
title @a[tag=mg_ctf] title {"text": "VERLÄNGERUNG!", "color": "light_purple", "italic": false, "bold": true}
execute as @a[tag=mg_ctf] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.5 1.2
