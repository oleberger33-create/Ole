execute store result score #n mg if entity @a[tag=mg_q_ctf,tag=mg_hub]
execute if score #n mg matches 2.. run scoreboard players set #ctf_cd mg 300
execute if score #n mg matches 2.. run execute in minecraft:overworld run forceload add 77952 -48 78048 48
execute if score #n mg matches 2.. run tellraw @a[tag=mg_q_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Capture the Flag startet in 15 Sekunden!", "color": "blue"}]
execute if score #n mg matches 2.. run scoreboard players set #ctf mg 1
