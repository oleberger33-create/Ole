tag @s add mg_ctf_r
team join mg_ctf_rot @s
execute in minecraft:overworld run spawnpoint @s 77960 101 0
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du spielst für ", "color": "gray", "italic": false}, {"text": "Team Rot", "color": "red", "italic": false, "bold": true}, {"text": "! Klau die blaue Flagge.", "color": "gray", "italic": false}]
