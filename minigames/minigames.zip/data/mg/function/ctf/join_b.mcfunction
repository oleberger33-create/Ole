tag @s add mg_ctf_b
team join mg_ctf_blau @s
execute in minecraft:overworld run spawnpoint @s 78040 101 0
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du spielst für ", "color": "gray", "italic": false}, {"text": "Team Blau", "color": "blue", "italic": false, "bold": true}, {"text": "! Klau die rote Flagge.", "color": "gray", "italic": false}]
