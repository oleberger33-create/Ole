execute if entity @s[tag=mg_q_ctf] run return run function mg:ctf/leave
function mg:q/leave_all
tag @s add mg_q_ctf
execute if score #ctf mg matches 1.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Capture the Flag läuft gerade – du bist in der Warteschlange für die nächste Runde.", "color": "gray"}]
tellraw @a[tag=mg_hub] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " wartet auf ", "color": "gray"}, {"text": "Capture the Flag", "color": "blue", "bold": true}, {"text": " – ", "color": "gray"}, {"text": "[Mitspielen]", "color": "green", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 64"}}]
