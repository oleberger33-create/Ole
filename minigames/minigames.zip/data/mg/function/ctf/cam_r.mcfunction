gamemode spectator @s
execute in minecraft:overworld run tp @s 77978.5 112 0.5 90 30
tag @s add mg_ctf_cam
