scoreboard players set #ctf_fb mg 0
execute in minecraft:overworld run setblock 78035 102 0 minecraft:blue_banner[rotation=4]{patterns:[{pattern:"minecraft:rhombus",color:"white"},{pattern:"minecraft:border",color:"black"}]}
data merge entity @e[type=minecraft:text_display,tag=mg_ctfh_b,limit=1] {text:{"text": "⚑ Flagge Blau", "color": "blue", "italic": false, "bold": true}}
