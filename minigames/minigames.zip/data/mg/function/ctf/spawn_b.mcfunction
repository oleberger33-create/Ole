gamemode adventure @s
execute in minecraft:overworld run tp @s 78040.5 101 0.5 90 0
function mg:ctf/kit_b
effect clear @s
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 4 true
effect give @s minecraft:resistance 3 4 true
scoreboard players set @s mg_ctf_rs 0
playsound minecraft:item.armor.equip_iron master @s ~ ~ ~ 1 1
