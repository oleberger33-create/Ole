execute if score #ctf mg matches 2 run function mg:ctf/game
