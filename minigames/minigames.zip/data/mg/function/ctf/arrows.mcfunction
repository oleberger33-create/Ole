execute as @a[tag=mg_al_ctf,gamemode=adventure] store result score @s mg_ctf_a run clear @s minecraft:arrow 0
give @a[tag=mg_al_ctf,gamemode=adventure,scores={mg_ctf_a=..7}] minecraft:arrow 1
