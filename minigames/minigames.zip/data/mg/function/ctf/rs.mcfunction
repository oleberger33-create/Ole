scoreboard players remove @s mg_ctf_rs 1
execute store result score #ctf_hp mg run data get entity @s Health
execute if score #ctf_hp mg matches ..0 if score @s mg_ctf_rs matches ..0 run scoreboard players set @s mg_ctf_rs 1
execute if score #ctf_hp mg matches 1.. if entity @s[tag=!mg_ctf_cam,tag=mg_ctf_r] run function mg:ctf/cam_r
execute if score #ctf_hp mg matches 1.. if entity @s[tag=!mg_ctf_cam,tag=mg_ctf_b] run function mg:ctf/cam_b
execute if score @s mg_ctf_rs matches 59 run title @s actionbar {"text": "Respawn in 3 ...", "color": "gray", "italic": false}
execute if score @s mg_ctf_rs matches 40 run title @s actionbar {"text": "Respawn in 2 ...", "color": "gray", "italic": false}
execute if score @s mg_ctf_rs matches 20 run title @s actionbar {"text": "Respawn in 1 ...", "color": "gray", "italic": false}
execute if score @s mg_ctf_rs matches 20 run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute unless score @s mg_ctf_rs matches ..0 run return 0
execute if entity @s[tag=mg_ctf_r] run function mg:ctf/spawn_r
execute if entity @s[tag=mg_ctf_b] run function mg:ctf/spawn_b
title @s clear
