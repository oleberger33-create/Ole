clear @s
give @s minecraft:stone_sword[minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:unbreakable"]}]
give @s minecraft:bow[minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:unbreakable"]}]
give @s minecraft:cooked_beef 8
give @s minecraft:arrow 16
item replace entity @s armor.head with minecraft:leather_helmet[minecraft:dyed_color=11546150,minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:dyed_color","minecraft:unbreakable"]}]
item replace entity @s armor.chest with minecraft:leather_chestplate[minecraft:dyed_color=11546150,minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:dyed_color","minecraft:unbreakable"]}]
item replace entity @s armor.legs with minecraft:leather_leggings[minecraft:dyed_color=11546150,minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:dyed_color","minecraft:unbreakable"]}]
item replace entity @s armor.feet with minecraft:leather_boots[minecraft:dyed_color=11546150,minecraft:unbreakable={},minecraft:tooltip_display={hidden_components:["minecraft:dyed_color","minecraft:unbreakable"]}]
