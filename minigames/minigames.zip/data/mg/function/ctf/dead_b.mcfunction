gamemode spectator @s
tag @s remove mg_ctf_cam
scoreboard players set @s mg_ctf_rs 60
title @s times 5 40 15
title @s subtitle {"text": "Respawn in 3 Sekunden ...", "color": "gray", "italic": false}
title @s title {"text": "Du bist gestorben!", "color": "red", "italic": false, "bold": true}
