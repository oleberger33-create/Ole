scoreboard players set #ctf_fr mg 0
execute in minecraft:overworld run setblock 77965 102 0 minecraft:red_banner[rotation=12]{patterns:[{pattern:"minecraft:rhombus",color:"white"},{pattern:"minecraft:border",color:"black"}]}
data merge entity @e[type=minecraft:text_display,tag=mg_ctfh_r,limit=1] {text:{"text": "⚑ Flagge Rot", "color": "red", "italic": false, "bold": true}}
