execute store result score #ctf_nr mg if entity @a[tag=mg_ctf,tag=mg_ctf_r]
execute store result score #ctf_nb mg if entity @a[tag=mg_ctf,tag=mg_ctf_b]
execute if score #ctf_nr mg <= #ctf_nb mg run return run function mg:ctf/join_r
function mg:ctf/join_b
