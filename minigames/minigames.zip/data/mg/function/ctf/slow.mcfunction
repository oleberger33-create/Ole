execute in minecraft:overworld run kill @e[type=minecraft:item,x=77956,y=94,z=-20,dx=88,dy=34,dz=40]
execute at @a[tag=mg_al_ctf,tag=mg_ctf_b,tag=mg_ctf_c] run particle minecraft:dust{color:[0.85,0.12,0.12],scale:1.5} ~ ~2.4 ~ 0.25 0.25 0.25 0 4 force
execute at @a[tag=mg_al_ctf,tag=mg_ctf_r,tag=mg_ctf_c] run particle minecraft:dust{color:[0.2,0.3,0.95],scale:1.5} ~ ~2.4 ~ 0.25 0.25 0.25 0 4 force
