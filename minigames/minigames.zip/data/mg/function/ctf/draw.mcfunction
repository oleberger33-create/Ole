tag @a[tag=mg_ctf] remove mg_al_ctf
tellraw @a[tag=mg_ctf] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die Verlängerung ist vorbei – keine Eroberung. Beide Teams verlieren!", "color": "gray", "italic": false}]
title @a[tag=mg_ctf] subtitle {"text": "Unentschieden!", "color": "gray", "italic": false, "bold": true}
function mg:ctf/end
