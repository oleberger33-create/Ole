execute store result score #n mg if entity @a[tag=mg_q_murder,tag=mg_hub]
execute if score #n mg matches ..2 run execute in minecraft:overworld run forceload remove 73968 -32 74032 32
execute if score #n mg matches ..2 run tellraw @a[tag=mg_q_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zu wenig Spieler – Murder Mystery abgebrochen.", "color": "red"}]
execute if score #n mg matches ..2 run return run scoreboard players set #murder mg 0
scoreboard players remove #murder_cd mg 1
scoreboard players operation #s mg = #murder_cd mg
scoreboard players operation #s mg /= #20 mg
execute as @a[tag=mg_q_murder] run title @s actionbar [{"text":"Murder Mystery startet in ","color":"dark_red"},{"score":{"name":"#s","objective":"mg"},"color":"white","bold":true},{"text":" s","color":"dark_red"}]
execute if score #murder_cd mg matches 60 as @a[tag=mg_q_murder] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #murder_cd mg matches 40 as @a[tag=mg_q_murder] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #murder_cd mg matches 20 as @a[tag=mg_q_murder] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score #murder_cd mg matches ..0 in minecraft:overworld if loaded 73976 100 -24 if loaded 74024 100 24 run function mg:murder/start
