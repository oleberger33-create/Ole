tag @s remove mg_q_murder
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Murder Mystery-Warteschlange verlassen.", "color": "gray"}]
