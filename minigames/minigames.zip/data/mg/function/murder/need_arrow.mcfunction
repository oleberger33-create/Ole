execute store result score #n mg run clear @s minecraft:arrow 0
execute if score #n mg matches 1.. run return 0
execute store result score #n mg run clear @s *[minecraft:custom_data~{mg_murder:"dbow"}] 0
execute if score #n mg matches 1.. run return 1
return 0
