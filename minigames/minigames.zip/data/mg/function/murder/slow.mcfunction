execute as @e[type=minecraft:item,x=73970,y=95,z=-30,dx=60,dy=30,dz=60,tag=!mg_murder_bi] unless data entity @s {PickupDelay:32767s} if items entity @s contents *[minecraft:custom_data~{mg_murder:"dbow"}] run function mg:murder/bow_drop
execute as @e[type=minecraft:item,tag=mg_murder_bi] at @s if entity @a[tag=mg_al_murder,tag=!mg_murder_m,gamemode=adventure,distance=..1.8] run function mg:murder/bow_take
execute at @e[type=minecraft:item,tag=mg_murder_bi] run particle minecraft:end_rod ~ ~0.6 ~ 0.15 0.3 0.15 0.01 2
execute as @e[type=minecraft:item,x=73970,y=95,z=-30,dx=60,dy=30,dz=60] if items entity @s contents minecraft:arrow run kill @s
execute as @e[type=minecraft:item,x=73970,y=95,z=-30,dx=60,dy=30,dz=60] if items entity @s contents *[minecraft:custom_data~{mg_murder:"ibow"}] run kill @s
execute as @e[type=minecraft:item,x=73970,y=95,z=-30,dx=60,dy=30,dz=60] if items entity @s contents *[minecraft:custom_data~{mg_murder:"sword"}] run kill @s
kill @e[type=minecraft:arrow,x=73970,y=95,z=-30,dx=60,dy=30,dz=60,nbt={inGround:1b}]
clear @a[tag=mg_murder_m] minecraft:bow
clear @a[tag=mg_murder_m] minecraft:arrow
execute if score #murder_t mg matches 205.. as @a[tag=mg_al_murder,tag=mg_murder_m] unless items entity @s container.* *[minecraft:custom_data~{mg_murder:"sword"}] unless items entity @s weapon.offhand *[minecraft:custom_data~{mg_murder:"sword"}] unless items entity @s player.cursor *[minecraft:custom_data~{mg_murder:"sword"}] run give @s minecraft:iron_sword[minecraft:custom_name={"text": "Mordwaffe", "color": "dark_red", "italic": false, "bold": true},minecraft:lore=[{"text": "Ein Treffer genügt.", "color": "gray", "italic": false}],minecraft:attribute_modifiers=[{type:"minecraft:attack_damage",amount:1000,id:"mg:murder_sword",operation:"add_value",slot:"mainhand"}],minecraft:unbreakable={},minecraft:custom_data={mg_murder:"sword"},minecraft:tooltip_display={hidden_components:["minecraft:enchantments","minecraft:unbreakable","minecraft:attribute_modifiers"]}]
execute as @a[tag=mg_al_murder] store result score @s mg_murder_g run clear @s minecraft:gold_ingot 0
execute as @a[tag=mg_al_murder,scores={mg_murder_g=10..}] run function mg:murder/buy
execute if score #murder_t mg matches 210.. run function mg:murder/bow_check
