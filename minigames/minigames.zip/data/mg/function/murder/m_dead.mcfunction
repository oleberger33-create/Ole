scoreboard players set #murder_win mg 1
tag @a[tag=mg_murder,tag=!mg_murder_m,scores={mg_murder_k=1..}] add mg_murder_hero
execute if entity @a[tag=mg_murder_hero] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_murder_hero]", "color": "aqua", "bold": true}, {"text": " hat den Mörder ", "color": "white", "italic": false}, {"selector": "@s", "color": "dark_red", "bold": true}, {"text": " zur Strecke gebracht!", "color": "white", "italic": false}]
execute unless entity @a[tag=mg_murder_hero] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Der Mörder ", "color": "white", "italic": false}, {"selector": "@s", "color": "dark_red", "bold": true}, {"text": " ist tot!", "color": "white", "italic": false}]
scoreboard players add @a[tag=mg_murder_hero] mg_coins 10
