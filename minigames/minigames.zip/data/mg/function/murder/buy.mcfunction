clear @s minecraft:gold_ingot 10
scoreboard players remove @s mg_murder_g 10
execute if entity @s[tag=mg_murder_m] run return run function mg:murder/buy_m
execute unless items entity @s container.* minecraft:bow run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "10 Gold eingetauscht: ", "color": "gold", "italic": false}, {"text": "Bogen + Pfeil!", "color": "green", "italic": false, "bold": true}]
execute if items entity @s container.* minecraft:bow run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "10 Gold eingetauscht: ", "color": "gold", "italic": false}, {"text": "+1 Pfeil!", "color": "green", "italic": false, "bold": true}]
execute unless items entity @s container.* minecraft:bow run give @s minecraft:bow[minecraft:custom_name={"text": "Bogen", "color": "green", "italic": false, "bold": true},minecraft:lore=[{"text": "Ein Treffer genügt. Triff bloß keinen Unschuldigen!", "color": "gray", "italic": false}],minecraft:enchantments={"minecraft:power":255},minecraft:unbreakable={},minecraft:custom_data={mg_murder:"ibow"},minecraft:tooltip_display={hidden_components:["minecraft:enchantments","minecraft:unbreakable","minecraft:attribute_modifiers"]}]
give @s minecraft:arrow 1
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1.3
