scoreboard players set @s mg_deaths 0
tag @s remove mg_al_murder
gamemode spectator @s
clear @s
execute in minecraft:overworld run tp @s 74000 120 23
execute if entity @s[tag=mg_murder_m] run return run function mg:murder/m_dead
execute store result score #murder_alive mg if entity @a[tag=mg_al_murder,tag=!mg_murder_m]
execute if entity @s[tag=mg_murder_d] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Der Detektiv ist tot! ", "color": "aqua", "italic": false, "bold": true}, {"text": "Sein Bogen liegt jetzt irgendwo am Boden ...", "color": "gray", "italic": false}]
execute unless entity @s[tag=mg_murder_bad] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "☠ ", "color": "dark_red", "italic": false}, {"selector": "@s", "color": "white"}, {"text": " ist tot! ", "color": "red", "italic": false}, {"text": "Unschuldige am Leben: ", "color": "gray", "italic": false}, {"score": {"name": "#murder_alive", "objective": "mg"}, "color": "white"}]
execute if entity @s[tag=mg_murder_bad] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "☠ ", "color": "dark_red", "italic": false}, {"text": "Unschuldige am Leben: ", "color": "gray", "italic": false}, {"score": {"name": "#murder_alive", "objective": "mg"}, "color": "white"}]
title @s times 5 70 20
title @s subtitle {"text": "Du schaust jetzt zu – nichts verraten!", "color": "gray"}
title @s title {"text": "Du bist tot!", "color": "dark_red", "bold": true}
execute as @a[tag=mg_murder] at @s run playsound minecraft:entity.player.hurt_sweet_berry_bush master @s ~ ~ ~ 0.4 0.5
execute as @a[tag=mg_murder] at @s run playsound minecraft:block.bell.resonate master @s ~ ~ ~ 0.5 0.6
scoreboard players add @s mg_coins 2
