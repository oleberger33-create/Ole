execute as @a[tag=mg_al_murder] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold", "bold": true}, {"text": " gewinnt Murder Mystery!", "color": "white"}]
execute unless entity @a[tag=mg_al_murder] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Unentschieden – niemand hat überlebt.", "color": "gray"}]
scoreboard players add @a[tag=mg_al_murder] mg_wins 1
scoreboard players add @a[tag=mg_al_murder] mg_coins 10
title @a[tag=mg_murder] title {"text": "Spiel vorbei!", "color": "dark_red", "bold": true}
execute as @a[tag=mg_al_murder] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"large_ball",colors:[I;16766720],has_twinkle:true}]}}}}
scoreboard players set #murder mg 3
schedule function mg:murder/finish 100t
