kill @e[type=minecraft:text_display,tag=mg_murderh]
kill @e[type=minecraft:marker,tag=mg_murder_sp]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=73970,y=95,z=-30,dx=60,dy=30,dz=60]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=73970,y=95,z=-30,dx=60,dy=30,dz=60]
execute in minecraft:overworld run fill 73970 99 -30 73973 117 30 minecraft:air
execute in minecraft:overworld run fill 73974 99 -30 73977 117 30 minecraft:air
execute in minecraft:overworld run fill 73978 99 -30 73981 117 30 minecraft:air
execute in minecraft:overworld run fill 73982 99 -30 73985 117 30 minecraft:air
execute in minecraft:overworld run fill 73986 99 -30 73989 117 30 minecraft:air
execute in minecraft:overworld run fill 73990 99 -30 73993 117 30 minecraft:air
execute in minecraft:overworld run fill 73994 99 -30 73997 117 30 minecraft:air
execute in minecraft:overworld run fill 73998 99 -30 74001 117 30 minecraft:air
execute in minecraft:overworld run fill 74002 99 -30 74005 117 30 minecraft:air
execute in minecraft:overworld run fill 74006 99 -30 74009 117 30 minecraft:air
execute in minecraft:overworld run fill 74010 99 -30 74013 117 30 minecraft:air
execute in minecraft:overworld run fill 74014 99 -30 74017 117 30 minecraft:air
execute in minecraft:overworld run fill 74018 99 -30 74021 117 30 minecraft:air
execute in minecraft:overworld run fill 74022 99 -30 74025 117 30 minecraft:air
execute in minecraft:overworld run fill 74026 99 -30 74029 117 30 minecraft:air
execute in minecraft:overworld run fill 74030 99 -30 74030 117 30 minecraft:air
execute in minecraft:overworld run fill 73971 99 -29 74029 99 29 minecraft:dirt
execute in minecraft:overworld run fill 73971 100 -29 74029 100 29 minecraft:grass_block
execute in minecraft:overworld run fill 73971 101 -29 73971 103 29 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73971 101 -29 74029 103 -29 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73971 104 -29 73971 106 29 minecraft:barrier
execute in minecraft:overworld run fill 73971 104 -29 74029 106 -29 minecraft:barrier
execute in minecraft:overworld run fill 74029 101 -29 74029 103 29 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73971 101 29 74029 103 29 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 74029 104 -29 74029 106 29 minecraft:barrier
execute in minecraft:overworld run fill 73971 104 29 74029 106 29 minecraft:barrier
execute in minecraft:overworld run fill 73982 100 -18 74018 100 18 minecraft:dirt_path
execute in minecraft:overworld run fill 73999 100 17 74001 100 28 minecraft:dirt_path
execute in minecraft:overworld run fill 74000 100 -28 74000 100 -17 minecraft:dirt_path
execute in minecraft:overworld run fill 73972 100 0 73983 100 0 minecraft:dirt_path
execute in minecraft:overworld run fill 74017 100 0 74028 100 0 minecraft:dirt_path
execute in minecraft:overworld run setblock 73977 101 25 minecraft:allium
execute in minecraft:overworld run setblock 73973 101 -11 minecraft:cornflower
execute in minecraft:overworld run setblock 73980 101 -26 minecraft:short_grass
execute in minecraft:overworld run setblock 73974 101 22 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73978 101 -7 minecraft:short_grass
execute in minecraft:overworld run setblock 73974 101 12 minecraft:short_grass
execute in minecraft:overworld run setblock 73973 101 -8 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74011 101 19 minecraft:poppy
execute in minecraft:overworld run setblock 73973 101 -18 minecraft:allium
execute in minecraft:overworld run setblock 73981 101 -21 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73992 101 27 minecraft:allium
execute in minecraft:overworld run setblock 73973 101 -4 minecraft:short_grass
execute in minecraft:overworld run setblock 74025 101 6 minecraft:dandelion
execute in minecraft:overworld run setblock 73979 101 -26 minecraft:short_grass
execute in minecraft:overworld run setblock 73980 101 19 minecraft:allium
execute in minecraft:overworld run setblock 73979 101 15 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73989 101 -20 minecraft:short_grass
execute in minecraft:overworld run setblock 73995 101 23 minecraft:short_grass
execute in minecraft:overworld run setblock 74022 101 9 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74026 101 -24 minecraft:short_grass
execute in minecraft:overworld run setblock 73977 101 2 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74008 101 25 minecraft:poppy
execute in minecraft:overworld run setblock 73994 101 23 minecraft:short_grass
execute in minecraft:overworld run setblock 73981 101 -25 minecraft:poppy
execute in minecraft:overworld run setblock 73992 101 -23 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74022 101 11 minecraft:allium
execute in minecraft:overworld run setblock 73992 101 21 minecraft:poppy
execute in minecraft:overworld run setblock 73984 101 23 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 73992 101 -21 minecraft:short_grass
execute in minecraft:overworld run setblock 73989 101 20 minecraft:short_grass
execute in minecraft:overworld run setblock 73974 101 -12 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74018 101 19 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74011 101 -20 minecraft:short_grass
execute in minecraft:overworld run setblock 74017 101 21 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74020 101 -13 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74021 101 -24 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74014 101 -26 minecraft:short_grass
execute in minecraft:overworld run setblock 74014 101 19 minecraft:allium
execute in minecraft:overworld run setblock 73973 101 21 minecraft:short_grass
execute in minecraft:overworld run setblock 73974 101 -7 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74023 101 -26 minecraft:cornflower
execute in minecraft:overworld run setblock 74021 101 5 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73980 101 19 minecraft:short_grass
execute in minecraft:overworld run setblock 74023 101 -21 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74006 101 -24 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74024 101 -11 minecraft:short_grass
execute in minecraft:overworld run setblock 73980 101 -6 minecraft:cornflower
execute in minecraft:overworld run setblock 73973 101 10 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73979 101 -16 minecraft:short_grass
execute in minecraft:overworld run setblock 73988 101 -22 minecraft:short_grass
execute in minecraft:overworld run setblock 74023 101 12 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 73985 101 -24 minecraft:cornflower
execute in minecraft:overworld run setblock 73985 101 -24 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74027 101 5 minecraft:allium
execute in minecraft:overworld run setblock 74021 101 -4 minecraft:short_grass
execute in minecraft:overworld run setblock 74019 101 -26 minecraft:short_grass
execute in minecraft:overworld run setblock 73993 101 -19 minecraft:short_grass
execute in minecraft:overworld run setblock 73982 101 -25 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 73985 101 -26 minecraft:short_grass
execute in minecraft:overworld run setblock 74022 101 -7 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73986 101 19 minecraft:short_grass
execute in minecraft:overworld run setblock 73988 101 -27 minecraft:poppy
execute in minecraft:overworld run setblock 74012 101 25 minecraft:short_grass
execute in minecraft:overworld run setblock 73976 101 -2 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73978 101 6 minecraft:dandelion
execute in minecraft:overworld run setblock 73979 101 -15 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73986 101 24 minecraft:allium
execute in minecraft:overworld run setblock 74019 101 -9 minecraft:short_grass
execute in minecraft:overworld run setblock 74006 101 -21 minecraft:dandelion
execute in minecraft:overworld run setblock 73977 101 -25 minecraft:short_grass
execute in minecraft:overworld run setblock 73995 101 21 minecraft:short_grass
execute in minecraft:overworld run setblock 73978 101 8 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74024 101 17 minecraft:short_grass
execute in minecraft:overworld run setblock 74017 101 27 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74021 101 26 minecraft:short_grass
execute in minecraft:overworld run setblock 73995 101 -20 minecraft:poppy
execute in minecraft:overworld run setblock 73973 101 26 minecraft:dandelion
execute in minecraft:overworld run setblock 73977 101 7 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 73981 101 14 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74007 101 -25 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74022 101 20 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74022 101 -8 minecraft:dandelion
execute in minecraft:overworld run setblock 74009 101 -23 minecraft:short_grass
execute in minecraft:overworld run setblock 73977 101 8 minecraft:short_grass
execute in minecraft:overworld run setblock 74017 101 26 minecraft:cornflower
execute in minecraft:overworld run setblock 74027 101 -25 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73974 101 23 minecraft:short_grass
execute in minecraft:overworld run setblock 74022 101 2 minecraft:short_grass
execute in minecraft:overworld run setblock 73989 101 24 minecraft:cornflower
execute in minecraft:overworld run setblock 73980 101 5 minecraft:short_grass
execute in minecraft:overworld run setblock 74026 101 4 minecraft:cornflower
execute in minecraft:overworld run setblock 74025 101 26 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 73974 101 2 minecraft:allium
execute in minecraft:overworld run setblock 74027 101 8 minecraft:dandelion
execute in minecraft:overworld run setblock 73991 101 -22 minecraft:allium
execute in minecraft:overworld run setblock 73995 101 -23 minecraft:allium
execute in minecraft:overworld run setblock 73981 101 -21 minecraft:cornflower
execute in minecraft:overworld run setblock 73979 101 -5 minecraft:cornflower
execute in minecraft:overworld run setblock 73982 101 25 minecraft:short_grass
execute in minecraft:overworld run setblock 74005 101 27 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73978 101 -14 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73990 101 -21 minecraft:short_grass
execute in minecraft:overworld run setblock 74027 101 20 minecraft:allium
execute in minecraft:overworld run setblock 73974 101 -9 minecraft:dandelion
execute in minecraft:overworld run setblock 73976 101 -27 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74013 101 21 minecraft:poppy
execute in minecraft:overworld run setblock 74024 101 -27 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74011 101 23 minecraft:short_grass
execute in minecraft:overworld run setblock 74023 101 -10 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73973 101 11 minecraft:dandelion
execute in minecraft:overworld run setblock 73975 101 -9 minecraft:short_grass
execute in minecraft:overworld run setblock 73978 101 3 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74025 101 -10 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73973 101 25 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74019 101 13 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73982 101 -27 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 73974 101 6 minecraft:cornflower
execute in minecraft:overworld run setblock 74026 101 -8 minecraft:poppy
execute in minecraft:overworld run setblock 73980 101 -19 minecraft:allium
execute in minecraft:overworld run setblock 74022 101 15 minecraft:allium
execute in minecraft:overworld run setblock 73988 101 27 minecraft:allium
execute in minecraft:overworld run setblock 73980 101 -11 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73983 101 -22 minecraft:short_grass
execute in minecraft:overworld run setblock 73987 101 -26 minecraft:cornflower
execute in minecraft:overworld run setblock 73973 101 -16 minecraft:poppy
execute in minecraft:overworld run setblock 73977 101 7 minecraft:short_grass
execute in minecraft:overworld run setblock 73977 101 -26 minecraft:cornflower
execute in minecraft:overworld run setblock 73991 101 24 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73978 101 -17 minecraft:allium
execute in minecraft:overworld run setblock 74008 101 -22 minecraft:short_grass
execute in minecraft:overworld run setblock 73976 101 -6 minecraft:allium
execute in minecraft:overworld run setblock 73976 101 3 minecraft:short_grass
execute in minecraft:overworld run setblock 73981 101 18 minecraft:short_grass
execute in minecraft:overworld run setblock 74024 101 -26 minecraft:dandelion
execute in minecraft:overworld run setblock 73981 101 -19 minecraft:short_grass
execute in minecraft:overworld run setblock 73981 101 19 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73996 101 -27 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74027 101 24 minecraft:poppy
execute in minecraft:overworld run setblock 73976 101 19 minecraft:short_grass
execute in minecraft:overworld run setblock 73985 101 21 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74022 101 8 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74019 101 -26 minecraft:short_grass
execute in minecraft:overworld run setblock 73974 101 20 minecraft:poppy
execute in minecraft:overworld run setblock 73994 101 26 minecraft:dandelion
execute in minecraft:overworld run setblock 74014 101 -26 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74022 101 -20 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 73988 101 23 minecraft:allium
execute in minecraft:overworld run setblock 74020 101 -19 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74021 101 7 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73981 101 23 minecraft:allium
execute in minecraft:overworld run setblock 73992 101 -22 minecraft:dandelion
execute in minecraft:overworld run setblock 73990 101 -24 minecraft:poppy
execute in minecraft:overworld run setblock 74007 101 -19 minecraft:azure_bluet
execute in minecraft:overworld run setblock 74015 101 21 minecraft:oxeye_daisy
execute in minecraft:overworld run setblock 74026 101 23 minecraft:short_grass
execute in minecraft:overworld run setblock 74021 101 -13 minecraft:allium
execute in minecraft:overworld run setblock 73977 101 -5 minecraft:dandelion
execute in minecraft:overworld run setblock 73979 101 24 minecraft:allium
execute in minecraft:overworld run setblock 74011 101 22 minecraft:dandelion
execute in minecraft:overworld run setblock 73991 101 22 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73987 101 19 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74012 101 -21 minecraft:allium
execute in minecraft:overworld run setblock 74027 101 26 minecraft:dandelion
execute in minecraft:overworld run setblock 74026 101 -21 minecraft:azure_bluet
execute in minecraft:overworld run setblock 73987 101 20 minecraft:cornflower
execute in minecraft:overworld run setblock 74024 101 -15 minecraft:allium
execute in minecraft:overworld run setblock 73975 101 -12 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 73976 101 13 minecraft:short_grass
execute in minecraft:overworld run setblock 74025 101 12 minecraft:short_grass
execute in minecraft:overworld run setblock 74014 101 19 minecraft:short_grass
execute in minecraft:overworld run setblock 73980 101 27 minecraft:cornflower
execute in minecraft:overworld run setblock 73975 101 -3 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74005 101 -21 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74027 101 -8 minecraft:lily_of_the_valley
execute in minecraft:overworld run setblock 74013 101 24 minecraft:short_grass
execute in minecraft:overworld run setblock 73979 101 -10 minecraft:short_grass
execute in minecraft:overworld run setblock 73974 101 -23 minecraft:short_grass
execute in minecraft:overworld run setblock 73974 101 24 minecraft:lily_of_the_valley
execute in minecraft:overworld run fill 73999 100 20 74001 100 20 minecraft:stone_bricks
execute in minecraft:overworld run fill 73998 100 21 74002 100 21 minecraft:stone_bricks
execute in minecraft:overworld run fill 73997 100 22 74003 100 22 minecraft:stone_bricks
execute in minecraft:overworld run fill 73997 100 23 74003 100 23 minecraft:stone_bricks
execute in minecraft:overworld run fill 73997 100 24 74003 100 24 minecraft:stone_bricks
execute in minecraft:overworld run fill 73998 100 25 74002 100 25 minecraft:stone_bricks
execute in minecraft:overworld run fill 73999 100 26 74001 100 26 minecraft:stone_bricks
execute in minecraft:overworld run fill 73996 101 23 73996 101 23 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73997 101 21 73997 101 21 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73997 101 22 73997 101 22 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73997 101 23 73997 101 23 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73997 101 24 73997 101 24 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73997 101 25 73997 101 25 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73998 101 20 73998 101 20 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73998 101 26 73998 101 26 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73999 101 20 73999 101 20 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73999 101 26 73999 101 26 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74000 101 19 74000 101 19 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74000 101 20 74000 101 20 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74000 101 26 74000 101 26 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74000 101 27 74000 101 27 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74001 101 20 74001 101 20 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74001 101 26 74001 101 26 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74002 101 20 74002 101 20 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74002 101 26 74002 101 26 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74003 101 21 74003 101 21 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74003 101 22 74003 101 22 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74003 101 23 74003 101 23 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74003 101 24 74003 101 24 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74003 101 25 74003 101 25 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 74004 101 23 74004 101 23 minecraft:stone_brick_wall
execute in minecraft:overworld run fill 73999 100 21 74001 100 21 minecraft:water
execute in minecraft:overworld run fill 73998 100 22 74002 100 22 minecraft:water
execute in minecraft:overworld run fill 73998 100 23 74002 100 23 minecraft:water
execute in minecraft:overworld run fill 73998 100 24 74002 100 24 minecraft:water
execute in minecraft:overworld run fill 73999 100 25 74001 100 25 minecraft:water
execute in minecraft:overworld run fill 74000 100 23 74000 102 23 minecraft:chiseled_stone_bricks
execute in minecraft:overworld run setblock 74000 103 23 minecraft:water
execute in minecraft:overworld run fill 73998 101 -25 73998 103 -25 minecraft:dark_oak_fence
execute in minecraft:overworld run fill 73998 101 -21 73998 103 -21 minecraft:dark_oak_fence
execute in minecraft:overworld run fill 74002 101 -25 74002 103 -25 minecraft:dark_oak_fence
execute in minecraft:overworld run fill 74002 101 -21 74002 103 -21 minecraft:dark_oak_fence
execute in minecraft:overworld run fill 73997 104 -26 74003 104 -20 minecraft:dark_oak_slab[type=bottom]
execute in minecraft:overworld run fill 73998 104 -25 74002 104 -21 minecraft:dark_oak_planks
execute in minecraft:overworld run setblock 74000 105 -23 minecraft:dark_oak_slab[type=bottom]
execute in minecraft:overworld run setblock 74000 103 -23 minecraft:lantern[hanging=true]
execute in minecraft:overworld run fill 73999 101 -25 74001 101 -25 minecraft:spruce_stairs[facing=north]
execute in minecraft:overworld run fill 73998 100 -25 74002 100 -21 minecraft:spruce_planks
execute in minecraft:overworld run fill 73975 104 -25 73979 105 -21 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73976 106 -24 73978 106 -22 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run setblock 73977 107 -23 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73977 101 -23 73977 106 -23 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74021 104 -25 74025 105 -21 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 74022 106 -24 74024 106 -22 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run setblock 74023 107 -23 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 74023 101 -23 74023 106 -23 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73975 104 21 73979 105 25 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73976 106 22 73978 106 24 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run setblock 73977 107 23 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73977 101 23 73977 106 23 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74021 104 21 74025 105 25 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 74022 106 22 74024 106 24 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run setblock 74023 107 23 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 74023 101 23 74023 106 23 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73992 101 20 73992 102 20 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 73992 103 20 minecraft:lantern
execute in minecraft:overworld run fill 74008 101 20 74008 102 20 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 74008 103 20 minecraft:lantern
execute in minecraft:overworld run fill 73980 101 -8 73980 102 -8 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 73980 103 -8 minecraft:lantern
execute in minecraft:overworld run fill 74020 101 8 74020 102 8 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 74020 103 8 minecraft:lantern
execute in minecraft:overworld run fill 73980 101 8 73980 102 8 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 73980 103 8 minecraft:lantern
execute in minecraft:overworld run fill 74020 101 -8 74020 102 -8 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 74020 103 -8 minecraft:lantern
execute in minecraft:overworld run fill 73992 101 -20 73992 102 -20 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 73992 103 -20 minecraft:lantern
execute in minecraft:overworld run fill 74008 101 -20 74008 102 -20 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 74008 103 -20 minecraft:lantern
execute in minecraft:overworld run fill 73976 101 -4 73976 101 -2 minecraft:spruce_stairs[facing=west]
execute in minecraft:overworld run fill 74024 101 2 74024 101 4 minecraft:spruce_stairs[facing=east]
execute in minecraft:overworld run fill 73986 101 24 73988 101 24 minecraft:spruce_stairs[facing=south]
execute in minecraft:overworld run fill 74012 101 -24 74014 101 -24 minecraft:spruce_stairs[facing=north]
execute in minecraft:overworld run fill 73988 101 17 73996 101 17 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 74004 101 17 74012 101 17 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73983 101 -12 73983 101 -4 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 74017 101 4 74017 101 12 minecraft:oak_leaves[persistent=true]
execute in minecraft:overworld run fill 73984 100 -16 74016 100 16 minecraft:stone_bricks
execute in minecraft:overworld run fill 73985 100 -15 74015 100 15 minecraft:dark_oak_planks
execute in minecraft:overworld run fill 73985 100 -15 73993 100 -7 minecraft:spruce_planks
execute in minecraft:overworld run fill 73995 100 7 74005 100 15 minecraft:polished_andesite
execute in minecraft:overworld run fill 73999 100 7 74001 100 16 minecraft:stone_bricks
execute in minecraft:overworld run fill 74007 100 7 74015 100 15 minecraft:moss_block
execute in minecraft:overworld run fill 74011 100 7 74011 100 15 minecraft:mossy_cobblestone
execute in minecraft:overworld run setblock 74007 100 -14 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74007 100 -12 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74007 100 -10 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74007 100 -8 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74008 100 -15 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74008 100 -13 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74008 100 -11 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74008 100 -9 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74008 100 -7 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74009 100 -14 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74009 100 -12 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74009 100 -10 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74009 100 -8 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74010 100 -15 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74010 100 -13 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74010 100 -11 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74010 100 -9 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74010 100 -7 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74011 100 -14 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74011 100 -12 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74011 100 -10 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74011 100 -8 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74012 100 -15 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74012 100 -13 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74012 100 -11 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74012 100 -9 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74012 100 -7 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74013 100 -14 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74013 100 -12 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74013 100 -10 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74013 100 -8 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74014 100 -15 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74014 100 -13 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74014 100 -11 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74014 100 -9 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74014 100 -7 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74015 100 -14 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74015 100 -12 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74015 100 -10 minecraft:polished_blackstone
execute in minecraft:overworld run setblock 74015 100 -8 minecraft:polished_blackstone
execute in minecraft:overworld run fill 74007 100 -15 74015 100 -7 minecraft:smooth_quartz replace minecraft:dark_oak_planks
execute in minecraft:overworld run fill 73984 101 -16 74016 105 -16 minecraft:white_terracotta
execute in minecraft:overworld run fill 73984 101 -16 73984 105 16 minecraft:white_terracotta
execute in minecraft:overworld run fill 73984 101 -16 74016 101 -16 minecraft:stone_bricks
execute in minecraft:overworld run fill 73984 101 -16 73984 101 16 minecraft:stone_bricks
execute in minecraft:overworld run fill 73984 105 -16 74016 105 -16 minecraft:stripped_dark_oak_wood
execute in minecraft:overworld run fill 73984 105 -16 73984 105 16 minecraft:stripped_dark_oak_wood
execute in minecraft:overworld run fill 73984 101 -16 73984 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73984 101 -16 73984 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73989 101 -16 73989 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73984 101 -11 73984 104 -11 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73994 101 -16 73994 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73984 101 -6 73984 104 -6 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73998 101 -16 73998 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73984 101 -2 73984 104 -2 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74002 101 -16 74002 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73984 101 2 73984 104 2 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74006 101 -16 74006 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73984 101 6 73984 104 6 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74011 101 -16 74011 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73984 101 11 73984 104 11 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 -16 74016 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73984 101 16 73984 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73986 102 -16 73987 103 -16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 73984 102 -14 73984 103 -13 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 73991 102 -16 73992 103 -16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 73984 102 -9 73984 103 -8 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 73996 102 -16 73996 103 -16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 73984 102 -4 73984 103 -4 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 74004 102 -16 74004 103 -16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 73984 102 4 73984 103 4 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 74008 102 -16 74009 103 -16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 73984 102 8 73984 103 9 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 74013 102 -16 74014 103 -16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 73984 102 13 73984 103 14 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 73984 101 16 74016 105 16 minecraft:white_terracotta
execute in minecraft:overworld run fill 74016 101 -16 74016 105 16 minecraft:white_terracotta
execute in minecraft:overworld run fill 73984 101 16 74016 101 16 minecraft:stone_bricks
execute in minecraft:overworld run fill 74016 101 -16 74016 101 16 minecraft:stone_bricks
execute in minecraft:overworld run fill 73984 105 16 74016 105 16 minecraft:stripped_dark_oak_wood
execute in minecraft:overworld run fill 74016 105 -16 74016 105 16 minecraft:stripped_dark_oak_wood
execute in minecraft:overworld run fill 73984 101 16 73984 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 -16 74016 104 -16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73989 101 16 73989 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 -11 74016 104 -11 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73994 101 16 73994 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 -6 74016 104 -6 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73998 101 16 73998 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 -2 74016 104 -2 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74002 101 16 74002 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 2 74016 104 2 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74006 101 16 74006 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 6 74016 104 6 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74011 101 16 74011 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 11 74016 104 11 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 16 74016 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 74016 101 16 74016 104 16 minecraft:dark_oak_log
execute in minecraft:overworld run fill 73986 102 16 73987 103 16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 74016 102 -14 74016 103 -13 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 73991 102 16 73992 103 16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 74016 102 -9 74016 103 -8 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 73996 102 16 73996 103 16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 74016 102 -4 74016 103 -4 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 74004 102 16 74004 103 16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 74016 102 4 74016 103 4 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 74008 102 16 74009 103 16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 74016 102 8 74016 103 9 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 74013 102 16 74014 103 16 minecraft:glass_pane[east=true,west=true]
execute in minecraft:overworld run fill 74016 102 13 74016 103 14 minecraft:glass_pane[north=true,south=true]
execute in minecraft:overworld run fill 73994 101 -15 73994 105 15 minecraft:spruce_planks
execute in minecraft:overworld run fill 73985 101 -6 74015 105 -6 minecraft:spruce_planks
execute in minecraft:overworld run fill 73994 101 -6 73994 105 -6 minecraft:stripped_spruce_log
execute in minecraft:overworld run fill 74006 101 -15 74006 105 15 minecraft:spruce_planks
execute in minecraft:overworld run fill 73985 101 6 74015 105 6 minecraft:spruce_planks
execute in minecraft:overworld run fill 74006 101 6 74006 105 6 minecraft:stripped_spruce_log
execute in minecraft:overworld run fill 74016 102 7 74016 104 15 minecraft:glass
execute in minecraft:overworld run fill 74007 102 16 74015 104 16 minecraft:glass
execute in minecraft:overworld run fill 73994 101 -1 73994 103 1 minecraft:air
execute in minecraft:overworld run fill 74006 101 -1 74006 103 1 minecraft:air
execute in minecraft:overworld run fill 73999 101 -6 74001 103 -6 minecraft:air
execute in minecraft:overworld run fill 73999 101 6 74001 103 6 minecraft:air
execute in minecraft:overworld run fill 73999 101 16 74001 103 16 minecraft:air
execute in minecraft:overworld run setblock 73994 102 -11 minecraft:dark_oak_door[facing=east,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 73994 101 -11 minecraft:dark_oak_door[facing=east,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 74006 102 -11 minecraft:dark_oak_door[facing=west,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 74006 101 -11 minecraft:dark_oak_door[facing=west,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 73994 102 9 minecraft:dark_oak_door[facing=east,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 73994 101 9 minecraft:dark_oak_door[facing=east,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 74006 102 9 minecraft:dark_oak_door[facing=west,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 74006 101 9 minecraft:dark_oak_door[facing=west,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 73991 102 -6 minecraft:dark_oak_door[facing=south,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 73991 101 -6 minecraft:dark_oak_door[facing=south,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 73989 102 6 minecraft:dark_oak_door[facing=north,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 73989 101 6 minecraft:dark_oak_door[facing=north,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 74011 102 -6 minecraft:dark_oak_door[facing=south,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 74011 101 -6 minecraft:dark_oak_door[facing=south,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 74011 102 6 minecraft:dark_oak_door[facing=north,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 74011 101 6 minecraft:dark_oak_door[facing=north,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 74000 102 -16 minecraft:dark_oak_door[facing=south,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 74000 101 -16 minecraft:dark_oak_door[facing=south,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 73984 102 0 minecraft:dark_oak_door[facing=east,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 73984 101 0 minecraft:dark_oak_door[facing=east,half=lower,hinge=left,open=false]
execute in minecraft:overworld run setblock 74016 102 0 minecraft:dark_oak_door[facing=west,half=upper,hinge=left,open=false]
execute in minecraft:overworld run setblock 74016 101 0 minecraft:dark_oak_door[facing=west,half=lower,hinge=left,open=false]
execute in minecraft:overworld run fill 73984 106 -16 74016 106 16 minecraft:dark_oak_planks
execute in minecraft:overworld run setblock 73987 106 -13 minecraft:shroomlight
execute in minecraft:overworld run setblock 73991 106 -13 minecraft:shroomlight
execute in minecraft:overworld run setblock 73987 106 -9 minecraft:shroomlight
execute in minecraft:overworld run setblock 73991 106 -9 minecraft:shroomlight
execute in minecraft:overworld run setblock 73987 106 -2 minecraft:shroomlight
execute in minecraft:overworld run setblock 73991 106 -2 minecraft:shroomlight
execute in minecraft:overworld run setblock 73987 106 2 minecraft:shroomlight
execute in minecraft:overworld run setblock 73991 106 2 minecraft:shroomlight
execute in minecraft:overworld run setblock 73987 106 9 minecraft:shroomlight
execute in minecraft:overworld run setblock 73991 106 9 minecraft:shroomlight
execute in minecraft:overworld run setblock 73987 106 13 minecraft:shroomlight
execute in minecraft:overworld run setblock 73991 106 13 minecraft:shroomlight
execute in minecraft:overworld run setblock 73998 106 -13 minecraft:shroomlight
execute in minecraft:overworld run setblock 74002 106 -13 minecraft:shroomlight
execute in minecraft:overworld run setblock 73998 106 -9 minecraft:shroomlight
execute in minecraft:overworld run setblock 74002 106 -9 minecraft:shroomlight
execute in minecraft:overworld run setblock 73998 106 -2 minecraft:shroomlight
execute in minecraft:overworld run setblock 74002 106 -2 minecraft:shroomlight
execute in minecraft:overworld run setblock 73998 106 2 minecraft:shroomlight
execute in minecraft:overworld run setblock 74002 106 2 minecraft:shroomlight
execute in minecraft:overworld run setblock 73998 106 9 minecraft:shroomlight
execute in minecraft:overworld run setblock 74002 106 9 minecraft:shroomlight
execute in minecraft:overworld run setblock 73998 106 13 minecraft:shroomlight
execute in minecraft:overworld run setblock 74002 106 13 minecraft:shroomlight
execute in minecraft:overworld run setblock 74009 106 -13 minecraft:shroomlight
execute in minecraft:overworld run setblock 74013 106 -13 minecraft:shroomlight
execute in minecraft:overworld run setblock 74009 106 -9 minecraft:shroomlight
execute in minecraft:overworld run setblock 74013 106 -9 minecraft:shroomlight
execute in minecraft:overworld run setblock 74009 106 -2 minecraft:shroomlight
execute in minecraft:overworld run setblock 74013 106 -2 minecraft:shroomlight
execute in minecraft:overworld run setblock 74009 106 2 minecraft:shroomlight
execute in minecraft:overworld run setblock 74013 106 2 minecraft:shroomlight
execute in minecraft:overworld run setblock 74009 106 9 minecraft:shroomlight
execute in minecraft:overworld run setblock 74013 106 9 minecraft:shroomlight
execute in minecraft:overworld run setblock 74009 106 13 minecraft:shroomlight
execute in minecraft:overworld run setblock 74013 106 13 minecraft:shroomlight
execute in minecraft:overworld run fill 73983 107 -17 74017 107 17 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run fill 73984 107 -16 74016 107 16 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 73985 108 -15 74015 108 15 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run fill 73986 108 -14 74014 108 14 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 73987 109 -13 74013 109 13 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run fill 73988 109 -12 74012 109 12 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 73989 110 -11 74011 110 11 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run fill 73990 110 -10 74010 110 10 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 73991 111 -9 74009 111 9 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run fill 73992 111 -8 74008 111 8 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 73993 112 -7 74007 112 7 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run fill 73994 112 -6 74006 112 6 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 73995 113 -5 74005 113 5 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run fill 73996 113 -4 74004 113 4 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 73997 114 -3 74003 114 3 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run fill 73998 114 -2 74002 114 2 minecraft:deepslate_tiles
execute in minecraft:overworld run fill 73999 115 -1 74001 115 1 minecraft:deepslate_tile_slab[type=bottom]
execute in minecraft:overworld run setblock 74000 116 0 minecraft:lightning_rod
execute in minecraft:overworld run fill 73986 107 -5 73987 111 -4 minecraft:bricks
execute in minecraft:overworld run setblock 73986 112 -5 minecraft:campfire[lit=true]
execute in minecraft:overworld run setblock 73987 112 -4 minecraft:campfire[lit=true]
execute in minecraft:overworld run fill 73997 106 17 74003 106 18 minecraft:dark_oak_slab[type=bottom]
execute in minecraft:overworld run fill 73997 101 18 73997 105 18 minecraft:dark_oak_fence
execute in minecraft:overworld run fill 74003 101 18 74003 105 18 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 73998 105 17 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 74002 105 17 minecraft:lantern[hanging=true]
execute in minecraft:overworld run fill 73985 101 -15 73985 104 -7 minecraft:bookshelf
execute in minecraft:overworld run fill 73985 101 -15 73993 104 -15 minecraft:bookshelf
execute in minecraft:overworld run fill 73987 101 -12 73990 103 -12 minecraft:bookshelf
execute in minecraft:overworld run fill 73987 101 -10 73991 101 -8 minecraft:red_carpet
execute in minecraft:overworld run setblock 73991 101 -9 minecraft:lectern[facing=south]
execute in minecraft:overworld run setblock 73989 105 -11 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 73986 101 -9 minecraft:spruce_stairs[facing=west]
execute in minecraft:overworld run setblock 73986 101 -14 minecraft:potted_fern
execute in minecraft:overworld run fill 73997 101 -12 74003 101 -10 minecraft:dark_oak_slab[type=top]
execute in minecraft:overworld run fill 73996 101 -15 73998 101 -15 minecraft:stripped_spruce_log[axis=y]
execute in minecraft:overworld run fill 74002 101 -15 74004 101 -15 minecraft:stripped_spruce_log[axis=y]
execute in minecraft:overworld run setblock 73996 102 -15 minecraft:potted_red_tulip
execute in minecraft:overworld run setblock 74004 102 -15 minecraft:potted_white_tulip
execute in minecraft:overworld run setblock 73997 102 -15 minecraft:lantern
execute in minecraft:overworld run setblock 74003 102 -15 minecraft:lantern
execute in minecraft:overworld run setblock 73997 101 -13 minecraft:spruce_stairs[facing=north]
execute in minecraft:overworld run setblock 73997 101 -9 minecraft:spruce_stairs[facing=south]
execute in minecraft:overworld run setblock 73999 101 -13 minecraft:spruce_stairs[facing=north]
execute in minecraft:overworld run setblock 73999 101 -9 minecraft:spruce_stairs[facing=south]
execute in minecraft:overworld run setblock 74001 101 -13 minecraft:spruce_stairs[facing=north]
execute in minecraft:overworld run setblock 74001 101 -9 minecraft:spruce_stairs[facing=south]
execute in minecraft:overworld run setblock 74003 101 -13 minecraft:spruce_stairs[facing=north]
execute in minecraft:overworld run setblock 74003 101 -9 minecraft:spruce_stairs[facing=south]
execute in minecraft:overworld run setblock 73998 102 -11 minecraft:candle[candles=3,lit=true]
execute in minecraft:overworld run setblock 74000 102 -11 minecraft:candle[candles=3,lit=true]
execute in minecraft:overworld run setblock 74002 102 -11 minecraft:candle[candles=3,lit=true]
execute in minecraft:overworld run setblock 73998 105 -11 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 74002 105 -11 minecraft:lantern[hanging=true]
execute in minecraft:overworld run fill 74008 101 -15 74014 101 -15 minecraft:polished_andesite
execute in minecraft:overworld run setblock 74009 101 -15 minecraft:polished_deepslate
execute in minecraft:overworld run setblock 74011 101 -15 minecraft:polished_deepslate
execute in minecraft:overworld run setblock 74013 101 -15 minecraft:water_cauldron[level=3]
execute in minecraft:overworld run fill 74015 101 -14 74015 102 -13 minecraft:stripped_spruce_log[axis=x]
execute in minecraft:overworld run setblock 74015 101 -10 minecraft:fletching_table
execute in minecraft:overworld run fill 74010 101 -11 74012 101 -10 minecraft:smooth_stone_slab[type=top]
execute in minecraft:overworld run setblock 74011 102 -11 minecraft:cake
execute in minecraft:overworld run setblock 74011 105 -12 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 74008 102 -15 minecraft:potted_cactus
execute in minecraft:overworld run fill 73985 101 -5 73989 104 -5 minecraft:bricks
execute in minecraft:overworld run setblock 73987 101 -5 minecraft:campfire[lit=true,facing=south]
execute in minecraft:overworld run setblock 73987 102 -5 minecraft:air
execute in minecraft:overworld run fill 73985 103 -4 73989 103 -4 minecraft:spruce_slab[type=top]
execute in minecraft:overworld run fill 73986 101 0 73991 101 3 minecraft:brown_carpet
execute in minecraft:overworld run setblock 73986 101 -2 minecraft:spruce_stairs[facing=south]
execute in minecraft:overworld run setblock 73988 101 -2 minecraft:spruce_stairs[facing=south]
execute in minecraft:overworld run setblock 73990 101 -1 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 73990 102 -1 minecraft:oak_pressure_plate
execute in minecraft:overworld run setblock 73989 105 1 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 73985 101 4 minecraft:bookshelf
execute in minecraft:overworld run setblock 73985 102 4 minecraft:potted_allium
execute in minecraft:overworld run fill 73995 101 -1 74005 101 1 minecraft:red_carpet
execute in minecraft:overworld run fill 73999 101 -5 74001 101 5 minecraft:red_carpet
execute in minecraft:overworld run setblock 74000 105 0 minecraft:iron_chain[axis=y]
execute in minecraft:overworld run setblock 74000 104 0 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 74002 105 0 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 73998 105 0 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 74000 105 2 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 74000 105 -2 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 73995 101 -5 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 73995 101 5 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 74005 101 -5 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 74005 101 5 minecraft:flowering_azalea
execute in minecraft:overworld run fill 74009 101 -3 74013 101 3 minecraft:cyan_carpet
execute in minecraft:overworld run fill 74013 101 -5 74015 101 -5 minecraft:polished_blackstone
execute in minecraft:overworld run fill 74013 102 -5 74015 102 -5 minecraft:quartz_slab[type=bottom]
execute in minecraft:overworld run setblock 74014 101 -4 minecraft:spruce_stairs[facing=south]
execute in minecraft:overworld run setblock 74015 101 3 minecraft:jukebox
execute in minecraft:overworld run setblock 74015 101 2 minecraft:note_block
execute in minecraft:overworld run setblock 74015 101 -2 minecraft:note_block
execute in minecraft:overworld run setblock 74011 105 0 minecraft:lantern[hanging=true]
execute in minecraft:overworld run setblock 74015 101 5 minecraft:potted_bamboo
execute in minecraft:overworld run setblock 73985 101 9 minecraft:red_bed[facing=west,part=head]
execute in minecraft:overworld run setblock 73986 101 9 minecraft:red_bed[facing=west,part=foot]
execute in minecraft:overworld run setblock 73985 101 12 minecraft:blue_bed[facing=west,part=head]
execute in minecraft:overworld run setblock 73986 101 12 minecraft:blue_bed[facing=west,part=foot]
execute in minecraft:overworld run setblock 73985 101 10 minecraft:stripped_spruce_log[axis=y]
execute in minecraft:overworld run setblock 73985 102 10 minecraft:candle[candles=2,lit=true]
execute in minecraft:overworld run fill 73987 101 15 73989 103 15 minecraft:stripped_spruce_wood
execute in minecraft:overworld run fill 73987 101 9 73990 101 13 minecraft:white_carpet
execute in minecraft:overworld run setblock 73989 105 11 minecraft:lantern[hanging=true]
execute in minecraft:overworld run fill 73999 101 7 74001 101 15 minecraft:red_carpet
execute in minecraft:overworld run setblock 73997 101 15 minecraft:potted_azalea_bush
execute in minecraft:overworld run setblock 74003 101 15 minecraft:potted_azalea_bush
execute in minecraft:overworld run fill 73995 101 11 73995 101 13 minecraft:spruce_stairs[facing=west]
execute in minecraft:overworld run fill 74005 101 11 74005 101 13 minecraft:spruce_stairs[facing=east]
execute in minecraft:overworld run fill 73995 101 15 73995 102 15 minecraft:dark_oak_fence
execute in minecraft:overworld run setblock 74000 105 11 minecraft:lantern[hanging=true]
execute in minecraft:overworld run fill 74013 100 13 74014 100 14 minecraft:water
execute in minecraft:overworld run setblock 74013 101 13 minecraft:lily_pad
execute in minecraft:overworld run setblock 74015 101 7 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 74007 101 15 minecraft:flowering_azalea
execute in minecraft:overworld run setblock 74015 101 15 minecraft:azalea
execute in minecraft:overworld run setblock 74008 101 8 minecraft:potted_orange_tulip
execute in minecraft:overworld run setblock 74015 101 10 minecraft:potted_oxeye_daisy
execute in minecraft:overworld run fill 74008 101 11 74008 101 12 minecraft:spruce_stairs[facing=west]
execute in minecraft:overworld run setblock 74011 105 11 minecraft:lantern[hanging=true]
execute in minecraft:overworld run summon minecraft:text_display 74000.5 104.6 17.6 {Tags:["mg_holo","mg_murderh"],billboard:"center",background:0,shadow:true,text:[{"text": "Villa Nachtschatten", "color": "dark_red", "bold": true}],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.2f,1.2f,1.2f]}}
execute in minecraft:overworld run summon minecraft:marker 73988.5 101 -9.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74000.5 101 -14.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74012.5 101 -8.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 73990.5 101 2.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74000.5 101 3.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74010.5 101 -2.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 73990.5 101 12.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74000.5 101 12.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74011.5 101 12.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 73978.5 101 -12.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74022.5 101 12.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 73988.5 101 22.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74012.5 101 -22.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 73978.5 101 18.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74022.5 101 -18.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run summon minecraft:marker 74006.5 101 26.5 {Tags:["mg_murder_sp"]}
execute in minecraft:overworld run kill @e[type=minecraft:item,x=73970,y=95,z=-30,dx=60,dy=30,dz=60]
