execute as @p[tag=mg_al_murder,tag=!mg_murder_m,gamemode=adventure,distance=..1.8] run function mg:murder/bow_get
kill @s
