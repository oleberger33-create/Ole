title @a[tag=mg_murder_m] times 5 70 20
title @a[tag=mg_murder_m] subtitle {"text": "Erledige alle – aber bleib unerkannt!", "color": "gray"}
title @a[tag=mg_murder_m] title {"text": "Du bist der MÖRDER", "color": "dark_red", "bold": true}
title @a[tag=mg_murder_d] times 5 70 20
title @a[tag=mg_murder_d] subtitle {"text": "Finde den Mörder und erschieße ihn!", "color": "gray"}
title @a[tag=mg_murder_d] title {"text": "Du bist der DETEKTIV", "color": "aqua", "bold": true}
title @a[tag=mg_murder_i] times 5 70 20
title @a[tag=mg_murder_i] subtitle {"text": "Überlebe! 10 Gold = Bogen + Pfeil", "color": "gray"}
title @a[tag=mg_murder_i] title {"text": "Du bist UNSCHULDIG", "color": "green", "bold": true}
tellraw @a[tag=mg_murder_m] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du bist der Mörder. In 7 Sekunden bekommst du dein Schwert – ein Treffer tötet. Tu so, als wärst du unschuldig!", "color": "red", "italic": false}]
tellraw @a[tag=mg_murder_d] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du bist der Detektiv. In 7 Sekunden bekommst du einen Bogen. Nach jedem Schuss gibt es nach 5 s einen neuen Pfeil. Triffst du einen Unschuldigen, stirbst du selbst!", "color": "aqua", "italic": false}]
tellraw @a[tag=mg_murder_i] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du bist unschuldig. Versteck dich, sammle Gold (10 Gold = Bogen + Pfeil) und überlebe 4 Minuten!", "color": "green", "italic": false}]
execute as @a[tag=mg_murder_m] at @s run playsound minecraft:entity.elder_guardian.curse master @s ~ ~ ~ 0.7 1
execute as @a[tag=mg_murder_d] at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.2
execute as @a[tag=mg_murder_i] at @s run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 1 1
