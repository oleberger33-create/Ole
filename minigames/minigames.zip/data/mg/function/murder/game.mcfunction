scoreboard players add #murder_t mg 1
scoreboard players operation #m mg = #murder_t mg
scoreboard players operation #m mg %= #20 mg
scoreboard players operation #m5 mg = #murder_t mg
scoreboard players operation #m5 mg %= #5 mg
scoreboard players operation #m200 mg = #murder_t mg
scoreboard players operation #m200 mg %= #murder_200 mg
execute if score #murder_t mg matches 60 run function mg:murder/reveal
execute if score #murder_t mg matches 200 run function mg:murder/arm
execute if score #murder_t mg matches 3600 run function mg:murder/last_minute
execute if score #murder_t mg matches 4600.. if score #m mg matches 0 as @a[tag=mg_murder] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1.5
execute as @a[tag=mg_al_murder,scores={mg_deaths=1..}] run function mg:murder/died
execute if score #murder_win mg matches 0 as @a[tag=mg_al_murder,tag=!mg_murder_m,scores={mg_murder_k=1..}] run function mg:murder/punish
scoreboard players set @a[tag=mg_murder_m] mg_murder_k 0
execute as @a[tag=mg_al_murder,scores={mg_murder_cd=1}] run function mg:murder/arrow_give
scoreboard players remove @a[tag=mg_al_murder,scores={mg_murder_cd=1..}] mg_murder_cd 1
execute as @a[tag=mg_al_murder,tag=!mg_murder_m,scores={mg_murder_cd=0}] if function mg:murder/need_arrow run scoreboard players set @s mg_murder_cd 100
execute if score #m5 mg matches 0 run function mg:murder/slow
execute if score #m200 mg matches 100 run function mg:murder/gold
execute if score #m mg matches 0 run function mg:murder/hud
execute if score #m mg matches 10 run function mg:murder/hud
execute if score #murder_win mg matches 1 run return run function mg:murder/win_i
execute unless entity @a[tag=mg_al_murder,tag=mg_murder_m] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Der Mörder hat das Spiel verlassen!", "color": "yellow", "italic": false, "bold": true}]
execute unless entity @a[tag=mg_al_murder,tag=mg_murder_m] run return run function mg:murder/win_i
execute unless entity @a[tag=mg_al_murder,tag=!mg_murder_m] run return run function mg:murder/win_m
execute if score #murder_t mg matches 4800.. run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die Zeit ist um – der Mörder hat versagt!", "color": "yellow", "italic": false, "bold": true}]
execute if score #murder_t mg matches 4800.. run return run function mg:murder/win_i
