tp @s @e[type=minecraft:marker,tag=mg_murder_sp,tag=!mg_murder_used,sort=random,limit=1]
execute at @s run tag @e[type=minecraft:marker,tag=mg_murder_sp,distance=..0.6] add mg_murder_used
execute at @s run playsound minecraft:block.wooden_door.open master @s ~ ~ ~ 0.6 0.8
