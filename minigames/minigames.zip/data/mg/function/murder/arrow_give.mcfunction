give @s minecraft:arrow 1
playsound minecraft:item.crossbow.loading_end master @s ~ ~ ~ 1 1.2
