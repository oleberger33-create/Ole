effect give @s minecraft:speed 10 1 true
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "10 Gold eingetauscht: ", "color": "gold", "italic": false}, {"text": "10 s Tempo!", "color": "dark_red", "italic": false, "bold": true}]
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 0.8
