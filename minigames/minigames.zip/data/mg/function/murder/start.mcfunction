function mg:murder/build
tag @a[tag=mg_q_murder,tag=mg_hub,limit=12,sort=random] add mg_murder
tag @a[tag=mg_murder] remove mg_q_murder
execute as @a[tag=mg_murder] run function mg:q/leave_all
tag @a[tag=mg_murder] remove mg_hub
clear @a[tag=mg_murder]
effect clear @a[tag=mg_murder]
gamemode adventure @a[tag=mg_murder]
tag @a[tag=mg_murder] add mg_al_murder
scoreboard players set @a[tag=mg_murder] mg_deaths 0
execute as @a[tag=mg_murder] run execute in minecraft:overworld run spawnpoint @s 74000 120 23
scoreboard players set #murder_t mg 0
tag @a[tag=mg_murder] remove mg_murder_m
tag @a[tag=mg_murder] remove mg_murder_d
tag @a[tag=mg_murder] remove mg_murder_i
tag @a[tag=mg_murder] remove mg_murder_bad
tag @a[tag=mg_murder] remove mg_murder_hero
execute as @a[tag=mg_murder] run function mg:murder/spawn_one
kill @e[type=minecraft:marker,tag=mg_murder_sp]
team join mg_murder_t @a[tag=mg_murder]
tag @a[tag=mg_murder,sort=random,limit=1] add mg_murder_m
tag @a[tag=mg_murder,tag=!mg_murder_m,sort=random,limit=1] add mg_murder_d
tag @a[tag=mg_murder,tag=!mg_murder_m,tag=!mg_murder_d] add mg_murder_i
scoreboard players set @a[tag=mg_murder] mg_murder_k 0
scoreboard players set @a[tag=mg_murder] mg_murder_g 0
scoreboard players set @a[tag=mg_murder] mg_murder_cd 0
effect give @a[tag=mg_murder] minecraft:weakness infinite 0 true
effect give @a[tag=mg_murder] minecraft:saturation infinite 0 true
effect give @a[tag=mg_murder] minecraft:instant_health 1 10 true
scoreboard players set #murder_win mg 0
bossbar set mg:murder color yellow
bossbar set mg:murder value 4800
bossbar set mg:murder players @a[tag=mg_murder]
bossbar set mg:murder visible true
execute in minecraft:overworld run forceload remove 73968 -32 74032 32
scoreboard players set #murder mg 2
title @a[tag=mg_murder] times 5 50 10
title @a[tag=mg_murder] title {"text": "MURDER MYSTERY", "color": "dark_red", "bold": true}
title @a[tag=mg_murder] subtitle {"text": "Wer ist der Mörder?", "color": "white"}
tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Einer ist der Mörder (Schwert, ein Treffer tötet), einer der Detektiv (Bogen, neuer Pfeil nach 5 s), alle anderen sind unschuldig. Sammle Gold: 10 Gold = Bogen + Pfeil. Wer einen Unschuldigen erschießt, stirbt selbst. Die Unschuldigen gewinnen, wenn der Mörder stirbt oder 4 Minuten um sind – der Mörder, wenn alle anderen tot sind. Namen sind versteckt!", "color": "gray"}]
tellraw @a[tag=mg_murder] [{"text": "  "}, {"text": "[Spiel verlassen]", "color": "red", "click_event": {"action": "run_command", "command": "/trigger mg_aktion set 99"}}]
