execute store result score #n mg if entity @e[type=minecraft:item,x=73970,y=95,z=-30,dx=60,dy=30,dz=60,tag=mg_murder_gi]
execute if score #n mg matches 14.. run return 0
function mg:murder/gold_one
function mg:murder/gold_one
function mg:murder/gold_one
