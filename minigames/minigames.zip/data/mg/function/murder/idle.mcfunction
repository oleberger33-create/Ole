execute store result score #n mg if entity @a[tag=mg_q_murder,tag=mg_hub]
execute if score #n mg matches 3.. run scoreboard players set #murder_cd mg 300
execute if score #n mg matches 3.. run execute in minecraft:overworld run forceload add 73968 -32 74032 32
execute if score #n mg matches 3.. run tellraw @a[tag=mg_q_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Murder Mystery startet in 15 Sekunden!", "color": "dark_red"}]
execute if score #n mg matches 3.. run scoreboard players set #murder mg 1
