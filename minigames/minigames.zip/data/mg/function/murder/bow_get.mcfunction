clear @s minecraft:bow
give @s minecraft:bow[minecraft:custom_name={"text": "Detektiv-Bogen", "color": "aqua", "italic": false, "bold": true},minecraft:lore=[{"text": "Ein Treffer genügt. Neuer Pfeil nach 5 s.", "color": "gray", "italic": false}],minecraft:enchantments={"minecraft:power":255},minecraft:unbreakable={},minecraft:custom_data={mg_murder:"dbow"},minecraft:tooltip_display={hidden_components:["minecraft:enchantments","minecraft:unbreakable","minecraft:attribute_modifiers"]}]
execute unless items entity @s container.* minecraft:arrow run give @s minecraft:arrow 1
scoreboard players set @s mg_murder_cd 0
tag @s remove mg_murder_i
tag @s add mg_murder_d
tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Jemand hat den Detektiv-Bogen aufgehoben!", "color": "aqua", "italic": false}]
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du hast jetzt den Detektiv-Bogen – finde den Mörder!", "color": "aqua", "italic": false, "bold": true}]
playsound minecraft:item.armor.equip_chain master @s ~ ~ ~ 1 1.2
