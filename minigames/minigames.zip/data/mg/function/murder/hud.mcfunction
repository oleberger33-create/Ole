scoreboard players operation #murder_rem mg = #murder_len mg
scoreboard players operation #murder_rem mg -= #murder_t mg
scoreboard players operation #murder_s mg = #murder_rem mg
scoreboard players add #murder_s mg 19
scoreboard players operation #murder_s mg /= #20 mg
scoreboard players operation #murder_mm mg = #murder_s mg
scoreboard players operation #murder_mm mg /= #60 mg
scoreboard players operation #murder_ss mg = #murder_s mg
scoreboard players operation #murder_ss mg %= #60 mg
scoreboard players operation #murder_s10 mg = #murder_ss mg
scoreboard players operation #murder_s10 mg /= #10 mg
scoreboard players operation #murder_s1 mg = #murder_ss mg
scoreboard players operation #murder_s1 mg %= #10 mg
execute store result score #murder_alive mg if entity @a[tag=mg_al_murder,tag=!mg_murder_m]
execute store result bossbar mg:murder value run scoreboard players get #murder_rem mg
bossbar set mg:murder name [{"text": "Villa Nachtschatten  ", "color": "dark_red", "italic": false, "bold": true}, {"text": "⌛ ", "color": "gray", "italic": false}, {"score": {"name": "#murder_mm", "objective": "mg"}, "color": "white"}, {"text": ":", "color": "white", "italic": false}, {"score": {"name": "#murder_s10", "objective": "mg"}, "color": "white"}, {"score": {"name": "#murder_s1", "objective": "mg"}, "color": "white"}, {"text": "   ☺ ", "color": "green", "italic": false}, {"score": {"name": "#murder_alive", "objective": "mg"}, "color": "white"}, {"text": " Unschuldige", "color": "gray", "italic": false}]
bossbar set mg:murder players @a[tag=mg_murder]
execute as @a[tag=mg_al_murder,tag=mg_murder_m] run title @s actionbar [{"text": "⚔ MÖRDER", "color": "dark_red", "italic": false, "bold": true}, {"text": "   Gold ", "color": "gold", "italic": false}, {"score": {"name": "@s", "objective": "mg_murder_g"}, "color": "yellow"}, {"text": "/10", "color": "gold", "italic": false}]
execute as @a[tag=mg_al_murder,tag=mg_murder_d,scores={mg_murder_cd=0}] run title @s actionbar [{"text": "✪ DETEKTIV", "color": "aqua", "italic": false, "bold": true}, {"text": "   Gold ", "color": "gold", "italic": false}, {"score": {"name": "@s", "objective": "mg_murder_g"}, "color": "yellow"}, {"text": "/10", "color": "gold", "italic": false}]
execute as @a[tag=mg_al_murder,tag=mg_murder_d,scores={mg_murder_cd=1..}] run title @s actionbar [{"text": "✪ DETEKTIV", "color": "aqua", "italic": false, "bold": true}, {"text": "   Pfeil lädt ...", "color": "gray", "italic": false}, {"text": "   Gold ", "color": "gold", "italic": false}, {"score": {"name": "@s", "objective": "mg_murder_g"}, "color": "yellow"}, {"text": "/10", "color": "gold", "italic": false}]
execute as @a[tag=mg_al_murder,tag=mg_murder_i] run title @s actionbar [{"text": "☺ UNSCHULDIG", "color": "green", "italic": false, "bold": true}, {"text": "   Gold ", "color": "gold", "italic": false}, {"score": {"name": "@s", "objective": "mg_murder_g"}, "color": "yellow"}, {"text": "/10", "color": "gold", "italic": false}]
title @a[tag=mg_murder,tag=!mg_al_murder] actionbar [{"text": "☠ Du bist tot", "color": "gray", "italic": false, "bold": true}, {"text": " – du schaust zu", "color": "dark_gray", "italic": false}]
