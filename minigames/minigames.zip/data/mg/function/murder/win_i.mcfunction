tag @a[tag=mg_murder,tag=!mg_murder_m,tag=!mg_murder_bad] add mg_al_murder
tag @a[tag=mg_murder_m] remove mg_al_murder
tag @a[tag=mg_murder_bad] remove mg_al_murder
title @a[tag=mg_murder] subtitle {"text": "Die Unschuldigen gewinnen!", "color": "green", "italic": false, "bold": true}
tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die Unschuldigen gewinnen!", "color": "green", "italic": false, "bold": true}]
execute if entity @a[tag=mg_murder_m] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Der Mörder war: ", "color": "gray", "italic": false}, {"selector": "@a[tag=mg_murder_m]", "color": "dark_red", "bold": true}]
execute if entity @a[tag=mg_murder_d] run tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Detektiv: ", "color": "gray", "italic": false}, {"selector": "@a[tag=mg_murder_d]", "color": "aqua", "bold": true}]
execute as @a[tag=mg_al_murder] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
execute as @a[tag=mg_murder_m] at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 0.4 1.2
clear @a[tag=mg_murder] minecraft:iron_sword
clear @a[tag=mg_murder] minecraft:bow
clear @a[tag=mg_murder] minecraft:arrow
effect give @a[tag=mg_murder] minecraft:resistance 10 4 true
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=73970,y=95,z=-30,dx=60,dy=30,dz=60]
kill @e[type=minecraft:item,tag=mg_murder_bi]
function mg:murder/end
