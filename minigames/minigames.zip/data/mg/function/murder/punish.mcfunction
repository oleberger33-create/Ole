scoreboard players set @s mg_murder_k 0
tag @s add mg_murder_bad
tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " hat einen Unschuldigen getötet – und stirbt dafür selbst!", "color": "red", "italic": false}]
kill @s
