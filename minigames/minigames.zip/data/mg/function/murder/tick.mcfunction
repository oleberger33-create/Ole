execute if score #murder mg matches 2 run function mg:murder/game
