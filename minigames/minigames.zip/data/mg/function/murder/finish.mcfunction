execute as @a[tag=mg_murder] run function mg:hub/enter
tag @a remove mg_murder
tag @a remove mg_al_murder
scoreboard players set #murder mg 0
bossbar set mg:murder players
bossbar set mg:murder visible false
tag @a remove mg_murder_m
tag @a remove mg_murder_d
tag @a remove mg_murder_i
tag @a remove mg_murder_bad
tag @a remove mg_murder_hero
team empty mg_murder_t
kill @e[type=minecraft:marker,tag=mg_murder_sp]
kill @e[type=minecraft:item,tag=mg_murder_bi]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=73970,y=95,z=-30,dx=60,dy=30,dz=60]
execute in minecraft:overworld run kill @e[type=minecraft:item,x=73968,dx=64,y=60,dy=90,z=-32,dz=64]
