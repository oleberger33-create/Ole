bossbar set mg:murder color red
effect give @a[tag=mg_al_murder] minecraft:glowing infinite 0 true
tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Noch 60 Sekunden! ", "color": "red", "italic": false, "bold": true}, {"text": "Alle Lebenden leuchten jetzt – niemand kann sich mehr verstecken!", "color": "gray", "italic": false}]
execute as @a[tag=mg_murder] at @s run playsound minecraft:block.bell.use master @s ~ ~ ~ 1 0.7
