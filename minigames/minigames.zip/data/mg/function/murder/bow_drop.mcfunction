tag @s add mg_murder_bi
data merge entity @s {PickupDelay:32767,Glowing:1b,Age:-32768}
tellraw @a[tag=mg_murder] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Der Detektiv-Bogen liegt am Boden! ", "color": "aqua", "italic": false, "bold": true}, {"text": "Unschuldige können ihn aufheben.", "color": "gray", "italic": false}]
execute as @a[tag=mg_murder] at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 0.8
