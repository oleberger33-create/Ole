execute store result score #n mg run clear @a[tag=mg_al_murder] *[minecraft:custom_data~{mg_murder:"dbow"}] 0
execute if entity @e[type=minecraft:item,tag=mg_murder_bi] run scoreboard players add #n mg 1
execute if score #n mg matches 0 run function mg:murder/bow_respawn
