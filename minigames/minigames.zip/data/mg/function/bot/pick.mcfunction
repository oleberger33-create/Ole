scoreboard players operation #bot_m mg = @s mg_aktion
scoreboard players remove #bot_m mg 200
scoreboard players operation #bot_d mg = #bot_m mg
scoreboard players operation #bot_d mg %= #10 mg
scoreboard players operation #bot_m mg /= #10 mg
execute unless score #bot_m mg matches 1..5 run return 0
execute unless score #bot_d mg matches 1..4 run return 0
execute store result score #bot_dif mg run difficulty
execute if score #bot_dif mg matches 0 run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Bot-Duelle gehen nicht, solange der Server auf Friedlich steht.", "color": "red", "italic": false}]
execute if score #bot_s1 mg matches 0 run return run function mg:bot/claim1
execute if score #bot_s2 mg matches 0 run return run function mg:bot/claim2
execute if score #bot_s3 mg matches 0 run return run function mg:bot/claim3
execute if score #bot_s4 mg matches 0 run return run function mg:bot/claim4
execute if score #bot_s5 mg matches 0 run return run function mg:bot/claim5
execute if score #bot_s6 mg matches 0 run return run function mg:bot/claim6
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Alle Bot-Arenen sind gerade belegt – versuch es gleich nochmal.", "color": "red", "italic": false}]
