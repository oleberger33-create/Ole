execute in minecraft:overworld positioned 90600.5 100 0.5 run kill @e[tag=mg_botm,distance=..90]
execute in minecraft:overworld positioned 90600.5 100 0.5 run kill @e[type=minecraft:item,distance=..90]
execute in minecraft:overworld positioned 90600.5 100 0.5 run kill @e[type=#minecraft:arrows,distance=..90]
execute in minecraft:overworld positioned 90600.5 100 0.5 run kill @e[type=minecraft:experience_orb,distance=..90]
execute in minecraft:overworld run forceload remove 90576 -24 90624 24
scoreboard players set #bot_s2 mg 0
scoreboard players set #bot_o2 mg 0
