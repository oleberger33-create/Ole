function mg:q/leave_all
scoreboard players add #bot_id mg 1
scoreboard players operation @s mg_bot_id = #bot_id mg
scoreboard players set #bot_s4 mg 1
scoreboard players operation #bot_o4 mg = #bot_id mg
scoreboard players set @s mg_bot_sl 4
scoreboard players operation @s mg_bot_md = #bot_m mg
scoreboard players operation @s mg_bot_df = #bot_d mg
scoreboard players set @s mg_bot_p 0
scoreboard players set @s mg_bot_b 0
scoreboard players set @s mg_bot_st 4
scoreboard players set @s mg_bot_t 0
execute in minecraft:overworld run forceload add 91176 -24 91224 24
tag @s remove mg_hub
tag @s add mg_bot
clear @s
effect clear @s
effect give @s minecraft:resistance 10 4 true
title @s actionbar {"text": "Arena wird vorbereitet …", "color": "gray", "italic": false}
