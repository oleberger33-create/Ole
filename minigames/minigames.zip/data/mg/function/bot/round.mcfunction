kill @e[tag=mg_botm,distance=..90]
kill @e[type=minecraft:item,distance=..90]
kill @e[type=#minecraft:arrows,distance=..90]
scoreboard players set @s mg_bot_st 1
scoreboard players set @s mg_bot_t 0
scoreboard players set @s mg_deaths 0
scoreboard players set @s mg_bot_hp 0
scoreboard players set @s mg_bot_hb 0
scoreboard players set @s mg_bot_dd 0
scoreboard players set @s mg_bot_dt 0
execute if score @s mg_bot_md matches 1 run function mg:bot/kit_schwert
execute if score @s mg_bot_md matches 2 run function mg:bot/kit_boxen
execute if score @s mg_bot_md matches 3 run function mg:bot/kit_sumo
execute if score @s mg_bot_md matches 4 run function mg:bot/kit_kb
execute if score @s mg_bot_md matches 5 run function mg:bot/kit_bogen
execute if score @s mg_bot_md matches 1 run tp @s ~-7 ~1 ~ -90 0
execute if score @s mg_bot_md matches 2 run tp @s ~-3 ~1 ~ -90 0
execute if score @s mg_bot_md matches 3 run tp @s ~-3 ~1 ~ -90 0
execute if score @s mg_bot_md matches 4 run tp @s ~-3 ~1 ~ -90 0
execute if score @s mg_bot_md matches 5 run tp @s ~-14 ~1 ~ -90 0
execute in minecraft:overworld run spawnpoint @s 0 101 17
execute if score @s mg_bot_md matches 1 if score @s mg_bot_df matches 1 run function mg:bot/mob_11
execute if score @s mg_bot_md matches 1 if score @s mg_bot_df matches 2 run function mg:bot/mob_12
execute if score @s mg_bot_md matches 1 if score @s mg_bot_df matches 3 run function mg:bot/mob_13
execute if score @s mg_bot_md matches 1 if score @s mg_bot_df matches 4 run function mg:bot/mob_14
execute if score @s mg_bot_md matches 2 if score @s mg_bot_df matches 1 run function mg:bot/mob_21
execute if score @s mg_bot_md matches 2 if score @s mg_bot_df matches 2 run function mg:bot/mob_22
execute if score @s mg_bot_md matches 2 if score @s mg_bot_df matches 3 run function mg:bot/mob_23
execute if score @s mg_bot_md matches 2 if score @s mg_bot_df matches 4 run function mg:bot/mob_24
execute if score @s mg_bot_md matches 3 if score @s mg_bot_df matches 1 run function mg:bot/mob_31
execute if score @s mg_bot_md matches 3 if score @s mg_bot_df matches 2 run function mg:bot/mob_32
execute if score @s mg_bot_md matches 3 if score @s mg_bot_df matches 3 run function mg:bot/mob_33
execute if score @s mg_bot_md matches 3 if score @s mg_bot_df matches 4 run function mg:bot/mob_34
execute if score @s mg_bot_md matches 4 if score @s mg_bot_df matches 1 run function mg:bot/mob_41
execute if score @s mg_bot_md matches 4 if score @s mg_bot_df matches 2 run function mg:bot/mob_42
execute if score @s mg_bot_md matches 4 if score @s mg_bot_df matches 3 run function mg:bot/mob_43
execute if score @s mg_bot_md matches 4 if score @s mg_bot_df matches 4 run function mg:bot/mob_44
execute if score @s mg_bot_md matches 5 if score @s mg_bot_df matches 1 run function mg:bot/mob_51
execute if score @s mg_bot_md matches 5 if score @s mg_bot_df matches 2 run function mg:bot/mob_52
execute if score @s mg_bot_md matches 5 if score @s mg_bot_df matches 3 run function mg:bot/mob_53
execute if score @s mg_bot_md matches 5 if score @s mg_bot_df matches 4 run function mg:bot/mob_54
scoreboard players operation @e[tag=mg_botm_new,distance=..40] mg_bot_id = @s mg_bot_id
tag @e[tag=mg_botm_new,distance=..40] remove mg_botm_new
scoreboard players operation #bot_rn mg = @s mg_bot_p
scoreboard players operation #bot_rn mg += @s mg_bot_b
scoreboard players add #bot_rn mg 1
title @s times 0 30 10
title @s title [{"text": "Runde ", "color": "gold", "italic": false, "bold": true},{"score":{"name":"#bot_rn","objective":"mg"},"color":"gold","bold":true}]
title @s subtitle [{"text": "Du ", "color": "gray", "italic": false},{"score":{"name":"@s","objective":"mg_bot_p"},"color":"white","bold":true},{"text": " : ", "color": "gray", "italic": false},{"score":{"name":"@s","objective":"mg_bot_b"},"color":"white","bold":true},{"text": " Bot", "color": "gray", "italic": false}]
