execute in minecraft:overworld positioned 91500.5 100 0.5 run kill @e[tag=mg_botm,distance=..90]
execute in minecraft:overworld positioned 91500.5 100 0.5 run kill @e[type=minecraft:item,distance=..90]
execute in minecraft:overworld positioned 91500.5 100 0.5 run kill @e[type=#minecraft:arrows,distance=..90]
execute in minecraft:overworld positioned 91500.5 100 0.5 run kill @e[type=minecraft:experience_orb,distance=..90]
execute in minecraft:overworld run forceload remove 91476 -24 91524 24
scoreboard players set #bot_s5 mg 0
scoreboard players set #bot_o5 mg 0
