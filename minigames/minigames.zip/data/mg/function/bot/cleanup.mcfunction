execute if score @s mg_bot_sl matches 1 if score #bot_o1 mg = @s mg_bot_id run function mg:bot/free1
execute if score @s mg_bot_sl matches 2 if score #bot_o2 mg = @s mg_bot_id run function mg:bot/free2
execute if score @s mg_bot_sl matches 3 if score #bot_o3 mg = @s mg_bot_id run function mg:bot/free3
execute if score @s mg_bot_sl matches 4 if score #bot_o4 mg = @s mg_bot_id run function mg:bot/free4
execute if score @s mg_bot_sl matches 5 if score #bot_o5 mg = @s mg_bot_id run function mg:bot/free5
execute if score @s mg_bot_sl matches 6 if score #bot_o6 mg = @s mg_bot_id run function mg:bot/free6
tag @s remove mg_bot
scoreboard players set @s mg_bot_sl 0
scoreboard players set @s mg_bot_st 0
