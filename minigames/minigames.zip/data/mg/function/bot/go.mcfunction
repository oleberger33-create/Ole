scoreboard players set @s mg_bot_st 2
scoreboard players set @s mg_bot_t 0
execute as @e[tag=mg_botm,distance=..90] run data merge entity @s {NoAI:0b,Invulnerable:0b}
effect clear @s minecraft:slowness
effect clear @s minecraft:weakness
scoreboard players set @s mg_bot_dd 0
scoreboard players set @s mg_bot_dt 0
title @s actionbar {"text": "LOS!", "color": "green", "italic": false, "bold": true}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
