clear @s
effect clear @s
attribute @s minecraft:max_health base set 20
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
effect give @s minecraft:slowness 3 255 true
effect give @s minecraft:weakness 3 255 true
effect give @s minecraft:resistance 3 4 true
