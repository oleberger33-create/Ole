tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zeit um – die Runde wird wiederholt.", "color": "gray", "italic": false}]
function mg:bot/round
