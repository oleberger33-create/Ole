execute in minecraft:overworld positioned 90900.5 100 0.5 run kill @e[tag=mg_botm,distance=..90]
execute in minecraft:overworld positioned 90900.5 100 0.5 run kill @e[type=minecraft:item,distance=..90]
execute in minecraft:overworld positioned 90900.5 100 0.5 run kill @e[type=#minecraft:arrows,distance=..90]
execute in minecraft:overworld positioned 90900.5 100 0.5 run kill @e[type=minecraft:experience_orb,distance=..90]
execute in minecraft:overworld run forceload remove 90876 -24 90924 24
scoreboard players set #bot_s3 mg 0
scoreboard players set #bot_o3 mg 0
