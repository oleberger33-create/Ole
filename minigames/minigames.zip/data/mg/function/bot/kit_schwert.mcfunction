clear @s
effect clear @s
attribute @s minecraft:max_health base set 20
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
effect give @s minecraft:slowness 3 255 true
effect give @s minecraft:weakness 3 255 true
effect give @s minecraft:resistance 3 4 true
item replace entity @s armor.head with minecraft:iron_helmet[minecraft:unbreakable={}]
item replace entity @s armor.chest with minecraft:iron_chestplate[minecraft:unbreakable={}]
item replace entity @s armor.legs with minecraft:iron_leggings[minecraft:unbreakable={}]
item replace entity @s armor.feet with minecraft:iron_boots[minecraft:unbreakable={}]
item replace entity @s hotbar.0 with minecraft:iron_sword[minecraft:unbreakable={}]
item replace entity @s hotbar.1 with minecraft:cooked_beef 4
