execute if score @s mg_deaths matches 1.. run return run function mg:bot/r_bot
execute at @s if entity @s[y=-64,dy=159] run return run function mg:bot/r_bot
execute as @e[tag=mg_botm,distance=..90] at @s if entity @s[y=-64,dy=159] run kill @s
execute unless entity @e[tag=mg_botm,distance=..90] run return run function mg:bot/nomob
execute if score @s mg_bot_t matches 600 run effect give @e[tag=mg_botm,distance=..90] minecraft:glowing infinite 0 true
execute if score @s mg_bot_t matches 2400.. run return run function mg:bot/draw
execute if score @s mg_bot_md matches 2 run return run function mg:bot/boxhits
scoreboard players operation #bot_m20 mg = @s mg_bot_t
scoreboard players operation #bot_m20 mg %= #20 mg
execute if score #bot_m20 mg matches 0 run title @s actionbar [{"text": "Du ", "color": "gray", "italic": false}, {"score": {"name": "@s", "objective": "mg_bot_p"}, "color": "white", "bold": true}, {"text": " : ", "color": "gray", "italic": false}, {"score": {"name": "@s", "objective": "mg_bot_b"}, "color": "white", "bold": true}, {"text": " Bot", "color": "gray", "italic": false}]
