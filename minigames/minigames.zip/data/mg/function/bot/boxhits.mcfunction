execute if score @s mg_bot_dd matches 1.. run scoreboard players add @s mg_bot_hp 1
scoreboard players set @s mg_bot_dd 0
execute if score @s mg_bot_dt matches 1.. run scoreboard players add @s mg_bot_hb 1
scoreboard players set @s mg_bot_dt 0
title @s actionbar [{"text": "Treffer  Du ", "color": "gray", "italic": false}, {"score": {"name": "@s", "objective": "mg_bot_hp"}, "color": "white", "bold": true}, {"text": "/10", "color": "gray", "italic": false}, {"text": "   Bot ", "color": "gray", "italic": false}, {"score": {"name": "@s", "objective": "mg_bot_hb"}, "color": "white", "bold": true}, {"text": "/", "color": "gray", "italic": false}, {"score": {"name": "@s", "objective": "mg_bot_nd"}, "color": "gray"}]
execute if score @s mg_bot_hp matches 10.. run return run function mg:bot/r_player
execute if score @s mg_bot_hb >= @s mg_bot_nd run return run function mg:bot/r_bot
