execute in minecraft:overworld positioned 91800.5 100 0.5 run kill @e[tag=mg_botm,distance=..90]
execute in minecraft:overworld positioned 91800.5 100 0.5 run kill @e[type=minecraft:item,distance=..90]
execute in minecraft:overworld positioned 91800.5 100 0.5 run kill @e[type=#minecraft:arrows,distance=..90]
execute in minecraft:overworld positioned 91800.5 100 0.5 run kill @e[type=minecraft:experience_orb,distance=..90]
execute in minecraft:overworld run forceload remove 91776 -24 91824 24
scoreboard players set #bot_s6 mg 0
scoreboard players set #bot_o6 mg 0
