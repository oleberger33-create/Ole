scoreboard players add @s mg_bot_t 1
kill @e[type=minecraft:item,distance=..90]
kill @e[type=minecraft:experience_orb,distance=..90]
execute if score @s mg_bot_st matches 4 run return run function mg:bot/loading
execute if score @s mg_bot_st matches 1 run return run function mg:bot/freeze
execute if score @s mg_bot_st matches 2 run return run function mg:bot/fight
execute if score @s mg_bot_st matches 3 if score @s mg_bot_t matches 50.. run function mg:hub/enter
