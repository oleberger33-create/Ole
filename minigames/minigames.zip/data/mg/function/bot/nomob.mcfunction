execute store result score #bot_dif mg run difficulty
execute if score #bot_dif mg matches 0 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Der Server steht auf Friedlich – das Bot-Duell wurde abgebrochen.", "color": "red", "italic": false}]
execute if score #bot_dif mg matches 0 run return run function mg:hub/enter
function mg:bot/r_player
