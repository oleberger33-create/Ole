execute if score @s mg_bot_sl matches 1 in minecraft:overworld positioned 90300.5 100 0.5 run return run function mg:bot/stick
execute if score @s mg_bot_sl matches 2 in minecraft:overworld positioned 90600.5 100 0.5 run return run function mg:bot/stick
execute if score @s mg_bot_sl matches 3 in minecraft:overworld positioned 90900.5 100 0.5 run return run function mg:bot/stick
execute if score @s mg_bot_sl matches 4 in minecraft:overworld positioned 91200.5 100 0.5 run return run function mg:bot/stick
execute if score @s mg_bot_sl matches 5 in minecraft:overworld positioned 91500.5 100 0.5 run return run function mg:bot/stick
execute if score @s mg_bot_sl matches 6 in minecraft:overworld positioned 91800.5 100 0.5 run return run function mg:bot/stick
