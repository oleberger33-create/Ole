execute if loaded ~-20 ~ ~-20 if loaded ~20 ~ ~20 if loaded ~-20 ~ ~20 if loaded ~20 ~ ~-20 run return run function mg:bot/begin
execute if score @s mg_bot_t matches 200.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Die Arena konnte nicht geladen werden – versuch es nochmal.", "color": "red", "italic": false}]
execute if score @s mg_bot_t matches 200.. run function mg:hub/enter
