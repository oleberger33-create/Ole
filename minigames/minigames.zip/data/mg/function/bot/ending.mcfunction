scoreboard players set @s mg_bot_st 3
scoreboard players set @s mg_bot_t 0
kill @e[tag=mg_botm,distance=..90]
effect give @s minecraft:resistance 5 4 true
effect give @s minecraft:weakness 5 255 true
scoreboard players set @s mg_deaths 0
title @s times 5 50 15
