scoreboard players set #bot_q mg -1
scoreboard players operation #bot_q mg = @s mg_bot_id
execute as @a[tag=mg_bot] if score @s mg_bot_id = #bot_q mg run return 0
kill @s
