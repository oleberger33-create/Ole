execute if score @s mg_bot_t matches 1 run title @s actionbar {"text":"3","color":"red","bold":true}
execute if score @s mg_bot_t matches 20 run title @s actionbar {"text":"2","color":"gold","bold":true}
execute if score @s mg_bot_t matches 40 run title @s actionbar {"text":"1","color":"yellow","bold":true}
execute if score @s mg_bot_t matches 1 run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score @s mg_bot_t matches 20 run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score @s mg_bot_t matches 40 run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
execute if score @s mg_bot_t matches 60.. run function mg:bot/go
