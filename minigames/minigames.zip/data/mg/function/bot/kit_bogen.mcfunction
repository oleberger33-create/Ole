clear @s
effect clear @s
attribute @s minecraft:max_health base set 20
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
effect give @s minecraft:slowness 3 255 true
effect give @s minecraft:weakness 3 255 true
effect give @s minecraft:resistance 3 4 true
item replace entity @s armor.head with minecraft:chainmail_helmet[minecraft:unbreakable={}]
item replace entity @s armor.chest with minecraft:chainmail_chestplate[minecraft:unbreakable={}]
item replace entity @s armor.legs with minecraft:chainmail_leggings[minecraft:unbreakable={}]
item replace entity @s armor.feet with minecraft:chainmail_boots[minecraft:unbreakable={}]
item replace entity @s hotbar.0 with minecraft:bow[minecraft:enchantments={"minecraft:infinity":1},minecraft:unbreakable={}]
item replace entity @s hotbar.1 with minecraft:stone_sword[minecraft:unbreakable={}]
item replace entity @s hotbar.2 with minecraft:cooked_beef 4
item replace entity @s inventory.0 with minecraft:arrow 1
