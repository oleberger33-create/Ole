scoreboard players add @s mg_bot_p 1
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Runde an dich! ", "color": "green", "italic": false, "bold": true}, {"text": "Du ", "color": "gray", "italic": false}, {"score": {"name": "@s", "objective": "mg_bot_p"}, "color": "white", "bold": true}, {"text": " : ", "color": "gray", "italic": false}, {"score": {"name": "@s", "objective": "mg_bot_b"}, "color": "white", "bold": true}, {"text": " Bot", "color": "gray", "italic": false}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if score @s mg_bot_p matches 2.. run return run function mg:bot/win
function mg:bot/round
