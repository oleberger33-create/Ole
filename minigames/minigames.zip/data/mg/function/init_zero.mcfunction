scoreboard players set #zero mg 0
