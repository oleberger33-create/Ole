execute as @a[tag=mg_duel_parkour] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Parkour-Duell – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_parkour] mg_wins 1
function mg:parkour/stop
