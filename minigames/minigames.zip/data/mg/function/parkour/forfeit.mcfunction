execute if score #parkour_r mg matches 2.. as @a[tag=mg_duel_parkour] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Parkour-Duell – Gegner ist weg.", "color": "white"}]
execute if score #parkour_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_parkour] mg_wins 1
execute if score #parkour_r mg matches 2.. run scoreboard players add @a[tag=mg_duel_parkour] mg_coins 5
execute if score #parkour_r mg matches ..1 run tellraw @a[tag=mg_duel_parkour] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dein Gegner ist weg, bevor eine Runde fertig war – keine Wertung.", "color": "gray"}]
function mg:parkour/stop
