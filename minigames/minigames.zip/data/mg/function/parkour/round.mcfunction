execute in minecraft:overworld run kill @e[type=minecraft:item,x=14955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=14955,dx=90,y=70,dy=80,z=-45,dz=90]
execute as @a[tag=mg_duel_parkour] run function mg:parkour/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_parkour,tag=mg_p1,limit=1] 14970 101 -6 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_parkour,tag=mg_p2,limit=1] 14970 101 6 -90 0
execute as @a[tag=mg_duel_parkour] run execute in minecraft:overworld run spawnpoint @s 0 101 17
kill @e[type=minecraft:horse,tag=mg_horse_parkour]
scoreboard players set #parkour_cd mg 60
scoreboard players set #parkour mg 1
title @a[tag=mg_duel_parkour] times 0 30 10
title @a[tag=mg_duel_parkour] title {"text": "Parkour-Duell", "color": "light_purple", "bold": true}
title @a[tag=mg_duel_parkour] subtitle [{"score":{"name":"@a[tag=mg_duel_parkour,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_parkour,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
