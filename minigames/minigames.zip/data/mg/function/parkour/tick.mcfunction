execute if score #parkour_cd mg matches 1.. run scoreboard players remove #parkour_cd mg 1
execute if score #parkour mg matches 1 if score #parkour_cd mg matches 0 run function mg:parkour/go
execute if score #parkour mg matches 1 if score #parkour_cd mg matches 0 run scoreboard players set #parkour mg 2
execute unless score #parkour mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_parkour]
execute if score #n mg matches ..1 run return run function mg:parkour/forfeit
execute as @a[tag=mg_duel_parkour] if entity @s[x=15018,dx=2,y=108,dy=3,z=-7,dz=2] run function mg:parkour/point
execute as @a[tag=mg_duel_parkour] if entity @s[x=15018,dx=2,y=108,dy=3,z=5,dz=2] run function mg:parkour/point
execute as @a[tag=mg_duel_parkour,tag=mg_p1,limit=1] at @s if entity @s[y=-64,dy=154] run execute in minecraft:overworld run tp @s 14970 101 -6 -90 0
execute as @a[tag=mg_duel_parkour,tag=mg_p2,limit=1] at @s if entity @s[y=-64,dy=154] run execute in minecraft:overworld run tp @s 14970 101 6 -90 0
