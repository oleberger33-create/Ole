title @a[tag=mg_duel_parkour] actionbar {"text": "LOS!", "color": "light_purple", "bold": true}
execute as @a[tag=mg_duel_parkour] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
