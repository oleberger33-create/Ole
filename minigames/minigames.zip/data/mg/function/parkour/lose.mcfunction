execute unless score #parkour mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_parkour] remove mg_rw
tag @a[tag=mg_duel_parkour] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_parkour] mg_round 1
tellraw @a[tag=mg_duel_parkour] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_parkour]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "light_purple"}]
execute as @a[tag=mg_duel_parkour] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_parkour,scores={mg_round=1..}] run return run function mg:parkour/win
scoreboard players set #parkour mg 1
function mg:parkour/round
