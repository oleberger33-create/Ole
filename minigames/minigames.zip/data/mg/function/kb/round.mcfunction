execute in minecraft:overworld run kill @e[type=minecraft:item,x=6955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=6955,dx=90,y=70,dy=80,z=-45,dz=90]
execute as @a[tag=mg_duel_kb] run function mg:kb/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_kb,tag=mg_p1,limit=1] 6997 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_kb,tag=mg_p2,limit=1] 7003 101 0 90 0
execute as @a[tag=mg_duel_kb] run execute in minecraft:overworld run spawnpoint @s 0 101 17
kill @e[type=minecraft:horse,tag=mg_horse_kb]
scoreboard players set #kb_cd mg 60
scoreboard players set #kb mg 1
title @a[tag=mg_duel_kb] times 0 30 10
title @a[tag=mg_duel_kb] title {"text": "Knockback-Stock", "color": "gold", "bold": true}
title @a[tag=mg_duel_kb] subtitle [{"score":{"name":"@a[tag=mg_duel_kb,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_kb,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
