execute unless score #kb mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_kb] remove mg_rw
tag @a[tag=mg_duel_kb] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_kb] mg_round 1
tellraw @a[tag=mg_duel_kb] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_kb]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "gold"}]
execute as @a[tag=mg_duel_kb] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_kb,scores={mg_round=2..}] run return run function mg:kb/win
scoreboard players set #kb mg 1
function mg:kb/round
