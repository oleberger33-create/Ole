title @a[tag=mg_duel_kb] actionbar {"text": "LOS!", "color": "gold", "bold": true}
execute as @a[tag=mg_duel_kb] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
