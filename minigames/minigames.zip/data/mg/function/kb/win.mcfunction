scoreboard players add @a[tag=mg_rw,tag=mg_duel_kb] mg_wins 1
scoreboard players add @a[tag=mg_rw,tag=mg_duel_kb] mg_coins 5
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_kb]", "color": "gold", "bold": true}, {"text": " gewinnt Knockback-Stock!", "color": "white"}]
title @a[tag=mg_duel_kb] times 10 50 15
title @a[tag=mg_duel_kb,tag=mg_rw] title {"text": "SIEG!", "color": "gold", "bold": true}
title @a[tag=mg_duel_kb,tag=!mg_rw] title {"text": "Verloren", "color": "red", "bold": true}
execute as @a[tag=mg_rw,tag=mg_duel_kb] at @s run summon minecraft:firework_rocket ~ ~1 ~ {LifeTime:20,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{flight_duration:1,explosions:[{shape:"star",colors:[I;16766720],has_twinkle:true}]}}}}
function mg:kb/stop
