execute as @a[tag=mg_duel_kb] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Knockback-Stock – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_kb] mg_wins 1
function mg:kb/stop
