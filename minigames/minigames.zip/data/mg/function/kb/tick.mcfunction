execute if score #kb_cd mg matches 1.. run scoreboard players remove #kb_cd mg 1
execute if score #kb mg matches 1 if score #kb_cd mg matches 0 run function mg:kb/go
execute if score #kb mg matches 1 if score #kb_cd mg matches 0 run scoreboard players set #kb mg 2
execute unless score #kb mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_kb]
execute if score #n mg matches ..1 run return run function mg:kb/forfeit
execute as @a[tag=mg_duel_kb] at @s if entity @s[y=-64,dy=159] run function mg:kb/lose
execute as @e[type=minecraft:player,tag=mg_duel_kb,scores={mg_deaths=1..}] run function mg:kb/lose
