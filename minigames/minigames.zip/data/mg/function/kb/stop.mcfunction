scoreboard players set #kb mg 0
kill @e[type=minecraft:horse,tag=mg_horse_kb]
execute as @a[tag=mg_duel_kb] run function mg:hub/enter
tag @a remove mg_duel_kb
tag @a[tag=mg_hub] remove mg_rw
execute in minecraft:overworld run kill @e[type=minecraft:item,x=6955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=6955,dx=90,y=70,dy=80,z=-45,dz=90]
