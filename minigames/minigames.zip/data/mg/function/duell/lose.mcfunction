execute unless score #duell mg matches 2 run return 0
scoreboard players set @s mg_deaths 0
tag @a[tag=mg_duel_duell] remove mg_rw
tag @a[tag=mg_duel_duell] add mg_rw
tag @s remove mg_rw
scoreboard players add @a[tag=mg_rw,tag=mg_duel_duell] mg_round 1
tellraw @a[tag=mg_duel_duell] [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=mg_rw,tag=mg_duel_duell]", "color": "white"}, {"text": " gewinnt die Runde!", "color": "red"}]
execute as @a[tag=mg_duel_duell] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1
execute if entity @a[tag=mg_rw,tag=mg_duel_duell,scores={mg_round=2..}] run return run function mg:duell/win
scoreboard players set #duell mg 1
function mg:duell/round
