execute if score #duell_cd mg matches 1.. run scoreboard players remove #duell_cd mg 1
execute if score #duell mg matches 1 if score #duell_cd mg matches 0 run function mg:duell/go
execute if score #duell mg matches 1 if score #duell_cd mg matches 0 run scoreboard players set #duell mg 2
execute unless score #duell mg matches 2 run return 0
execute store result score #n mg if entity @a[tag=mg_duel_duell]
execute if score #n mg matches ..1 run return run function mg:duell/forfeit
execute as @a[tag=mg_duel_duell,scores={mg_deaths=1..}] run function mg:duell/lose
execute as @a[tag=mg_duel_duell] at @s if entity @s[y=-64,dy=154] run function mg:duell/lose
