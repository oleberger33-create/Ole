title @a[tag=mg_duel_duell] actionbar {"text": "LOS!", "color": "red", "bold": true}
execute as @a[tag=mg_duel_duell] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
