execute in minecraft:overworld run kill @e[type=minecraft:item,x=4955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=4955,dx=90,y=70,dy=80,z=-45,dz=90]
title @a[tag=mg_duel_duell] actionbar {"text": "LOS!", "color": "red", "bold": true}
execute as @a[tag=mg_duel_duell] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2
