scoreboard players set #duell mg 0
execute as @a[tag=mg_duel_duell] run function mg:hub/enter
tag @a remove mg_duel_duell
tag @a[tag=mg_hub] remove mg_rw
execute in minecraft:overworld run kill @e[type=minecraft:item,x=4980,dx=40,y=90,dy=30,z=-20,dz=40]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=4980,dx=40,y=90,dy=30,z=-20,dz=40]
