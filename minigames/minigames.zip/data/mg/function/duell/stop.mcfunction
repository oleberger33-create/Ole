scoreboard players set #duell mg 0
kill @e[type=minecraft:horse,tag=mg_horse_duell]
execute as @a[tag=mg_duel_duell] run function mg:hub/enter
tag @a remove mg_duel_duell
tag @a[tag=mg_hub] remove mg_rw
execute in minecraft:overworld run kill @e[type=minecraft:item,x=4955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=minecraft:arrow,x=4955,dx=90,y=70,dy=80,z=-45,dz=90]
