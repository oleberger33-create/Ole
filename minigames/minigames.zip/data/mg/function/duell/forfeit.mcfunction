execute as @a[tag=mg_duel_duell] run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "gold"}, {"text": " gewinnt Duell – Gegner ist weg.", "color": "white"}]
scoreboard players add @a[tag=mg_duel_duell] mg_wins 1
function mg:duell/stop
