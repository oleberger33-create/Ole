execute as @a[tag=mg_duel_duell] run function mg:duell/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_duell,tag=mg_p1] 4991 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_duell,tag=mg_p2] 5009 101 0 90 0
scoreboard players set #duell_cd mg 60
scoreboard players set #duell mg 1
title @a[tag=mg_duel_duell] times 0 30 10
title @a[tag=mg_duel_duell] title {"text": "Runde", "color": "red", "bold": true}
title @a[tag=mg_duel_duell] subtitle [{"score":{"name":"@a[tag=mg_p1,tag=mg_duel_duell]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_p2,tag=mg_duel_duell]","objective":"mg_round"},"color":"white"}]
