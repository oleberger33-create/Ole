execute in minecraft:overworld run kill @e[type=minecraft:item,x=4955,dx=90,y=70,dy=80,z=-45,dz=90]
execute in minecraft:overworld run kill @e[type=#minecraft:arrows,x=4955,dx=90,y=70,dy=80,z=-45,dz=90]
execute as @a[tag=mg_duel_duell] run function mg:duell/kit
execute in minecraft:overworld run tp @a[tag=mg_duel_duell,tag=mg_p1,limit=1] 4991 101 0 -90 0
execute in minecraft:overworld run tp @a[tag=mg_duel_duell,tag=mg_p2,limit=1] 5009 101 0 90 0
execute as @a[tag=mg_duel_duell] run execute in minecraft:overworld run spawnpoint @s 0 101 17
kill @e[type=minecraft:horse,tag=mg_horse_duell]
scoreboard players set #duell_cd mg 60
scoreboard players set #duell mg 1
title @a[tag=mg_duel_duell] times 0 30 10
title @a[tag=mg_duel_duell] title {"text": "Duell", "color": "red", "bold": true}
title @a[tag=mg_duel_duell] subtitle [{"score":{"name":"@a[tag=mg_duel_duell,tag=mg_p1,limit=1]","objective":"mg_round"},"color":"white"},{"text":" : ","color":"gray"},{"score":{"name":"@a[tag=mg_duel_duell,tag=mg_p2,limit=1]","objective":"mg_round"},"color":"white"}]
