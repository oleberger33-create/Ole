clear @s
effect clear @s
effect give @s minecraft:instant_health 1 10 true
effect give @s minecraft:saturation 1 20 true
gamemode adventure @s
scoreboard players set @s mg_deaths 0
execute in minecraft:overworld run spawnpoint @s 0 101 0
effect give @s minecraft:slowness 3 255 true
effect give @s minecraft:resistance 3 4 true
item replace entity @s armor.head with minecraft:iron_helmet
item replace entity @s armor.chest with minecraft:iron_chestplate
item replace entity @s armor.legs with minecraft:iron_leggings
item replace entity @s armor.feet with minecraft:iron_boots
item replace entity @s hotbar.0 with minecraft:iron_sword
item replace entity @s hotbar.1 with minecraft:bow
item replace entity @s hotbar.2 with minecraft:cooked_beef 8
item replace entity @s weapon.offhand with minecraft:shield
item replace entity @s inventory.0 with minecraft:arrow 16
