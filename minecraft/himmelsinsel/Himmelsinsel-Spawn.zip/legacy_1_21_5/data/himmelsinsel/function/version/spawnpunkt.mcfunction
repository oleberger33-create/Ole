# Minecraft 1.21.5 bis 1.21.10
setworldspawn 0 225 6
gamerule spawnRadius 0
