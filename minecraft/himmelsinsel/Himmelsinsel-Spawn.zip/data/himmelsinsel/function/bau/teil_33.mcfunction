fill -4 233 -26 -3 233 -26 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -2 233 -26 2 233 -26 minecraft:deepslate_tiles
fill 3 233 -26 4 233 -26 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -5 233 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -4 233 -25 minecraft:deepslate_tiles
setblock 4 233 -25 minecraft:deepslate_tiles
setblock 5 233 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -6 233 -24 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -5 233 -24 minecraft:deepslate_tiles
setblock 5 233 -24 minecraft:deepslate_tiles
setblock 6 233 -24 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -42 233 -23 -40 236 -23 minecraft:cherry_leaves[persistent=true]
setblock -7 233 -23 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -6 233 -23 minecraft:deepslate_tiles
setblock 6 233 -23 minecraft:deepslate_tiles
setblock 7 233 -23 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -43 233 -22 -42 233 -22 minecraft:cherry_leaves[persistent=true]
setblock -41 233 -22 minecraft:cherry_log[axis=x]
fill -8 233 -22 -8 233 -21 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -7 233 -22 minecraft:deepslate_tiles
setblock 7 233 -22 minecraft:deepslate_tiles
fill 8 233 -22 8 233 -21 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -41 233 -21 -41 236 -21 minecraft:cherry_leaves[persistent=true]
fill -8 233 -20 -8 233 -16 minecraft:deepslate_tiles
setblock 0 233 -20 minecraft:dark_oak_fence[south=true]
fill 8 233 -20 8 233 -16 minecraft:deepslate_tiles
fill -9 233 -19 -9 233 -17 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock 0 233 -19 minecraft:dark_oak_fence[north=true,south=true]
fill 9 233 -19 9 233 -17 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -2 233 -18 minecraft:dark_oak_fence[east=true]
setblock -1 233 -18 minecraft:dark_oak_fence[east=true,west=true]
setblock 0 233 -18 minecraft:dark_oak_fence[north=true,east=true,south=true,west=true]
setblock 1 233 -18 minecraft:dark_oak_fence[east=true,west=true]
setblock 2 233 -18 minecraft:dark_oak_fence[west=true]
setblock 0 233 -17 minecraft:dark_oak_fence[north=true,south=true]
setblock 16 233 -17 minecraft:cherry_leaves[persistent=true]
setblock 0 233 -16 minecraft:dark_oak_fence[north=true]
setblock 15 233 -16 minecraft:cherry_leaves[persistent=true]
fill -8 233 -15 -8 233 -14 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill 8 233 -15 8 233 -14 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -7 233 -14 minecraft:deepslate_tiles
setblock 7 233 -14 minecraft:deepslate_tiles
setblock 16 233 -14 minecraft:cherry_leaves[persistent=true]
setblock -7 233 -13 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -6 233 -13 minecraft:deepslate_tiles
setblock 6 233 -13 minecraft:deepslate_tiles
setblock 7 233 -13 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -6 233 -12 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -5 233 -12 minecraft:deepslate_tiles
setblock 5 233 -12 minecraft:deepslate_tiles
setblock 6 233 -12 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -5 233 -11 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
setblock -4 233 -11 minecraft:deepslate_tiles
setblock 4 233 -11 minecraft:deepslate_tiles
setblock 5 233 -11 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -4 233 -10 -3 233 -10 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 233 -10 2 233 -10 minecraft:deepslate_tiles
fill 3 233 -10 4 233 -10 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -1 233 -9 1 233 -9 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill 16 233 -3 22 233 3 minecraft:spruce_slab[type=bottom]
fill -2 234 -26 2 234 -26 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -4 234 -25 -3 234 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -2 234 -25 2 234 -25 minecraft:deepslate_tiles
fill 3 234 -25 4 234 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -42 234 -24 -40 235 -24 minecraft:cherry_leaves[persistent=true]
setblock -5 234 -24 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -4 234 -24 minecraft:deepslate_tiles
setblock 4 234 -24 minecraft:deepslate_tiles
setblock 5 234 -24 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -43 234 -23 -43 235 -21 minecraft:cherry_leaves[persistent=true]
setblock -6 234 -23 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -5 234 -23 minecraft:deepslate_tiles
setblock 5 234 -23 minecraft:deepslate_tiles
setblock 6 234 -23 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -42 234 -22 minecraft:cherry_log[axis=y]
fill -41 234 -22 -41 237 -22 minecraft:cherry_leaves[persistent=true]
fill -39 234 -22 -39 235 -21 minecraft:cherry_leaves[persistent=true]
fill -7 234 -22 -7 234 -21 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -6 234 -22 minecraft:deepslate_tiles
setblock 6 234 -22 minecraft:deepslate_tiles
fill 7 234 -22 7 234 -21 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -42 234 -21 -42 236 -20 minecraft:cherry_leaves[persistent=true]
fill -40 234 -21 -40 235 -20 minecraft:cherry_leaves[persistent=true]
fill -41 234 -20 -41 236 -20 minecraft:cherry_leaves[persistent=true]
fill -8 234 -20 -8 234 -16 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill -7 234 -20 -7 234 -16 minecraft:deepslate_tiles
fill 7 234 -20 7 234 -16 minecraft:deepslate_tiles
fill 8 234 -20 8 234 -16 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill 0 234 -18 0 241 -18 minecraft:dark_oak_fence
fill -7 234 -15 -7 234 -14 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill 7 234 -15 7 234 -14 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -6 234 -14 minecraft:deepslate_tiles
setblock 6 234 -14 minecraft:deepslate_tiles
setblock -6 234 -13 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -5 234 -13 minecraft:deepslate_tiles
setblock 5 234 -13 minecraft:deepslate_tiles
setblock 6 234 -13 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -5 234 -12 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
setblock -4 234 -12 minecraft:deepslate_tiles
setblock 4 234 -12 minecraft:deepslate_tiles
setblock 5 234 -12 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -4 234 -11 -3 234 -11 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 234 -11 2 234 -11 minecraft:deepslate_tiles
fill 3 234 -11 4 234 -11 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 234 -10 2 234 -10 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 235 -25 2 235 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -4 235 -24 -3 235 -24 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -2 235 -24 2 235 -24 minecraft:deepslate_tiles
fill 3 235 -24 4 235 -24 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -39 235 -23 -39 236 -23 minecraft:cherry_leaves[persistent=true]
setblock -5 235 -23 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -4 235 -23 minecraft:deepslate_tiles
setblock 4 235 -23 minecraft:deepslate_tiles
setblock 5 235 -23 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -42 235 -22 -42 237 -22 minecraft:cherry_leaves[persistent=true]
fill -40 235 -22 -40 237 -22 minecraft:cherry_leaves[persistent=true]
fill -6 235 -22 -6 235 -21 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -5 235 -22 minecraft:deepslate_tiles
setblock 5 235 -22 minecraft:deepslate_tiles
fill 6 235 -22 6 235 -21 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -7 235 -20 -7 235 -16 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill -6 235 -20 -6 235 -16 minecraft:deepslate_tiles
fill 6 235 -20 6 235 -16 minecraft:deepslate_tiles
fill 7 235 -20 7 235 -16 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -6 235 -15 -6 235 -14 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill 6 235 -15 6 235 -14 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -5 235 -14 minecraft:deepslate_tiles
setblock 5 235 -14 minecraft:deepslate_tiles
setblock -5 235 -13 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -4 235 -13 minecraft:deepslate_tiles
setblock 4 235 -13 minecraft:deepslate_tiles
setblock 5 235 -13 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -4 235 -12 -3 235 -12 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 235 -12 2 235 -12 minecraft:deepslate_tiles
fill 3 235 -12 4 235 -12 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 235 -11 2 235 -11 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -42 236 -24 -41 236 -24 minecraft:cherry_leaves[persistent=true]
fill -2 236 -24 2 236 -24 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -4 236 -23 -3 236 -23 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -2 236 -23 minecraft:deepslate_tiles
setblock 2 236 -23 minecraft:deepslate_tiles
fill 3 236 -23 4 236 -23 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -43 236 -22 -43 236 -21 minecraft:cherry_leaves[persistent=true]
setblock -39 236 -22 minecraft:cherry_leaves[persistent=true]
fill -5 236 -22 -5 236 -21 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -4 236 -22 minecraft:deepslate_tiles
setblock 4 236 -22 minecraft:deepslate_tiles
fill 5 236 -22 5 236 -21 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -40 236 -21 minecraft:cherry_leaves[persistent=true]
fill -6 236 -20 -6 236 -16 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -5 236 -20 minecraft:deepslate_tiles
setblock 5 236 -20 minecraft:deepslate_tiles
fill 6 236 -20 6 236 -16 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -5 236 -16 minecraft:deepslate_tiles
setblock 5 236 -16 minecraft:deepslate_tiles
fill -5 236 -15 -5 236 -14 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill 5 236 -15 5 236 -14 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -4 236 -14 minecraft:deepslate_tiles
setblock 4 236 -14 minecraft:deepslate_tiles
fill -4 236 -13 -3 236 -13 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
setblock -2 236 -13 minecraft:deepslate_tiles
setblock 2 236 -13 minecraft:deepslate_tiles
fill 3 236 -13 4 236 -13 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 236 -12 2 236 -12 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 237 -23 2 237 -23 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -4 237 -22 -4 237 -21 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -3 237 -22 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -2 237 -22 minecraft:deepslate_tiles
setblock 2 237 -22 minecraft:deepslate_tiles
setblock 3 237 -22 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill 4 237 -22 4 237 -21 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -5 237 -20 -5 237 -16 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -4 237 -20 minecraft:deepslate_tiles
setblock 4 237 -20 minecraft:deepslate_tiles
fill 5 237 -20 5 237 -16 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -4 237 -16 minecraft:deepslate_tiles
setblock 4 237 -16 minecraft:deepslate_tiles
fill -4 237 -15 -4 237 -14 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill 4 237 -15 4 237 -14 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -3 237 -14 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
setblock -2 237 -14 minecraft:deepslate_tiles
setblock 2 237 -14 minecraft:deepslate_tiles
setblock 3 237 -14 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -2 237 -13 2 237 -13 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
setblock -2 238 -22 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -1 238 -22 1 238 -22 minecraft:deepslate_tiles
setblock 2 238 -22 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -3 238 -21 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -2 238 -21 minecraft:deepslate_tiles
setblock 2 238 -21 minecraft:deepslate_tiles
setblock 3 238 -21 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -4 238 -20 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -3 238 -20 minecraft:deepslate_tiles
setblock 3 238 -20 minecraft:deepslate_tiles
setblock 4 238 -20 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -4 238 -19 -4 238 -17 minecraft:deepslate_tiles
fill 4 238 -19 4 238 -17 minecraft:deepslate_tiles
setblock -4 238 -16 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -3 238 -16 minecraft:deepslate_tiles
setblock 3 238 -16 minecraft:deepslate_tiles
setblock 4 238 -16 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -3 238 -15 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -2 238 -15 minecraft:deepslate_tiles
setblock 2 238 -15 minecraft:deepslate_tiles
setblock 3 238 -15 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -2 238 -14 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -1 238 -14 1 238 -14 minecraft:deepslate_tiles
setblock 2 238 -14 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -1 239 -22 1 239 -22 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -2 239 -21 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -1 239 -21 1 239 -21 minecraft:deepslate_tiles
setblock 2 239 -21 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -3 239 -20 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -2 239 -20 minecraft:deepslate_tiles
setblock 2 239 -20 minecraft:deepslate_tiles
setblock 3 239 -20 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -4 239 -19 -4 239 -17 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill -3 239 -19 -3 239 -17 minecraft:deepslate_tiles
fill 3 239 -19 3 239 -17 minecraft:deepslate_tiles
fill 4 239 -19 4 239 -17 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
