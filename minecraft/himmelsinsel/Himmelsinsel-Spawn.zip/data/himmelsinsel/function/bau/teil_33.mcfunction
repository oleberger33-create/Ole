fill -19 225 -2 -19 226 -2 minecraft:spruce_fence
fill -4 225 -2 -3 225 -2 minecraft:polished_deepslate_slab[type=bottom]
fill 3 225 -2 4 225 -2 minecraft:polished_deepslate_slab[type=bottom]
fill 17 225 -2 21 226 -2 minecraft:bookshelf
fill -4 225 -1 -4 225 2 minecraft:polished_deepslate_slab[type=bottom]
fill 4 225 -1 4 225 2 minecraft:polished_deepslate_slab[type=bottom]
fill 17 225 -1 17 226 -1 minecraft:bookshelf
fill 21 225 -1 21 226 -1 minecraft:bookshelf
setblock 0 225 0 minecraft:beacon
setblock 19 225 0 minecraft:enchanting_table
fill 25 225 0 25 228 0 minecraft:stripped_spruce_log[axis=y]
fill 17 225 1 17 226 2 minecraft:bookshelf
fill 21 225 1 21 226 2 minecraft:bookshelf
fill 25 225 1 25 225 5 minecraft:spruce_fence[north=true,south=true]
fill -25 225 2 -25 226 2 minecraft:spruce_fence
fill -12 225 2 -12 226 2 minecraft:spruce_fence
fill -3 225 2 -3 225 3 minecraft:polished_deepslate_slab[type=bottom]
fill 3 225 2 3 225 3 minecraft:polished_deepslate_slab[type=bottom]
fill 10 225 2 10 226 2 minecraft:spruce_fence
fill 18 225 2 20 226 2 minecraft:bookshelf
setblock -34 225 3 minecraft:spruce_fence[north=true,east=true]
fill -33 225 3 -29 225 3 minecraft:spruce_fence[east=true,west=true]
setblock -28 225 3 minecraft:spruce_fence[west=true]
fill -2 225 3 -2 225 4 minecraft:polished_deepslate_slab[type=bottom]
fill 2 225 3 2 225 4 minecraft:polished_deepslate_slab[type=bottom]
fill -1 225 4 1 225 4 minecraft:polished_deepslate_slab[type=bottom]
fill -5 225 5 -5 226 5 minecraft:spruce_fence
fill 5 225 5 5 226 5 minecraft:spruce_fence
setblock 15 225 5 minecraft:crafting_table
setblock 17 225 5 minecraft:crafting_table
setblock 19 225 5 minecraft:ender_chest[facing=north]
setblock 21 225 5 minecraft:ender_chest[facing=north]
setblock 23 225 5 minecraft:stonecutter[facing=north]
fill 13 225 6 13 228 6 minecraft:stripped_spruce_log[axis=y]
setblock 14 225 6 minecraft:spruce_fence[east=true,west=true]
setblock 15 225 6 minecraft:spruce_fence[north=true,east=true,west=true]
setblock 16 225 6 minecraft:spruce_fence[east=true,west=true]
setblock 17 225 6 minecraft:spruce_fence[north=true,east=true,west=true]
setblock 18 225 6 minecraft:spruce_fence[east=true,west=true]
fill 19 225 6 19 228 6 minecraft:stripped_spruce_log[axis=y]
fill 20 225 6 24 225 6 minecraft:spruce_fence[east=true,west=true]
fill 25 225 6 25 228 6 minecraft:stripped_spruce_log[axis=y]
fill -22 225 10 -22 229 10 minecraft:cherry_log[axis=y]
fill 21 225 11 21 225 12 minecraft:azalea_leaves[persistent=true]
fill 22 225 11 23 225 11 minecraft:flowering_azalea_leaves[persistent=true]
fill 22 225 12 22 226 12 minecraft:azalea_leaves[persistent=true]
fill 23 225 12 23 226 12 minecraft:flowering_azalea_leaves[persistent=true]
fill -10 225 13 -10 226 13 minecraft:spruce_fence
fill -2 225 13 -2 226 13 minecraft:spruce_fence
fill 21 225 13 22 225 13 minecraft:flowering_azalea_leaves[persistent=true]
setblock 23 225 13 minecraft:azalea_leaves[persistent=true]
fill -19 225 15 -19 227 15 minecraft:dark_oak_log[axis=y]
fill -18 225 15 -16 225 15 minecraft:mossy_cobblestone
fill -15 225 15 -15 227 15 minecraft:dark_oak_log[axis=y]
fill -19 225 16 -19 225 18 minecraft:mossy_cobblestone
setblock -18 225 16 minecraft:water_cauldron[level=3]
setblock -15 225 16 minecraft:mossy_cobblestone
fill 13 225 16 13 229 16 minecraft:cherry_log[axis=y]
setblock -18 225 18 minecraft:brewing_stand
setblock -15 225 18 minecraft:mossy_cobblestone
fill -19 225 19 -19 227 19 minecraft:dark_oak_log[axis=y]
fill -18 225 19 -16 225 19 minecraft:mossy_cobblestone
fill -15 225 19 -15 227 19 minecraft:dark_oak_log[axis=y]
fill 2 225 20 2 226 20 minecraft:spruce_fence
setblock 43 225 22 minecraft:dirt
fill -7 225 23 -6 225 23 minecraft:azalea_leaves[persistent=true]
setblock -5 225 23 minecraft:flowering_azalea_leaves[persistent=true]
setblock 7 225 23 minecraft:azalea_leaves[persistent=true]
setblock 8 225 23 minecraft:flowering_azalea_leaves[persistent=true]
fill 9 225 23 9 225 25 minecraft:azalea_leaves[persistent=true]
fill -7 225 24 -6 225 25 minecraft:flowering_azalea_leaves[persistent=true]
fill -5 225 24 -5 225 25 minecraft:azalea_leaves[persistent=true]
fill 7 225 24 7 225 25 minecraft:flowering_azalea_leaves[persistent=true]
fill 8 225 24 8 225 25 minecraft:azalea_leaves[persistent=true]
fill -2 225 25 -2 226 25 minecraft:spruce_fence
setblock -2 225 27 minecraft:spruce_fence[south=true]
setblock 2 225 27 minecraft:spruce_fence[south=true]
fill -2 225 28 -2 225 30 minecraft:spruce_fence[north=true,south=true]
fill 2 225 28 2 225 30 minecraft:spruce_fence[north=true,south=true]
fill -2 225 31 -2 227 31 minecraft:stripped_spruce_log[axis=y]
fill 2 225 31 2 227 31 minecraft:stripped_spruce_log[axis=y]
fill 33 226 -36 33 227 -36 minecraft:spruce_fence
fill 35 226 -36 35 227 -36 minecraft:spruce_fence
fill 39 226 -36 39 227 -36 minecraft:spruce_fence
fill 41 226 -36 41 227 -36 minecraft:spruce_fence
fill 33 226 -34 33 227 -34 minecraft:spruce_fence
fill 35 226 -34 35 227 -34 minecraft:spruce_fence
fill 39 226 -34 39 227 -34 minecraft:spruce_fence
fill 41 226 -34 41 227 -34 minecraft:spruce_fence
fill 30 226 -30 30 227 -30 minecraft:spruce_fence
fill 32 226 -30 32 227 -30 minecraft:spruce_fence
fill 42 226 -30 42 227 -30 minecraft:spruce_fence
fill 44 226 -30 44 227 -30 minecraft:spruce_fence
setblock -4 226 -29 minecraft:azalea_leaves[persistent=true]
fill -5 226 -28 -4 226 -28 minecraft:flowering_azalea_leaves[persistent=true]
setblock -3 226 -28 minecraft:azalea_leaves[persistent=true]
fill 30 226 -28 30 227 -28 minecraft:spruce_fence
fill 32 226 -28 32 227 -28 minecraft:spruce_fence
fill 42 226 -28 42 227 -28 minecraft:spruce_fence
fill 44 226 -28 44 227 -28 minecraft:spruce_fence
setblock -42 226 -26 minecraft:dripstone_block
fill -41 226 -26 -40 226 -26 minecraft:stone
fill -39 226 -26 -38 226 -26 minecraft:mossy_cobblestone
fill -2 226 -26 2 226 -26 minecraft:deepslate_bricks
setblock -43 226 -25 minecraft:stone
fill -37 226 -25 -37 226 -24 minecraft:stone
fill -5 226 -25 -4 226 -25 minecraft:deepslate_bricks
fill 4 226 -25 5 226 -25 minecraft:deepslate_bricks
fill 43 226 -25 43 226 -24 minecraft:azalea_leaves[persistent=true]
fill -44 226 -24 -44 226 -23 minecraft:andesite
setblock -6 226 -24 minecraft:cracked_deepslate_bricks
setblock -5 226 -24 minecraft:deepslate_bricks
fill 5 226 -24 6 226 -24 minecraft:deepslate_bricks
setblock 42 226 -24 minecraft:flowering_azalea_leaves[persistent=true]
fill -7 226 -23 -6 226 -23 minecraft:deepslate_bricks
fill 6 226 -23 7 226 -23 minecraft:deepslate_bricks
setblock 43 226 -23 minecraft:flowering_azalea_leaves[persistent=true]
fill -45 226 -22 -44 226 -22 minecraft:stone
setblock -36 226 -22 minecraft:amethyst_block
fill -7 226 -22 -7 227 -22 minecraft:cracked_deepslate_bricks
fill 7 226 -22 7 230 -22 minecraft:deepslate_bricks
setblock -45 226 -21 minecraft:stone
setblock -42 226 -21 minecraft:stone
fill -41 226 -21 -40 226 -20 minecraft:mossy_cobblestone
fill -39 226 -21 -38 227 -21 minecraft:stone
setblock -45 226 -20 minecraft:andesite
fill -44 226 -20 -43 226 -20 minecraft:stone
setblock -42 226 -20 minecraft:mossy_cobblestone
fill -39 226 -20 -39 226 -19 minecraft:mossy_cobblestone
fill -38 226 -20 -38 227 -20 minecraft:stone
fill -36 226 -20 -36 227 -20 minecraft:stone
fill -8 226 -20 -8 226 -16 minecraft:deepslate_bricks
fill 8 226 -20 8 226 -16 minecraft:deepslate_bricks
setblock -44 226 -19 minecraft:andesite
fill -43 226 -19 -42 226 -19 minecraft:stone
fill -40 226 -19 -40 226 -18 minecraft:stone
fill -38 226 -19 -37 226 -19 minecraft:mossy_cobblestone
fill -42 226 -18 -41 226 -18 minecraft:stone
setblock -39 226 -18 minecraft:stone
setblock -38 226 -18 minecraft:dripstone_block
setblock 35 226 -17 minecraft:spruce_fence
setblock 39 226 -17 minecraft:spruce_fence
setblock 24 226 -15 minecraft:flowering_azalea_leaves[persistent=true]
fill -11 226 -14 -11 226 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill -7 226 -14 -7 226 -13 minecraft:deepslate_bricks
fill 7 226 -14 7 226 -13 minecraft:deepslate_bricks
setblock 25 226 -14 minecraft:flowering_azalea_leaves[persistent=true]
setblock -12 226 -13 minecraft:azalea_leaves[persistent=true]
setblock -10 226 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill -6 226 -13 -6 226 -12 minecraft:deepslate_bricks
setblock 6 226 -13 minecraft:cracked_deepslate_bricks
setblock -25 226 -12 minecraft:azalea_leaves[persistent=true]
setblock -23 226 -12 minecraft:flowering_azalea_leaves[persistent=true]
setblock -11 226 -12 minecraft:azalea_leaves[persistent=true]
fill -5 226 -12 -5 226 -11 minecraft:deepslate_bricks
fill 5 226 -12 6 226 -12 minecraft:deepslate_bricks
setblock 31 226 -12 minecraft:spruce_fence
fill -4 226 -11 -4 227 -11 minecraft:deepslate_bricks
fill 4 226 -11 5 226 -11 minecraft:deepslate_bricks
setblock 31 226 -8 minecraft:spruce_fence
setblock 26 226 -5 minecraft:azalea_leaves[persistent=true]
fill 25 226 -4 27 226 -4 minecraft:flowering_azalea_leaves[persistent=true]
setblock -34 226 -3 minecraft:spruce_fence
setblock 26 226 -3 minecraft:azalea_leaves[persistent=true]
setblock 0 226 0 minecraft:purple_stained_glass
setblock -34 226 3 minecraft:spruce_fence
setblock 22 226 11 minecraft:azalea_leaves[persistent=true]
setblock 21 226 12 minecraft:flowering_azalea_leaves[persistent=true]
setblock 22 226 13 minecraft:azalea_leaves[persistent=true]
fill -18 226 15 -18 228 15 minecraft:dark_oak_planks
setblock -17 226 15 minecraft:purple_stained_glass
fill -16 226 15 -16 228 15 minecraft:dark_oak_planks
fill -19 226 16 -19 228 16 minecraft:dark_oak_planks
fill -15 226 16 -15 228 16 minecraft:dark_oak_planks
setblock -19 226 17 minecraft:purple_stained_glass
fill -19 226 18 -19 228 18 minecraft:dark_oak_planks
fill -15 226 18 -15 228 18 minecraft:dark_oak_planks
fill -18 226 19 -18 228 19 minecraft:dark_oak_planks
setblock -17 226 19 minecraft:purple_stained_glass
fill -16 226 19 -16 228 19 minecraft:dark_oak_planks
fill 41 226 21 42 226 29 minecraft:grass_block
fill 37 226 22 40 226 27 minecraft:grass_block
fill 43 226 22 43 226 27 minecraft:grass_block
setblock -6 226 23 minecraft:azalea_leaves[persistent=true]
setblock 8 226 23 minecraft:azalea_leaves[persistent=true]
fill 36 226 23 36 226 26 minecraft:grass_block
fill -7 226 24 -5 226 24 minecraft:flowering_azalea_leaves[persistent=true]
setblock 7 226 24 minecraft:azalea_leaves[persistent=true]
setblock 8 226 24 minecraft:flowering_azalea_leaves[persistent=true]
setblock 9 226 24 minecraft:azalea_leaves[persistent=true]
fill 44 226 24 44 226 25 minecraft:grass_block
setblock -6 226 25 minecraft:flowering_azalea_leaves[persistent=true]
fill 38 226 28 40 226 28 minecraft:grass_block
setblock 40 226 29 minecraft:grass_block
fill -41 227 -27 -40 227 -27 minecraft:stone
fill -39 227 -27 -39 227 -26 minecraft:mossy_cobblestone
setblock -38 227 -27 minecraft:dripstone_block
fill -43 227 -26 -41 229 -25 minecraft:dirt
setblock -40 227 -26 minecraft:stone
fill -38 227 -26 -37 229 -26 minecraft:dirt
fill -2 227 -26 -2 228 -26 minecraft:deepslate_bricks
fill -1 227 -26 1 229 -26 minecraft:purple_stained_glass
fill 2 227 -26 2 230 -26 minecraft:deepslate_bricks
fill -40 227 -25 -39 229 -23 minecraft:dirt
setblock -38 227 -25 minecraft:rooted_dirt
fill -37 227 -25 -37 229 -23 minecraft:dirt
setblock -36 227 -25 minecraft:rooted_dirt
fill -5 227 -25 -5 229 -24 minecraft:purple_stained_glass
fill -4 227 -25 -4 230 -25 minecraft:deepslate_bricks
fill 4 227 -25 4 228 -25 minecraft:deepslate_bricks
fill 5 227 -25 5 229 -24 minecraft:purple_stained_glass
setblock -44 227 -24 minecraft:rooted_dirt
fill -43 227 -24 -42 229 -24 minecraft:dirt
fill -41 227 -24 -41 227 -23 minecraft:rooted_dirt
fill -38 227 -24 -38 229 -24 minecraft:dirt
fill -36 227 -24 -36 229 -23 minecraft:dirt
fill -6 227 -24 -6 229 -23 minecraft:purple_stained_glass
fill 6 227 -24 6 229 -23 minecraft:purple_stained_glass
setblock 30 227 -24 minecraft:cherry_log[axis=x]
fill -44 227 -23 -44 229 -23 minecraft:dirt
