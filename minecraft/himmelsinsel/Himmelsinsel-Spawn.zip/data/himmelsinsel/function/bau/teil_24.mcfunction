setblock -4 221 16 minecraft:rooted_dirt
fill 4 221 16 5 223 16 minecraft:dirt
fill 8 221 16 9 221 16 minecraft:rooted_dirt
fill 11 221 16 11 221 18 minecraft:stone
setblock 14 221 16 minecraft:stone
setblock 21 221 16 minecraft:rooted_dirt
setblock 23 221 16 minecraft:tuff
setblock 24 221 16 minecraft:stone
fill -24 221 17 -23 221 18 minecraft:stone
fill -18 221 17 -18 223 21 minecraft:dirt
setblock -10 221 17 minecraft:rooted_dirt
fill -7 221 17 -6 223 17 minecraft:dirt
setblock -5 221 17 minecraft:rooted_dirt
fill -4 221 17 -3 221 17 minecraft:stone
setblock 1 221 17 minecraft:mossy_cobblestone
fill 4 221 17 4 223 22 minecraft:dirt
setblock 5 221 17 minecraft:rooted_dirt
fill 8 221 17 9 223 19 minecraft:dirt
fill 14 221 17 14 223 21 minecraft:dirt
fill 16 221 17 16 221 18 minecraft:rooted_dirt
setblock 19 221 17 minecraft:rooted_dirt
fill 21 221 17 21 223 22 minecraft:dirt
fill 22 221 17 22 221 18 minecraft:rooted_dirt
setblock 23 221 17 minecraft:stone
setblock 24 221 17 minecraft:dripstone_block
setblock -20 221 18 minecraft:stone
setblock -17 221 18 minecraft:rooted_dirt
fill -16 221 18 -16 223 20 minecraft:dirt
setblock -15 221 18 minecraft:rooted_dirt
setblock -13 221 18 minecraft:andesite
setblock -10 221 18 minecraft:andesite
setblock -8 221 18 minecraft:rooted_dirt
fill -7 221 18 -7 223 18 minecraft:dirt
setblock -6 221 18 minecraft:stone
setblock 1 221 18 minecraft:stone
fill 2 221 18 2 221 20 minecraft:mossy_cobblestone
fill 5 221 18 5 223 18 minecraft:dirt
fill 10 221 18 10 223 18 minecraft:dirt
fill 19 221 18 20 223 18 minecraft:dirt
fill 23 221 18 23 223 18 minecraft:dirt
fill -23 221 19 -21 223 19 minecraft:dirt
setblock -20 221 19 minecraft:rooted_dirt
fill -19 221 19 -19 223 20 minecraft:dirt
fill -17 221 19 -17 223 20 minecraft:dirt
fill -15 221 19 -15 223 28 minecraft:dirt
fill 1 221 19 1 221 20 minecraft:mossy_cobblestone
setblock 3 221 19 minecraft:rooted_dirt
fill 5 221 19 6 221 19 minecraft:rooted_dirt
fill 10 221 19 10 221 20 minecraft:rooted_dirt
fill 11 221 19 13 223 20 minecraft:dirt
setblock 15 221 19 minecraft:rooted_dirt
fill 16 221 19 16 223 21 minecraft:dirt
fill 19 221 19 19 223 21 minecraft:dirt
setblock 20 221 19 minecraft:rooted_dirt
fill 22 221 19 22 223 19 minecraft:dirt
setblock 23 221 19 minecraft:rooted_dirt
fill -22 221 20 -20 223 20 minecraft:dirt
fill 3 221 20 3 223 26 minecraft:dirt
fill 5 221 20 6 223 26 minecraft:dirt
fill 8 221 20 8 223 26 minecraft:dirt
setblock 9 221 20 minecraft:rooted_dirt
fill 15 221 20 15 223 21 minecraft:dirt
fill 20 221 20 20 223 23 minecraft:dirt
setblock 22 221 20 minecraft:rooted_dirt
setblock -22 221 21 minecraft:rooted_dirt
fill -21 221 21 -20 223 21 minecraft:dirt
setblock -19 221 21 minecraft:rooted_dirt
fill -17 221 21 -16 221 21 minecraft:rooted_dirt
fill -1 221 21 1 221 21 minecraft:stone
setblock 2 221 21 minecraft:rooted_dirt
setblock 7 221 21 minecraft:rooted_dirt
fill 9 221 21 11 223 21 minecraft:dirt
setblock 12 221 21 minecraft:rooted_dirt
fill 13 221 21 13 223 21 minecraft:dirt
fill -21 221 22 -20 221 22 minecraft:rooted_dirt
fill -19 221 22 -19 223 24 minecraft:dirt
setblock -18 221 22 minecraft:rooted_dirt
fill -17 221 22 -16 223 22 minecraft:dirt
setblock -1 221 22 minecraft:stone
fill 0 221 22 2 223 22 minecraft:dirt
fill 7 221 22 7 223 22 minecraft:dirt
fill 9 221 22 9 221 23 minecraft:rooted_dirt
fill 10 221 22 10 223 26 minecraft:dirt
setblock 11 221 22 minecraft:rooted_dirt
fill 12 221 22 13 221 22 minecraft:stone
fill 18 221 22 19 221 22 minecraft:rooted_dirt
setblock -20 221 23 minecraft:rooted_dirt
fill -18 221 23 -17 223 25 minecraft:dirt
fill -16 221 23 -16 221 24 minecraft:rooted_dirt
fill -14 221 23 -14 221 24 minecraft:stone
fill -1 221 23 0 223 25 minecraft:dirt
setblock 1 221 23 minecraft:rooted_dirt
fill 2 221 23 2 223 25 minecraft:dirt
setblock 4 221 23 minecraft:rooted_dirt
setblock 7 221 23 minecraft:rooted_dirt
fill 11 221 23 11 221 25 minecraft:stone
setblock 17 221 23 minecraft:stone
fill 18 221 23 19 223 23 minecraft:dirt
fill 37 221 23 39 221 23 minecraft:stone
fill 43 221 23 43 222 23 minecraft:stone
fill -8 221 24 -8 223 25 minecraft:dirt
fill -4 221 24 -3 221 24 minecraft:stone
fill 1 221 24 1 223 26 minecraft:dirt
fill 4 221 24 4 223 24 minecraft:dirt
fill 7 221 24 7 223 24 minecraft:dirt
fill 9 221 24 9 223 26 minecraft:dirt
fill 12 221 24 13 221 25 minecraft:stone
setblock 17 221 24 minecraft:andesite
fill 18 221 24 18 221 25 minecraft:stone
fill 19 221 24 19 223 24 minecraft:dirt
setblock 37 221 24 minecraft:amethyst_block
fill 40 221 24 40 222 24 minecraft:stone
fill 42 221 24 42 222 25 minecraft:stone
fill 43 221 24 43 222 26 minecraft:andesite
fill -16 221 25 -16 223 27 minecraft:dirt
setblock -13 221 25 minecraft:stone
setblock 4 221 25 minecraft:rooted_dirt
setblock 7 221 25 minecraft:rooted_dirt
fill 37 221 25 37 221 26 minecraft:stone
setblock -17 221 26 minecraft:rooted_dirt
setblock -14 221 26 minecraft:stone
fill -13 221 26 -13 221 28 minecraft:mossy_cobblestone
fill -8 221 26 -8 221 27 minecraft:mossy_cobblestone
setblock -6 221 26 minecraft:mossy_cobblestone
fill -1 221 26 -1 221 27 minecraft:rooted_dirt
fill 0 221 26 0 223 29 minecraft:dirt
setblock 2 221 26 minecraft:rooted_dirt
fill 4 221 26 4 221 27 minecraft:stone
fill 7 221 26 7 223 26 minecraft:dirt
fill 11 221 26 13 223 26 minecraft:dirt
setblock 17 221 26 minecraft:mossy_cobblestone
setblock -14 221 27 minecraft:mossy_cobblestone
setblock -9 221 27 minecraft:mossy_cobblestone
fill -6 221 27 -6 221 29 minecraft:stone
fill -2 221 27 -2 223 29 minecraft:dirt
setblock 1 221 27 minecraft:rooted_dirt
fill 2 221 27 2 223 27 minecraft:dirt
setblock 3 221 27 minecraft:stone
fill 8 221 27 9 221 27 minecraft:stone
fill 10 221 27 12 221 27 minecraft:rooted_dirt
fill 13 221 27 13 223 28 minecraft:dirt
fill 14 221 27 15 221 27 minecraft:stone
fill 38 221 27 38 222 27 minecraft:stone
setblock 42 221 27 minecraft:stone
fill -9 221 28 -8 221 28 minecraft:andesite
setblock -7 221 28 minecraft:stone
fill -1 221 28 -1 223 29 minecraft:dirt
fill 1 221 28 1 223 31 minecraft:dirt
setblock 2 221 28 minecraft:rooted_dirt
fill 3 221 28 4 221 28 minecraft:andesite
fill 9 221 28 9 221 29 minecraft:stone
fill 10 221 28 10 223 29 minecraft:dirt
fill 11 221 28 12 221 28 minecraft:rooted_dirt
setblock 14 221 28 minecraft:dripstone_block
fill 40 221 28 41 222 28 minecraft:stone
fill -13 221 29 -11 221 29 minecraft:stone
setblock -10 221 29 minecraft:andesite
setblock -8 221 29 minecraft:andesite
setblock -3 221 29 minecraft:tuff
fill 2 221 29 2 223 31 minecraft:dirt
fill 3 221 29 3 221 30 minecraft:stone
setblock 4 221 29 minecraft:andesite
fill 5 221 29 7 221 29 minecraft:stone
fill 11 221 29 11 223 29 minecraft:dirt
setblock -12 221 30 minecraft:stone
setblock -11 221 30 minecraft:dripstone_block
fill -6 221 30 -5 221 30 minecraft:mossy_cobblestone
fill -4 221 30 -3 223 30 minecraft:dirt
fill -2 221 30 0 221 30 minecraft:rooted_dirt
setblock 4 221 30 minecraft:amethyst_block
setblock 5 221 30 minecraft:dripstone_block
setblock 6 221 30 minecraft:stone
setblock 7 221 30 minecraft:amethyst_block
fill -9 221 31 -8 221 31 minecraft:stone
setblock -6 221 31 minecraft:rooted_dirt
fill -5 221 31 -5 223 31 minecraft:dirt
fill -4 221 31 -3 221 31 minecraft:rooted_dirt
fill -2 221 31 -2 223 31 minecraft:dirt
setblock -1 221 31 minecraft:rooted_dirt
fill 0 221 31 0 223 31 minecraft:dirt
fill 36 222 -38 36 223 -38 minecraft:dirt
fill 38 222 -38 39 223 -38 minecraft:dirt
fill 33 222 -37 33 223 -37 minecraft:dirt
setblock 34 222 -37 minecraft:rooted_dirt
fill 31 222 -36 31 222 -35 minecraft:rooted_dirt
fill 32 222 -36 32 223 -34 minecraft:dirt
setblock 33 222 -36 minecraft:rooted_dirt
fill 34 222 -36 34 223 -35 minecraft:dirt
fill 42 222 -36 42 223 -36 minecraft:dirt
fill 30 222 -35 30 223 -35 minecraft:dirt
fill 33 222 -35 33 223 -35 minecraft:dirt
fill 36 222 -35 37 223 -35 minecraft:dirt
fill 44 222 -35 44 223 -35 minecraft:dirt
fill 29 222 -34 29 223 -33 minecraft:dirt
fill 31 222 -34 31 223 -34 minecraft:dirt
setblock 33 222 -34 minecraft:rooted_dirt
fill 40 222 -34 43 223 -33 minecraft:dirt
setblock 44 222 -34 minecraft:rooted_dirt
fill 45 222 -34 45 223 -34 minecraft:dirt
fill 44 222 -33 44 223 -30 minecraft:dirt
setblock 45 222 -33 minecraft:rooted_dirt
fill 30 222 -32 31 223 -32 minecraft:dirt
fill 39 222 -32 39 223 -32 minecraft:dirt
setblock 40 222 -32 minecraft:rooted_dirt
fill 41 222 -32 43 223 -32 minecraft:dirt
fill 45 222 -32 45 223 -32 minecraft:dirt
fill 32 222 -31 32 223 -30 minecraft:dirt
fill 40 222 -31 41 223 -31 minecraft:dirt
fill 42 222 -31 43 222 -31 minecraft:rooted_dirt
setblock 45 222 -31 minecraft:rooted_dirt
fill 46 222 -31 46 223 -28 minecraft:dirt
fill -5 222 -30 1 223 -30 minecraft:dirt
fill 3 222 -30 3 223 -30 minecraft:dirt
fill 33 222 -30 33 223 -30 minecraft:dirt
fill 37 222 -30 37 223 -30 minecraft:dirt
fill 39 222 -30 40 223 -30 minecraft:dirt
fill 42 222 -30 43 223 -30 minecraft:dirt
fill 45 222 -30 45 223 -30 minecraft:dirt
fill -10 222 -29 -10 223 -29 minecraft:dirt
fill -6 222 -29 -6 223 -29 minecraft:dirt
