fill 15 216 12 17 216 12 minecraft:andesite
fill 18 216 12 18 218 12 minecraft:stone
fill -21 216 13 -21 217 13 minecraft:andesite
fill -18 216 13 -18 221 13 minecraft:stone
fill -14 216 13 -14 218 13 minecraft:andesite
setblock 0 216 13 minecraft:cobblestone
fill 20 216 13 20 219 15 minecraft:stone
fill -20 216 14 -19 220 14 minecraft:stone
fill -14 216 14 -14 220 16 minecraft:stone
fill -12 216 14 -11 220 14 minecraft:andesite
fill 3 216 14 3 221 14 minecraft:stone
fill -18 216 15 -18 219 16 minecraft:stone
fill -12 216 15 -12 217 16 minecraft:stone
fill -17 216 16 -17 220 16 minecraft:stone
fill -1 216 16 -1 219 16 minecraft:cobblestone
fill 1 216 16 1 219 16 minecraft:cobblestone
fill 16 216 16 16 220 16 minecraft:stone
fill 20 216 16 20 216 17 minecraft:dripstone_block
fill -18 216 17 -18 216 19 minecraft:cobblestone
fill -1 216 17 -1 221 17 minecraft:stone
fill 17 216 17 17 220 17 minecraft:stone
fill 19 216 17 19 220 19 minecraft:stone
fill -17 216 18 -17 220 18 minecraft:stone
fill 18 216 18 18 220 19 minecraft:stone
fill -11 216 19 -10 216 20 minecraft:andesite
fill -9 216 19 -8 221 19 minecraft:stone
fill 16 216 19 17 220 19 minecraft:stone
fill -18 216 20 -18 220 20 minecraft:stone
setblock -17 216 20 minecraft:dripstone_block
fill -13 216 20 -12 216 21 minecraft:stone
fill -9 216 20 -7 216 20 minecraft:andesite
fill 15 216 20 16 220 20 minecraft:stone
fill -17 216 21 -16 220 21 minecraft:stone
fill -14 216 21 -14 220 22 minecraft:stone
fill -11 216 21 -11 221 21 minecraft:andesite
setblock -10 216 21 minecraft:amethyst_block
fill -9 216 21 -8 216 21 minecraft:andesite
fill -7 216 21 -7 221 21 minecraft:stone
fill -5 216 21 -5 221 21 minecraft:stone
fill 14 216 21 15 220 21 minecraft:stone
fill -16 216 22 -15 220 22 minecraft:stone
fill -11 216 22 -8 221 22 minecraft:stone
setblock -5 216 22 minecraft:dripstone_block
fill -4 216 22 -3 221 22 minecraft:stone
fill 11 216 22 13 220 22 minecraft:stone
fill -10 216 23 -9 218 24 minecraft:stone
fill -6 216 23 -6 221 25 minecraft:stone
fill -5 216 23 -4 216 23 minecraft:tuff
fill -3 216 23 -2 217 24 minecraft:stone
fill 7 216 23 11 220 23 minecraft:stone
fill 41 216 23 41 216 24 minecraft:stone
fill -7 216 24 -7 219 25 minecraft:stone
fill -5 216 24 -5 217 24 minecraft:tuff
fill 7 216 24 7 217 24 minecraft:tuff
fill 9 216 24 9 216 25 minecraft:tuff
setblock 10 216 24 minecraft:dripstone_block
setblock 40 216 24 minecraft:stone
fill -9 216 25 -8 219 25 minecraft:stone
fill -2 216 25 -2 219 26 minecraft:stone
fill 3 216 25 3 219 25 minecraft:stone
fill 6 216 25 7 220 25 minecraft:stone
fill 8 216 25 8 217 25 minecraft:tuff
fill -1 216 26 2 216 26 minecraft:stone
fill -1 216 27 1 220 27 minecraft:tuff
fill 0 216 28 0 220 28 minecraft:tuff
fill -8 217 -27 -6 219 -26 minecraft:tuff
fill -5 217 -27 -3 218 -27 minecraft:stone
fill 2 217 -27 3 220 -27 minecraft:stone
fill 4 217 -27 4 218 -25 minecraft:andesite
fill 5 217 -27 5 219 -27 minecraft:stone
fill -9 217 -26 -9 220 -24 minecraft:tuff
fill -5 217 -26 -4 220 -24 minecraft:stone
setblock -3 217 -26 minecraft:dripstone_block
fill -2 217 -26 2 219 -26 minecraft:stone
fill 3 217 -26 3 220 -26 minecraft:andesite
fill 5 217 -26 5 219 -25 minecraft:andesite
fill 6 217 -26 8 219 -26 minecraft:stone
setblock -13 217 -25 minecraft:amethyst_block
fill -12 217 -25 -11 220 -25 minecraft:stone
fill -10 217 -25 -10 220 -25 minecraft:tuff
fill -8 217 -25 -7 221 -25 minecraft:tuff
fill -6 217 -25 -6 217 -24 minecraft:stone
fill -3 217 -25 -3 221 -25 minecraft:stone
fill 9 217 -25 9 220 -25 minecraft:tuff
fill -16 217 -24 -14 220 -24 minecraft:stone
setblock -8 217 -24 minecraft:dripstone_block
setblock -7 217 -24 minecraft:stone
fill 6 217 -24 6 220 -24 minecraft:stone
setblock 8 217 -24 minecraft:stone
setblock 10 217 -24 minecraft:amethyst_block
setblock -16 217 -23 minecraft:dripstone_block
setblock -15 217 -23 minecraft:amethyst_block
fill 9 217 -23 9 220 -23 minecraft:tuff
setblock 10 217 -23 minecraft:dripstone_block
fill -40 217 -22 -40 226 -22 minecraft:stone
fill -17 217 -22 -16 217 -22 minecraft:stone
fill -15 217 -22 -15 220 -21 minecraft:tuff
fill -12 217 -22 -12 221 -22 minecraft:stone
fill 3 217 -22 3 219 -22 minecraft:andesite
fill 11 217 -22 11 221 -19 minecraft:stone
fill -17 217 -21 -17 217 -20 minecraft:stone
fill -16 217 -21 -16 220 -17 minecraft:tuff
fill -14 217 -21 -12 217 -21 minecraft:cobblestone
fill -9 217 -21 -9 221 -19 minecraft:stone
fill 2 217 -21 3 217 -21 minecraft:stone
fill 4 217 -21 4 219 -21 minecraft:andesite
fill 5 217 -21 6 217 -21 minecraft:stone
fill 12 217 -21 17 218 -21 minecraft:stone
fill -18 217 -20 -18 219 -19 minecraft:stone
setblock -13 217 -20 minecraft:cobblestone
fill -12 217 -20 -12 221 -19 minecraft:stone
fill -10 217 -20 -10 221 -19 minecraft:stone
fill 12 217 -20 14 220 -20 minecraft:stone
fill 18 217 -20 18 220 -18 minecraft:stone
setblock -13 217 -19 minecraft:tuff
fill 12 217 -19 12 221 -19 minecraft:stone
setblock 19 217 -19 minecraft:dripstone_block
fill -19 217 -18 -19 221 -18 minecraft:stone
fill 17 217 -18 17 220 -18 minecraft:stone
fill 19 217 -18 19 218 -16 minecraft:stone
fill -23 217 -17 -20 220 -17 minecraft:stone
setblock -13 217 -17 minecraft:tuff
fill 20 217 -17 20 217 -15 minecraft:stone
fill 22 217 -17 23 217 -16 minecraft:stone
fill -24 217 -16 -21 220 -16 minecraft:stone
setblock -16 217 -16 minecraft:stone
fill -15 217 -16 -15 220 -16 minecraft:tuff
fill -13 217 -16 -13 221 -16 minecraft:stone
fill -5 217 -16 -5 219 -16 minecraft:cobblestone
fill 3 217 -16 4 218 -16 minecraft:cobblestone
fill 5 217 -16 6 220 -16 minecraft:stone
fill 21 217 -16 21 218 -15 minecraft:stone
setblock 24 217 -16 minecraft:dripstone_block
fill -25 217 -15 -25 217 -13 minecraft:cobblestone
fill -24 217 -15 -24 220 -15 minecraft:stone
fill -20 217 -15 -20 221 -13 minecraft:stone
setblock 5 217 -15 minecraft:cobblestone
setblock 22 217 -15 minecraft:dripstone_block
fill 23 217 -15 24 217 -15 minecraft:stone
fill 25 217 -15 25 218 -14 minecraft:andesite
setblock -24 217 -14 minecraft:cobblestone
fill -23 217 -14 -23 220 -13 minecraft:stone
fill -3 217 -14 -3 220 -14 minecraft:stone
fill 4 217 -14 4 219 -14 minecraft:cobblestone
fill 23 217 -14 23 218 -12 minecraft:stone
setblock 24 217 -14 minecraft:dripstone_block
fill -26 217 -13 -26 219 -13 minecraft:cobblestone
fill -24 217 -13 -24 220 -13 minecraft:stone
fill -13 217 -13 -13 217 -11 minecraft:stone
fill -12 217 -13 -12 219 -13 minecraft:cobblestone
fill 4 217 -13 4 217 -11 minecraft:stone
setblock 5 217 -13 minecraft:cobblestone
fill 14 217 -13 14 219 -13 minecraft:tuff
fill 24 217 -13 24 217 -10 minecraft:stone
fill -26 217 -12 -26 218 -11 minecraft:stone
fill -12 217 -12 -12 218 -11 minecraft:stone
fill -7 217 -12 -6 220 -12 minecraft:stone
fill 5 217 -12 6 218 -12 minecraft:tuff
fill 25 217 -12 25 218 -11 minecraft:stone
fill -27 217 -11 -27 217 -10 minecraft:stone
fill -25 217 -11 -25 220 -10 minecraft:stone
fill -6 217 -11 -6 217 -10 minecraft:cobblestone
fill 5 217 -11 5 220 -11 minecraft:tuff
fill 6 217 -11 7 221 -11 minecraft:stone
setblock 23 217 -11 minecraft:tuff
fill 26 217 -11 26 221 -10 minecraft:stone
fill -28 217 -10 -28 217 -6 minecraft:stone
fill -26 217 -10 -26 218 -10 minecraft:tuff
fill -18 217 -10 -18 221 -8 minecraft:stone
fill -7 217 -10 -7 218 -10 minecraft:cobblestone
fill 4 217 -10 4 221 -10 minecraft:tuff
fill 8 217 -10 8 221 -10 minecraft:stone
fill 9 217 -10 9 218 -10 minecraft:cobblestone
fill 10 217 -10 10 220 -10 minecraft:stone
fill 13 217 -10 13 220 -10 minecraft:stone
fill 16 217 -10 17 220 -10 minecraft:tuff
fill 23 217 -10 23 220 -10 minecraft:stone
fill -27 217 -9 -27 219 -6 minecraft:tuff
fill -25 217 -9 -25 217 -8 minecraft:tuff
fill -1 217 -9 -1 221 -9 minecraft:stone
fill 3 217 -9 3 220 -9 minecraft:tuff
fill 13 217 -9 13 219 -9 minecraft:andesite
fill 14 217 -9 14 220 -9 minecraft:stone
fill 27 217 -9 27 218 -6 minecraft:stone
fill -26 217 -8 -26 219 -8 minecraft:tuff
fill -21 217 -8 -20 220 -8 minecraft:stone
fill 0 217 -8 0 221 -8 minecraft:stone
fill 7 217 -8 7 220 -7 minecraft:stone
fill 14 217 -8 15 217 -8 minecraft:andesite
fill 16 217 -8 16 218 -7 minecraft:stone
fill -25 217 -7 -25 221 -4 minecraft:stone
setblock -21 217 -7 minecraft:andesite
fill 11 217 -7 12 218 -6 minecraft:stone
fill 13 217 -7 14 218 -7 minecraft:andesite
fill -26 217 -6 -26 218 -5 minecraft:tuff
fill -24 217 -6 -24 221 -4 minecraft:stone
fill -22 217 -6 -22 221 -6 minecraft:stone
fill -15 217 -6 -15 218 -6 minecraft:andesite
fill -3 217 -6 -3 220 -6 minecraft:andesite
fill 9 217 -6 10 219 -6 minecraft:stone
fill 13 217 -6 14 220 -6 minecraft:stone
fill 15 217 -6 16 218 -6 minecraft:andesite
setblock 17 217 -6 minecraft:stone
fill 26 217 -6 26 220 -5 minecraft:stone
fill 28 217 -6 28 220 -2 minecraft:stone
fill -23 217 -5 -23 221 -5 minecraft:stone
setblock -22 217 -5 minecraft:cobblestone
fill -21 217 -5 -21 217 -4 minecraft:stone
setblock -3 217 -5 minecraft:stone
setblock 4 217 -5 minecraft:stone
fill 5 217 -5 5 221 -5 minecraft:tuff
setblock 16 217 -5 minecraft:stone
fill 17 217 -5 17 221 -4 minecraft:andesite
fill 23 217 -5 24 220 -5 minecraft:stone
fill -20 217 -4 -20 219 -2 minecraft:andesite
fill -2 217 -4 -2 220 -4 minecraft:andesite
fill 1 217 -4 1 220 -4 minecraft:andesite
setblock 23 217 -4 minecraft:andesite
fill 24 217 -4 24 219 -4 minecraft:cobblestone
fill -26 217 -3 -25 217 -2 minecraft:tuff
