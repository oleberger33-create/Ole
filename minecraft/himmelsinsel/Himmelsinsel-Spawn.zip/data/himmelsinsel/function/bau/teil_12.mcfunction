fill 27 216 -5 27 220 -4 minecraft:stone
fill -23 216 -4 -22 220 -1 minecraft:stone
fill 5 216 -4 5 221 -4 minecraft:tuff
fill 18 216 -4 18 221 -4 minecraft:andesite
fill 24 216 -4 24 216 -2 minecraft:andesite
fill 25 216 -4 26 220 -4 minecraft:stone
fill -24 216 -3 -24 221 -3 minecraft:stone
fill -19 216 -3 -19 219 -3 minecraft:andesite
fill 0 216 -3 0 217 -3 minecraft:stone
fill 9 216 -3 9 221 -3 minecraft:stone
fill 18 216 -3 18 217 -3 minecraft:stone
fill 25 216 -3 26 217 -3 minecraft:cobblestone
fill -25 216 -2 -24 216 -2 minecraft:tuff
setblock -19 216 -2 minecraft:stone
fill -18 216 -2 -17 219 -2 minecraft:andesite
setblock -16 216 -2 minecraft:stone
fill 21 216 -2 21 221 -2 minecraft:andesite
fill 25 216 -2 25 219 -2 minecraft:cobblestone
fill -26 216 -1 -26 219 -1 minecraft:tuff
fill -18 216 -1 -18 217 0 minecraft:stone
fill 21 216 -1 21 216 0 minecraft:stone
fill 22 216 -1 23 219 -1 minecraft:andesite
fill -26 216 0 -26 216 1 minecraft:stone
setblock -23 216 0 minecraft:tuff
fill -22 216 0 -22 219 10 minecraft:stone
setblock 0 216 0 minecraft:stone
fill 1 216 0 1 218 2 minecraft:andesite
fill 22 216 0 22 221 0 minecraft:andesite
fill 23 216 0 23 218 0 minecraft:stone
fill -23 216 1 -23 220 6 minecraft:stone
fill 0 216 1 0 219 2 minecraft:andesite
fill 16 216 1 16 218 1 minecraft:tuff
setblock 23 216 1 minecraft:amethyst_block
fill -25 216 2 -25 220 2 minecraft:stone
fill 23 216 2 23 219 2 minecraft:stone
fill -24 216 3 -24 220 3 minecraft:stone
fill -20 216 3 -20 221 3 minecraft:stone
fill 12 216 3 12 219 3 minecraft:stone
setblock 23 216 3 minecraft:dripstone_block
fill 11 216 4 11 220 4 minecraft:stone
setblock 12 216 4 minecraft:tuff
fill 3 216 5 3 221 5 minecraft:stone
setblock 11 216 5 minecraft:tuff
fill -19 216 6 -18 217 7 minecraft:cobblestone
fill -17 216 6 -17 218 8 minecraft:stone
fill 2 216 6 3 216 6 minecraft:cobblestone
setblock 11 216 6 minecraft:stone
fill 22 216 6 22 217 8 minecraft:stone
fill -13 216 7 -12 218 7 minecraft:stone
fill 0 216 7 0 219 7 minecraft:stone
fill 1 216 7 1 218 7 minecraft:tuff
fill -21 216 8 -21 219 9 minecraft:stone
fill -12 216 8 -12 218 8 minecraft:stone
fill 4 216 8 4 220 9 minecraft:stone
setblock -17 216 9 minecraft:cobblestone
fill -1 216 9 -1 218 9 minecraft:stone
fill 0 216 9 0 221 9 minecraft:tuff
fill 22 216 9 22 218 9 minecraft:cobblestone
setblock -21 216 10 minecraft:dripstone_block
fill -20 216 10 -20 216 11 minecraft:stone
fill -19 216 10 -18 216 10 minecraft:cobblestone
fill -17 216 10 -16 221 10 minecraft:stone
fill -11 216 10 -11 220 10 minecraft:stone
fill 1 216 10 1 220 11 minecraft:tuff
fill 18 216 10 21 218 10 minecraft:cobblestone
fill -22 216 11 -21 216 12 minecraft:andesite
fill 2 216 11 2 219 12 minecraft:tuff
fill 15 216 11 17 216 11 minecraft:stone
fill 20 216 11 21 217 12 minecraft:stone
fill -20 216 12 -20 216 13 minecraft:andesite
fill -19 216 12 -19 220 12 minecraft:stone
fill -3 216 12 -3 220 13 minecraft:andesite
fill -2 216 12 1 216 12 minecraft:stone
fill 15 216 12 17 216 12 minecraft:andesite
fill 18 216 12 18 218 12 minecraft:stone
fill -21 216 13 -21 217 13 minecraft:andesite
fill -18 216 13 -18 221 13 minecraft:stone
fill -14 216 13 -14 218 13 minecraft:andesite
setblock 0 216 13 minecraft:cobblestone
fill 20 216 13 20 219 15 minecraft:stone
fill -20 216 14 -19 220 14 minecraft:stone
fill -14 216 14 -14 220 16 minecraft:stone
fill -12 216 14 -11 220 14 minecraft:andesite
fill 3 216 14 3 221 14 minecraft:stone
fill -18 216 15 -18 219 16 minecraft:stone
fill -12 216 15 -12 217 16 minecraft:stone
fill -17 216 16 -17 220 16 minecraft:stone
fill -1 216 16 -1 219 16 minecraft:cobblestone
fill 1 216 16 1 219 16 minecraft:cobblestone
fill 16 216 16 16 220 16 minecraft:stone
fill 20 216 16 20 216 17 minecraft:dripstone_block
fill -18 216 17 -18 216 19 minecraft:cobblestone
fill -1 216 17 -1 221 17 minecraft:stone
fill 17 216 17 17 220 17 minecraft:stone
fill 19 216 17 19 220 19 minecraft:stone
fill -17 216 18 -17 220 18 minecraft:stone
fill 18 216 18 18 220 19 minecraft:stone
fill -11 216 19 -10 216 20 minecraft:andesite
fill -9 216 19 -8 221 19 minecraft:stone
fill 16 216 19 17 220 19 minecraft:stone
fill -18 216 20 -18 220 20 minecraft:stone
setblock -17 216 20 minecraft:dripstone_block
fill -13 216 20 -12 216 21 minecraft:stone
fill -9 216 20 -7 216 20 minecraft:andesite
fill 15 216 20 16 220 20 minecraft:stone
fill -17 216 21 -16 220 21 minecraft:stone
fill -14 216 21 -14 220 22 minecraft:stone
fill -11 216 21 -11 221 21 minecraft:andesite
setblock -10 216 21 minecraft:amethyst_block
fill -9 216 21 -8 216 21 minecraft:andesite
fill -7 216 21 -7 221 21 minecraft:stone
fill -5 216 21 -5 221 21 minecraft:stone
fill 14 216 21 15 220 21 minecraft:stone
fill -16 216 22 -15 220 22 minecraft:stone
fill -11 216 22 -8 221 22 minecraft:stone
setblock -5 216 22 minecraft:dripstone_block
fill -4 216 22 -3 221 22 minecraft:stone
fill 11 216 22 13 220 22 minecraft:stone
fill -10 216 23 -9 218 24 minecraft:stone
fill -6 216 23 -6 221 25 minecraft:stone
fill -5 216 23 -4 216 23 minecraft:tuff
fill -3 216 23 -2 217 24 minecraft:stone
fill 7 216 23 11 220 23 minecraft:stone
fill 41 216 23 41 216 24 minecraft:stone
fill -7 216 24 -7 219 25 minecraft:stone
fill -5 216 24 -5 217 24 minecraft:tuff
fill 7 216 24 7 217 24 minecraft:tuff
fill 9 216 24 9 216 25 minecraft:tuff
setblock 10 216 24 minecraft:dripstone_block
setblock 40 216 24 minecraft:stone
fill -9 216 25 -8 219 25 minecraft:stone
fill -2 216 25 -2 219 26 minecraft:stone
fill 3 216 25 3 219 25 minecraft:stone
fill 6 216 25 7 220 25 minecraft:stone
fill 8 216 25 8 217 25 minecraft:tuff
fill -1 216 26 2 216 26 minecraft:stone
fill -1 216 27 1 220 27 minecraft:tuff
fill 0 216 28 0 220 28 minecraft:tuff
fill 35 217 -36 35 218 -36 minecraft:stone
fill 34 217 -35 34 220 -35 minecraft:stone
fill 37 217 -35 37 220 -35 minecraft:tuff
fill 38 217 -34 40 220 -34 minecraft:stone
fill 33 217 -33 33 218 -33 minecraft:stone
fill 40 217 -33 41 221 -33 minecraft:stone
fill 32 217 -32 32 219 -31 minecraft:stone
setblock 40 217 -32 minecraft:andesite
fill 41 217 -32 41 221 -32 minecraft:stone
fill 31 217 -30 31 220 -28 minecraft:stone
fill 42 217 -30 42 218 -28 minecraft:stone
fill 32 217 -28 32 220 -28 minecraft:stone
fill -8 217 -27 -6 219 -26 minecraft:tuff
fill -5 217 -27 -3 218 -27 minecraft:stone
fill 2 217 -27 3 220 -27 minecraft:stone
fill 4 217 -27 4 218 -25 minecraft:andesite
fill 5 217 -27 5 219 -27 minecraft:stone
setblock 42 217 -27 minecraft:amethyst_block
fill -9 217 -26 -9 220 -24 minecraft:tuff
fill -5 217 -26 -4 220 -24 minecraft:stone
setblock -3 217 -26 minecraft:dripstone_block
fill -2 217 -26 2 219 -26 minecraft:stone
fill 3 217 -26 3 220 -26 minecraft:andesite
fill 5 217 -26 5 219 -25 minecraft:andesite
fill 6 217 -26 8 219 -26 minecraft:stone
fill 32 217 -26 33 220 -26 minecraft:stone
fill 42 217 -26 42 218 -26 minecraft:stone
setblock -13 217 -25 minecraft:amethyst_block
fill -12 217 -25 -11 220 -25 minecraft:stone
fill -10 217 -25 -10 220 -25 minecraft:tuff
fill -8 217 -25 -7 221 -25 minecraft:tuff
fill -6 217 -25 -6 217 -24 minecraft:stone
fill -3 217 -25 -3 221 -25 minecraft:stone
fill 9 217 -25 9 220 -25 minecraft:tuff
fill 33 217 -25 33 220 -25 minecraft:stone
setblock 34 217 -25 minecraft:dripstone_block
fill 35 217 -25 37 221 -25 minecraft:stone
fill 41 217 -25 41 219 -25 minecraft:stone
fill -16 217 -24 -14 220 -24 minecraft:stone
setblock -8 217 -24 minecraft:dripstone_block
setblock -7 217 -24 minecraft:stone
fill 6 217 -24 6 220 -24 minecraft:stone
setblock 8 217 -24 minecraft:stone
setblock 10 217 -24 minecraft:amethyst_block
fill 36 217 -24 37 217 -24 minecraft:andesite
fill 38 217 -24 38 220 -24 minecraft:stone
setblock 40 217 -24 minecraft:dripstone_block
setblock -16 217 -23 minecraft:dripstone_block
setblock -15 217 -23 minecraft:amethyst_block
fill 9 217 -23 9 220 -23 minecraft:tuff
setblock 10 217 -23 minecraft:dripstone_block
fill 39 217 -23 39 220 -23 minecraft:stone
fill -40 217 -22 -40 226 -22 minecraft:stone
fill -17 217 -22 -16 217 -22 minecraft:stone
fill -15 217 -22 -15 220 -21 minecraft:tuff
fill -12 217 -22 -12 221 -22 minecraft:stone
fill 3 217 -22 3 219 -22 minecraft:andesite
fill 11 217 -22 11 221 -19 minecraft:stone
fill -17 217 -21 -17 217 -20 minecraft:stone
fill -16 217 -21 -16 220 -17 minecraft:tuff
fill -14 217 -21 -12 217 -21 minecraft:cobblestone
fill -9 217 -21 -9 221 -19 minecraft:stone
fill 2 217 -21 3 217 -21 minecraft:stone
fill 4 217 -21 4 219 -21 minecraft:andesite
fill 5 217 -21 6 217 -21 minecraft:stone
fill 12 217 -21 17 218 -21 minecraft:stone
fill -18 217 -20 -18 219 -19 minecraft:stone
setblock -13 217 -20 minecraft:cobblestone
fill -12 217 -20 -12 221 -19 minecraft:stone
fill -10 217 -20 -10 221 -19 minecraft:stone
fill 12 217 -20 14 220 -20 minecraft:stone
fill 18 217 -20 18 220 -18 minecraft:stone
setblock -13 217 -19 minecraft:tuff
fill 12 217 -19 12 221 -19 minecraft:stone
setblock 19 217 -19 minecraft:dripstone_block
fill -19 217 -18 -19 221 -18 minecraft:stone
fill 17 217 -18 17 220 -18 minecraft:stone
fill 19 217 -18 19 218 -16 minecraft:stone
fill -23 217 -17 -20 220 -17 minecraft:stone
setblock -13 217 -17 minecraft:tuff
fill 20 217 -17 20 217 -15 minecraft:stone
fill 22 217 -17 23 217 -16 minecraft:stone
