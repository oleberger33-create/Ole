fill -15 211 2 -15 221 2 minecraft:stone
fill 15 211 2 15 221 2 minecraft:stone
fill -14 211 3 -14 221 3 minecraft:stone
fill -12 211 3 -12 220 3 minecraft:stone
setblock 5 211 3 minecraft:stone
fill 6 211 3 7 213 3 minecraft:andesite
fill 18 211 3 18 221 3 minecraft:stone
setblock 20 211 3 minecraft:amethyst_block
setblock -14 211 4 minecraft:dripstone_block
fill 14 211 4 14 221 5 minecraft:stone
fill 21 211 4 21 220 4 minecraft:stone
fill -14 211 5 -14 220 7 minecraft:stone
fill -11 211 5 -11 211 6 minecraft:andesite
fill 17 211 5 17 220 8 minecraft:stone
setblock -12 211 6 minecraft:stone
setblock -10 211 6 minecraft:andesite
fill 15 211 6 15 220 6 minecraft:stone
fill 21 211 6 21 219 6 minecraft:stone
setblock -15 211 7 minecraft:dripstone_block
fill -12 211 7 -12 215 7 minecraft:andesite
fill 1 211 7 1 213 9 minecraft:stone
fill 16 211 7 16 220 7 minecraft:stone
setblock 20 211 7 minecraft:amethyst_block
fill -15 211 8 -15 212 8 minecraft:cobblestone
setblock -14 211 8 minecraft:dripstone_block
fill 6 211 8 6 211 10 minecraft:stone
setblock 16 211 8 minecraft:dripstone_block
fill -14 211 9 -13 211 9 minecraft:stone
fill -12 211 9 -12 216 10 minecraft:andesite
fill 7 211 9 7 220 11 minecraft:stone
fill 16 211 9 16 220 9 minecraft:stone
fill -13 211 10 -13 211 12 minecraft:stone
fill -10 211 10 -10 212 10 minecraft:andesite
fill -9 211 10 -8 221 11 minecraft:stone
fill 14 211 10 15 220 10 minecraft:stone
fill -12 211 11 -12 211 13 minecraft:stone
fill -11 211 11 -11 219 11 minecraft:andesite
fill -10 211 11 -10 214 16 minecraft:stone
fill -7 211 11 -7 221 13 minecraft:stone
fill -1 211 11 0 211 11 minecraft:stone
fill 8 211 11 8 220 11 minecraft:stone
fill 13 211 11 14 217 11 minecraft:stone
setblock 15 211 11 minecraft:amethyst_block
fill -11 211 12 -11 211 14 minecraft:stone
fill -1 211 12 -1 212 12 minecraft:stone
fill 0 211 12 0 215 13 minecraft:cobblestone
fill 3 211 12 3 221 13 minecraft:stone
fill 7 211 12 7 211 14 minecraft:tuff
fill 12 211 12 13 218 12 minecraft:stone
fill -6 211 13 -6 220 13 minecraft:stone
fill 1 211 13 1 216 14 minecraft:cobblestone
setblock 2 211 13 minecraft:andesite
fill 11 211 13 11 220 13 minecraft:stone
setblock -9 211 14 minecraft:dripstone_block
fill -8 211 14 -8 220 15 minecraft:stone
fill -2 211 14 0 211 14 minecraft:stone
fill 3 211 14 3 215 14 minecraft:cobblestone
fill 4 211 14 4 221 14 minecraft:stone
fill 6 211 14 6 220 14 minecraft:stone
fill 8 211 14 8 220 14 minecraft:stone
fill 10 211 14 10 220 14 minecraft:stone
fill -9 211 15 -9 220 15 minecraft:stone
fill 4 211 15 4 213 15 minecraft:cobblestone
fill 5 211 15 5 217 15 minecraft:stone
fill 9 211 15 9 219 15 minecraft:stone
fill -6 211 16 -6 220 17 minecraft:stone
fill -2 211 16 -2 216 17 minecraft:stone
setblock -1 211 16 minecraft:dripstone_block
fill 0 211 16 1 214 16 minecraft:stone
fill 2 211 16 3 211 16 minecraft:tuff
fill 4 211 16 4 218 17 minecraft:stone
fill 6 211 16 6 220 17 minecraft:stone
setblock 9 211 16 minecraft:andesite
fill -9 211 17 -9 220 17 minecraft:stone
setblock -8 211 17 minecraft:amethyst_block
fill -7 211 17 -7 220 17 minecraft:stone
fill -5 211 17 -3 220 17 minecraft:stone
setblock 3 211 17 minecraft:tuff
fill 5 211 17 5 220 17 minecraft:stone
fill 7 211 17 8 220 17 minecraft:stone
fill -5 212 -20 -3 220 -20 minecraft:stone
fill -5 212 -19 -5 220 -18 minecraft:stone
fill -3 212 -19 -3 220 -18 minecraft:stone
fill 4 212 -19 8 219 -18 minecraft:stone
fill -4 212 -18 -4 220 -18 minecraft:stone
fill 3 212 -18 3 220 -18 minecraft:stone
setblock -5 212 -17 minecraft:amethyst_block
fill -2 212 -17 -2 221 -16 minecraft:stone
fill 2 212 -17 2 221 -17 minecraft:stone
setblock 8 212 -17 minecraft:dripstone_block
fill -1 212 -16 -1 220 -16 minecraft:stone
fill 1 212 -16 1 219 -15 minecraft:stone
fill 3 212 -16 5 212 -16 minecraft:stone
fill 6 212 -16 6 216 -16 minecraft:cobblestone
fill 9 212 -16 9 213 -15 minecraft:andesite
fill -6 212 -15 -5 217 -15 minecraft:stone
setblock -1 212 -15 minecraft:dripstone_block
fill 0 212 -15 0 219 -14 minecraft:stone
fill -9 212 -14 -8 221 -14 minecraft:stone
setblock -7 212 -14 minecraft:cobblestone
fill 8 212 -14 10 212 -14 minecraft:cobblestone
fill 11 212 -14 11 221 -14 minecraft:stone
setblock -10 212 -13 minecraft:amethyst_block
fill 7 212 -13 7 221 -12 minecraft:stone
setblock 8 212 -13 minecraft:amethyst_block
fill 9 212 -13 9 213 -13 minecraft:cobblestone
fill 14 212 -13 14 216 -13 minecraft:stone
fill -11 212 -12 -10 212 -12 minecraft:stone
fill -6 212 -12 -6 213 -11 minecraft:stone
fill 8 212 -12 9 212 -12 minecraft:stone
fill 15 212 -12 15 213 -12 minecraft:stone
fill -15 212 -11 -12 213 -11 minecraft:stone
fill -1 212 -11 0 221 -11 minecraft:stone
fill 9 212 -11 9 221 -11 minecraft:stone
fill 16 212 -11 16 214 -11 minecraft:stone
fill -14 212 -10 -14 221 -10 minecraft:stone
fill -10 212 -10 -8 212 -10 minecraft:stone
setblock -7 212 -10 minecraft:tuff
fill 17 212 -10 17 216 -10 minecraft:stone
fill -10 212 -9 -10 220 -9 minecraft:stone
fill -1 212 -9 -1 216 -9 minecraft:andesite
fill 3 212 -9 4 213 -9 minecraft:stone
setblock 5 212 -9 minecraft:tuff
fill 6 212 -9 6 214 -9 minecraft:stone
fill 16 212 -9 16 215 -8 minecraft:andesite
fill 18 212 -9 18 213 -8 minecraft:andesite
fill -20 212 -8 -19 215 -8 minecraft:andesite
fill -13 212 -8 -12 220 -8 minecraft:stone
fill -10 212 -8 -10 213 -8 minecraft:cobblestone
fill 0 212 -8 1 214 -8 minecraft:andesite
fill 4 212 -8 4 220 -7 minecraft:tuff
setblock -20 212 -7 minecraft:cobblestone
fill -19 212 -7 -18 214 -7 minecraft:andesite
fill -15 212 -7 -15 221 -7 minecraft:stone
setblock -10 212 -7 minecraft:stone
setblock 16 212 -7 minecraft:stone
fill 17 212 -7 17 215 -7 minecraft:andesite
fill 18 212 -7 18 220 -6 minecraft:stone
fill -19 212 -6 -19 219 -6 minecraft:andesite
setblock -18 212 -6 minecraft:cobblestone
fill -8 212 -6 -8 221 -6 minecraft:stone
fill 17 212 -6 17 216 -4 minecraft:stone
fill -15 212 -5 -15 220 -5 minecraft:andesite
fill -10 212 -4 -10 220 -4 minecraft:stone
fill -8 212 -4 -8 213 -3 minecraft:andesite
fill -7 212 -4 -7 220 -4 minecraft:stone
setblock 9 212 -4 minecraft:tuff
setblock 16 212 -4 minecraft:tuff
fill -10 212 -3 -9 212 -3 minecraft:andesite
fill -7 212 -3 -6 212 -3 minecraft:andesite
fill -5 212 -3 -5 220 -2 minecraft:stone
fill -3 212 -3 -3 220 -3 minecraft:stone
setblock 17 212 -3 minecraft:dripstone_block
fill -18 212 -2 -18 215 0 minecraft:stone
setblock -6 212 -2 minecraft:andesite
fill 0 212 -2 1 213 -2 minecraft:andesite
fill 11 212 -2 12 212 -2 minecraft:cobblestone
fill 13 212 -2 13 220 -2 minecraft:stone
fill 18 212 -2 18 219 -1 minecraft:stone
fill 7 212 0 8 221 0 minecraft:stone
fill 18 212 0 18 212 1 minecraft:dripstone_block
fill -17 212 1 -17 220 1 minecraft:stone
setblock -16 212 1 minecraft:andesite
fill -15 212 1 -15 220 1 minecraft:stone
fill 12 212 1 12 219 1 minecraft:stone
fill 17 212 1 17 216 2 minecraft:stone
setblock -17 212 2 minecraft:andesite
fill 5 212 2 5 212 3 minecraft:andesite
setblock 12 212 2 minecraft:tuff
fill 16 212 2 16 217 2 minecraft:stone
fill 18 212 2 19 220 2 minecraft:stone
setblock -15 212 3 minecraft:dripstone_block
setblock 12 212 3 minecraft:stone
fill 15 212 3 15 219 3 minecraft:stone
fill 20 212 3 20 220 3 minecraft:stone
fill -14 212 4 -14 221 4 minecraft:stone
fill 17 212 4 17 221 4 minecraft:stone
fill -15 212 5 -15 216 6 minecraft:stone
fill -11 212 5 -11 216 5 minecraft:stone
fill 15 212 5 15 221 5 minecraft:stone
fill -16 212 6 -16 216 6 minecraft:stone
fill -12 212 6 -11 213 6 minecraft:andesite
fill -10 212 6 -10 216 6 minecraft:stone
fill 0 212 6 0 217 6 minecraft:stone
fill 16 212 6 16 221 6 minecraft:stone
fill -16 212 7 -15 212 7 minecraft:cobblestone
fill 20 212 7 20 217 7 minecraft:stone
setblock -17 212 8 minecraft:stone
fill -16 212 8 -16 213 9 minecraft:cobblestone
fill -14 212 8 -14 214 11 minecraft:stone
setblock 6 212 8 minecraft:tuff
fill 16 212 8 16 220 8 minecraft:stone
setblock 18 212 8 minecraft:dripstone_block
setblock -15 212 9 minecraft:amethyst_block
fill -13 212 9 -13 217 10 minecraft:andesite
fill 6 212 9 6 220 10 minecraft:stone
fill 17 212 9 17 220 10 minecraft:stone
fill 0 212 10 0 216 10 minecraft:stone
fill 16 212 10 16 220 10 minecraft:stone
fill -13 212 11 -13 212 14 minecraft:stone
fill -12 212 11 -12 220 12 minecraft:andesite
fill -1 212 11 -1 218 11 minecraft:stone
fill 0 212 11 0 214 11 minecraft:cobblestone
fill 15 212 11 15 213 12 minecraft:stone
setblock 16 212 11 minecraft:amethyst_block
fill -11 212 12 -11 219 12 minecraft:andesite
fill -9 212 12 -8 221 13 minecraft:stone
fill 2 212 12 2 215 12 minecraft:stone
fill 6 212 12 8 220 12 minecraft:stone
fill 14 212 12 14 220 13 minecraft:stone
setblock 16 212 12 minecraft:stone
fill -12 212 13 -11 212 14 minecraft:stone
fill -3 212 13 -2 213 13 minecraft:stone
fill -1 212 13 -1 217 14 minecraft:cobblestone
setblock 2 212 13 minecraft:cobblestone
fill 6 212 13 7 212 13 minecraft:tuff
fill 8 212 13 8 220 13 minecraft:stone
fill 12 212 13 13 220 13 minecraft:stone
setblock 15 212 13 minecraft:dripstone_block
fill -9 212 14 -9 221 14 minecraft:stone
