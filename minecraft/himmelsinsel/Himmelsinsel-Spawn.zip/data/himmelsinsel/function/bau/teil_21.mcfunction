fill 15 221 -5 16 222 -5 minecraft:dirt
fill 24 221 -5 24 221 -4 minecraft:rooted_dirt
fill 25 221 -5 25 222 -5 minecraft:dirt
setblock 27 221 -5 minecraft:rooted_dirt
fill 29 221 -5 29 223 -5 minecraft:dirt
setblock -29 221 -4 minecraft:tuff
fill -23 221 -4 -23 221 -2 minecraft:stone
fill -22 221 -4 -22 221 -3 minecraft:andesite
setblock -20 221 -4 minecraft:andesite
fill -17 221 -4 -17 223 -3 minecraft:dirt
setblock -10 221 -4 minecraft:tuff
setblock -7 221 -4 minecraft:rooted_dirt
fill -5 221 -4 -5 223 -3 minecraft:dirt
fill -4 221 -4 -4 221 -3 minecraft:rooted_dirt
fill -2 221 -4 -2 223 -4 minecraft:dirt
fill 12 221 -4 12 221 -3 minecraft:rooted_dirt
fill 15 221 -4 16 221 -4 minecraft:andesite
fill 25 221 -4 25 221 -3 minecraft:rooted_dirt
fill 27 221 -4 27 223 -2 minecraft:dirt
fill 29 221 -4 29 221 -2 minecraft:rooted_dirt
fill 31 221 -4 31 221 -1 minecraft:stone
fill -25 221 -3 -25 221 -2 minecraft:stone
setblock -21 221 -3 minecraft:andesite
setblock -20 221 -3 minecraft:mossy_cobblestone
fill -16 221 -3 -16 223 -2 minecraft:dirt
setblock -15 221 -3 minecraft:rooted_dirt
fill -14 221 -3 -14 223 -3 minecraft:dirt
fill -10 221 -3 -10 221 -2 minecraft:rooted_dirt
fill -7 221 -3 -7 223 -2 minecraft:dirt
setblock -2 221 -3 minecraft:rooted_dirt
setblock 1 221 -3 minecraft:rooted_dirt
setblock 10 221 -3 minecraft:stone
fill 23 221 -3 24 222 -3 minecraft:dirt
setblock -29 221 -2 minecraft:tuff
setblock -24 221 -2 minecraft:stone
setblock -22 221 -2 minecraft:stone
fill -21 221 -2 -21 221 -1 minecraft:mossy_cobblestone
setblock -17 221 -2 minecraft:rooted_dirt
fill -15 221 -2 -15 223 -2 minecraft:dirt
setblock -14 221 -2 minecraft:rooted_dirt
fill -13 221 -2 -13 223 -1 minecraft:dirt
setblock -12 221 -2 minecraft:rooted_dirt
fill -11 221 -2 -11 223 -1 minecraft:dirt
setblock -5 221 -2 minecraft:stone
fill -2 221 -2 -1 222 -2 minecraft:dirt
setblock 0 221 -2 minecraft:rooted_dirt
fill 1 221 -2 2 222 -2 minecraft:dirt
setblock 4 221 -2 minecraft:stone
fill 12 221 -2 12 223 3 minecraft:dirt
fill 15 221 -2 15 222 0 minecraft:dirt
fill 16 221 -2 17 221 -2 minecraft:andesite
fill 23 221 -2 24 221 5 minecraft:mossy_cobblestone
setblock 25 221 -2 minecraft:stone
setblock 28 221 -2 minecraft:rooted_dirt
setblock 30 221 -2 minecraft:stone
fill -30 221 -1 -30 223 -1 minecraft:dirt
setblock -29 221 -1 minecraft:rooted_dirt
fill -28 221 -1 -23 223 -1 minecraft:dirt
setblock -22 221 -1 minecraft:mossy_cobblestone
setblock -20 221 -1 minecraft:mossy_cobblestone
fill -18 221 -1 -18 221 0 minecraft:mossy_cobblestone
fill -17 221 -1 -17 223 1 minecraft:dirt
fill -16 221 -1 -15 221 0 minecraft:rooted_dirt
fill -14 221 -1 -14 223 0 minecraft:dirt
fill -12 221 -1 -12 223 0 minecraft:dirt
fill -10 221 -1 -9 223 4 minecraft:dirt
fill -8 221 -1 -7 221 -1 minecraft:stone
setblock -2 221 -1 minecraft:stone
fill -1 221 -1 0 221 -1 minecraft:andesite
setblock 2 221 -1 minecraft:rooted_dirt
fill 3 221 -1 5 222 1 minecraft:dirt
fill 13 221 -1 13 222 0 minecraft:dirt
fill 14 221 -1 14 221 0 minecraft:rooted_dirt
setblock 16 221 -1 minecraft:rooted_dirt
setblock 18 221 -1 minecraft:andesite
fill 21 221 -1 22 221 -1 minecraft:stone
fill 25 221 -1 25 221 1 minecraft:andesite
fill 26 221 -1 27 221 -1 minecraft:stone
setblock -30 221 0 minecraft:rooted_dirt
fill -29 221 0 -28 223 0 minecraft:dirt
fill -27 221 0 -27 221 1 minecraft:rooted_dirt
fill -26 221 0 -22 223 1 minecraft:dirt
fill -21 221 0 -20 221 0 minecraft:andesite
fill -13 221 0 -13 221 2 minecraft:rooted_dirt
fill -11 221 0 -11 221 2 minecraft:rooted_dirt
setblock -8 221 0 minecraft:stone
setblock -4 221 0 minecraft:stone
fill 0 221 0 0 221 2 minecraft:mossy_cobblestone
fill 2 221 0 2 222 1 minecraft:dirt
setblock 11 221 0 minecraft:stone
fill 16 221 0 17 222 0 minecraft:dirt
setblock 20 221 0 minecraft:andesite
fill 21 221 0 21 221 1 minecraft:stone
setblock 26 221 0 minecraft:andesite
fill 27 221 0 27 221 1 minecraft:stone
setblock 30 221 0 minecraft:stone
fill -30 221 1 -30 223 2 minecraft:dirt
fill -29 221 1 -28 221 1 minecraft:rooted_dirt
fill -21 221 1 -21 221 3 minecraft:stone
fill -16 221 1 -15 223 1 minecraft:dirt
fill -14 221 1 -14 221 2 minecraft:rooted_dirt
setblock -12 221 1 minecraft:rooted_dirt
fill -8 221 1 -8 223 6 minecraft:dirt
fill 6 221 1 6 223 8 minecraft:dirt
fill 7 221 1 8 221 1 minecraft:stone
fill 11 221 1 11 223 1 minecraft:dirt
setblock 13 221 1 minecraft:rooted_dirt
fill 14 221 1 14 222 1 minecraft:dirt
setblock 15 221 1 minecraft:stone
fill 19 221 1 20 221 1 minecraft:rooted_dirt
setblock 22 221 1 minecraft:andesite
fill 26 221 1 26 221 4 minecraft:stone
setblock 28 221 1 minecraft:stone
fill -29 221 2 -29 223 2 minecraft:dirt
setblock -28 221 2 minecraft:rooted_dirt
fill -27 221 2 -26 223 2 minecraft:dirt
setblock -25 221 2 minecraft:rooted_dirt
fill -24 221 2 -23 223 2 minecraft:dirt
fill -22 221 2 -22 221 4 minecraft:stone
fill -16 221 2 -16 221 4 minecraft:stone
fill -12 221 2 -12 223 3 minecraft:dirt
fill -7 221 2 -7 223 3 minecraft:dirt
fill -6 221 2 -5 221 2 minecraft:rooted_dirt
fill -4 221 2 -4 223 2 minecraft:dirt
setblock -2 221 2 minecraft:andesite
fill 1 221 2 2 221 2 minecraft:rooted_dirt
fill 3 221 2 4 223 2 minecraft:dirt
fill 5 221 2 5 221 3 minecraft:rooted_dirt
fill 7 221 2 7 223 4 minecraft:dirt
setblock 9 221 2 minecraft:mossy_cobblestone
fill 10 221 2 10 223 3 minecraft:dirt
fill 11 221 2 11 221 3 minecraft:rooted_dirt
fill 13 221 2 13 222 4 minecraft:dirt
setblock 18 221 2 minecraft:stone
fill 19 221 2 21 222 2 minecraft:dirt
fill 22 221 2 22 221 5 minecraft:stone
fill 25 221 2 25 221 6 minecraft:stone
fill 28 221 2 28 221 4 minecraft:mossy_cobblestone
setblock 30 221 2 minecraft:stone
setblock -29 221 3 minecraft:rooted_dirt
fill -28 221 3 -28 223 3 minecraft:dirt
fill -27 221 3 -26 221 3 minecraft:rooted_dirt
fill -25 221 3 -24 223 3 minecraft:dirt
fill -23 221 3 -23 221 6 minecraft:stone
setblock -13 221 3 minecraft:stone
fill -11 221 3 -11 223 4 minecraft:dirt
fill -6 221 3 -5 223 3 minecraft:dirt
setblock -4 221 3 minecraft:rooted_dirt
fill -3 221 3 3 222 3 minecraft:dirt
setblock 4 221 3 minecraft:rooted_dirt
fill 8 221 3 9 223 5 minecraft:dirt
fill 15 221 3 16 221 3 minecraft:stone
fill 19 221 3 19 222 4 minecraft:dirt
setblock 20 221 3 minecraft:rooted_dirt
fill 21 221 3 21 222 8 minecraft:dirt
fill -29 221 4 -29 223 4 minecraft:dirt
setblock -28 221 4 minecraft:rooted_dirt
fill -27 221 4 -27 223 6 minecraft:dirt
fill -26 221 4 -26 221 5 minecraft:rooted_dirt
fill -25 221 4 -25 223 4 minecraft:dirt
setblock -21 221 4 minecraft:tuff
setblock -7 221 4 minecraft:rooted_dirt
fill -6 221 4 -6 223 6 minecraft:dirt
setblock -5 221 4 minecraft:rooted_dirt
fill -4 221 4 -3 223 5 minecraft:dirt
setblock -2 221 4 minecraft:rooted_dirt
fill -1 221 4 3 223 4 minecraft:dirt
setblock 4 221 4 minecraft:tuff
fill 5 221 4 5 223 5 minecraft:dirt
setblock 10 221 4 minecraft:rooted_dirt
fill 11 221 4 11 223 10 minecraft:dirt
fill 12 221 4 12 221 6 minecraft:rooted_dirt
setblock 15 221 4 minecraft:tuff
fill 20 221 4 20 222 4 minecraft:dirt
setblock 30 221 4 minecraft:rooted_dirt
setblock -29 221 5 minecraft:rooted_dirt
fill -28 221 5 -28 223 6 minecraft:dirt
setblock -25 221 5 minecraft:stone
fill -16 221 5 -16 221 6 minecraft:mossy_cobblestone
fill -15 221 5 -14 221 5 minecraft:stone
fill -11 221 5 -10 221 5 minecraft:rooted_dirt
fill -9 221 5 -9 223 6 minecraft:dirt
fill -7 221 5 -7 223 6 minecraft:dirt
fill -5 221 5 -5 223 5 minecraft:dirt
fill -2 221 5 0 223 5 minecraft:dirt
setblock 1 221 5 minecraft:rooted_dirt
fill 2 221 5 2 223 5 minecraft:dirt
setblock 7 221 5 minecraft:rooted_dirt
fill 10 221 5 10 223 6 minecraft:dirt
setblock 13 221 5 minecraft:rooted_dirt
setblock 17 221 5 minecraft:stone
fill 19 221 5 20 221 5 minecraft:rooted_dirt
fill -26 221 6 -26 223 6 minecraft:dirt
fill -20 221 6 -18 221 6 minecraft:stone
setblock -17 221 6 minecraft:mossy_cobblestone
setblock -15 221 6 minecraft:mossy_cobblestone
setblock -14 221 6 minecraft:stone
setblock -12 221 6 minecraft:stone
fill -10 221 6 -10 223 6 minecraft:dirt
fill -5 221 6 -4 221 8 minecraft:rooted_dirt
fill -3 221 6 -2 223 6 minecraft:dirt
fill -1 221 6 0 221 7 minecraft:mossy_cobblestone
fill 4 221 6 5 221 7 minecraft:stone
fill 7 221 6 7 223 8 minecraft:dirt
setblock 8 221 6 minecraft:rooted_dirt
fill 9 221 6 9 223 6 minecraft:dirt
fill 13 221 6 15 222 8 minecraft:dirt
fill 17 221 6 18 222 12 minecraft:dirt
fill 19 221 6 19 221 8 minecraft:rooted_dirt
fill 20 221 6 20 222 8 minecraft:dirt
setblock 23 221 6 minecraft:mossy_cobblestone
setblock 24 221 6 minecraft:stone
setblock 26 221 6 minecraft:stone
fill 27 221 6 27 223 6 minecraft:dirt
fill 28 221 6 29 221 6 minecraft:rooted_dirt
fill -28 221 7 -26 221 7 minecraft:stone
fill -23 221 7 -23 221 8 minecraft:mossy_cobblestone
fill -20 221 7 -19 221 8 minecraft:stone
fill -18 221 7 -16 223 8 minecraft:dirt
fill -15 221 7 -13 221 7 minecraft:rooted_dirt
