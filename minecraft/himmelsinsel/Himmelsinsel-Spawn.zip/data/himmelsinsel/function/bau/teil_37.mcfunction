setblock -8 225 7 minecraft:dandelion
setblock -6 225 7 minecraft:short_grass
fill -4 225 7 -4 225 8 minecraft:short_grass
setblock 3 225 7 minecraft:short_grass
fill 5 225 7 6 225 7 minecraft:short_grass
setblock 12 225 7 minecraft:short_grass
fill 13 225 7 13 225 8 minecraft:fern
setblock 14 225 7 minecraft:short_grass
setblock 16 225 7 minecraft:pink_petals[facing=west,flower_amount=1]
setblock 17 225 7 minecraft:fern
fill 18 225 7 19 225 7 minecraft:short_grass
fill 22 225 7 23 225 7 minecraft:short_grass
setblock 25 225 7 minecraft:short_grass
setblock -26 225 8 minecraft:lily_of_the_valley
setblock -24 225 8 minecraft:lily_of_the_valley
setblock -22 225 8 minecraft:short_grass
setblock -19 225 8 minecraft:fern
setblock -17 225 8 minecraft:poppy
fill -16 225 8 -15 225 8 minecraft:cornflower
setblock -14 225 8 minecraft:allium
setblock -11 225 8 minecraft:tall_grass[half=lower]
setblock -10 225 8 minecraft:short_grass
fill -3 225 8 -3 225 9 minecraft:tall_grass[half=lower]
setblock 2 225 8 minecraft:short_grass
fill 5 225 8 5 225 10 minecraft:short_grass
setblock 12 225 8 minecraft:wildflowers[facing=east,flower_amount=4]
setblock 19 225 8 minecraft:azure_bluet
setblock 20 225 8 minecraft:fern
setblock 21 225 8 minecraft:tall_grass[half=lower]
setblock 23 225 8 minecraft:short_grass
setblock 24 225 8 minecraft:lily_of_the_valley
fill 27 225 8 29 225 8 minecraft:short_grass
setblock -27 225 9 minecraft:pink_petals[facing=west,flower_amount=1]
setblock -26 225 9 minecraft:short_grass
fill -15 225 9 -14 225 9 minecraft:short_grass
fill -12 225 9 -12 225 10 minecraft:short_grass
setblock -10 225 9 minecraft:lily_of_the_valley
setblock -9 225 9 minecraft:short_grass
setblock -7 225 9 minecraft:short_grass
setblock -6 225 9 minecraft:pink_petals[facing=west,flower_amount=1]
setblock -5 225 9 minecraft:short_grass
setblock 2 225 9 minecraft:tall_grass[half=lower]
setblock 6 225 9 minecraft:dandelion
setblock 8 225 9 minecraft:wildflowers[facing=south,flower_amount=2]
setblock 9 225 9 minecraft:tall_grass[half=lower]
setblock 10 225 9 minecraft:short_grass
setblock 15 225 9 minecraft:allium
setblock 21 225 9 minecraft:cornflower
setblock 22 225 9 minecraft:short_grass
setblock 24 225 9 minecraft:short_grass
setblock 26 225 9 minecraft:fern
fill -19 225 10 -17 225 10 minecraft:short_grass
setblock -15 225 10 minecraft:short_grass
setblock -14 225 10 minecraft:cornflower
setblock -11 225 10 minecraft:short_grass
setblock -4 225 10 minecraft:short_grass
setblock 4 225 10 minecraft:short_grass
setblock 6 225 10 minecraft:tall_grass[half=lower]
fill 13 225 10 13 225 12 minecraft:short_grass
setblock 14 225 10 minecraft:lily_of_the_valley
setblock 18 225 10 minecraft:short_grass
setblock 20 225 10 minecraft:short_grass
setblock 21 225 10 minecraft:lily_of_the_valley
setblock 25 225 10 minecraft:short_grass
setblock 27 225 10 minecraft:fern
setblock -27 225 11 minecraft:short_grass
setblock -26 225 11 minecraft:pink_petals[facing=west,flower_amount=2]
setblock -24 225 11 minecraft:dandelion
setblock -19 225 11 minecraft:short_grass
setblock -17 225 11 minecraft:short_grass
setblock -15 225 11 minecraft:tall_grass[half=lower]
setblock -14 225 11 minecraft:short_grass
setblock -6 225 11 minecraft:short_grass
setblock -4 225 11 minecraft:wildflowers[facing=east,flower_amount=3]
setblock -2 225 11 minecraft:fern
setblock 2 225 11 minecraft:tall_grass[half=lower]
setblock 8 225 11 minecraft:short_grass
setblock 10 225 11 minecraft:short_grass
setblock 12 225 11 minecraft:short_grass
setblock 14 225 11 minecraft:short_grass
setblock 15 225 11 minecraft:fern
setblock 17 225 11 minecraft:short_grass
setblock 18 225 11 minecraft:fern
fill -23 225 12 -20 225 12 minecraft:short_grass
setblock -18 225 12 minecraft:short_grass
setblock -12 225 12 minecraft:short_grass
setblock -10 225 12 minecraft:short_grass
fill -9 225 12 -9 225 13 minecraft:tall_grass[half=lower]
setblock -2 225 12 minecraft:short_grass
setblock 4 225 12 minecraft:short_grass
setblock 6 225 12 minecraft:pink_petals[facing=east,flower_amount=2]
setblock 7 225 12 minecraft:fern
setblock 9 225 12 minecraft:short_grass
setblock 12 225 12 minecraft:pink_petals[facing=west,flower_amount=4]
setblock 15 225 12 minecraft:cornflower
setblock 16 225 12 minecraft:short_grass
setblock 17 225 12 minecraft:fern
setblock 20 225 12 minecraft:short_grass
setblock 27 225 12 minecraft:short_grass
setblock -26 225 13 minecraft:short_grass
setblock -25 225 13 minecraft:wildflowers[facing=east,flower_amount=4]
fill -21 225 13 -19 225 13 minecraft:short_grass
setblock -18 225 13 minecraft:pink_petals[facing=north,flower_amount=4]
fill -16 225 13 -16 225 14 minecraft:short_grass
fill -7 225 13 -5 225 13 minecraft:short_grass
setblock 2 225 13 minecraft:short_grass
fill 5 225 13 5 225 15 minecraft:short_grass
setblock 6 225 13 minecraft:tall_grass[half=lower]
setblock 7 225 13 minecraft:short_grass
setblock 14 225 13 minecraft:short_grass
setblock 16 225 13 minecraft:tall_grass[half=lower]
setblock 19 225 13 minecraft:short_grass
fill 25 225 13 25 225 14 minecraft:short_grass
setblock -25 225 14 minecraft:short_grass
setblock -24 225 14 minecraft:azure_bluet
fill -23 225 14 -21 225 15 minecraft:short_grass
setblock -20 225 14 minecraft:fern
setblock -18 225 14 minecraft:short_grass
fill -14 225 14 -13 225 14 minecraft:short_grass
setblock -11 225 14 minecraft:pink_petals[facing=west,flower_amount=4]
setblock -10 225 14 minecraft:dandelion
fill -7 225 14 -6 225 16 minecraft:short_grass
setblock -5 225 14 minecraft:pink_petals[facing=north,flower_amount=3]
setblock -4 225 14 minecraft:short_grass
setblock -3 225 14 minecraft:fern
setblock 2 225 14 minecraft:cornflower
setblock 4 225 14 minecraft:short_grass
setblock 8 225 14 minecraft:short_grass
fill 12 225 14 13 225 14 minecraft:short_grass
setblock 16 225 14 minecraft:short_grass
setblock 18 225 14 minecraft:dandelion
setblock 20 225 14 minecraft:short_grass
fill 23 225 14 23 225 18 minecraft:short_grass
setblock 26 225 14 minecraft:short_grass
setblock -24 225 15 minecraft:short_grass
setblock -20 225 15 minecraft:short_grass
setblock -14 225 15 minecraft:short_grass
setblock -10 225 15 minecraft:cornflower
fill -9 225 15 -8 225 15 minecraft:short_grass
setblock -3 225 15 minecraft:short_grass
setblock 3 225 15 minecraft:fern
setblock 4 225 15 minecraft:pink_petals[facing=west,flower_amount=4]
setblock 6 225 15 minecraft:pink_petals[facing=west,flower_amount=1]
setblock 7 225 15 minecraft:lily_of_the_valley
setblock 9 225 15 minecraft:tall_grass[half=lower]
setblock 18 225 15 minecraft:pink_petals[facing=west,flower_amount=3]
setblock 20 225 15 minecraft:tall_grass[half=lower]
fill 21 225 15 21 225 16 minecraft:short_grass
setblock 22 225 15 minecraft:dandelion
setblock -25 225 16 minecraft:allium
setblock -23 225 16 minecraft:pink_petals[facing=west,flower_amount=3]
setblock -22 225 16 minecraft:short_grass
setblock -16 225 16 minecraft:purple_candle[candles=3,lit=true]
setblock -14 225 16 minecraft:azure_bluet
setblock -11 225 16 minecraft:dandelion
setblock -9 225 16 minecraft:short_grass
setblock -5 225 16 minecraft:wildflowers[facing=north,flower_amount=2]
fill -2 225 16 -2 225 18 minecraft:short_grass
fill 2 225 16 4 225 16 minecraft:short_grass
setblock 5 225 16 minecraft:azure_bluet
fill 7 225 16 9 225 16 minecraft:short_grass
setblock 17 225 16 minecraft:azure_bluet
setblock 19 225 16 minecraft:short_grass
setblock 20 225 16 minecraft:wildflowers[facing=south,flower_amount=4]
fill 22 225 16 22 225 17 minecraft:short_grass
fill -24 225 17 -23 225 17 minecraft:short_grass
fill -20 225 17 -20 225 19 minecraft:short_grass
fill -13 225 17 -12 225 17 minecraft:short_grass
setblock -10 225 17 minecraft:pink_petals[facing=west,flower_amount=4]
setblock -9 225 17 minecraft:pink_petals[facing=north,flower_amount=2]
setblock -8 225 17 minecraft:short_grass
setblock -7 225 17 minecraft:allium
fill -6 225 17 -5 225 18 minecraft:short_grass
setblock -4 225 17 minecraft:pink_petals[facing=south,flower_amount=1]
setblock 3 225 17 minecraft:short_grass
setblock 4 225 17 minecraft:tall_grass[half=lower]
fill 8 225 17 8 225 19 minecraft:short_grass
setblock 9 225 17 minecraft:fern
setblock 11 225 17 minecraft:tall_grass[half=lower]
setblock 15 225 17 minecraft:fern
setblock 16 225 17 minecraft:short_grass
setblock 17 225 17 minecraft:pink_petals[facing=south,flower_amount=4]
setblock -24 225 18 minecraft:short_grass
setblock -22 225 18 minecraft:short_grass
setblock -14 225 18 minecraft:lily_of_the_valley
setblock -13 225 18 minecraft:short_grass
fill -11 225 18 -11 225 22 minecraft:short_grass
setblock -7 225 18 minecraft:short_grass
fill -4 225 18 -4 225 19 minecraft:short_grass
setblock 2 225 18 minecraft:short_grass
setblock 4 225 18 minecraft:short_grass
fill 11 225 18 11 225 20 minecraft:short_grass
setblock 12 225 18 minecraft:pink_petals[facing=west,flower_amount=3]
setblock 13 225 18 minecraft:pink_petals[facing=north,flower_amount=4]
fill 17 225 18 18 225 18 minecraft:short_grass
setblock 19 225 18 minecraft:tall_grass[half=lower]
setblock 20 225 18 minecraft:azure_bluet
setblock -23 225 19 minecraft:pink_petals[facing=east,flower_amount=4]
setblock -10 225 19 minecraft:short_grass
setblock -8 225 19 minecraft:tall_grass[half=lower]
setblock -6 225 19 minecraft:wildflowers[facing=south,flower_amount=1]
setblock -5 225 19 minecraft:tall_grass[half=lower]
setblock 3 225 19 minecraft:tall_grass[half=lower]
setblock 9 225 19 minecraft:pink_petals[facing=west,flower_amount=1]
setblock 10 225 19 minecraft:fern
setblock 12 225 19 minecraft:cornflower
fill 13 225 19 13 225 20 minecraft:short_grass
setblock 15 225 19 minecraft:short_grass
fill 21 225 19 22 225 19 minecraft:short_grass
fill -21 225 20 -21 225 22 minecraft:short_grass
setblock -19 225 20 minecraft:pink_petals[facing=east,flower_amount=1]
setblock -18 225 20 minecraft:short_grass
setblock -17 225 20 minecraft:wildflowers[facing=west,flower_amount=4]
fill -16 225 20 -15 225 20 minecraft:short_grass
fill -12 225 20 -12 225 22 minecraft:short_grass
fill -7 225 20 -5 225 20 minecraft:short_grass
setblock 3 225 20 minecraft:short_grass
setblock 9 225 20 minecraft:wildflowers[facing=north,flower_amount=3]
setblock 10 225 20 minecraft:wildflowers[facing=south,flower_amount=2]
fill 12 225 20 12 225 21 minecraft:short_grass
