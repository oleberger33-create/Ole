setblock -36 231 -25 minecraft:wildflowers[facing=west,flower_amount=3]
setblock -38 231 -24 minecraft:wildflowers[facing=west,flower_amount=2]
setblock -37 231 -24 minecraft:short_grass
fill -42 231 -23 -42 231 -22 minecraft:short_grass
setblock -36 231 -23 minecraft:short_grass
fill -43 231 -22 -43 231 -21 minecraft:short_grass
setblock -38 231 -22 minecraft:tall_grass[half=lower]
fill -45 231 -21 -45 231 -20 minecraft:short_grass
setblock -44 231 -21 minecraft:tall_grass[half=lower]
fill -38 231 -21 -36 231 -21 minecraft:short_grass
setblock -35 231 -21 minecraft:wildflowers[facing=east,flower_amount=2]
setblock -41 231 -20 minecraft:wildflowers[facing=north,flower_amount=2]
fill -40 231 -20 -39 231 -20 minecraft:short_grass
setblock -38 231 -20 minecraft:fern
setblock -37 231 -20 minecraft:pink_petals[facing=west,flower_amount=4]
setblock -36 231 -20 minecraft:short_grass
setblock -44 231 -19 minecraft:pink_petals[facing=south,flower_amount=2]
setblock -43 231 -19 minecraft:pink_petals[facing=north,flower_amount=4]
fill -42 231 -19 -42 231 -18 minecraft:short_grass
setblock -41 231 -19 minecraft:oxeye_daisy
setblock -37 231 -19 minecraft:short_grass
setblock -41 231 -18 minecraft:short_grass
setblock -38 231 -18 minecraft:short_grass
fill -42 228 -28 -42 229 -28 minecraft:vine[south=true]
fill -40 227 -28 -40 229 -28 minecraft:vine[south=true]
fill -45 228 -24 -45 229 -24 minecraft:vine[east=true]
fill -34 225 -20 -34 229 -20 minecraft:vine[west=true]
fill -45 224 -19 -45 229 -19 minecraft:vine[east=true]
setblock 2 228 -25 minecraft:candle[candles=1,lit=true]
setblock 6 228 -21 minecraft:candle[candles=4,lit=true]
setblock -7 228 -20 minecraft:purple_candle[candles=1,lit=true]
setblock -6 228 -15 minecraft:white_candle[candles=3,lit=true]
setblock 16 228 -3 minecraft:lantern[hanging=true]
setblock 22 228 -3 minecraft:lantern[hanging=true]
setblock 16 228 3 minecraft:lantern[hanging=true]
setblock 22 228 3 minecraft:lantern[hanging=true]
setblock 43 228 25 minecraft:tall_grass[half=upper]
setblock 34 227 -34 minecraft:lantern[hanging=true]
setblock 40 227 -34 minecraft:lantern[hanging=true]
setblock 32 227 -29 minecraft:lantern[hanging=true]
setblock 42 227 -29 minecraft:lantern[hanging=true]
setblock -42 227 -27 minecraft:hanging_roots
setblock 34 227 -25 minecraft:lantern[hanging=false]
setblock 40 227 -25 minecraft:lantern[hanging=false]
setblock 35 227 -17 minecraft:lantern[hanging=false]
setblock 39 227 -17 minecraft:lantern[hanging=false]
setblock 31 227 -12 minecraft:lantern[hanging=false]
setblock 37 227 -10 minecraft:lantern[hanging=true]
setblock 31 227 -8 minecraft:lantern[hanging=false]
setblock -5 227 -5 minecraft:lantern[hanging=false]
setblock 5 227 -5 minecraft:lantern[hanging=false]
setblock -34 227 -3 minecraft:lantern[hanging=false]
setblock -19 227 -2 minecraft:lantern[hanging=false]
setblock 17 227 -2 minecraft:candle[candles=2,lit=true]
setblock 18 227 -2 minecraft:candle[candles=3,lit=true]
setblock 20 227 -2 minecraft:candle[candles=1,lit=true]
setblock 17 227 1 minecraft:candle[candles=2,lit=true]
setblock -25 227 2 minecraft:lantern[hanging=false]
setblock -12 227 2 minecraft:lantern[hanging=false]
setblock 10 227 2 minecraft:lantern[hanging=false]
setblock 17 227 2 minecraft:candle[candles=3,lit=true]
setblock 19 227 2 minecraft:candle[candles=3,lit=true]
setblock 21 227 2 minecraft:candle[candles=2,lit=true]
setblock -34 227 3 minecraft:lantern[hanging=false]
setblock -5 227 5 minecraft:lantern[hanging=false]
setblock 5 227 5 minecraft:lantern[hanging=false]
setblock -10 227 13 minecraft:lantern[hanging=false]
setblock -2 227 13 minecraft:lantern[hanging=false]
setblock -17 227 17 minecraft:soul_lantern[hanging=true]
setblock 2 227 20 minecraft:lantern[hanging=false]
setblock 41 227 21 minecraft:short_grass
setblock 39 227 22 minecraft:short_grass
fill 40 227 22 41 227 22 minecraft:fern
fill 42 227 22 43 227 22 minecraft:short_grass
setblock 37 227 23 minecraft:short_grass
setblock 40 227 23 minecraft:short_grass
fill 42 227 23 42 227 25 minecraft:short_grass
setblock 43 227 23 minecraft:cornflower
setblock 44 227 24 minecraft:short_grass
setblock -2 227 25 minecraft:lantern[hanging=false]
fill 37 227 25 38 227 25 minecraft:short_grass
setblock 43 227 25 minecraft:tall_grass[half=lower]
setblock 38 227 26 minecraft:short_grass
setblock 37 227 27 minecraft:short_grass
fill 39 227 27 41 227 27 minecraft:short_grass
setblock 38 227 28 minecraft:pink_petals[facing=north,flower_amount=4]
setblock 40 227 28 minecraft:short_grass
setblock 40 227 29 minecraft:dandelion
setblock 42 227 29 minecraft:oxeye_daisy
setblock -1 227 31 minecraft:lantern[hanging=true]
setblock 1 227 31 minecraft:lantern[hanging=true]
setblock 40 226 -37 minecraft:tall_grass[half=upper]
setblock 42 226 -37 minecraft:tall_grass[half=upper]
setblock 44 226 -36 minecraft:tall_grass[half=upper]
setblock 32 226 -34 minecraft:tall_grass[half=upper]
setblock 41 226 -33 minecraft:tall_grass[half=upper]
setblock 45 226 -33 minecraft:tall_grass[half=upper]
setblock 44 226 -31 minecraft:tall_grass[half=upper]
setblock -6 226 -29 minecraft:tall_grass[half=upper]
setblock -38 226 -27 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock -37 226 -26 minecraft:hanging_roots
setblock 11 226 -26 minecraft:tall_grass[half=upper]
setblock 8 226 -25 minecraft:tall_grass[half=upper]
setblock -10 226 -24 minecraft:tall_grass[half=upper]
setblock -36 226 -23 minecraft:hanging_roots
setblock -21 226 -23 minecraft:tall_grass[half=upper]
setblock -35 226 -21 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock -11 226 -21 minecraft:tall_grass[half=upper]
setblock -13 226 -19 minecraft:tall_grass[half=upper]
setblock -11 226 -19 minecraft:tall_grass[half=upper]
setblock -1 226 -19 minecraft:purple_candle[candles=4,lit=true]
setblock 1 226 -19 minecraft:purple_candle[candles=4,lit=true]
setblock 27 226 -18 minecraft:tall_grass[half=upper]
setblock -26 226 -17 minecraft:tall_grass[half=upper]
setblock -1 226 -17 minecraft:purple_candle[candles=4,lit=true]
setblock 1 226 -17 minecraft:purple_candle[candles=4,lit=true]
setblock 13 226 -17 minecraft:tall_grass[half=upper]
setblock 26 226 -17 minecraft:tall_grass[half=upper]
fill -21 226 -15 -20 226 -15 minecraft:tall_grass[half=upper]
setblock -28 226 -14 minecraft:tall_grass[half=upper]
setblock -25 226 -14 minecraft:tall_grass[half=upper]
setblock -27 226 -13 minecraft:tall_grass[half=upper]
setblock 12 226 -13 minecraft:tall_grass[half=upper]
setblock 11 226 -11 minecraft:tall_grass[half=upper]
setblock -21 226 -10 minecraft:tall_grass[half=upper]
setblock -11 226 -8 minecraft:tall_grass[half=upper]
setblock 14 226 -8 minecraft:tall_grass[half=upper]
setblock 28 226 -7 minecraft:tall_grass[half=upper]
setblock -25 226 -6 minecraft:tall_grass[half=upper]
setblock -21 226 -6 minecraft:tall_grass[half=upper]
setblock 26 226 -6 minecraft:tall_grass[half=upper]
setblock -14 226 -5 minecraft:tall_grass[half=upper]
setblock -6 226 -5 minecraft:tall_grass[half=upper]
fill 11 226 -5 12 226 -5 minecraft:tall_grass[half=upper]
setblock -25 226 -3 minecraft:tall_grass[half=upper]
setblock 30 226 -3 minecraft:tall_grass[half=upper]
setblock -15 226 -2 minecraft:tall_grass[half=upper]
fill 28 226 -2 29 226 -2 minecraft:tall_grass[half=upper]
setblock 26 226 1 minecraft:tall_grass[half=upper]
setblock -8 226 2 minecraft:tall_grass[half=upper]
fill -20 226 3 -19 226 3 minecraft:tall_grass[half=upper]
setblock 27 226 3 minecraft:tall_grass[half=upper]
setblock -26 226 4 minecraft:tall_grass[half=upper]
setblock -24 226 4 minecraft:tall_grass[half=upper]
setblock -21 226 5 minecraft:tall_grass[half=upper]
setblock 29 226 6 minecraft:tall_grass[half=upper]
setblock -20 226 7 minecraft:tall_grass[half=upper]
setblock -11 226 8 minecraft:tall_grass[half=upper]
fill -3 226 8 -3 226 9 minecraft:tall_grass[half=upper]
setblock 21 226 8 minecraft:tall_grass[half=upper]
setblock 2 226 9 minecraft:tall_grass[half=upper]
setblock 9 226 9 minecraft:tall_grass[half=upper]
setblock 6 226 10 minecraft:tall_grass[half=upper]
setblock -15 226 11 minecraft:tall_grass[half=upper]
setblock 2 226 11 minecraft:tall_grass[half=upper]
fill -9 226 12 -9 226 13 minecraft:tall_grass[half=upper]
setblock 6 226 13 minecraft:tall_grass[half=upper]
setblock 16 226 13 minecraft:tall_grass[half=upper]
setblock 9 226 15 minecraft:tall_grass[half=upper]
setblock 20 226 15 minecraft:tall_grass[half=upper]
setblock 4 226 17 minecraft:tall_grass[half=upper]
setblock 11 226 17 minecraft:tall_grass[half=upper]
setblock 19 226 18 minecraft:tall_grass[half=upper]
setblock -8 226 19 minecraft:tall_grass[half=upper]
setblock -5 226 19 minecraft:tall_grass[half=upper]
setblock 3 226 19 minecraft:tall_grass[half=upper]
setblock -10 226 21 minecraft:tall_grass[half=upper]
setblock 5 226 21 minecraft:tall_grass[half=upper]
setblock 7 226 21 minecraft:tall_grass[half=upper]
setblock -2 226 22 minecraft:tall_grass[half=upper]
setblock 15 226 22 minecraft:tall_grass[half=upper]
setblock 19 226 22 minecraft:tall_grass[half=upper]
setblock -20 226 23 minecraft:tall_grass[half=upper]
setblock 3 226 23 minecraft:tall_grass[half=upper]
setblock -11 226 24 minecraft:tall_grass[half=upper]
setblock -9 226 24 minecraft:tall_grass[half=upper]
setblock -3 226 24 minecraft:tall_grass[half=upper]
setblock 10 226 24 minecraft:tall_grass[half=upper]
setblock 17 226 25 minecraft:tall_grass[half=upper]
setblock -14 226 26 minecraft:tall_grass[half=upper]
setblock -15 226 27 minecraft:tall_grass[half=upper]
setblock -10 226 29 minecraft:tall_grass[half=upper]
setblock -3 226 30 minecraft:tall_grass[half=upper]
setblock -6 226 31 minecraft:tall_grass[half=upper]
setblock 35 225 -38 minecraft:short_grass
setblock 36 225 -38 minecraft:fern
setblock 33 225 -37 minecraft:short_grass
setblock 35 225 -37 minecraft:fern
setblock 40 225 -37 minecraft:tall_grass[half=lower]
setblock 42 225 -37 minecraft:tall_grass[half=lower]
fill 31 225 -36 31 225 -34 minecraft:short_grass
setblock 42 225 -36 minecraft:short_grass
setblock 44 225 -36 minecraft:tall_grass[half=lower]
setblock 30 225 -35 minecraft:short_grass
setblock 32 225 -35 minecraft:short_grass
setblock 38 225 -35 minecraft:pink_petals[facing=west,flower_amount=4]
fill 43 225 -35 44 225 -35 minecraft:short_grass
setblock 29 225 -34 minecraft:poppy
setblock 30 225 -34 minecraft:fern
setblock 32 225 -34 minecraft:tall_grass[half=lower]
setblock 37 225 -34 minecraft:short_grass
setblock 43 225 -34 minecraft:cornflower
setblock 29 225 -33 minecraft:short_grass
fill 32 225 -33 33 225 -33 minecraft:short_grass
setblock 40 225 -33 minecraft:wildflowers[facing=south,flower_amount=2]
setblock 41 225 -33 minecraft:tall_grass[half=lower]
setblock 42 225 -33 minecraft:short_grass
setblock 44 225 -33 minecraft:short_grass
setblock 45 225 -33 minecraft:tall_grass[half=lower]
setblock 31 225 -32 minecraft:short_grass
setblock 33 225 -32 minecraft:wildflowers[facing=south,flower_amount=2]
setblock 43 225 -32 minecraft:short_grass
fill 45 225 -32 45 225 -30 minecraft:short_grass
fill 29 225 -31 29 225 -30 minecraft:short_grass
setblock 31 225 -31 minecraft:oxeye_daisy
setblock 32 225 -31 minecraft:short_grass
setblock 43 225 -31 minecraft:wildflowers[facing=east,flower_amount=1]
setblock 44 225 -31 minecraft:tall_grass[half=lower]
setblock -5 225 -30 minecraft:short_grass
setblock -4 225 -30 minecraft:allium
