setblock 4 191 0 minecraft:cave_vines[age=25,berries=true]
fill -11 189 2 -11 191 2 minecraft:cave_vines_plant[berries=false]
setblock 0 191 3 minecraft:cave_vines_plant[berries=true]
setblock 0 190 3 minecraft:cave_vines[age=25,berries=true]
setblock -11 188 2 minecraft:cave_vines[age=25,berries=false]
fill -2 188 5 -1 188 5 minecraft:glow_lichen[up=true]
fill -1 224 -3 1 224 -2 minecraft:water
fill -2 224 -2 -2 224 2 minecraft:water
fill 2 224 -2 2 224 2 minecraft:water
fill -3 224 -1 -3 224 1 minecraft:water
fill 3 224 -1 3 224 1 minecraft:water
fill -1 224 2 1 224 3 minecraft:water
setblock 3 225 -27 minecraft:light[level=12]
setblock 12 225 -24 minecraft:light[level=12]
setblock -23 225 -21 minecraft:light[level=12]
setblock -10 225 -21 minecraft:light[level=12]
setblock 18 225 -18 minecraft:light[level=12]
setblock -17 225 -15 minecraft:light[level=12]
setblock -29 225 -14 minecraft:light[level=12]
setblock 28 225 9 minecraft:light[level=12]
setblock 19 225 12 minecraft:light[level=12]
setblock -26 225 14 minecraft:light[level=12]
setblock 10 225 15 minecraft:light[level=12]
setblock -5 226 -30 minecraft:light[level=12]
setblock -16 226 -26 minecraft:light[level=12]
setblock 9 226 -15 minecraft:light[level=12]
setblock -21 226 21 minecraft:light[level=12]
setblock 13 226 24 minecraft:light[level=12]
setblock -15 226 26 minecraft:light[level=12]
setblock 39 227 23 minecraft:light[level=12]
setblock -42 231 -26 minecraft:light[level=12]
setblock -38 232 -18 minecraft:light[level=12]
