fill -17 222 -6 -17 223 -5 minecraft:dirt
fill -12 222 -6 -12 223 -2 minecraft:dirt
fill -9 222 -6 -8 223 -6 minecraft:dirt
fill -6 222 -6 -6 223 -6 minecraft:dirt
fill -3 222 -6 -2 223 -6 minecraft:dirt
fill 1 222 -6 4 223 -6 minecraft:dirt
setblock 5 222 -6 minecraft:rooted_dirt
fill 7 222 -6 7 222 -5 minecraft:rooted_dirt
fill 8 222 -6 9 223 -6 minecraft:dirt
fill 12 222 -6 12 223 -6 minecraft:dirt
fill 20 222 -6 20 222 -5 minecraft:dirt
fill 22 222 -6 22 222 -5 minecraft:dirt
fill 29 222 -6 29 223 -6 minecraft:dirt
setblock -30 222 -5 minecraft:rooted_dirt
fill -29 222 -5 -28 223 -5 minecraft:dirt
setblock -27 222 -5 minecraft:rooted_dirt
fill -23 222 -5 -21 223 -5 minecraft:dirt
fill -20 222 -5 -19 222 -5 minecraft:rooted_dirt
fill -13 222 -5 -13 222 -4 minecraft:rooted_dirt
fill -11 222 -5 -10 223 -5 minecraft:dirt
fill -2 222 -5 -2 223 -5 minecraft:dirt
fill 2 222 -5 5 223 -5 minecraft:dirt
fill 8 222 -5 8 223 -5 minecraft:dirt
setblock 9 222 -5 minecraft:rooted_dirt
fill 10 222 -5 10 223 -4 minecraft:dirt
setblock 17 222 -5 minecraft:rooted_dirt
fill 24 222 -5 24 222 -4 minecraft:dirt
fill 27 222 -5 27 223 -5 minecraft:dirt
setblock -31 222 -4 minecraft:rooted_dirt
fill -30 222 -4 -30 223 -2 minecraft:dirt
fill -29 222 -4 -28 222 -4 minecraft:rooted_dirt
fill -27 222 -4 -27 223 -2 minecraft:dirt
setblock -26 222 -4 minecraft:rooted_dirt
fill -23 222 -4 -23 222 -2 minecraft:rooted_dirt
fill -22 222 -4 -20 223 -3 minecraft:dirt
fill -19 222 -4 -19 222 -2 minecraft:rooted_dirt
fill -11 222 -4 -11 223 -3 minecraft:dirt
setblock -10 222 -4 minecraft:rooted_dirt
fill -7 222 -4 -7 223 -4 minecraft:dirt
fill -4 222 -4 -4 223 1 minecraft:dirt
fill 2 222 -4 2 223 -3 minecraft:dirt
setblock 3 222 -4 minecraft:rooted_dirt
fill 4 222 -4 5 223 -2 minecraft:dirt
setblock 6 222 -4 minecraft:rooted_dirt
fill 7 222 -4 7 223 -2 minecraft:dirt
setblock 8 222 -4 minecraft:rooted_dirt
fill 9 222 -4 9 223 -2 minecraft:dirt
fill 12 222 -4 12 223 -3 minecraft:dirt
setblock 15 222 -4 minecraft:rooted_dirt
fill 16 222 -4 17 222 -4 minecraft:dirt
setblock 18 222 -4 minecraft:rooted_dirt
setblock 20 222 -4 minecraft:rooted_dirt
fill 22 222 -4 22 222 -3 minecraft:rooted_dirt
fill 25 222 -4 25 222 -2 minecraft:dirt
fill 29 222 -4 29 223 -2 minecraft:dirt
fill 31 222 -4 31 223 -1 minecraft:dirt
fill -31 222 -3 -31 223 -3 minecraft:dirt
fill -29 222 -3 -28 223 -2 minecraft:dirt
fill -26 222 -3 -25 223 -2 minecraft:dirt
setblock -24 222 -3 minecraft:rooted_dirt
fill -15 222 -3 -15 223 -3 minecraft:dirt
fill -13 222 -3 -13 223 -3 minecraft:dirt
fill -10 222 -3 -10 223 -2 minecraft:dirt
fill -2 222 -3 -2 223 -3 minecraft:dirt
setblock 1 222 -3 minecraft:dirt
fill 3 222 -3 3 223 -2 minecraft:dirt
fill 6 222 -3 6 223 0 minecraft:dirt
fill 8 222 -3 8 223 -3 minecraft:dirt
setblock 10 222 -3 minecraft:rooted_dirt
fill 15 222 -3 16 222 -3 minecraft:dirt
setblock 17 222 -3 minecraft:rooted_dirt
setblock 18 222 -3 minecraft:dirt
fill 20 222 -3 20 222 -2 minecraft:dirt
setblock -31 222 -2 minecraft:rooted_dirt
fill -24 222 -2 -24 223 -2 minecraft:dirt
fill -22 222 -2 -22 223 -2 minecraft:dirt
fill -21 222 -2 -20 222 -2 minecraft:rooted_dirt
fill -17 222 -2 -17 223 -2 minecraft:dirt
fill -14 222 -2 -14 223 -2 minecraft:dirt
fill -6 222 -2 -5 223 -2 minecraft:dirt
fill -3 222 -2 -3 222 -1 minecraft:dirt
setblock 0 222 -2 minecraft:dirt
setblock 8 222 -2 minecraft:rooted_dirt
fill 10 222 -2 10 223 1 minecraft:dirt
fill 16 222 -2 17 222 -1 minecraft:dirt
fill 18 222 -2 19 222 -2 minecraft:rooted_dirt
fill 22 222 -2 24 222 -1 minecraft:dirt
fill 28 222 -2 28 223 0 minecraft:dirt
setblock 30 222 -2 minecraft:rooted_dirt
fill -31 222 -1 -31 223 -1 minecraft:dirt
fill -29 222 -1 -29 223 -1 minecraft:dirt
setblock -22 222 -1 minecraft:rooted_dirt
fill -21 222 -1 -18 223 1 minecraft:dirt
fill -16 222 -1 -15 223 0 minecraft:dirt
fill -8 222 -1 -8 222 0 minecraft:rooted_dirt
fill -7 222 -1 -7 223 0 minecraft:dirt
fill -6 222 -1 -6 222 0 minecraft:rooted_dirt
fill -5 222 -1 -5 223 2 minecraft:dirt
fill -2 222 -1 -2 222 2 minecraft:rooted_dirt
fill -1 222 -1 -1 222 2 minecraft:dirt
setblock 0 222 -1 minecraft:rooted_dirt
fill 1 222 -1 2 222 -1 minecraft:dirt
fill 7 222 -1 7 222 0 minecraft:rooted_dirt
fill 8 222 -1 8 223 0 minecraft:dirt
setblock 9 222 -1 minecraft:rooted_dirt
fill 11 222 -1 11 223 -1 minecraft:dirt
fill 14 222 -1 14 222 0 minecraft:dirt
fill 18 222 -1 19 222 1 minecraft:dirt
setblock 20 222 -1 minecraft:rooted_dirt
fill 25 222 -1 25 222 1 minecraft:rooted_dirt
fill 26 222 -1 27 223 -1 minecraft:dirt
fill 29 222 -1 29 222 0 minecraft:rooted_dirt
fill 30 222 -1 30 223 4 minecraft:dirt
fill -30 222 0 -30 223 0 minecraft:dirt
fill -27 222 0 -27 223 1 minecraft:dirt
fill -13 222 0 -13 223 2 minecraft:dirt
fill -11 222 0 -11 223 2 minecraft:dirt
setblock -3 222 0 minecraft:rooted_dirt
fill 0 222 0 1 222 0 minecraft:dirt
fill 9 222 0 9 223 2 minecraft:dirt
setblock 11 222 0 minecraft:rooted_dirt
fill 20 222 0 20 222 1 minecraft:dirt
setblock 22 222 0 minecraft:rooted_dirt
fill 23 222 0 23 222 1 minecraft:dirt
setblock 24 222 0 minecraft:rooted_dirt
setblock 26 222 0 minecraft:rooted_dirt
fill 27 222 0 27 223 1 minecraft:dirt
fill -29 222 1 -28 223 1 minecraft:dirt
fill -14 222 1 -14 223 4 minecraft:dirt
fill -12 222 1 -12 223 1 minecraft:dirt
setblock -7 222 1 minecraft:rooted_dirt
fill -6 222 1 -6 223 2 minecraft:dirt
fill -3 222 1 -3 222 2 minecraft:dirt
setblock 0 222 1 minecraft:rooted_dirt
fill 1 222 1 1 222 2 minecraft:dirt
fill 7 222 1 7 223 1 minecraft:dirt
setblock 8 222 1 minecraft:rooted_dirt
setblock 13 222 1 minecraft:dirt
fill 15 222 1 15 222 2 minecraft:dirt
fill 16 222 1 16 222 2 minecraft:rooted_dirt
fill 17 222 1 17 222 5 minecraft:dirt
fill 22 222 1 22 222 6 minecraft:dirt
fill 24 222 1 24 222 2 minecraft:dirt
fill 26 222 1 26 223 3 minecraft:dirt
setblock 28 222 1 minecraft:rooted_dirt
fill 29 222 1 29 223 1 minecraft:dirt
fill -28 222 2 -28 223 2 minecraft:dirt
fill -25 222 2 -25 223 2 minecraft:dirt
fill -22 222 2 -20 223 2 minecraft:dirt
fill -19 222 2 -18 222 2 minecraft:rooted_dirt
fill -17 222 2 -15 223 5 minecraft:dirt
setblock 0 222 2 minecraft:dirt
setblock 2 222 2 minecraft:dirt
fill 5 222 2 5 223 3 minecraft:dirt
fill 8 222 2 8 223 2 minecraft:dirt
fill 11 222 2 11 223 3 minecraft:dirt
fill 14 222 2 14 222 5 minecraft:dirt
fill 18 222 2 18 222 5 minecraft:dirt
setblock 23 222 2 minecraft:rooted_dirt
setblock 25 222 2 minecraft:dirt
setblock 27 222 2 minecraft:rooted_dirt
fill 28 222 2 28 223 2 minecraft:dirt
setblock 29 222 2 minecraft:rooted_dirt
fill -29 222 3 -29 223 3 minecraft:dirt
fill -27 222 3 -26 223 3 minecraft:dirt
fill -23 222 3 -22 223 5 minecraft:dirt
setblock -21 222 3 minecraft:rooted_dirt
fill -20 222 3 -20 223 3 minecraft:dirt
fill -19 222 3 -19 222 4 minecraft:rooted_dirt
fill -18 222 3 -18 223 4 minecraft:dirt
fill -13 222 3 -13 222 4 minecraft:rooted_dirt
fill -4 222 3 -4 223 3 minecraft:dirt
fill 4 222 3 4 223 6 minecraft:dirt
setblock 15 222 3 minecraft:rooted_dirt
fill 16 222 3 16 222 6 minecraft:dirt
setblock 20 222 3 minecraft:dirt
fill 23 222 3 23 222 5 minecraft:dirt
fill 24 222 3 25 222 3 minecraft:rooted_dirt
fill 27 222 3 27 223 3 minecraft:dirt
fill 28 222 3 28 222 4 minecraft:rooted_dirt
fill 29 222 3 29 223 6 minecraft:dirt
fill -28 222 4 -28 223 4 minecraft:dirt
fill -26 222 4 -26 223 5 minecraft:dirt
fill -24 222 4 -24 223 4 minecraft:dirt
fill -21 222 4 -21 223 6 minecraft:dirt
fill -20 222 4 -20 222 5 minecraft:rooted_dirt
fill -12 222 4 -12 223 8 minecraft:dirt
fill -7 222 4 -7 223 4 minecraft:dirt
fill -5 222 4 -5 223 4 minecraft:dirt
fill -2 222 4 -2 223 4 minecraft:dirt
fill 10 222 4 10 223 4 minecraft:dirt
fill 12 222 4 12 223 6 minecraft:dirt
fill 15 222 4 15 222 5 minecraft:dirt
fill 24 222 4 24 222 7 minecraft:dirt
fill 25 222 4 27 222 4 minecraft:rooted_dirt
fill -29 222 5 -29 223 5 minecraft:dirt
fill -25 222 5 -25 223 10 minecraft:dirt
setblock -24 222 5 minecraft:rooted_dirt
fill -19 222 5 -19 223 7 minecraft:dirt
setblock -18 222 5 minecraft:rooted_dirt
setblock -14 222 5 minecraft:rooted_dirt
fill -13 222 5 -13 223 8 minecraft:dirt
fill -11 222 5 -10 223 5 minecraft:dirt
fill 1 222 5 1 223 8 minecraft:dirt
fill 3 222 5 3 223 5 minecraft:dirt
fill 7 222 5 7 223 5 minecraft:dirt
setblock 13 222 5 minecraft:dirt
fill 19 222 5 20 222 5 minecraft:dirt
fill 25 222 5 28 222 5 minecraft:dirt
fill -24 222 6 -24 223 11 minecraft:dirt
setblock -23 222 6 minecraft:rooted_dirt
fill -22 222 6 -22 223 8 minecraft:dirt
fill -20 222 6 -20 223 9 minecraft:dirt
fill -18 222 6 -16 223 6 minecraft:dirt
setblock -15 222 6 minecraft:rooted_dirt
fill -14 222 6 -14 223 7 minecraft:dirt
fill -11 222 6 -11 223 8 minecraft:dirt
fill -5 222 6 -4 223 8 minecraft:dirt
fill -1 222 6 0 223 8 minecraft:dirt
fill 2 222 6 3 222 6 minecraft:rooted_dirt
