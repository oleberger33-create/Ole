fill -2 222 -29 -2 223 -29 minecraft:dirt
fill -1 222 -29 -1 222 -27 minecraft:rooted_dirt
fill 0 222 -29 0 223 -29 minecraft:dirt
setblock 1 222 -29 minecraft:rooted_dirt
fill 2 222 -29 2 223 -29 minecraft:dirt
fill 28 222 -29 29 223 -29 minecraft:dirt
fill 36 222 -29 36 223 -25 minecraft:dirt
fill 41 222 -29 41 223 -29 minecraft:dirt
fill 43 222 -29 45 222 -29 minecraft:rooted_dirt
fill -13 222 -28 -11 223 -28 minecraft:dirt
fill -8 222 -28 -7 223 -27 minecraft:dirt
fill -3 222 -28 -3 223 -28 minecraft:dirt
setblock 0 222 -28 minecraft:rooted_dirt
fill 1 222 -28 1 222 -27 minecraft:dirt
fill 9 222 -28 9 223 -28 minecraft:dirt
setblock 10 222 -28 minecraft:rooted_dirt
setblock 28 222 -28 minecraft:rooted_dirt
fill 29 222 -28 29 223 -28 minecraft:dirt
fill 31 222 -28 31 223 -28 minecraft:dirt
setblock 35 222 -28 minecraft:rooted_dirt
fill 37 222 -28 37 223 -26 minecraft:dirt
fill 40 222 -28 40 223 -28 minecraft:dirt
setblock 43 222 -28 minecraft:rooted_dirt
fill 44 222 -28 44 223 -25 minecraft:dirt
setblock 45 222 -28 minecraft:rooted_dirt
fill -15 222 -27 -12 223 -27 minecraft:dirt
setblock -11 222 -27 minecraft:rooted_dirt
fill -5 222 -27 -4 222 -25 minecraft:dirt
setblock 0 222 -27 minecraft:dirt
fill 3 222 -27 3 223 -27 minecraft:dirt
fill 5 222 -27 5 223 -27 minecraft:dirt
fill 10 222 -27 12 223 -27 minecraft:dirt
fill 28 222 -27 28 223 -26 minecraft:dirt
setblock 29 222 -27 minecraft:rooted_dirt
fill 30 222 -27 30 223 -27 minecraft:dirt
fill 33 222 -27 33 223 -26 minecraft:dirt
fill 35 222 -27 35 223 -27 minecraft:dirt
fill 41 222 -27 41 223 -27 minecraft:dirt
fill 43 222 -27 43 223 -26 minecraft:dirt
fill 45 222 -27 45 223 -24 minecraft:dirt
fill -13 222 -26 -12 223 -26 minecraft:dirt
setblock -3 222 -26 minecraft:dirt
fill 7 222 -26 7 223 -26 minecraft:dirt
setblock 10 222 -26 minecraft:rooted_dirt
fill 11 222 -26 12 223 -24 minecraft:dirt
setblock 13 222 -26 minecraft:rooted_dirt
fill 14 222 -26 14 223 -26 minecraft:dirt
fill 29 222 -26 29 223 -26 minecraft:dirt
fill 31 222 -26 31 223 -26 minecraft:dirt
setblock 35 222 -26 minecraft:rooted_dirt
setblock -18 222 -25 minecraft:rooted_dirt
fill -17 222 -25 -17 223 -24 minecraft:dirt
fill -15 222 -25 -14 223 -25 minecraft:dirt
fill -12 222 -25 -12 223 -24 minecraft:dirt
fill -10 222 -25 -10 223 -25 minecraft:dirt
fill -8 222 -25 -6 222 -25 minecraft:dirt
setblock -3 222 -25 minecraft:rooted_dirt
fill 1 222 -25 1 222 -23 minecraft:dirt
fill 4 222 -25 4 222 -24 minecraft:dirt
fill 10 222 -25 10 223 -22 minecraft:dirt
fill 13 222 -25 13 223 -25 minecraft:dirt
fill 14 222 -25 15 222 -25 minecraft:rooted_dirt
fill 16 222 -25 16 223 -25 minecraft:dirt
setblock 29 222 -25 minecraft:rooted_dirt
fill 32 222 -25 32 223 -24 minecraft:dirt
fill 35 222 -25 35 223 -24 minecraft:dirt
setblock 37 222 -25 minecraft:rooted_dirt
setblock 43 222 -25 minecraft:rooted_dirt
fill -41 222 -24 -41 226 -24 minecraft:stone
fill -40 222 -24 -40 226 -24 minecraft:tuff
fill -20 222 -24 -18 223 -23 minecraft:dirt
fill -11 222 -24 -11 223 -24 minecraft:dirt
fill -9 222 -24 -8 223 -23 minecraft:dirt
fill -7 222 -24 -6 222 -24 minecraft:rooted_dirt
fill -5 222 -24 -5 222 -22 minecraft:dirt
setblock -4 222 -24 minecraft:rooted_dirt
fill -3 222 -24 -3 222 -22 minecraft:dirt
fill 3 222 -24 3 222 -23 minecraft:dirt
setblock 5 222 -24 minecraft:dirt
fill 13 222 -24 13 222 -22 minecraft:rooted_dirt
fill 14 222 -24 15 223 -22 minecraft:dirt
fill 16 222 -24 16 222 -23 minecraft:rooted_dirt
fill 17 222 -24 18 223 -22 minecraft:dirt
fill 30 222 -24 31 223 -24 minecraft:dirt
setblock 34 222 -24 minecraft:rooted_dirt
setblock 36 222 -24 minecraft:rooted_dirt
fill 37 222 -24 38 223 -24 minecraft:dirt
fill 41 222 -24 43 223 -24 minecraft:dirt
fill 44 222 -24 44 222 -23 minecraft:rooted_dirt
fill -42 222 -23 -42 226 -23 minecraft:stone
fill -39 222 -23 -39 226 -23 minecraft:tuff
setblock -21 222 -23 minecraft:rooted_dirt
fill -7 222 -23 -7 222 -22 minecraft:rooted_dirt
fill -6 222 -23 -6 222 -22 minecraft:dirt
setblock -4 222 -23 minecraft:dirt
setblock -1 222 -23 minecraft:dirt
fill 4 222 -23 5 222 -23 minecraft:rooted_dirt
fill 9 222 -23 9 223 -23 minecraft:dirt
fill 11 222 -23 11 223 -23 minecraft:dirt
setblock 12 222 -23 minecraft:rooted_dirt
fill 19 222 -23 20 223 -21 minecraft:dirt
fill 34 222 -23 34 223 -21 minecraft:dirt
setblock 35 222 -23 minecraft:rooted_dirt
fill 36 222 -23 36 223 -22 minecraft:dirt
setblock 37 222 -23 minecraft:rooted_dirt
fill 40 222 -23 40 223 -22 minecraft:dirt
fill 43 222 -23 43 223 -22 minecraft:dirt
fill -39 222 -22 -38 223 -22 minecraft:cobblestone
fill -22 222 -22 -20 223 -21 minecraft:dirt
fill -19 222 -22 -18 222 -22 minecraft:rooted_dirt
fill -17 222 -22 -17 223 -22 minecraft:dirt
fill -12 222 -22 -10 223 -22 minecraft:dirt
fill -9 222 -22 -9 222 -21 minecraft:rooted_dirt
fill -8 222 -22 -8 222 -21 minecraft:dirt
fill 0 222 -22 0 222 -12 minecraft:dirt
setblock 7 222 -22 minecraft:dirt
setblock 11 222 -22 minecraft:rooted_dirt
fill 12 222 -22 12 223 -21 minecraft:dirt
fill 16 222 -22 16 223 -22 minecraft:dirt
fill 21 222 -22 22 223 -22 minecraft:dirt
fill 32 222 -22 32 223 -22 minecraft:dirt
setblock 33 222 -22 minecraft:rooted_dirt
fill 35 222 -22 35 223 -20 minecraft:dirt
fill 37 222 -22 39 223 -20 minecraft:dirt
setblock -42 222 -21 minecraft:andesite
fill -41 222 -21 -41 225 -21 minecraft:cobblestone
fill -38 222 -21 -37 222 -21 minecraft:cobblestone
fill -19 222 -21 -18 223 -19 minecraft:dirt
fill -15 222 -21 -12 223 -21 minecraft:dirt
setblock -11 222 -21 minecraft:rooted_dirt
fill -10 222 -21 -10 223 -20 minecraft:dirt
fill -7 222 -21 -7 222 -16 minecraft:dirt
fill -1 222 -21 -1 222 -17 minecraft:dirt
fill 1 222 -21 2 222 -21 minecraft:dirt
fill 4 222 -21 6 222 -21 minecraft:dirt
fill 11 222 -21 11 223 -21 minecraft:dirt
fill 13 222 -21 14 223 -19 minecraft:dirt
fill 17 222 -21 17 223 -21 minecraft:dirt
fill 21 222 -21 21 223 -18 minecraft:dirt
fill 23 222 -21 23 223 -21 minecraft:dirt
fill 33 222 -21 33 223 -21 minecraft:dirt
setblock 36 222 -21 minecraft:rooted_dirt
fill 42 222 -21 42 223 -21 minecraft:dirt
fill -39 222 -20 -38 224 -20 minecraft:stone
fill -24 222 -20 -24 223 -20 minecraft:dirt
setblock -22 222 -20 minecraft:rooted_dirt
fill -21 222 -20 -20 223 -20 minecraft:dirt
fill -17 222 -20 -17 223 -20 minecraft:dirt
setblock -15 222 -20 minecraft:rooted_dirt
fill -14 222 -20 -11 223 -20 minecraft:dirt
setblock -9 222 -20 minecraft:dirt
setblock -8 222 -20 minecraft:rooted_dirt
fill 1 222 -20 2 222 -20 minecraft:rooted_dirt
fill 3 222 -20 3 222 -19 minecraft:dirt
setblock 5 222 -20 minecraft:dirt
setblock 8 222 -20 minecraft:dirt
fill 11 222 -20 12 222 -19 minecraft:rooted_dirt
fill 15 222 -20 15 223 -20 minecraft:dirt
setblock 19 222 -20 minecraft:rooted_dirt
fill 20 222 -20 20 223 -19 minecraft:dirt
fill 24 222 -20 24 223 -19 minecraft:dirt
setblock 34 222 -20 minecraft:rooted_dirt
fill 36 222 -20 36 223 -20 minecraft:dirt
setblock 40 222 -20 minecraft:rooted_dirt
fill -22 222 -19 -21 223 -19 minecraft:dirt
setblock -20 222 -19 minecraft:rooted_dirt
fill -16 222 -19 -15 223 -19 minecraft:dirt
fill -14 222 -19 -13 222 -19 minecraft:rooted_dirt
fill -12 222 -19 -11 223 -19 minecraft:dirt
fill -10 222 -19 -9 222 -19 minecraft:rooted_dirt
fill -8 222 -19 -8 222 -17 minecraft:dirt
fill -6 222 -19 -4 222 -19 minecraft:dirt
fill 1 222 -19 2 222 -18 minecraft:dirt
setblock 6 222 -19 minecraft:dirt
fill 17 222 -19 17 223 -17 minecraft:dirt
fill 19 222 -19 19 223 -12 minecraft:dirt
fill 26 222 -19 26 223 -19 minecraft:dirt
fill -26 222 -18 -25 223 -18 minecraft:dirt
fill -21 222 -18 -20 223 -17 minecraft:dirt
setblock -19 222 -18 minecraft:rooted_dirt
fill -18 222 -18 -18 223 -18 minecraft:dirt
fill -14 222 -18 -13 223 -16 minecraft:dirt
fill -12 222 -18 -11 222 -18 minecraft:rooted_dirt
fill -10 222 -18 -9 222 -17 minecraft:dirt
fill -6 222 -18 -6 222 -15 minecraft:dirt
fill -2 222 -18 -2 222 -15 minecraft:dirt
fill 10 222 -18 13 223 -18 minecraft:dirt
setblock 14 222 -18 minecraft:rooted_dirt
fill 15 222 -18 15 223 -14 minecraft:dirt
setblock 18 222 -18 minecraft:rooted_dirt
fill 20 222 -18 20 222 -17 minecraft:rooted_dirt
fill 22 222 -18 22 223 -16 minecraft:dirt
fill 27 222 -18 27 223 -16 minecraft:dirt
fill -27 222 -17 -27 223 -17 minecraft:dirt
fill -23 222 -17 -22 223 -17 minecraft:dirt
fill -19 222 -17 -19 223 -16 minecraft:dirt
setblock -12 222 -17 minecraft:rooted_dirt
fill -11 222 -17 -11 223 -10 minecraft:dirt
fill -4 222 -17 -3 222 -17 minecraft:dirt
fill 1 222 -17 1 222 -15 minecraft:dirt
setblock 2 222 -17 minecraft:rooted_dirt
fill 10 222 -17 12 223 -15 minecraft:dirt
fill 13 222 -17 13 222 -16 minecraft:rooted_dirt
fill 14 222 -17 14 223 -17 minecraft:dirt
fill 18 222 -17 18 223 -13 minecraft:dirt
setblock 21 222 -17 minecraft:rooted_dirt
fill 25 222 -17 26 223 -17 minecraft:dirt
fill 28 222 -17 28 223 -17 minecraft:dirt
fill -23 222 -16 -23 223 -16 minecraft:dirt
setblock -20 222 -16 minecraft:rooted_dirt
fill -16 222 -16 -15 223 -16 minecraft:dirt
fill -12 222 -16 -12 223 -10 minecraft:dirt
fill -10 222 -16 -10 223 -14 minecraft:dirt
fill -9 222 -16 -8 222 -16 minecraft:rooted_dirt
fill -5 222 -16 -4 222 -16 minecraft:dirt
setblock -1 222 -16 minecraft:rooted_dirt
fill 3 222 -16 3 222 -12 minecraft:dirt
setblock 5 222 -16 minecraft:dirt
setblock 7 222 -16 minecraft:dirt
setblock 9 222 -16 minecraft:dirt
