fill -21 219 0 -21 220 4 minecraft:stone
fill 1 219 0 1 221 0 minecraft:stone
setblock 23 219 0 minecraft:andesite
fill 24 219 0 24 219 4 minecraft:cobblestone
fill 28 219 0 28 221 0 minecraft:stone
fill 1 219 1 1 219 2 minecraft:andesite
fill 16 219 1 16 221 1 minecraft:stone
setblock 23 219 1 minecraft:stone
fill -8 219 2 -8 220 2 minecraft:stone
fill -4 219 2 -4 220 2 minecraft:stone
setblock 12 219 2 minecraft:stone
fill 16 219 2 16 219 3 minecraft:tuff
fill 17 219 2 17 221 2 minecraft:stone
fill 25 219 2 25 219 4 minecraft:cobblestone
fill 27 219 2 27 221 5 minecraft:stone
fill -29 219 3 -28 220 3 minecraft:andesite
fill -8 219 3 -8 220 4 minecraft:andesite
setblock 9 219 3 minecraft:cobblestone
fill 28 219 3 28 220 4 minecraft:stone
fill -28 219 4 -28 220 4 minecraft:andesite
fill -7 219 4 -7 220 4 minecraft:andesite
setblock 9 219 4 minecraft:stone
setblock 16 219 4 minecraft:stone
setblock -28 219 5 minecraft:stone
fill -21 219 5 -21 219 7 minecraft:cobblestone
fill -11 219 5 -11 220 5 minecraft:stone
fill -8 219 5 -8 220 5 minecraft:stone
fill -4 219 5 -3 220 5 minecraft:andesite
fill 0 219 5 0 219 6 minecraft:cobblestone
fill 1 219 5 1 220 5 minecraft:stone
setblock 24 219 5 minecraft:stone
fill 25 219 5 26 219 6 minecraft:andesite
setblock 28 219 5 minecraft:amethyst_block
fill -27 219 6 -27 220 7 minecraft:stone
fill -19 219 6 -19 220 9 minecraft:stone
fill -17 219 6 -17 220 6 minecraft:stone
fill -11 219 6 -11 219 8 minecraft:tuff
fill -10 219 6 -10 220 6 minecraft:stone
fill -4 219 6 -4 220 6 minecraft:stone
setblock 1 219 6 minecraft:cobblestone
fill 11 219 6 13 220 6 minecraft:stone
fill 22 219 6 22 221 6 minecraft:andesite
fill 24 219 6 24 219 7 minecraft:andesite
fill 27 219 6 27 220 10 minecraft:andesite
setblock 28 219 6 minecraft:dripstone_block
fill -17 219 7 -17 220 7 minecraft:andesite
fill -13 219 7 -13 220 7 minecraft:stone
fill -12 219 7 -12 221 8 minecraft:tuff
fill -10 219 7 -10 220 7 minecraft:tuff
setblock 1 219 7 minecraft:stone
setblock 13 219 7 minecraft:tuff
fill 26 219 7 26 220 8 minecraft:andesite
fill 28 219 7 28 220 8 minecraft:andesite
fill -26 219 8 -26 221 9 minecraft:stone
setblock -17 219 8 minecraft:stone
fill -16 219 8 -15 219 8 minecraft:andesite
fill -10 219 8 -10 219 9 minecraft:stone
fill 1 219 8 1 220 9 minecraft:tuff
fill 2 219 8 2 221 8 minecraft:stone
setblock 11 219 8 minecraft:stone
fill 12 219 8 12 220 8 minecraft:tuff
fill 13 219 8 13 220 8 minecraft:stone
fill 19 219 8 22 220 8 minecraft:andesite
fill 23 219 8 25 219 8 minecraft:stone
fill -20 219 9 -20 221 9 minecraft:stone
setblock -18 219 9 minecraft:stone
fill -11 219 9 -11 220 9 minecraft:stone
fill -1 219 9 -1 220 12 minecraft:tuff
setblock 2 219 9 minecraft:tuff
fill 22 219 9 24 220 10 minecraft:stone
fill 26 219 9 26 219 11 minecraft:stone
fill -26 219 10 -26 220 10 minecraft:andesite
setblock -5 219 10 minecraft:stone
fill 18 219 10 21 220 10 minecraft:stone
setblock -26 219 11 minecraft:dripstone_block
fill -5 219 11 -5 220 13 minecraft:andesite
fill 17 219 11 17 220 11 minecraft:stone
fill 18 219 11 19 219 12 minecraft:cobblestone
setblock 22 219 11 minecraft:cobblestone
fill 23 219 11 25 221 11 minecraft:stone
fill -25 219 12 -25 220 12 minecraft:andesite
fill -14 219 12 -14 221 13 minecraft:stone
fill 12 219 12 13 220 12 minecraft:andesite
setblock 17 219 12 minecraft:cobblestone
fill 20 219 12 21 219 12 minecraft:cobblestone
fill 24 219 12 25 221 13 minecraft:stone
fill -25 219 13 -25 221 13 minecraft:stone
fill 2 219 13 2 221 13 minecraft:stone
fill 15 219 13 16 220 13 minecraft:stone
fill 19 219 13 19 219 16 minecraft:stone
fill -24 219 14 -24 221 14 minecraft:stone
fill 16 219 14 16 220 14 minecraft:stone
fill 24 219 14 24 221 14 minecraft:stone
fill -23 219 15 -23 221 16 minecraft:stone
fill -13 219 15 -13 220 15 minecraft:andesite
setblock -5 219 15 minecraft:stone
fill 2 219 15 2 221 15 minecraft:stone
fill 4 219 15 4 220 16 minecraft:andesite
fill 23 219 15 23 220 17 minecraft:stone
fill -22 219 16 -22 221 18 minecraft:stone
fill -12 219 16 -11 220 16 minecraft:andesite
fill -20 219 17 -20 221 17 minecraft:stone
fill -15 219 17 -13 219 17 minecraft:stone
fill -12 219 17 -12 221 17 minecraft:andesite
setblock -11 219 17 minecraft:stone
fill 4 219 17 4 220 17 minecraft:stone
fill 20 219 17 20 220 18 minecraft:stone
setblock -13 219 18 minecraft:stone
fill -11 219 18 -11 221 18 minecraft:andesite
fill -10 219 18 -10 220 18 minecraft:stone
fill 22 219 18 22 220 19 minecraft:stone
setblock -22 219 19 minecraft:dripstone_block
fill -13 219 19 -13 221 19 minecraft:andesite
setblock 9 219 19 minecraft:tuff
fill 10 219 19 10 220 20 minecraft:stone
fill -21 219 20 -21 220 21 minecraft:stone
fill -10 219 20 -10 221 21 minecraft:stone
fill 3 219 20 3 219 21 minecraft:cobblestone
fill 4 219 20 4 220 20 minecraft:stone
fill 9 219 20 9 220 20 minecraft:stone
fill -20 219 21 -20 220 22 minecraft:stone
fill -13 219 21 -13 221 21 minecraft:andesite
fill 21 219 21 21 220 21 minecraft:stone
fill -19 219 22 -19 220 23 minecraft:stone
fill -13 219 22 -13 221 23 minecraft:stone
fill 3 219 22 3 219 24 minecraft:tuff
fill 18 219 22 18 220 23 minecraft:stone
fill 20 219 22 20 220 22 minecraft:stone
fill 41 219 22 41 222 22 minecraft:stone
fill -12 219 23 -12 221 23 minecraft:stone
fill -10 219 23 -9 219 23 minecraft:stone
fill -3 219 23 -3 221 23 minecraft:stone
fill 17 219 23 17 220 24 minecraft:stone
fill 19 219 23 19 220 23 minecraft:stone
fill 40 219 23 40 222 23 minecraft:stone
fill -18 219 24 -18 220 24 minecraft:stone
fill -12 219 24 -12 219 27 minecraft:cobblestone
setblock -10 219 24 minecraft:stone
setblock -9 219 24 minecraft:cobblestone
setblock -3 219 24 minecraft:cobblestone
fill 4 219 24 4 220 24 minecraft:tuff
setblock 9 219 24 minecraft:cobblestone
fill 10 219 24 12 220 24 minecraft:stone
fill 14 219 24 16 221 24 minecraft:stone
fill 38 219 24 38 221 24 minecraft:cobblestone
fill -17 219 25 -17 220 25 minecraft:stone
fill -15 219 25 -15 220 25 minecraft:stone
setblock -11 219 25 minecraft:stone
fill 12 219 25 12 220 26 minecraft:stone
fill 14 219 25 15 221 25 minecraft:stone
setblock 38 219 25 minecraft:stone
setblock 40 219 25 minecraft:cobblestone
fill 42 219 25 42 220 25 minecraft:andesite
fill -16 219 26 -16 220 26 minecraft:stone
setblock -15 219 26 minecraft:cobblestone
setblock -14 219 26 minecraft:dripstone_block
fill -13 219 26 -13 219 27 minecraft:cobblestone
fill -11 219 26 -11 219 27 minecraft:cobblestone
fill 2 219 26 7 220 26 minecraft:stone
fill 14 219 26 14 221 26 minecraft:stone
setblock -15 219 27 minecraft:dripstone_block
setblock -14 219 27 minecraft:cobblestone
fill -9 219 27 -9 220 28 minecraft:andesite
fill -6 219 27 -5 219 27 minecraft:stone
fill 2 219 27 3 220 27 minecraft:stone
fill 4 219 27 5 219 28 minecraft:andesite
fill 6 219 27 7 221 27 minecraft:stone
fill 12 219 27 13 219 27 minecraft:tuff
fill 40 219 27 40 222 27 minecraft:stone
fill -11 219 28 -10 219 28 minecraft:stone
fill -5 219 28 -5 219 29 minecraft:cobblestone
fill -4 219 28 -4 221 28 minecraft:tuff
fill 2 219 28 2 220 29 minecraft:stone
setblock 3 219 28 minecraft:dripstone_block
fill 6 219 28 6 221 28 minecraft:stone
setblock 7 219 28 minecraft:amethyst_block
fill 8 219 28 8 221 28 minecraft:stone
setblock 9 219 28 minecraft:amethyst_block
fill 10 219 28 12 219 28 minecraft:stone
fill -10 219 29 -7 219 29 minecraft:stone
setblock -6 219 29 minecraft:cobblestone
setblock -4 219 29 minecraft:stone
fill -3 219 29 -2 220 29 minecraft:tuff
setblock 3 219 29 minecraft:amethyst_block
setblock -7 219 30 minecraft:dripstone_block
fill -6 219 30 -5 219 30 minecraft:stone
fill -4 219 30 -3 219 30 minecraft:cobblestone
setblock -2 219 30 minecraft:stone
fill 1 219 30 2 219 30 minecraft:tuff
fill -4 219 31 -3 220 31 minecraft:stone
setblock 34 220 -37 minecraft:dripstone_block
setblock 35 220 -37 minecraft:tuff
fill 38 220 -37 41 220 -37 minecraft:stone
setblock 33 220 -36 minecraft:stone
fill 34 220 -36 34 221 -36 minecraft:tuff
setblock 38 220 -36 minecraft:stone
fill 42 220 -36 43 220 -36 minecraft:stone
fill 31 220 -35 32 221 -34 minecraft:stone
setblock 35 220 -35 minecraft:tuff
fill 43 220 -35 44 220 -35 minecraft:stone
setblock 30 220 -34 minecraft:stone
fill 33 220 -34 33 221 -34 minecraft:stone
setblock 35 220 -34 minecraft:stone
fill 44 220 -34 44 221 -28 minecraft:stone
fill 29 220 -33 29 220 -32 minecraft:stone
fill 32 220 -33 33 220 -32 minecraft:andesite
setblock 31 220 -32 minecraft:andesite
fill 28 220 -31 28 220 -28 minecraft:stone
fill 31 220 -31 33 220 -31 minecraft:stone
fill 45 220 -31 45 221 -28 minecraft:stone
setblock -9 220 -29 minecraft:dripstone_block
fill -2 220 -29 -2 221 -29 minecraft:stone
fill -1 220 -29 1 221 -27 minecraft:mossy_cobblestone
fill 6 220 -29 7 220 -29 minecraft:stone
fill -11 220 -28 -11 220 -27 minecraft:mossy_cobblestone
setblock 7 220 -28 minecraft:stone
setblock 9 220 -28 minecraft:stone
fill 30 220 -28 30 220 -24 minecraft:mossy_cobblestone
fill 39 220 -28 40 220 -28 minecraft:stone
fill 41 220 -28 43 220 -26 minecraft:mossy_cobblestone
