fill -6 205 7 -6 221 7 minecraft:stone
fill -5 205 7 -5 206 7 minecraft:andesite
fill -4 205 7 -4 220 7 minecraft:stone
fill 0 205 7 0 213 7 minecraft:tuff
setblock 1 205 7 minecraft:stone
fill 9 205 7 9 220 7 minecraft:stone
fill 3 205 8 8 209 8 minecraft:stone
fill -5 205 9 -5 220 9 minecraft:stone
fill -2 205 9 -2 221 10 minecraft:stone
fill -4 205 10 -3 216 10 minecraft:stone
fill -3 205 11 -3 216 11 minecraft:stone
setblock -7 206 -11 minecraft:amethyst_block
fill -6 206 -11 -4 210 -11 minecraft:stone
fill -3 206 -11 -3 207 -11 minecraft:tuff
fill -8 206 -10 -7 207 -10 minecraft:andesite
fill -2 206 -10 -2 220 -10 minecraft:stone
fill -1 206 -9 -1 207 -8 minecraft:stone
fill 0 206 -9 0 208 -8 minecraft:cobblestone
fill 6 206 -9 6 207 -9 minecraft:deepslate
fill 7 206 -9 8 219 -9 minecraft:stone
fill -9 206 -8 -9 209 -8 minecraft:stone
fill -6 206 -8 -6 220 -8 minecraft:stone
setblock 1 206 -8 minecraft:cobblestone
setblock 9 206 -8 minecraft:amethyst_block
fill 10 206 -8 10 206 -7 minecraft:tuff
fill -8 206 -7 -8 210 -7 minecraft:andesite
fill -6 206 -7 -6 206 -4 minecraft:andesite
setblock -1 206 -7 minecraft:andesite
fill 1 206 -7 1 213 -7 minecraft:stone
fill 8 206 -7 8 220 -7 minecraft:stone
fill 9 206 -7 9 207 -7 minecraft:tuff
fill -9 206 -6 -9 210 -6 minecraft:andesite
fill 9 206 -6 11 206 -6 minecraft:cobblestone
fill -10 206 -5 -10 209 -4 minecraft:andesite
fill -2 206 -5 -1 208 -5 minecraft:andesite
fill 0 206 -5 0 213 -5 minecraft:stone
fill 7 206 -5 11 206 -5 minecraft:stone
fill -4 206 -4 -4 210 -4 minecraft:andesite
fill -1 206 -4 -1 214 -4 minecraft:stone
fill 0 206 -4 0 206 -3 minecraft:cobblestone
fill 1 206 -4 1 209 -4 minecraft:stone
fill 6 206 -4 7 206 -4 minecraft:deepslate
fill 8 206 -4 8 221 -4 minecraft:stone
fill 10 206 -4 11 206 -4 minecraft:amethyst_block
fill 12 206 -4 12 212 -3 minecraft:tuff
fill -14 206 -3 -14 220 -3 minecraft:stone
fill -10 206 -3 -10 207 -3 minecraft:stone
fill -6 206 -3 -6 207 0 minecraft:stone
fill -4 206 -3 -4 208 -3 minecraft:stone
setblock 1 206 -3 minecraft:cobblestone
fill 4 206 -3 4 208 -3 minecraft:stone
fill 5 206 -3 5 210 -3 minecraft:deepslate
fill 8 206 -3 8 207 -2 minecraft:andesite
setblock 10 206 -3 minecraft:deepslate
fill 11 206 -3 11 207 -1 minecraft:stone
fill -13 206 -2 -11 220 -2 minecraft:stone
fill 6 206 -2 6 208 -2 minecraft:deepslate
fill 7 206 -2 7 208 -2 minecraft:andesite
fill 10 206 -2 10 213 -2 minecraft:stone
fill -13 206 -1 -13 206 1 minecraft:deepslate
fill -12 206 -1 -12 220 1 minecraft:stone
fill 1 206 -1 1 207 -1 minecraft:tuff
fill 2 206 -1 2 220 -1 minecraft:stone
fill -15 206 0 -15 207 0 minecraft:deepslate
fill -4 206 0 -4 219 1 minecraft:stone
fill 2 206 0 2 207 0 minecraft:tuff
fill 3 206 0 3 220 1 minecraft:stone
setblock 11 206 0 minecraft:dripstone_block
fill -11 206 1 -11 220 4 minecraft:stone
fill -5 206 1 -5 221 1 minecraft:stone
fill 8 206 1 8 207 1 minecraft:stone
setblock 10 206 1 minecraft:dripstone_block
fill 11 206 1 11 206 3 minecraft:andesite
setblock -13 206 2 minecraft:andesite
fill -2 206 2 -2 216 2 minecraft:stone
fill -4 206 3 -4 208 3 minecraft:deepslate
fill -2 206 3 -2 207 3 minecraft:deepslate
fill 5 206 3 5 208 3 minecraft:deepslate
fill 8 206 3 8 219 3 minecraft:stone
fill -4 206 4 -4 207 6 minecraft:stone
fill 11 206 4 11 215 6 minecraft:stone
fill -10 206 5 -10 216 5 minecraft:stone
fill 5 206 5 5 220 5 minecraft:stone
fill 6 206 5 6 208 5 minecraft:deepslate
fill 7 206 5 8 220 5 minecraft:stone
fill 18 206 5 18 221 5 minecraft:stone
fill -9 206 6 -9 220 6 minecraft:stone
setblock -6 206 6 minecraft:andesite
fill 20 206 6 20 220 6 minecraft:stone
fill -1 206 7 -1 212 7 minecraft:tuff
fill 1 206 7 1 210 7 minecraft:tuff
fill 10 206 7 10 220 7 minecraft:stone
setblock -6 206 8 minecraft:dripstone_block
setblock -1 206 8 minecraft:stone
setblock 2 206 8 minecraft:dripstone_block
fill 9 206 8 10 206 8 minecraft:tuff
fill 3 206 9 3 214 9 minecraft:stone
setblock 4 206 9 minecraft:dripstone_block
fill 5 206 9 7 208 9 minecraft:stone
fill 8 206 9 8 208 9 minecraft:tuff
setblock -5 206 10 minecraft:dripstone_block
setblock -1 206 10 minecraft:amethyst_block
fill -4 206 11 -4 216 11 minecraft:stone
setblock -2 206 11 minecraft:dripstone_block
fill -1 206 11 0 210 12 minecraft:stone
fill -3 206 12 -2 215 12 minecraft:stone
fill -5 207 -12 -3 213 -12 minecraft:stone
fill -8 207 -11 -8 220 -11 minecraft:stone
setblock -7 207 -11 minecraft:andesite
fill -2 207 -11 -2 221 -11 minecraft:stone
fill -9 207 -10 -9 209 -10 minecraft:stone
fill -1 207 -10 -1 210 -10 minecraft:stone
setblock 0 207 -10 minecraft:cobblestone
fill 1 207 -10 4 210 -10 minecraft:stone
fill 1 207 -9 2 210 -9 minecraft:stone
setblock 3 207 -9 minecraft:deepslate
fill 9 207 -9 10 218 -9 minecraft:stone
fill -12 207 -8 -11 207 -7 minecraft:stone
fill 1 207 -8 1 211 -8 minecraft:stone
fill 3 207 -8 3 215 -7 minecraft:stone
fill 4 207 -8 6 208 -8 minecraft:deepslate
fill 7 207 -8 7 209 -4 minecraft:stone
setblock 9 207 -8 minecraft:tuff
fill 10 207 -8 11 218 -8 minecraft:stone
fill -10 207 -7 -9 208 -7 minecraft:stone
fill -6 207 -7 -1 207 -7 minecraft:stone
fill 0 207 -7 0 209 -7 minecraft:cobblestone
fill 4 207 -7 6 210 -7 minecraft:stone
fill 10 207 -7 12 207 -7 minecraft:tuff
setblock -11 207 -6 minecraft:dripstone_block
fill -10 207 -6 -10 220 -6 minecraft:stone
fill -6 207 -6 -5 207 -6 minecraft:andesite
fill 5 207 -6 6 214 -6 minecraft:stone
fill 8 207 -6 10 208 -6 minecraft:cobblestone
fill 11 207 -6 12 209 -6 minecraft:tuff
fill -11 207 -5 -11 221 -5 minecraft:stone
fill -6 207 -5 -6 209 -4 minecraft:andesite
setblock 8 207 -5 minecraft:stone
fill 9 207 -5 10 208 -5 minecraft:cobblestone
fill 11 207 -5 11 207 -4 minecraft:stone
fill 12 207 -5 12 210 -5 minecraft:tuff
fill -11 207 -4 -11 209 -4 minecraft:andesite
fill -3 207 -4 -3 209 -4 minecraft:andesite
fill 0 207 -4 0 209 -4 minecraft:stone
fill 6 207 -4 6 207 -3 minecraft:deepslate
fill 9 207 -4 10 209 -3 minecraft:stone
fill -15 207 -3 -15 214 -3 minecraft:stone
fill -13 207 -3 -13 221 -3 minecraft:stone
fill -11 207 -3 -11 221 -3 minecraft:stone
fill 0 207 -3 0 207 -2 minecraft:cobblestone
fill 1 207 -3 1 209 -2 minecraft:stone
setblock 7 207 -3 minecraft:deepslate
fill 13 207 -3 13 213 -3 minecraft:tuff
setblock -1 207 -2 minecraft:stone
fill 2 207 -2 2 220 -2 minecraft:stone
fill 5 207 -2 5 209 -2 minecraft:deepslate
fill 9 207 -2 9 207 0 minecraft:andesite
fill 12 207 -2 12 209 -2 minecraft:tuff
fill -15 207 -1 -13 220 -1 minecraft:stone
fill 8 207 -1 8 209 0 minecraft:andesite
fill 10 207 -1 10 208 -1 minecraft:stone
setblock 12 207 -1 minecraft:dripstone_block
fill -13 207 0 -13 220 3 minecraft:stone
setblock 10 207 0 minecraft:dripstone_block
fill 11 207 0 11 207 3 minecraft:stone
fill 12 207 0 12 208 1 minecraft:deepslate
setblock -14 207 1 minecraft:deepslate
fill 0 207 1 0 208 2 minecraft:tuff
fill 9 207 1 10 207 1 minecraft:stone
fill -12 207 2 -12 209 4 minecraft:stone
fill -5 207 2 -4 217 2 minecraft:stone
fill -1 207 2 -1 216 5 minecraft:stone
fill 7 207 2 7 209 2 minecraft:stone
fill 12 207 2 12 207 8 minecraft:stone
fill -5 207 3 -5 216 7 minecraft:stone
fill 0 207 3 0 216 5 minecraft:stone
setblock 7 207 3 minecraft:deepslate
fill -3 207 4 -3 208 4 minecraft:deepslate
fill -2 207 4 -2 217 5 minecraft:stone
fill 4 207 4 4 220 4 minecraft:stone
fill 5 207 4 5 209 4 minecraft:deepslate
fill 7 207 4 7 220 4 minecraft:stone
setblock 19 207 4 minecraft:cobblestone
fill 20 207 4 20 220 4 minecraft:stone
fill -11 207 5 -11 210 5 minecraft:stone
fill -3 207 5 -3 218 5 minecraft:stone
fill -10 207 6 -10 210 6 minecraft:stone
fill -6 207 6 -6 220 6 minecraft:stone
fill 1 207 6 1 217 6 minecraft:stone
fill 18 207 6 18 220 6 minecraft:stone
fill -7 207 7 -7 221 7 minecraft:stone
fill 11 207 7 11 217 8 minecraft:stone
fill -6 207 8 -6 221 9 minecraft:stone
fill -1 207 8 0 213 8 minecraft:tuff
setblock 1 207 8 minecraft:dripstone_block
fill 2 207 8 2 213 11 minecraft:stone
fill 9 207 8 9 207 9 minecraft:tuff
fill 10 207 8 10 220 8 minecraft:stone
fill -1 207 9 1 207 9 minecraft:stone
fill 4 207 9 4 213 9 minecraft:stone
setblock 10 207 9 minecraft:tuff
fill -5 207 10 -5 218 11 minecraft:stone
fill -1 207 10 0 208 10 minecraft:stone
setblock 1 207 10 minecraft:dripstone_block
fill 3 207 10 3 214 10 minecraft:stone
fill 5 207 10 7 207 10 minecraft:stone
fill 8 207 10 8 209 10 minecraft:tuff
fill -2 207 11 -2 220 11 minecraft:stone
setblock 1 207 11 minecraft:amethyst_block
fill -4 207 12 -4 216 13 minecraft:stone
fill 1 207 12 1 209 12 minecraft:stone
fill -3 207 13 -1 211 13 minecraft:stone
fill 37 208 -29 37 209 -29 minecraft:andesite
fill -5 208 -13 -3 212 -13 minecraft:stone
fill -7 208 -12 -6 210 -12 minecraft:stone
fill -7 208 -11 -7 210 -10 minecraft:stone
fill -3 208 -11 -3 220 -11 minecraft:stone
fill -8 208 -10 -8 209 -10 minecraft:stone
fill 0 208 -10 0 209 -10 minecraft:stone
fill 5 208 -10 7 215 -10 minecraft:stone
