fill 15 218 13 16 218 13 minecraft:andesite
fill 17 218 13 17 219 13 minecraft:stone
fill 21 218 13 23 219 14 minecraft:stone
fill -22 218 14 -22 221 15 minecraft:stone
fill -6 218 14 -6 220 14 minecraft:stone
fill -5 218 14 -5 220 14 minecraft:andesite
fill -1 218 14 -1 219 15 minecraft:cobblestone
fill 11 218 14 15 220 14 minecraft:stone
setblock 16 218 14 minecraft:andesite
fill -21 218 15 -21 220 19 minecraft:stone
fill -12 218 15 -11 220 15 minecraft:andesite
fill -4 218 15 -4 219 15 minecraft:cobblestone
fill 0 218 15 0 219 15 minecraft:tuff
fill 5 218 15 5 219 16 minecraft:andesite
fill 22 218 15 22 220 17 minecraft:stone
fill -20 218 16 -20 221 16 minecraft:stone
setblock -12 218 16 minecraft:stone
setblock -20 218 17 minecraft:dripstone_block
fill -19 218 17 -19 221 18 minecraft:stone
setblock 20 218 17 minecraft:andesite
fill 21 218 17 21 220 17 minecraft:stone
fill -20 218 18 -20 220 20 minecraft:stone
fill -13 218 18 -13 218 19 minecraft:stone
fill -12 218 18 -12 221 18 minecraft:andesite
fill 9 218 18 9 219 18 minecraft:tuff
fill -18 218 19 -18 220 19 minecraft:stone
fill 1 218 19 6 219 19 minecraft:stone
fill 7 218 19 8 220 19 minecraft:tuff
fill 21 218 19 21 220 20 minecraft:stone
fill -19 218 20 -19 220 21 minecraft:stone
fill -13 218 20 -13 221 20 minecraft:andesite
fill -10 218 20 -10 218 21 minecraft:andesite
fill -9 218 20 -9 221 21 minecraft:stone
fill 8 218 20 8 219 22 minecraft:stone
fill -13 218 21 -13 218 23 minecraft:stone
fill 3 218 21 3 218 22 minecraft:stone
fill 4 218 21 4 219 23 minecraft:tuff
fill 20 218 21 20 220 21 minecraft:stone
fill -18 218 22 -18 219 23 minecraft:stone
fill 16 218 22 17 221 22 minecraft:stone
setblock 18 218 22 minecraft:amethyst_block
fill 19 218 22 19 220 22 minecraft:stone
fill -17 218 23 -17 220 24 minecraft:stone
fill -12 218 23 -12 218 25 minecraft:cobblestone
setblock -3 218 23 minecraft:cobblestone
fill -2 218 23 -2 221 24 minecraft:stone
fill 5 218 23 5 220 24 minecraft:tuff
fill 6 218 23 6 220 23 minecraft:stone
fill 14 218 23 16 221 23 minecraft:stone
setblock 40 218 23 minecraft:cobblestone
fill 42 218 23 42 219 24 minecraft:andesite
fill -16 218 24 -14 220 24 minecraft:stone
fill -13 218 24 -13 219 25 minecraft:cobblestone
fill -5 218 24 -5 221 25 minecraft:stone
setblock -3 218 24 minecraft:stone
fill 6 218 24 6 219 24 minecraft:tuff
fill 7 218 24 8 220 24 minecraft:stone
fill 13 218 24 13 220 26 minecraft:stone
setblock 14 218 24 minecraft:dripstone_block
fill 39 218 24 39 221 25 minecraft:cobblestone
fill -16 218 25 -16 220 25 minecraft:stone
setblock -15 218 25 minecraft:dripstone_block
fill -14 218 25 -14 219 25 minecraft:cobblestone
fill -11 218 25 -11 218 26 minecraft:stone
fill 8 218 25 9 219 27 minecraft:stone
fill 12 218 25 12 218 27 minecraft:stone
fill -10 218 26 -10 219 27 minecraft:stone
fill -4 218 26 -4 221 26 minecraft:stone
fill -1 218 26 -1 220 26 minecraft:tuff
fill 1 218 26 1 220 26 minecraft:tuff
fill 2 218 26 7 218 27 minecraft:stone
fill 10 218 26 10 220 27 minecraft:stone
fill 39 218 26 39 222 26 minecraft:stone
fill 41 218 26 41 222 26 minecraft:stone
setblock -9 218 27 minecraft:amethyst_block
fill -8 218 27 -7 219 28 minecraft:andesite
fill -6 218 27 -5 218 27 minecraft:cobblestone
fill -4 218 27 -3 221 27 minecraft:tuff
fill 11 218 27 11 219 27 minecraft:stone
setblock -9 218 28 minecraft:stone
fill -6 218 28 -6 219 28 minecraft:cobblestone
setblock -5 218 28 minecraft:amethyst_block
setblock -4 218 28 minecraft:cobblestone
fill -3 218 28 -3 221 28 minecraft:tuff
setblock 2 218 28 minecraft:tuff
fill -3 218 29 -2 218 29 minecraft:stone
fill 1 218 29 1 220 29 minecraft:tuff
setblock -2 218 30 minecraft:dripstone_block
fill -1 218 30 0 220 30 minecraft:tuff
fill -8 219 -29 -6 220 -29 minecraft:stone
fill -5 219 -29 -3 220 -28 minecraft:tuff
fill -2 219 -29 -1 219 -29 minecraft:stone
setblock 1 219 -29 minecraft:amethyst_block
fill 2 219 -29 5 220 -29 minecraft:stone
fill -10 219 -28 -9 220 -28 minecraft:stone
fill -6 219 -28 -6 220 -28 minecraft:stone
fill -1 219 -28 -1 219 -27 minecraft:stone
fill 0 219 -28 1 219 -28 minecraft:cobblestone
fill 6 219 -28 6 220 -28 minecraft:stone
setblock 7 219 -28 minecraft:dripstone_block
fill 8 219 -28 8 220 -27 minecraft:stone
setblock -11 219 -27 minecraft:dripstone_block
fill -9 219 -27 -9 220 -27 minecraft:stone
fill -5 219 -27 -4 220 -27 minecraft:tuff
setblock -3 219 -27 minecraft:stone
fill 4 219 -27 4 220 -27 minecraft:stone
setblock 6 219 -27 minecraft:cobblestone
fill 7 219 -27 7 220 -27 minecraft:stone
fill 9 219 -27 10 220 -27 minecraft:stone
fill -15 219 -26 -15 220 -26 minecraft:stone
setblock -14 219 -26 minecraft:amethyst_block
fill -13 219 -26 -13 220 -26 minecraft:stone
fill -11 219 -26 -11 220 -26 minecraft:stone
fill 4 219 -26 4 220 -25 minecraft:andesite
fill 10 219 -26 11 221 -26 minecraft:stone
fill -17 219 -25 -17 220 -23 minecraft:stone
setblock 11 219 -25 minecraft:amethyst_block
fill 12 219 -25 12 221 -25 minecraft:stone
fill -18 219 -24 -18 220 -23 minecraft:stone
fill 11 219 -24 11 221 -23 minecraft:stone
setblock 12 219 -24 minecraft:cobblestone
fill 13 219 -24 14 219 -24 minecraft:stone
fill -40 219 -23 -40 222 -23 minecraft:stone
setblock -16 219 -23 minecraft:tuff
fill -15 219 -23 -15 220 -23 minecraft:stone
fill -9 219 -23 -8 221 -23 minecraft:tuff
fill -7 219 -23 -4 219 -23 minecraft:stone
fill 14 219 -23 16 221 -23 minecraft:stone
fill -41 219 -22 -41 226 -22 minecraft:stone
fill -39 219 -22 -39 221 -22 minecraft:stone
setblock -19 219 -22 minecraft:dripstone_block
fill -17 219 -22 -17 220 -22 minecraft:tuff
fill 12 219 -22 12 219 -21 minecraft:andesite
fill 13 219 -22 13 219 -21 minecraft:stone
fill 16 219 -22 16 220 -21 minecraft:stone
fill 18 219 -22 18 221 -22 minecraft:stone
setblock -39 219 -21 minecraft:andesite
fill -38 219 -21 -38 221 -21 minecraft:stone
fill -21 219 -21 -19 220 -21 minecraft:stone
fill -5 219 -21 -5 220 -21 minecraft:stone
fill -4 219 -21 -4 220 -21 minecraft:andesite
fill -1 219 -21 -1 221 -21 minecraft:stone
setblock 2 219 -21 minecraft:cobblestone
fill 14 219 -21 15 220 -21 minecraft:stone
fill 17 219 -21 17 220 -21 minecraft:stone
fill 19 219 -21 21 219 -21 minecraft:stone
fill -22 219 -20 -20 221 -20 minecraft:stone
fill 3 219 -20 5 219 -20 minecraft:andesite
fill 6 219 -20 6 220 -20 minecraft:stone
fill 19 219 -20 19 221 -20 minecraft:stone
fill 21 219 -20 23 219 -20 minecraft:stone
fill -23 219 -19 -22 220 -19 minecraft:stone
fill -17 219 -19 -17 220 -16 minecraft:tuff
fill -6 219 -19 -6 220 -17 minecraft:stone
fill 24 219 -19 25 220 -19 minecraft:stone
fill -25 219 -18 -24 220 -18 minecraft:stone
fill -22 219 -18 -22 220 -18 minecraft:stone
fill -13 219 -18 -13 221 -18 minecraft:stone
setblock 19 219 -18 minecraft:stone
fill 20 219 -18 20 220 -18 minecraft:tuff
setblock 22 219 -18 minecraft:tuff
fill 23 219 -18 23 220 -18 minecraft:stone
fill 25 219 -18 25 220 -18 minecraft:stone
fill 14 219 -17 14 221 -16 minecraft:stone
fill 19 219 -17 19 221 -17 minecraft:tuff
setblock 26 219 -17 minecraft:dripstone_block
fill -26 219 -16 -26 220 -16 minecraft:stone
fill -6 219 -16 -6 219 -15 minecraft:cobblestone
setblock -4 219 -16 minecraft:cobblestone
fill -3 219 -16 -3 220 -15 minecraft:stone
setblock 3 219 -16 minecraft:cobblestone
fill 4 219 -16 4 220 -16 minecraft:stone
setblock 15 219 -16 minecraft:stone
setblock 19 219 -16 minecraft:stone
fill 20 219 -16 21 220 -16 minecraft:tuff
fill 26 219 -16 26 220 -16 minecraft:stone
fill -27 219 -15 -27 219 -14 minecraft:dripstone_block
fill -17 219 -15 -17 220 -15 minecraft:stone
fill -16 219 -15 -15 219 -15 minecraft:tuff
fill 14 219 -15 15 219 -15 minecraft:cobblestone
setblock 16 219 -15 minecraft:stone
fill 20 219 -15 21 219 -15 minecraft:stone
fill 25 219 -15 25 220 -15 minecraft:stone
fill 27 219 -15 27 219 -14 minecraft:stone
fill -28 219 -14 -28 220 -14 minecraft:tuff
fill -26 219 -14 -26 220 -14 minecraft:stone
setblock 3 219 -14 minecraft:cobblestone
fill 5 219 -14 6 221 -14 minecraft:stone
fill 23 219 -14 23 220 -13 minecraft:andesite
fill 25 219 -14 25 219 -12 minecraft:andesite
fill 26 219 -14 26 221 -14 minecraft:stone
fill 28 219 -14 28 221 -12 minecraft:stone
fill -28 219 -13 -28 219 -12 minecraft:stone
fill -25 219 -13 -25 220 -13 minecraft:stone
setblock -14 219 -13 minecraft:stone
fill -13 219 -13 -13 219 -12 minecraft:cobblestone
fill 3 219 -13 3 219 -12 minecraft:stone
setblock 4 219 -13 minecraft:tuff
fill 6 219 -13 6 221 -12 minecraft:stone
setblock 26 219 -13 minecraft:andesite
fill -29 219 -12 -29 220 -11 minecraft:stone
fill -27 219 -12 -26 219 -12 minecraft:cobblestone
setblock -14 219 -12 minecraft:cobblestone
setblock -12 219 -12 minecraft:cobblestone
fill 5 219 -12 5 220 -12 minecraft:tuff
setblock 23 219 -12 minecraft:stone
fill 24 219 -12 24 221 -12 minecraft:andesite
fill 29 219 -12 29 221 -10 minecraft:stone
fill -27 219 -11 -26 219 -11 minecraft:stone
setblock -12 219 -11 minecraft:stone
fill 3 219 -11 3 221 -10 minecraft:tuff
fill 24 219 -11 25 219 -11 minecraft:stone
fill -26 219 -10 -26 220 -10 minecraft:stone
fill -8 219 -10 -7 220 -10 minecraft:stone
fill 2 219 -10 2 220 -10 minecraft:stone
fill 9 219 -10 9 221 -10 minecraft:stone
fill 14 219 -10 14 220 -10 minecraft:stone
fill 15 219 -10 15 220 -10 minecraft:tuff
fill 24 219 -10 24 221 -10 minecraft:stone
fill 30 219 -10 30 219 -6 minecraft:stone
