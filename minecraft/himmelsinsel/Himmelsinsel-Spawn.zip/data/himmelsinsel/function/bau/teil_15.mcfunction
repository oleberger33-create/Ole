fill 4 218 -6 4 220 -2 minecraft:tuff
setblock 17 218 -6 minecraft:andesite
fill 19 218 -6 20 221 -6 minecraft:andesite
fill 29 218 -6 29 220 -2 minecraft:stone
fill -27 218 -5 -27 220 -3 minecraft:tuff
fill -22 218 -5 -22 221 -5 minecraft:stone
fill -21 218 -5 -21 221 -4 minecraft:andesite
setblock -4 218 -5 minecraft:stone
fill -3 218 -5 -3 220 -4 minecraft:andesite
fill 16 218 -5 16 220 -4 minecraft:andesite
fill 21 218 -5 21 221 -3 minecraft:andesite
fill 22 218 -5 22 221 -5 minecraft:stone
fill -26 218 -4 -26 218 -2 minecraft:tuff
fill 3 218 -4 3 221 -3 minecraft:stone
fill 9 218 -4 15 218 -4 minecraft:stone
fill 22 218 -4 22 218 -3 minecraft:andesite
fill 23 218 -4 23 220 -4 minecraft:stone
setblock -28 218 -3 minecraft:dripstone_block
fill -25 218 -3 -25 220 -1 minecraft:stone
fill 0 218 -3 0 220 -3 minecraft:andesite
fill 17 218 -3 19 221 -3 minecraft:andesite
fill 24 218 -3 25 219 -3 minecraft:cobblestone
fill 26 218 -3 26 220 -3 minecraft:stone
fill -28 218 -2 -28 221 -2 minecraft:tuff
fill 5 218 -2 5 219 -2 minecraft:tuff
fill 24 218 -2 24 218 -1 minecraft:andesite
fill 26 218 -2 26 218 -1 minecraft:cobblestone
fill 27 218 -2 27 220 1 minecraft:stone
fill -29 218 -1 -28 218 -1 minecraft:stone
fill -27 218 -1 -27 220 -1 minecraft:tuff
fill -20 218 -1 -18 219 -1 minecraft:andesite
setblock -17 218 -1 minecraft:cobblestone
fill 10 218 -1 10 221 1 minecraft:stone
fill 28 218 -1 28 221 -1 minecraft:stone
setblock -29 218 0 minecraft:amethyst_block
fill -28 218 0 -27 218 0 minecraft:stone
setblock -25 218 0 minecraft:tuff
fill -24 218 0 -24 220 1 minecraft:stone
fill -18 218 0 -18 219 0 minecraft:cobblestone
fill 9 218 0 9 221 1 minecraft:stone
fill 20 218 0 20 220 1 minecraft:andesite
setblock 24 218 0 minecraft:stone
setblock 28 218 0 minecraft:amethyst_block
fill -28 218 1 -28 220 2 minecraft:stone
fill -25 218 1 -25 220 1 minecraft:stone
fill -2 218 1 -2 221 1 minecraft:stone
fill -1 218 1 -1 219 1 minecraft:andesite
fill 11 218 1 11 219 1 minecraft:stone
fill 17 218 1 17 221 1 minecraft:stone
fill 28 218 1 28 219 2 minecraft:andesite
fill -5 218 2 -5 220 2 minecraft:stone
setblock -4 218 2 minecraft:andesite
fill 9 218 2 11 219 2 minecraft:cobblestone
fill 16 218 2 17 218 2 minecraft:tuff
fill 24 218 2 26 218 3 minecraft:cobblestone
fill 27 218 2 27 218 3 minecraft:andesite
setblock -28 218 3 minecraft:amethyst_block
fill -27 218 3 -27 220 4 minecraft:andesite
fill -7 218 3 -6 220 3 minecraft:andesite
fill 10 218 3 11 219 3 minecraft:cobblestone
fill 23 218 3 23 219 5 minecraft:stone
fill -20 218 4 -20 221 4 minecraft:stone
fill -6 218 4 1 219 4 minecraft:andesite
setblock 24 218 4 minecraft:stone
setblock 25 218 4 minecraft:dripstone_block
fill 26 218 4 26 218 7 minecraft:andesite
setblock 27 218 4 minecraft:dripstone_block
fill -27 218 5 -25 219 5 minecraft:stone
fill -20 218 5 -20 219 7 minecraft:cobblestone
fill -19 218 5 -19 221 5 minecraft:stone
fill -16 218 5 -15 219 5 minecraft:stone
fill -11 218 5 -11 218 7 minecraft:tuff
fill -10 218 5 -10 220 5 minecraft:stone
fill -2 218 5 -1 219 5 minecraft:stone
fill 0 218 5 1 218 6 minecraft:cobblestone
fill 24 218 5 25 218 6 minecraft:andesite
fill 27 218 5 27 218 8 minecraft:andesite
fill -26 218 6 -26 220 7 minecraft:stone
fill -19 218 6 -19 218 7 minecraft:cobblestone
fill -18 218 6 -18 220 8 minecraft:stone
fill -16 218 6 -15 219 7 minecraft:andesite
fill -12 218 6 -12 220 6 minecraft:tuff
fill -10 218 6 -10 218 7 minecraft:tuff
setblock 22 218 6 minecraft:stone
fill 23 218 6 23 219 7 minecraft:andesite
fill -25 218 7 -25 221 9 minecraft:stone
fill 11 218 7 12 220 7 minecraft:tuff
fill 19 218 7 22 220 7 minecraft:andesite
fill 24 218 7 24 218 12 minecraft:stone
fill 25 218 7 25 221 7 minecraft:andesite
fill -20 218 8 -20 219 8 minecraft:stone
fill -16 218 8 -15 218 8 minecraft:stone
fill -11 218 8 -10 218 9 minecraft:stone
fill 1 218 8 2 218 9 minecraft:tuff
fill 3 218 8 3 221 10 minecraft:stone
fill 11 218 8 12 218 8 minecraft:stone
fill 22 218 8 23 218 8 minecraft:stone
setblock 25 218 8 minecraft:dripstone_block
fill 26 218 8 26 218 9 minecraft:stone
setblock -18 218 9 minecraft:cobblestone
fill -15 218 9 -15 220 10 minecraft:stone
fill -13 218 9 -13 220 10 minecraft:stone
fill 12 218 9 12 220 9 minecraft:stone
fill 20 218 9 21 220 9 minecraft:stone
fill 25 218 9 25 220 10 minecraft:stone
fill -25 218 10 -25 219 11 minecraft:andesite
fill -24 218 10 -24 221 13 minecraft:stone
fill -20 218 10 -19 220 10 minecraft:stone
fill -12 218 10 -12 220 10 minecraft:stone
fill -10 218 10 -10 221 10 minecraft:stone
fill -4 218 10 -4 220 10 minecraft:andesite
fill 2 218 10 2 219 10 minecraft:tuff
setblock 23 218 10 minecraft:cobblestone
fill 11 218 11 11 219 11 minecraft:stone
fill 12 218 11 13 220 11 minecraft:andesite
fill 14 218 11 14 220 11 minecraft:stone
fill 20 218 11 21 219 11 minecraft:cobblestone
fill -22 218 12 -21 220 13 minecraft:stone
fill -10 218 12 -10 221 12 minecraft:stone
fill -2 218 12 -2 220 13 minecraft:stone
fill 15 218 12 16 220 12 minecraft:stone
fill 20 218 12 21 218 12 minecraft:stone
fill 22 218 12 23 219 12 minecraft:cobblestone
fill -23 218 13 -23 221 14 minecraft:stone
fill -1 218 13 -1 219 13 minecraft:stone
fill 15 218 13 16 218 13 minecraft:andesite
fill 17 218 13 17 219 13 minecraft:stone
fill 21 218 13 23 219 14 minecraft:stone
fill -22 218 14 -22 221 15 minecraft:stone
fill -6 218 14 -6 220 14 minecraft:stone
fill -5 218 14 -5 220 14 minecraft:andesite
fill -1 218 14 -1 219 15 minecraft:cobblestone
fill 11 218 14 15 220 14 minecraft:stone
setblock 16 218 14 minecraft:andesite
fill -21 218 15 -21 220 19 minecraft:stone
fill -12 218 15 -11 220 15 minecraft:andesite
fill -4 218 15 -4 219 15 minecraft:cobblestone
fill 0 218 15 0 219 15 minecraft:tuff
fill 5 218 15 5 219 16 minecraft:andesite
fill 22 218 15 22 220 17 minecraft:stone
fill -20 218 16 -20 221 16 minecraft:stone
setblock -12 218 16 minecraft:stone
setblock -20 218 17 minecraft:dripstone_block
fill -19 218 17 -19 221 18 minecraft:stone
setblock 20 218 17 minecraft:andesite
fill 21 218 17 21 220 17 minecraft:stone
fill -20 218 18 -20 220 20 minecraft:stone
fill -13 218 18 -13 218 19 minecraft:stone
fill -12 218 18 -12 221 18 minecraft:andesite
fill 9 218 18 9 219 18 minecraft:tuff
fill -18 218 19 -18 220 19 minecraft:stone
fill 1 218 19 6 219 19 minecraft:stone
fill 7 218 19 8 220 19 minecraft:tuff
fill 21 218 19 21 220 20 minecraft:stone
fill -19 218 20 -19 220 21 minecraft:stone
fill -13 218 20 -13 221 20 minecraft:andesite
fill -10 218 20 -10 218 21 minecraft:andesite
fill -9 218 20 -9 221 21 minecraft:stone
fill 8 218 20 8 219 22 minecraft:stone
fill -13 218 21 -13 218 23 minecraft:stone
fill 3 218 21 3 218 22 minecraft:stone
fill 4 218 21 4 219 23 minecraft:tuff
fill 20 218 21 20 220 21 minecraft:stone
fill -18 218 22 -18 219 23 minecraft:stone
fill 16 218 22 17 221 22 minecraft:stone
setblock 18 218 22 minecraft:amethyst_block
fill 19 218 22 19 220 22 minecraft:stone
fill -17 218 23 -17 220 24 minecraft:stone
fill -12 218 23 -12 218 25 minecraft:cobblestone
setblock -3 218 23 minecraft:cobblestone
fill -2 218 23 -2 221 24 minecraft:stone
fill 5 218 23 5 220 24 minecraft:tuff
fill 6 218 23 6 220 23 minecraft:stone
fill 14 218 23 16 221 23 minecraft:stone
setblock 40 218 23 minecraft:cobblestone
fill 42 218 23 42 219 24 minecraft:andesite
fill -16 218 24 -14 220 24 minecraft:stone
fill -13 218 24 -13 219 25 minecraft:cobblestone
fill -5 218 24 -5 221 25 minecraft:stone
setblock -3 218 24 minecraft:stone
fill 6 218 24 6 219 24 minecraft:tuff
fill 7 218 24 8 220 24 minecraft:stone
fill 13 218 24 13 220 26 minecraft:stone
setblock 14 218 24 minecraft:dripstone_block
fill 39 218 24 39 221 25 minecraft:cobblestone
fill -16 218 25 -16 220 25 minecraft:stone
setblock -15 218 25 minecraft:dripstone_block
fill -14 218 25 -14 219 25 minecraft:cobblestone
fill -11 218 25 -11 218 26 minecraft:stone
fill 8 218 25 9 219 27 minecraft:stone
fill 12 218 25 12 218 27 minecraft:stone
fill -10 218 26 -10 219 27 minecraft:stone
fill -4 218 26 -4 221 26 minecraft:stone
fill -1 218 26 -1 220 26 minecraft:tuff
fill 1 218 26 1 220 26 minecraft:tuff
fill 2 218 26 7 218 27 minecraft:stone
fill 10 218 26 10 220 27 minecraft:stone
fill 39 218 26 39 222 26 minecraft:stone
fill 41 218 26 41 222 26 minecraft:stone
setblock -9 218 27 minecraft:amethyst_block
fill -8 218 27 -7 219 28 minecraft:andesite
fill -6 218 27 -5 218 27 minecraft:cobblestone
fill -4 218 27 -3 221 27 minecraft:tuff
fill 11 218 27 11 219 27 minecraft:stone
setblock -9 218 28 minecraft:stone
fill -6 218 28 -6 219 28 minecraft:cobblestone
setblock -5 218 28 minecraft:amethyst_block
setblock -4 218 28 minecraft:cobblestone
fill -3 218 28 -3 221 28 minecraft:tuff
setblock 2 218 28 minecraft:tuff
fill -3 218 29 -2 218 29 minecraft:stone
fill 1 218 29 1 220 29 minecraft:tuff
setblock -2 218 30 minecraft:dripstone_block
fill -1 218 30 0 220 30 minecraft:tuff
fill 36 219 -37 37 220 -37 minecraft:tuff
setblock 34 219 -36 minecraft:stone
fill 35 219 -36 35 220 -36 minecraft:tuff
setblock 38 219 -36 minecraft:tuff
fill 39 219 -36 41 220 -36 minecraft:stone
fill 33 219 -35 33 221 -35 minecraft:stone
