setblock -8 214 -19 minecraft:dripstone_block
fill -7 214 -19 -7 221 -18 minecraft:stone
fill -1 214 -19 -1 221 -18 minecraft:stone
fill 1 214 -19 1 220 -18 minecraft:stone
fill 10 214 -19 10 220 -15 minecraft:stone
fill -8 214 -18 -8 221 -18 minecraft:stone
fill 0 214 -18 0 221 -18 minecraft:stone
fill -16 214 -17 -14 215 -16 minecraft:stone
setblock -7 214 -17 minecraft:dripstone_block
fill 9 214 -17 9 220 -13 minecraft:stone
fill -17 214 -16 -17 218 -15 minecraft:stone
fill -13 214 -16 -13 214 -13 minecraft:stone
fill -12 214 -16 -11 214 -16 minecraft:dripstone_block
fill -10 214 -16 -7 220 -16 minecraft:stone
setblock 8 214 -16 minecraft:andesite
fill 11 214 -16 11 221 -15 minecraft:stone
fill -14 214 -15 -14 221 -15 minecraft:stone
fill -12 214 -15 -10 214 -15 minecraft:stone
fill -3 214 -15 -3 218 -15 minecraft:cobblestone
fill 4 214 -15 4 219 -15 minecraft:cobblestone
fill 8 214 -15 8 220 -14 minecraft:stone
fill 12 214 -15 13 219 -15 minecraft:stone
setblock 14 214 -15 minecraft:amethyst_block
fill 15 214 -15 16 218 -15 minecraft:stone
setblock -17 214 -14 minecraft:dripstone_block
fill -16 214 -14 -16 220 -14 minecraft:stone
fill -12 214 -14 -12 215 -14 minecraft:stone
fill 7 214 -14 7 215 -14 minecraft:cobblestone
fill 15 214 -14 15 220 -14 minecraft:stone
fill 16 214 -14 16 215 -14 minecraft:tuff
fill 17 214 -14 17 220 -14 minecraft:stone
fill -17 214 -13 -16 214 -13 minecraft:tuff
fill -12 214 -13 -11 214 -13 minecraft:andesite
fill -10 214 -13 -10 221 -13 minecraft:stone
fill -7 214 -13 -7 220 -13 minecraft:stone
fill -6 214 -13 -5 214 -12 minecraft:cobblestone
fill -4 214 -13 -4 220 -13 minecraft:stone
fill 15 214 -13 15 220 -12 minecraft:tuff
fill 17 214 -13 17 220 -12 minecraft:tuff
setblock 18 214 -13 minecraft:amethyst_block
fill -18 214 -12 -18 221 -11 minecraft:stone
fill -13 214 -12 -13 216 -12 minecraft:andesite
fill -7 214 -12 -7 216 -12 minecraft:cobblestone
setblock -4 214 -12 minecraft:cobblestone
fill -3 214 -12 -3 220 -12 minecraft:stone
fill 18 214 -12 19 219 -12 minecraft:stone
fill -16 214 -11 -13 214 -11 minecraft:stone
fill -12 214 -11 -12 216 -11 minecraft:andesite
setblock -6 214 -11 minecraft:stone
fill 19 214 -11 20 219 -10 minecraft:stone
fill -21 214 -10 -19 220 -10 minecraft:stone
fill -17 214 -10 -17 214 -9 minecraft:cobblestone
fill -8 214 -10 -8 217 -10 minecraft:stone
fill -1 214 -10 -1 221 -10 minecraft:stone
fill 1 214 -10 1 221 -10 minecraft:stone
fill -22 214 -9 -22 220 -8 minecraft:stone
fill -21 214 -9 -19 214 -9 minecraft:andesite
fill -18 214 -9 -18 216 -9 minecraft:cobblestone
fill -16 214 -9 -16 221 -8 minecraft:stone
setblock 1 214 -9 minecraft:andesite
fill 3 214 -9 3 216 -9 minecraft:stone
fill 4 214 -9 5 220 -9 minecraft:tuff
fill 18 214 -9 18 220 -8 minecraft:stone
fill 20 214 -9 22 220 -8 minecraft:stone
fill -21 214 -8 -21 216 -7 minecraft:andesite
fill -17 214 -8 -17 221 -7 minecraft:stone
fill -10 214 -8 -9 219 -8 minecraft:stone
fill -4 214 -8 -3 215 -8 minecraft:stone
fill -2 214 -8 -2 217 -8 minecraft:andesite
fill 23 214 -8 24 220 -8 minecraft:stone
setblock -22 214 -7 minecraft:cobblestone
fill -10 214 -7 -10 220 -7 minecraft:stone
fill -1 214 -7 -1 217 -7 minecraft:andesite
setblock 1 214 -7 minecraft:andesite
fill 7 214 -7 7 216 -7 minecraft:tuff
fill 15 214 -7 15 217 -7 minecraft:andesite
fill 20 214 -7 20 217 -6 minecraft:stone
fill 21 214 -7 22 214 -7 minecraft:dripstone_block
fill 23 214 -7 23 220 -6 minecraft:stone
fill 24 214 -7 24 214 -6 minecraft:cobblestone
fill -21 214 -6 -21 215 -6 minecraft:cobblestone
fill -20 214 -6 -20 219 -6 minecraft:andesite
fill 0 214 -6 0 219 -4 minecraft:andesite
fill 7 214 -6 7 221 -4 minecraft:stone
fill 19 214 -6 19 214 -4 minecraft:stone
fill 22 214 -6 22 220 -6 minecraft:stone
fill -21 214 -5 -20 215 -5 minecraft:stone
fill -18 214 -5 -18 219 -4 minecraft:andesite
fill 23 214 -5 24 215 -4 minecraft:andesite
setblock -20 214 -4 minecraft:amethyst_block
fill -17 214 -4 -17 219 -4 minecraft:andesite
fill -8 214 -4 -8 220 -3 minecraft:stone
fill 1 214 -4 1 216 -4 minecraft:stone
fill -20 214 -3 -20 216 -1 minecraft:stone
fill -18 214 -3 -17 214 -3 minecraft:stone
fill -16 214 -3 -16 220 -3 minecraft:andesite
fill -9 214 -3 -9 218 -2 minecraft:stone
setblock 9 214 -3 minecraft:stone
fill 13 214 -3 16 218 -3 minecraft:stone
setblock 19 214 -3 minecraft:amethyst_block
fill -17 214 -2 -16 215 -2 minecraft:stone
fill -8 214 -2 -8 214 -1 minecraft:andesite
fill -7 214 -2 -7 220 -1 minecraft:stone
setblock 0 214 -2 minecraft:andesite
fill 1 214 -2 1 220 -2 minecraft:stone
setblock 10 214 -2 minecraft:cobblestone
fill 11 214 -2 11 220 -2 minecraft:stone
fill 14 214 -2 15 220 -2 minecraft:stone
setblock 16 214 -2 minecraft:tuff
fill 17 214 -2 17 220 -2 minecraft:stone
fill 20 214 -2 20 218 -1 minecraft:stone
fill -23 214 -1 -22 214 0 minecraft:tuff
fill -19 214 -1 -19 216 5 minecraft:stone
fill -17 214 -1 -17 217 -1 minecraft:stone
setblock 15 214 -1 minecraft:tuff
fill 19 214 -1 19 219 0 minecraft:stone
setblock 21 214 -1 minecraft:dripstone_block
fill -24 214 0 -24 217 0 minecraft:tuff
fill 16 214 0 16 216 0 minecraft:tuff
fill 17 214 0 17 220 0 minecraft:stone
setblock 21 214 0 minecraft:amethyst_block
fill 21 214 1 21 216 2 minecraft:stone
fill 6 214 2 7 220 3 minecraft:stone
fill 20 214 2 20 220 2 minecraft:stone
fill -18 214 3 -18 214 5 minecraft:stone
fill 5 214 3 5 220 3 minecraft:stone
fill 12 214 3 12 215 4 minecraft:tuff
fill 13 214 3 13 220 3 minecraft:stone
fill 16 214 3 16 218 4 minecraft:stone
fill -17 214 4 -17 221 5 minecraft:stone
fill -16 214 5 -16 216 5 minecraft:stone
fill -13 214 5 -13 221 6 minecraft:stone
fill 3 214 5 4 214 5 minecraft:cobblestone
fill 12 214 5 12 214 9 minecraft:stone
setblock -19 214 6 minecraft:amethyst_block
fill -18 214 6 -17 215 7 minecraft:cobblestone
fill -12 214 6 -11 216 6 minecraft:stone
fill -19 214 7 -19 214 8 minecraft:stone
fill -16 214 7 -16 217 8 minecraft:stone
fill -13 214 7 -13 215 7 minecraft:andesite
fill 0 214 7 1 215 7 minecraft:stone
fill 21 214 7 21 217 7 minecraft:stone
fill -18 214 8 -18 217 9 minecraft:cobblestone
fill -1 214 8 0 214 8 minecraft:stone
fill 1 214 8 3 217 8 minecraft:tuff
fill 18 214 8 18 220 8 minecraft:stone
fill 20 214 8 20 218 8 minecraft:stone
fill -19 214 9 -19 218 9 minecraft:cobblestone
setblock -16 214 9 minecraft:cobblestone
fill 1 214 9 2 214 9 minecraft:stone
fill 4 214 9 4 215 9 minecraft:tuff
fill 18 214 9 18 216 9 minecraft:cobblestone
fill 19 214 9 19 214 10 minecraft:stone
setblock -19 214 10 minecraft:andesite
fill -18 214 10 -16 215 10 minecraft:stone
fill 2 214 10 2 214 11 minecraft:stone
fill 18 214 10 18 215 10 minecraft:stone
setblock -15 214 11 minecraft:dripstone_block
fill 15 214 11 15 215 12 minecraft:andesite
setblock 18 214 11 minecraft:dripstone_block
fill -15 214 12 -15 220 14 minecraft:stone
fill 18 214 12 18 215 12 minecraft:andesite
fill -13 214 13 -13 220 13 minecraft:andesite
fill -11 214 13 -11 220 13 minecraft:andesite
fill -3 214 13 -3 215 13 minecraft:stone
fill -2 214 13 -2 217 13 minecraft:cobblestone
fill 18 214 13 18 219 14 minecraft:stone
fill -16 214 14 -16 220 17 minecraft:stone
fill -13 214 14 -13 216 15 minecraft:stone
fill -11 214 14 -11 215 14 minecraft:stone
fill 17 214 14 17 220 16 minecraft:stone
fill -17 214 15 -17 220 15 minecraft:stone
fill -2 214 15 -2 219 15 minecraft:cobblestone
fill 4 214 15 4 218 15 minecraft:stone
fill 11 214 15 16 219 15 minecraft:stone
setblock 18 214 15 minecraft:dripstone_block
fill 11 214 16 11 220 20 minecraft:stone
fill 14 214 16 15 220 16 minecraft:stone
fill 16 214 16 16 215 16 minecraft:tuff
fill -15 214 17 -12 218 17 minecraft:stone
fill 10 214 17 10 221 17 minecraft:stone
setblock 14 214 17 minecraft:dripstone_block
fill 15 214 17 16 220 17 minecraft:stone
setblock -16 214 18 minecraft:dripstone_block
fill -15 214 18 -14 220 18 minecraft:stone
fill -11 214 18 -10 218 18 minecraft:stone
fill -15 214 19 -15 220 19 minecraft:stone
fill -9 214 19 -7 214 19 minecraft:andesite
fill -6 214 19 -3 221 19 minecraft:stone
fill 9 214 19 10 218 20 minecraft:stone
fill 12 214 19 12 220 20 minecraft:stone
fill -3 214 20 0 221 20 minecraft:stone
setblock 1 214 20 minecraft:amethyst_block
fill 2 214 20 2 219 22 minecraft:stone
fill 5 214 20 8 216 22 minecraft:stone
setblock -2 214 21 minecraft:dripstone_block
fill -1 214 21 1 220 22 minecraft:stone
fill 3 214 21 4 217 22 minecraft:stone
fill 9 214 21 9 220 21 minecraft:stone
fill 0 214 23 1 220 23 minecraft:stone
setblock 2 214 23 minecraft:amethyst_block
fill 3 214 23 3 218 24 minecraft:stone
setblock 4 214 23 minecraft:dripstone_block
fill 5 214 23 7 214 23 minecraft:stone
fill 8 214 23 8 215 23 minecraft:tuff
fill 2 214 24 2 219 24 minecraft:stone
fill 4 214 24 4 218 24 minecraft:stone
setblock 5 214 24 minecraft:amethyst_block
fill 0 215 -25 0 220 -25 minecraft:stone
fill -2 215 -24 -1 220 -24 minecraft:stone
fill 1 215 -24 2 220 -24 minecraft:stone
fill -3 215 -23 -2 220 -23 minecraft:stone
fill 2 215 -23 3 215 -22 minecraft:stone
fill 6 215 -23 6 220 -23 minecraft:stone
setblock 7 215 -23 minecraft:dripstone_block
fill 8 215 -23 8 217 -23 minecraft:stone
fill -7 215 -22 -5 220 -22 minecraft:stone
setblock -1 215 -22 minecraft:dripstone_block
fill 0 215 -22 1 220 -22 minecraft:stone
fill 4 215 -22 5 215 -22 minecraft:stone
