fill -17 221 21 -16 221 21 minecraft:rooted_dirt
fill -1 221 21 1 221 21 minecraft:stone
setblock 2 221 21 minecraft:rooted_dirt
setblock 7 221 21 minecraft:rooted_dirt
fill 9 221 21 11 223 21 minecraft:dirt
setblock 12 221 21 minecraft:rooted_dirt
fill 13 221 21 13 223 21 minecraft:dirt
fill -21 221 22 -20 221 22 minecraft:rooted_dirt
fill -19 221 22 -19 223 24 minecraft:dirt
setblock -18 221 22 minecraft:rooted_dirt
fill -17 221 22 -16 223 22 minecraft:dirt
setblock -1 221 22 minecraft:stone
fill 0 221 22 2 223 22 minecraft:dirt
fill 7 221 22 7 223 22 minecraft:dirt
fill 9 221 22 9 221 23 minecraft:rooted_dirt
fill 10 221 22 10 223 26 minecraft:dirt
setblock 11 221 22 minecraft:rooted_dirt
fill 12 221 22 13 221 22 minecraft:stone
fill 18 221 22 19 221 22 minecraft:rooted_dirt
setblock -20 221 23 minecraft:rooted_dirt
fill -18 221 23 -17 223 25 minecraft:dirt
fill -16 221 23 -16 221 24 minecraft:rooted_dirt
fill -14 221 23 -14 221 24 minecraft:stone
fill -1 221 23 0 223 25 minecraft:dirt
setblock 1 221 23 minecraft:rooted_dirt
fill 2 221 23 2 223 25 minecraft:dirt
setblock 4 221 23 minecraft:rooted_dirt
setblock 7 221 23 minecraft:rooted_dirt
fill 11 221 23 11 221 25 minecraft:stone
setblock 17 221 23 minecraft:stone
fill 18 221 23 19 223 23 minecraft:dirt
fill 37 221 23 39 221 23 minecraft:stone
fill 43 221 23 43 222 23 minecraft:stone
fill -8 221 24 -8 223 25 minecraft:dirt
fill -4 221 24 -3 221 24 minecraft:stone
fill 1 221 24 1 223 26 minecraft:dirt
fill 4 221 24 4 223 24 minecraft:dirt
fill 7 221 24 7 223 24 minecraft:dirt
fill 9 221 24 9 223 26 minecraft:dirt
fill 12 221 24 13 221 25 minecraft:stone
setblock 17 221 24 minecraft:andesite
fill 18 221 24 18 221 25 minecraft:stone
fill 19 221 24 19 223 24 minecraft:dirt
setblock 37 221 24 minecraft:amethyst_block
fill 40 221 24 40 222 24 minecraft:stone
fill 42 221 24 42 222 25 minecraft:stone
fill 43 221 24 43 222 26 minecraft:andesite
fill -16 221 25 -16 223 27 minecraft:dirt
setblock -13 221 25 minecraft:stone
setblock 4 221 25 minecraft:rooted_dirt
setblock 7 221 25 minecraft:rooted_dirt
fill 37 221 25 37 221 26 minecraft:stone
setblock -17 221 26 minecraft:rooted_dirt
setblock -14 221 26 minecraft:stone
fill -13 221 26 -13 221 28 minecraft:mossy_cobblestone
fill -8 221 26 -8 221 27 minecraft:mossy_cobblestone
setblock -6 221 26 minecraft:mossy_cobblestone
fill -1 221 26 -1 221 27 minecraft:rooted_dirt
fill 0 221 26 0 223 29 minecraft:dirt
setblock 2 221 26 minecraft:rooted_dirt
fill 4 221 26 4 221 27 minecraft:stone
fill 7 221 26 7 223 26 minecraft:dirt
fill 11 221 26 13 223 26 minecraft:dirt
setblock 17 221 26 minecraft:mossy_cobblestone
setblock -14 221 27 minecraft:mossy_cobblestone
setblock -9 221 27 minecraft:mossy_cobblestone
fill -6 221 27 -6 221 29 minecraft:stone
fill -2 221 27 -2 223 29 minecraft:dirt
setblock 1 221 27 minecraft:rooted_dirt
fill 2 221 27 2 223 27 minecraft:dirt
setblock 3 221 27 minecraft:stone
fill 8 221 27 9 221 27 minecraft:stone
fill 10 221 27 12 221 27 minecraft:rooted_dirt
fill 13 221 27 13 223 28 minecraft:dirt
fill 14 221 27 15 221 27 minecraft:stone
fill 38 221 27 38 222 27 minecraft:stone
setblock 42 221 27 minecraft:stone
fill -9 221 28 -8 221 28 minecraft:andesite
setblock -7 221 28 minecraft:stone
fill -1 221 28 -1 223 29 minecraft:dirt
fill 1 221 28 1 223 31 minecraft:dirt
setblock 2 221 28 minecraft:rooted_dirt
fill 3 221 28 4 221 28 minecraft:andesite
fill 9 221 28 9 221 29 minecraft:stone
fill 10 221 28 10 223 29 minecraft:dirt
fill 11 221 28 12 221 28 minecraft:rooted_dirt
setblock 14 221 28 minecraft:dripstone_block
fill 40 221 28 41 222 28 minecraft:stone
fill -13 221 29 -11 221 29 minecraft:stone
setblock -10 221 29 minecraft:andesite
setblock -8 221 29 minecraft:andesite
setblock -3 221 29 minecraft:tuff
fill 2 221 29 2 223 31 minecraft:dirt
fill 3 221 29 3 221 30 minecraft:stone
setblock 4 221 29 minecraft:andesite
fill 5 221 29 7 221 29 minecraft:stone
fill 11 221 29 11 223 29 minecraft:dirt
setblock -12 221 30 minecraft:stone
setblock -11 221 30 minecraft:dripstone_block
fill -6 221 30 -5 221 30 minecraft:mossy_cobblestone
fill -4 221 30 -3 223 30 minecraft:dirt
fill -2 221 30 0 221 30 minecraft:rooted_dirt
setblock 4 221 30 minecraft:amethyst_block
setblock 5 221 30 minecraft:dripstone_block
setblock 6 221 30 minecraft:stone
setblock 7 221 30 minecraft:amethyst_block
fill -9 221 31 -8 221 31 minecraft:stone
setblock -6 221 31 minecraft:rooted_dirt
fill -5 221 31 -5 223 31 minecraft:dirt
fill -4 221 31 -3 221 31 minecraft:rooted_dirt
fill -2 221 31 -2 223 31 minecraft:dirt
setblock -1 221 31 minecraft:rooted_dirt
fill 0 221 31 0 223 31 minecraft:dirt
fill -5 222 -30 1 223 -30 minecraft:dirt
fill 3 222 -30 3 223 -30 minecraft:dirt
fill -10 222 -29 -10 223 -29 minecraft:dirt
fill -6 222 -29 -6 223 -29 minecraft:dirt
fill -2 222 -29 -2 223 -29 minecraft:dirt
fill -1 222 -29 -1 222 -27 minecraft:rooted_dirt
fill 0 222 -29 0 223 -29 minecraft:dirt
setblock 1 222 -29 minecraft:rooted_dirt
fill 2 222 -29 2 223 -29 minecraft:dirt
fill -13 222 -28 -11 223 -28 minecraft:dirt
fill -8 222 -28 -7 223 -27 minecraft:dirt
fill -3 222 -28 -3 223 -28 minecraft:dirt
setblock 0 222 -28 minecraft:rooted_dirt
fill 1 222 -28 1 222 -27 minecraft:dirt
fill 9 222 -28 9 223 -28 minecraft:dirt
setblock 10 222 -28 minecraft:rooted_dirt
fill -15 222 -27 -12 223 -27 minecraft:dirt
setblock -11 222 -27 minecraft:rooted_dirt
fill -5 222 -27 -4 222 -25 minecraft:dirt
setblock 0 222 -27 minecraft:dirt
fill 3 222 -27 3 223 -27 minecraft:dirt
fill 5 222 -27 5 223 -27 minecraft:dirt
fill 10 222 -27 12 223 -27 minecraft:dirt
fill -13 222 -26 -12 223 -26 minecraft:dirt
setblock -3 222 -26 minecraft:dirt
fill 7 222 -26 7 223 -26 minecraft:dirt
setblock 10 222 -26 minecraft:rooted_dirt
fill 11 222 -26 12 223 -24 minecraft:dirt
setblock 13 222 -26 minecraft:rooted_dirt
fill 14 222 -26 14 223 -26 minecraft:dirt
setblock -18 222 -25 minecraft:rooted_dirt
fill -17 222 -25 -17 223 -24 minecraft:dirt
fill -15 222 -25 -14 223 -25 minecraft:dirt
fill -12 222 -25 -12 223 -24 minecraft:dirt
fill -10 222 -25 -10 223 -25 minecraft:dirt
fill -8 222 -25 -6 222 -25 minecraft:dirt
setblock -3 222 -25 minecraft:rooted_dirt
fill 1 222 -25 1 222 -23 minecraft:dirt
fill 4 222 -25 4 222 -24 minecraft:dirt
fill 10 222 -25 10 223 -22 minecraft:dirt
fill 13 222 -25 13 223 -25 minecraft:dirt
fill 14 222 -25 15 222 -25 minecraft:rooted_dirt
fill 16 222 -25 16 223 -25 minecraft:dirt
fill -41 222 -24 -41 226 -24 minecraft:stone
fill -40 222 -24 -40 226 -24 minecraft:tuff
fill -20 222 -24 -18 223 -23 minecraft:dirt
fill -11 222 -24 -11 223 -24 minecraft:dirt
fill -9 222 -24 -8 223 -23 minecraft:dirt
fill -7 222 -24 -6 222 -24 minecraft:rooted_dirt
fill -5 222 -24 -5 222 -22 minecraft:dirt
setblock -4 222 -24 minecraft:rooted_dirt
fill -3 222 -24 -3 222 -22 minecraft:dirt
fill 3 222 -24 3 222 -23 minecraft:dirt
setblock 5 222 -24 minecraft:dirt
fill 13 222 -24 13 222 -22 minecraft:rooted_dirt
fill 14 222 -24 15 223 -22 minecraft:dirt
fill 16 222 -24 16 222 -23 minecraft:rooted_dirt
fill 17 222 -24 18 223 -22 minecraft:dirt
fill -42 222 -23 -42 226 -23 minecraft:stone
fill -39 222 -23 -39 226 -23 minecraft:tuff
setblock -21 222 -23 minecraft:rooted_dirt
fill -7 222 -23 -7 222 -22 minecraft:rooted_dirt
fill -6 222 -23 -6 222 -22 minecraft:dirt
setblock -4 222 -23 minecraft:dirt
setblock -1 222 -23 minecraft:dirt
fill 4 222 -23 5 222 -23 minecraft:rooted_dirt
fill 9 222 -23 9 223 -23 minecraft:dirt
fill 11 222 -23 11 223 -23 minecraft:dirt
setblock 12 222 -23 minecraft:rooted_dirt
fill 19 222 -23 20 223 -21 minecraft:dirt
fill -39 222 -22 -38 223 -22 minecraft:cobblestone
fill -22 222 -22 -20 223 -21 minecraft:dirt
fill -19 222 -22 -18 222 -22 minecraft:rooted_dirt
fill -17 222 -22 -17 223 -22 minecraft:dirt
fill -12 222 -22 -10 223 -22 minecraft:dirt
fill -9 222 -22 -9 222 -21 minecraft:rooted_dirt
fill -8 222 -22 -8 222 -21 minecraft:dirt
fill 0 222 -22 0 222 -12 minecraft:dirt
setblock 7 222 -22 minecraft:dirt
setblock 11 222 -22 minecraft:rooted_dirt
fill 12 222 -22 12 223 -21 minecraft:dirt
fill 16 222 -22 16 223 -22 minecraft:dirt
fill 21 222 -22 22 223 -22 minecraft:dirt
setblock -42 222 -21 minecraft:andesite
fill -41 222 -21 -41 225 -21 minecraft:cobblestone
fill -38 222 -21 -37 222 -21 minecraft:cobblestone
fill -19 222 -21 -18 223 -19 minecraft:dirt
fill -15 222 -21 -12 223 -21 minecraft:dirt
setblock -11 222 -21 minecraft:rooted_dirt
fill -10 222 -21 -10 223 -20 minecraft:dirt
fill -7 222 -21 -7 222 -16 minecraft:dirt
fill -1 222 -21 -1 222 -17 minecraft:dirt
fill 1 222 -21 2 222 -21 minecraft:dirt
fill 4 222 -21 6 222 -21 minecraft:dirt
fill 11 222 -21 11 223 -21 minecraft:dirt
fill 13 222 -21 14 223 -19 minecraft:dirt
fill 17 222 -21 17 223 -21 minecraft:dirt
fill 21 222 -21 21 223 -18 minecraft:dirt
fill 23 222 -21 23 223 -21 minecraft:dirt
fill -39 222 -20 -38 224 -20 minecraft:stone
fill -24 222 -20 -24 223 -20 minecraft:dirt
setblock -22 222 -20 minecraft:rooted_dirt
fill -21 222 -20 -20 223 -20 minecraft:dirt
fill -17 222 -20 -17 223 -20 minecraft:dirt
setblock -15 222 -20 minecraft:rooted_dirt
fill -14 222 -20 -11 223 -20 minecraft:dirt
setblock -9 222 -20 minecraft:dirt
