setblock 20 221 3 minecraft:rooted_dirt
fill 21 221 3 21 222 8 minecraft:dirt
fill -29 221 4 -29 223 4 minecraft:dirt
setblock -28 221 4 minecraft:rooted_dirt
fill -27 221 4 -27 223 6 minecraft:dirt
fill -26 221 4 -26 221 5 minecraft:rooted_dirt
fill -25 221 4 -25 223 4 minecraft:dirt
setblock -21 221 4 minecraft:tuff
setblock -7 221 4 minecraft:rooted_dirt
fill -6 221 4 -6 223 6 minecraft:dirt
setblock -5 221 4 minecraft:rooted_dirt
fill -4 221 4 -3 223 5 minecraft:dirt
setblock -2 221 4 minecraft:rooted_dirt
fill -1 221 4 3 223 4 minecraft:dirt
setblock 4 221 4 minecraft:tuff
fill 5 221 4 5 223 5 minecraft:dirt
setblock 10 221 4 minecraft:rooted_dirt
fill 11 221 4 11 223 10 minecraft:dirt
fill 12 221 4 12 221 6 minecraft:rooted_dirt
setblock 15 221 4 minecraft:tuff
fill 20 221 4 20 222 4 minecraft:dirt
setblock 30 221 4 minecraft:rooted_dirt
setblock -29 221 5 minecraft:rooted_dirt
fill -28 221 5 -28 223 6 minecraft:dirt
setblock -25 221 5 minecraft:stone
fill -16 221 5 -16 221 6 minecraft:mossy_cobblestone
fill -15 221 5 -14 221 5 minecraft:stone
fill -11 221 5 -10 221 5 minecraft:rooted_dirt
fill -9 221 5 -9 223 6 minecraft:dirt
fill -7 221 5 -7 223 6 minecraft:dirt
fill -5 221 5 -5 223 5 minecraft:dirt
fill -2 221 5 0 223 5 minecraft:dirt
setblock 1 221 5 minecraft:rooted_dirt
fill 2 221 5 2 223 5 minecraft:dirt
setblock 7 221 5 minecraft:rooted_dirt
fill 10 221 5 10 223 6 minecraft:dirt
setblock 13 221 5 minecraft:rooted_dirt
setblock 17 221 5 minecraft:stone
fill 19 221 5 20 221 5 minecraft:rooted_dirt
fill -26 221 6 -26 223 6 minecraft:dirt
fill -20 221 6 -18 221 6 minecraft:stone
setblock -17 221 6 minecraft:mossy_cobblestone
setblock -15 221 6 minecraft:mossy_cobblestone
setblock -14 221 6 minecraft:stone
setblock -12 221 6 minecraft:stone
fill -10 221 6 -10 223 6 minecraft:dirt
fill -5 221 6 -4 221 8 minecraft:rooted_dirt
fill -3 221 6 -2 223 6 minecraft:dirt
fill -1 221 6 0 221 7 minecraft:mossy_cobblestone
fill 4 221 6 5 221 7 minecraft:stone
fill 7 221 6 7 223 8 minecraft:dirt
setblock 8 221 6 minecraft:rooted_dirt
fill 9 221 6 9 223 6 minecraft:dirt
fill 13 221 6 15 222 8 minecraft:dirt
fill 17 221 6 18 222 12 minecraft:dirt
fill 19 221 6 19 221 8 minecraft:rooted_dirt
fill 20 221 6 20 222 8 minecraft:dirt
setblock 23 221 6 minecraft:mossy_cobblestone
setblock 24 221 6 minecraft:stone
setblock 26 221 6 minecraft:stone
fill 27 221 6 27 223 6 minecraft:dirt
fill 28 221 6 29 221 6 minecraft:rooted_dirt
fill -28 221 7 -26 221 7 minecraft:stone
fill -23 221 7 -23 221 8 minecraft:mossy_cobblestone
fill -20 221 7 -19 221 8 minecraft:stone
fill -18 221 7 -16 223 8 minecraft:dirt
fill -15 221 7 -13 221 7 minecraft:rooted_dirt
setblock -10 221 7 minecraft:stone
fill -3 221 7 -3 223 16 minecraft:dirt
setblock -2 221 7 minecraft:mossy_cobblestone
setblock 3 221 7 minecraft:stone
fill 8 221 7 8 223 9 minecraft:dirt
fill 9 221 7 10 221 7 minecraft:rooted_dirt
fill 12 221 7 12 223 10 minecraft:dirt
fill 16 221 7 16 223 12 minecraft:dirt
fill 22 221 7 22 221 9 minecraft:andesite
setblock 26 221 7 minecraft:andesite
fill 27 221 7 27 221 9 minecraft:rooted_dirt
fill 28 221 7 29 223 7 minecraft:dirt
setblock -28 221 8 minecraft:stone
fill -15 221 8 -14 223 8 minecraft:dirt
setblock -13 221 8 minecraft:rooted_dirt
fill 1 221 8 1 221 10 minecraft:stone
setblock 4 221 8 minecraft:stone
fill 9 221 8 9 223 8 minecraft:dirt
setblock 10 221 8 minecraft:rooted_dirt
fill 26 221 8 26 223 8 minecraft:dirt
fill 28 221 8 28 223 10 minecraft:dirt
fill -23 221 9 -23 221 10 minecraft:stone
setblock -22 221 9 minecraft:mossy_cobblestone
fill -19 221 9 -18 221 9 minecraft:rooted_dirt
fill -17 221 9 -16 223 9 minecraft:dirt
setblock -15 221 9 minecraft:rooted_dirt
fill -14 221 9 -12 223 9 minecraft:dirt
fill -11 221 9 -10 221 9 minecraft:tuff
fill -5 221 9 -4 223 14 minecraft:dirt
fill -1 221 9 -1 221 10 minecraft:tuff
fill 4 221 9 4 221 10 minecraft:mossy_cobblestone
fill 6 221 9 7 221 9 minecraft:rooted_dirt
setblock 9 221 9 minecraft:rooted_dirt
fill 10 221 9 10 223 10 minecraft:dirt
setblock 13 221 9 minecraft:rooted_dirt
fill 14 221 9 15 223 9 minecraft:dirt
fill 19 221 9 19 223 13 minecraft:dirt
fill 20 221 9 21 221 9 minecraft:rooted_dirt
fill 23 221 9 24 221 10 minecraft:stone
setblock 25 221 9 minecraft:andesite
fill -27 221 10 -27 223 10 minecraft:dirt
setblock -26 221 10 minecraft:stone
fill -22 221 10 -18 223 10 minecraft:dirt
fill -15 221 10 -15 221 13 minecraft:stone
fill -14 221 10 -13 221 10 minecraft:rooted_dirt
fill -12 221 10 -12 223 10 minecraft:dirt
fill -11 221 10 -11 221 12 minecraft:rooted_dirt
setblock 0 221 10 minecraft:tuff
setblock 5 221 10 minecraft:mossy_cobblestone
setblock 6 221 10 minecraft:stone
fill 7 221 10 7 223 11 minecraft:dirt
setblock 8 221 10 minecraft:rooted_dirt
fill 9 221 10 9 223 11 minecraft:dirt
fill 13 221 10 13 223 10 minecraft:dirt
setblock 14 221 10 minecraft:rooted_dirt
fill 15 221 10 15 223 18 minecraft:dirt
setblock 20 221 10 minecraft:rooted_dirt
fill 21 221 10 22 221 10 minecraft:stone
setblock 25 221 10 minecraft:stone
setblock 26 221 10 minecraft:andesite
fill 27 221 10 27 223 10 minecraft:dirt
setblock -27 221 11 minecraft:rooted_dirt
fill -26 221 11 -25 223 11 minecraft:dirt
fill -23 221 11 -19 223 11 minecraft:dirt
fill -18 221 11 -16 221 11 minecraft:stone
fill -13 221 11 -13 223 17 minecraft:dirt
setblock -12 221 11 minecraft:rooted_dirt
fill -6 221 11 -6 221 13 minecraft:andesite
fill -2 221 11 0 221 11 minecraft:rooted_dirt
setblock 1 221 11 minecraft:tuff
fill 8 221 11 8 223 11 minecraft:dirt
fill 10 221 11 13 221 11 minecraft:rooted_dirt
fill 14 221 11 14 223 12 minecraft:dirt
fill 20 221 11 21 221 11 minecraft:stone
fill 26 221 11 26 221 13 minecraft:stone
fill -26 221 12 -26 223 13 minecraft:dirt
setblock -25 221 12 minecraft:rooted_dirt
setblock -23 221 12 minecraft:rooted_dirt
fill -22 221 12 -21 223 13 minecraft:dirt
setblock -20 221 12 minecraft:rooted_dirt
fill -19 221 12 -19 223 13 minecraft:dirt
fill -12 221 12 -12 223 12 minecraft:dirt
fill -2 221 12 1 223 13 minecraft:dirt
fill 6 221 12 6 221 13 minecraft:stone
fill 7 221 12 10 221 12 minecraft:rooted_dirt
fill 11 221 12 13 223 12 minecraft:dirt
fill 20 221 12 21 221 12 minecraft:mossy_cobblestone
fill 22 221 12 23 221 12 minecraft:stone
setblock 27 221 12 minecraft:andesite
fill -20 221 13 -20 223 13 minecraft:dirt
setblock -12 221 13 minecraft:rooted_dirt
fill -11 221 13 -11 223 13 minecraft:dirt
setblock -10 221 13 minecraft:stone
fill 7 221 13 7 223 20 minecraft:dirt
setblock 8 221 13 minecraft:rooted_dirt
fill 9 221 13 12 223 13 minecraft:dirt
fill 13 221 13 14 221 13 minecraft:rooted_dirt
setblock 16 221 13 minecraft:rooted_dirt
fill 17 221 13 17 223 21 minecraft:dirt
setblock 18 221 13 minecraft:rooted_dirt
fill 20 221 13 21 223 14 minecraft:dirt
setblock 22 221 13 minecraft:stone
fill -20 221 14 -19 221 14 minecraft:mossy_cobblestone
fill -18 221 14 -18 221 15 minecraft:stone
setblock -16 221 14 minecraft:stone
setblock -15 221 14 minecraft:rooted_dirt
fill -14 221 14 -14 223 22 minecraft:dirt
fill -12 221 14 -12 223 15 minecraft:dirt
setblock -11 221 14 minecraft:rooted_dirt
fill -10 221 14 -10 223 16 minecraft:dirt
setblock -8 221 14 minecraft:stone
fill -6 221 14 -6 223 15 minecraft:dirt
fill -2 221 14 -1 223 14 minecraft:dirt
setblock 0 221 14 minecraft:tuff
setblock 1 221 14 minecraft:stone
fill 6 221 14 6 223 18 minecraft:dirt
fill 8 221 14 8 223 15 minecraft:dirt
setblock 9 221 14 minecraft:rooted_dirt
fill 10 221 14 10 223 14 minecraft:dirt
fill 11 221 14 13 221 15 minecraft:stone
fill 14 221 14 14 223 14 minecraft:dirt
fill 16 221 14 16 223 16 minecraft:dirt
fill 18 221 14 18 223 21 minecraft:dirt
setblock 19 221 14 minecraft:rooted_dirt
fill 22 221 14 22 223 16 minecraft:dirt
fill -21 221 15 -20 221 15 minecraft:stone
setblock -19 221 15 minecraft:mossy_cobblestone
fill -17 221 15 -15 223 15 minecraft:dirt
fill -11 221 15 -11 223 17 minecraft:dirt
fill -9 221 15 -9 223 18 minecraft:dirt
setblock -8 221 15 minecraft:rooted_dirt
fill -7 221 15 -7 223 15 minecraft:dirt
setblock -5 221 15 minecraft:rooted_dirt
fill -4 221 15 -4 223 15 minecraft:dirt
fill -2 221 15 0 221 16 minecraft:mossy_cobblestone
fill 3 221 15 3 223 18 minecraft:dirt
fill 4 221 15 5 221 15 minecraft:rooted_dirt
fill 9 221 15 9 223 15 minecraft:dirt
setblock 14 221 15 minecraft:rooted_dirt
fill 19 221 15 19 223 16 minecraft:dirt
fill 20 221 15 20 221 17 minecraft:rooted_dirt
fill 21 221 15 21 223 15 minecraft:dirt
setblock 23 221 15 minecraft:stone
setblock 25 221 15 minecraft:dripstone_block
setblock -25 221 16 minecraft:stone
fill -21 221 16 -21 221 18 minecraft:stone
fill -17 221 16 -17 223 17 minecraft:dirt
fill -16 221 16 -16 221 17 minecraft:rooted_dirt
fill -15 221 16 -15 223 17 minecraft:dirt
setblock -12 221 16 minecraft:andesite
fill -8 221 16 -8 223 17 minecraft:dirt
fill -7 221 16 -6 221 16 minecraft:rooted_dirt
fill -5 221 16 -5 223 16 minecraft:dirt
