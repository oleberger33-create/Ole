fill 2 210 -12 3 210 -12 minecraft:deepslate
fill 11 210 -12 13 219 -12 minecraft:stone
fill -10 210 -11 -10 221 -11 minecraft:stone
fill -1 210 -11 -1 211 -11 minecraft:andesite
fill 1 210 -11 2 220 -11 minecraft:stone
fill 3 210 -11 4 210 -11 minecraft:deepslate
fill 5 210 -11 7 216 -11 minecraft:stone
fill 10 210 -11 10 220 -11 minecraft:stone
fill 13 210 -11 13 220 -11 minecraft:stone
setblock -12 210 -10 minecraft:dripstone_block
setblock -11 210 -10 minecraft:deepslate
fill -9 210 -10 -8 210 -10 minecraft:cobblestone
fill -5 210 -10 -5 210 -8 minecraft:deepslate
fill 0 210 -10 0 214 -10 minecraft:andesite
fill 14 210 -10 15 218 -10 minecraft:stone
setblock -13 210 -9 minecraft:tuff
fill -9 210 -9 -9 212 -8 minecraft:cobblestone
setblock -6 210 -9 minecraft:deepslate
fill 16 210 -9 16 211 -9 minecraft:stone
fill -4 210 -8 -1 212 -8 minecraft:stone
fill 4 210 -8 4 211 -8 minecraft:stone
fill 5 210 -8 7 210 -8 minecraft:tuff
fill 17 210 -8 17 210 -7 minecraft:stone
setblock -14 210 -7 minecraft:dripstone_block
fill -1 210 -7 0 212 -7 minecraft:stone
fill 7 210 -7 7 213 -4 minecraft:stone
setblock -15 210 -6 minecraft:amethyst_block
fill -13 210 -6 -13 220 -6 minecraft:stone
fill -7 210 -6 -7 220 -6 minecraft:stone
fill -1 210 -6 -1 214 -6 minecraft:stone
fill 9 210 -6 15 216 -6 minecraft:stone
fill 16 210 -6 16 210 -5 minecraft:dripstone_block
fill -17 210 -5 -17 212 -1 minecraft:stone
fill -15 210 -5 -15 211 -5 minecraft:stone
fill -10 210 -5 -10 221 -5 minecraft:stone
setblock -7 210 -5 minecraft:andesite
fill -6 210 -5 -5 219 -5 minecraft:stone
fill 3 210 -5 3 220 -5 minecraft:stone
fill 9 210 -5 9 210 -3 minecraft:stone
fill 10 210 -5 10 210 -3 minecraft:tuff
fill 15 210 -5 15 210 -2 minecraft:tuff
fill -12 210 -4 -11 221 -4 minecraft:stone
fill -10 210 -4 -10 211 -4 minecraft:andesite
setblock -6 210 -4 minecraft:andesite
fill -3 210 -4 -3 217 -4 minecraft:stone
fill 0 210 -4 1 213 -4 minecraft:andesite
fill 3 210 -4 3 210 -3 minecraft:deepslate
fill 1 210 -3 1 214 -3 minecraft:andesite
fill 6 210 -3 6 215 -3 minecraft:stone
fill 14 210 -3 14 213 -3 minecraft:tuff
fill -9 210 -2 -7 213 -2 minecraft:andesite
fill 1 210 -2 1 211 -2 minecraft:stone
fill 3 210 -2 3 221 -2 minecraft:stone
fill 5 210 -2 5 217 -2 minecraft:stone
fill 12 210 -2 13 211 -2 minecraft:stone
fill -7 210 -1 -7 212 -1 minecraft:stone
fill 7 210 -1 8 221 -1 minecraft:stone
fill 11 210 -1 11 221 -1 minecraft:stone
fill 14 210 -1 14 220 -1 minecraft:stone
setblock 15 210 -1 minecraft:dripstone_block
fill 0 210 0 1 215 0 minecraft:stone
fill 5 210 0 5 220 0 minecraft:stone
fill 6 210 0 8 210 0 minecraft:andesite
fill 11 210 0 11 210 3 minecraft:deepslate
fill 15 210 0 15 220 1 minecraft:stone
fill -16 210 1 -15 211 1 minecraft:andesite
fill 0 210 1 0 215 1 minecraft:stone
fill 6 210 1 6 212 2 minecraft:andesite
fill 12 210 1 12 211 3 minecraft:stone
fill -12 210 2 -12 220 2 minecraft:stone
fill 7 210 2 7 213 2 minecraft:andesite
setblock 9 210 2 minecraft:deepslate
fill 14 210 2 14 221 3 minecraft:stone
setblock -12 210 3 minecraft:deepslate
setblock 10 210 3 minecraft:deepslate
fill 19 210 3 19 220 3 minecraft:stone
fill -12 210 4 -12 221 4 minecraft:stone
fill 5 210 4 5 220 4 minecraft:stone
fill 10 210 4 10 219 6 minecraft:stone
fill -13 210 5 -13 212 8 minecraft:stone
fill 21 210 5 21 220 5 minecraft:stone
fill -12 210 6 -12 210 7 minecraft:stone
fill 14 210 6 14 220 6 minecraft:stone
fill -11 210 7 -10 212 9 minecraft:andesite
fill 15 210 7 15 220 9 minecraft:stone
fill 18 210 7 18 220 7 minecraft:stone
fill -12 210 8 -12 215 8 minecraft:andesite
fill 3 210 8 5 212 8 minecraft:stone
fill 6 210 8 6 210 10 minecraft:deepslate
fill 7 210 8 8 220 8 minecraft:stone
setblock -12 210 9 minecraft:dripstone_block
fill -9 210 9 -8 221 9 minecraft:stone
fill 5 210 9 5 219 10 minecraft:stone
fill 14 210 9 14 220 9 minecraft:stone
fill -12 210 10 -12 210 12 minecraft:stone
fill -11 210 10 -11 215 10 minecraft:andesite
setblock -10 210 10 minecraft:stone
fill -1 210 10 -1 212 10 minecraft:tuff
fill 4 210 10 4 220 10 minecraft:stone
fill 8 210 10 8 220 10 minecraft:stone
fill 13 210 10 13 220 10 minecraft:stone
setblock 14 210 10 minecraft:amethyst_block
fill -11 210 11 -11 210 12 minecraft:stone
setblock -7 210 11 minecraft:dripstone_block
fill -6 210 11 -6 220 11 minecraft:stone
fill 9 210 11 9 220 14 minecraft:stone
fill 11 210 11 12 217 11 minecraft:stone
fill 1 210 12 1 215 12 minecraft:cobblestone
fill 2 210 12 2 211 12 minecraft:andesite
fill 4 210 12 5 221 13 minecraft:stone
fill 6 210 12 6 211 13 minecraft:tuff
fill 10 210 12 11 219 12 minecraft:stone
setblock -6 210 13 minecraft:dripstone_block
fill 2 210 13 3 210 13 minecraft:stone
fill 10 210 13 10 220 13 minecraft:stone
fill -7 210 14 -7 221 14 minecraft:stone
fill 2 210 14 2 216 15 minecraft:cobblestone
setblock 3 210 14 minecraft:amethyst_block
fill 4 210 14 4 210 15 minecraft:cobblestone
fill 5 210 14 5 221 14 minecraft:stone
setblock 6 210 14 minecraft:amethyst_block
setblock -9 210 15 minecraft:amethyst_block
setblock -8 210 15 minecraft:dripstone_block
fill -2 210 15 1 211 15 minecraft:stone
fill 3 210 15 3 216 15 minecraft:cobblestone
setblock 5 210 15 minecraft:amethyst_block
fill 6 210 15 6 220 15 minecraft:stone
fill 8 210 15 8 220 16 minecraft:stone
fill -9 210 16 -9 220 16 minecraft:stone
setblock -6 210 16 minecraft:dripstone_block
fill -5 210 16 -3 219 16 minecraft:stone
fill 3 210 16 4 210 16 minecraft:tuff
fill 5 210 16 5 217 16 minecraft:stone
setblock 6 210 16 minecraft:dripstone_block
fill 7 210 16 7 220 16 minecraft:stone
fill -4 211 -19 -4 220 -19 minecraft:stone
setblock -4 211 -18 minecraft:dripstone_block
fill -4 211 -17 -3 214 -16 minecraft:stone
fill 3 211 -17 7 220 -17 minecraft:stone
fill -5 211 -16 -5 216 -16 minecraft:stone
fill 2 211 -16 2 217 -12 minecraft:stone
fill 7 211 -16 7 212 -14 minecraft:stone
fill 8 211 -16 8 213 -15 minecraft:andesite
setblock -5 211 -15 minecraft:cobblestone
fill -3 211 -15 -2 212 -15 minecraft:stone
setblock -7 211 -14 minecraft:stone
fill -6 211 -14 -6 212 -14 minecraft:cobblestone
fill -1 211 -14 -1 221 -12 minecraft:stone
fill 1 211 -14 1 220 -12 minecraft:stone
fill 3 211 -14 3 218 -10 minecraft:stone
fill 6 211 -14 6 214 -12 minecraft:stone
fill -9 211 -13 -9 221 -13 minecraft:stone
fill 0 211 -13 0 221 -12 minecraft:stone
fill 4 211 -13 5 216 -12 minecraft:stone
fill 10 211 -13 13 220 -13 minecraft:stone
setblock -10 211 -12 minecraft:dripstone_block
fill -7 211 -12 -7 213 -12 minecraft:stone
fill -6 211 -12 -6 211 -11 minecraft:tuff
fill 10 211 -12 10 221 -12 minecraft:stone
fill 14 211 -12 14 215 -11 minecraft:stone
fill -11 211 -11 -11 220 -9 minecraft:stone
fill -7 211 -11 -7 212 -11 minecraft:tuff
fill -5 211 -11 -4 214 -11 minecraft:stone
fill 4 211 -11 4 216 -10 minecraft:stone
fill 8 211 -11 8 221 -11 minecraft:stone
setblock 9 211 -11 minecraft:dripstone_block
fill 15 211 -11 15 214 -11 minecraft:stone
fill -13 211 -10 -12 220 -9 minecraft:stone
setblock -9 211 -10 minecraft:cobblestone
fill -8 211 -10 -7 211 -10 minecraft:stone
fill -5 211 -10 -5 220 -8 minecraft:stone
fill -1 211 -10 -1 213 -10 minecraft:andesite
fill 1 211 -10 1 213 -9 minecraft:andesite
fill 2 211 -10 2 218 -9 minecraft:stone
fill 16 211 -10 16 216 -10 minecraft:stone
fill -14 211 -9 -14 221 -7 minecraft:stone
fill -8 211 -9 -8 217 -7 minecraft:stone
fill -6 211 -9 -6 220 -9 minecraft:stone
setblock -1 211 -9 minecraft:stone
fill 0 211 -9 0 215 -9 minecraft:andesite
fill 17 211 -9 17 214 -8 minecraft:andesite
fill 5 211 -8 6 218 -7 minecraft:tuff
fill 7 211 -8 7 212 -8 minecraft:stone
setblock 4 211 -7 minecraft:stone
fill 17 211 -7 17 211 -6 minecraft:stone
fill -17 211 -6 -15 214 -6 minecraft:stone
fill -9 211 -6 -9 212 -6 minecraft:cobblestone
fill 16 211 -6 16 216 -5 minecraft:stone
fill -18 211 -5 -18 213 -3 minecraft:stone
fill -7 211 -5 -7 220 -5 minecraft:stone
fill 9 211 -5 15 218 -5 minecraft:stone
setblock 17 211 -5 minecraft:dripstone_block
fill -6 211 -4 -4 218 -4 minecraft:stone
fill 3 211 -4 4 217 -3 minecraft:stone
setblock 9 211 -4 minecraft:stone
fill 10 211 -4 11 212 -4 minecraft:tuff
fill 13 211 -4 15 212 -4 minecraft:tuff
setblock 16 211 -4 minecraft:dripstone_block
fill -4 211 -3 -4 220 -3 minecraft:stone
setblock -3 211 -3 minecraft:cobblestone
fill 0 211 -3 0 215 -3 minecraft:andesite
fill 5 211 -3 5 216 -3 minecraft:stone
fill 9 211 -3 10 212 -3 minecraft:tuff
fill 15 211 -3 16 213 -2 minecraft:tuff
fill -6 211 -2 -5 211 -2 minecraft:andesite
setblock 0 211 -2 minecraft:stone
fill 17 211 -2 17 213 -2 minecraft:tuff
fill -6 211 -1 -5 221 0 minecraft:stone
fill 10 211 -1 10 217 3 minecraft:stone
fill 15 211 -1 17 212 -1 minecraft:stone
fill -17 211 0 -15 219 0 minecraft:stone
fill -1 211 0 -1 219 0 minecraft:stone
fill 6 211 0 6 221 0 minecraft:stone
fill 7 211 0 8 211 0 minecraft:andesite
fill 9 211 0 9 217 2 minecraft:stone
fill 11 211 0 11 216 3 minecraft:stone
fill 16 211 0 17 213 0 minecraft:stone
setblock -17 211 1 minecraft:andesite
fill 16 211 1 16 215 1 minecraft:stone
fill -16 211 2 -16 212 2 minecraft:andesite
