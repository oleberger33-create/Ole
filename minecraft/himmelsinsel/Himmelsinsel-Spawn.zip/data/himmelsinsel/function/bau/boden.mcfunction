# Läuft nur einmal, solange unter dem Bauplatz noch freier Himmel ist.
# Unsichtbare Lichter im Schatten der Insel, damit dort tagsüber keine Monster spawnen.
execute positioned -30 0 -10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -30 0 0 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -30 0 10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -20 0 -20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -20 0 -10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -20 0 0 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -20 0 10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -20 0 20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -10 0 -30 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -10 0 -20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -10 0 -10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -10 0 0 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -10 0 10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -10 0 20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned -10 0 30 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 0 0 -30 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 0 0 -20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 0 0 -10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 0 0 0 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 0 0 10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 0 0 20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 0 0 30 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 10 0 -30 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 10 0 -20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 10 0 -10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 10 0 0 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 10 0 10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 10 0 20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 10 0 30 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 20 0 -20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 20 0 -10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 20 0 0 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 20 0 10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 20 0 20 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 30 0 -10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 30 0 0 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute positioned 30 0 10 positioned over motion_blocking_no_leaves run setblock ~ ~ ~ minecraft:light[level=13] keep
execute if score #bodenstation hs.config matches 1 positioned 0 0 41 positioned over motion_blocking_no_leaves run function himmelsinsel:bau/bodenstation
scoreboard players set #boden hs.state 1
