fill -2 220 -5 -1 220 -5 minecraft:andesite
fill 11 220 -5 11 220 -4 minecraft:stone
setblock 31 220 -5 minecraft:stone
fill -30 220 -4 -30 221 -3 minecraft:stone
fill -20 220 -4 -20 220 -3 minecraft:andesite
fill -1 220 -4 0 220 -4 minecraft:andesite
fill 6 220 -4 6 221 -4 minecraft:tuff
setblock 24 220 -4 minecraft:stone
fill -29 220 -3 -29 221 -3 minecraft:tuff
setblock -2 220 -3 minecraft:andesite
fill 6 220 -3 6 221 -3 minecraft:stone
fill 15 220 -3 15 221 -3 minecraft:andesite
fill 22 220 -3 22 221 -2 minecraft:stone
fill 23 220 -3 25 220 5 minecraft:mossy_cobblestone
fill -20 220 -2 -20 221 -2 minecraft:mossy_cobblestone
setblock -1 220 -2 minecraft:andesite
fill 5 220 -2 5 221 -2 minecraft:stone
fill 18 220 -2 19 221 -2 minecraft:andesite
setblock -30 220 -1 minecraft:tuff
setblock -26 220 -1 minecraft:stone
fill -20 220 -1 -20 220 0 minecraft:andesite
setblock -1 220 -1 minecraft:stone
fill 0 220 -1 0 220 7 minecraft:mossy_cobblestone
setblock 18 220 -1 minecraft:stone
fill 19 220 -1 19 221 0 minecraft:andesite
setblock 22 220 -1 minecraft:andesite
fill 29 220 -1 30 221 -1 minecraft:stone
setblock -30 220 0 minecraft:mossy_cobblestone
setblock -29 220 0 minecraft:tuff
fill -22 220 0 -22 220 4 minecraft:stone
fill -16 220 0 -15 220 0 minecraft:stone
setblock -4 220 0 minecraft:tuff
fill -1 220 0 -1 221 2 minecraft:mossy_cobblestone
fill 11 220 0 12 220 3 minecraft:mossy_cobblestone
fill 29 220 0 29 221 2 minecraft:stone
setblock 30 220 0 minecraft:dripstone_block
fill -30 220 1 -29 220 1 minecraft:stone
fill -20 220 1 -19 221 2 minecraft:stone
fill -18 220 1 -18 221 1 minecraft:mossy_cobblestone
fill -4 220 1 -4 221 1 minecraft:stone
fill 1 220 1 1 221 1 minecraft:stone
fill 28 220 1 28 220 2 minecraft:stone
fill 30 220 1 30 221 1 minecraft:stone
setblock -29 220 2 minecraft:stone
fill -18 220 2 -18 221 2 minecraft:stone
fill -3 220 2 -3 221 2 minecraft:stone
fill -2 220 2 -2 220 5 minecraft:andesite
fill 1 220 2 1 220 4 minecraft:andesite
fill 9 220 2 10 220 4 minecraft:mossy_cobblestone
fill 16 220 2 16 221 2 minecraft:stone
setblock 30 220 2 minecraft:amethyst_block
fill -19 220 3 -19 221 4 minecraft:stone
fill -3 220 3 -3 220 4 minecraft:andesite
fill -1 220 3 -1 220 4 minecraft:andesite
setblock 8 220 3 minecraft:mossy_cobblestone
fill 15 220 3 16 220 3 minecraft:tuff
fill 29 220 3 30 221 3 minecraft:mossy_cobblestone
setblock -29 220 4 minecraft:andesite
setblock -9 220 4 minecraft:andesite
fill -6 220 4 -4 220 4 minecraft:andesite
fill 16 220 4 16 221 4 minecraft:tuff
fill 29 220 4 29 221 4 minecraft:mossy_cobblestone
fill -28 220 5 -27 220 5 minecraft:andesite
fill -26 220 5 -25 220 5 minecraft:stone
fill -22 220 5 -21 221 8 minecraft:mossy_cobblestone
fill -20 220 5 -20 221 5 minecraft:stone
setblock -16 220 5 minecraft:stone
fill -15 220 5 -15 220 7 minecraft:mossy_cobblestone
fill -6 220 5 -5 220 5 minecraft:andesite
fill -1 220 5 -1 220 7 minecraft:mossy_cobblestone
fill 10 220 5 10 220 6 minecraft:stone
fill 26 220 5 26 221 5 minecraft:stone
fill 28 220 5 29 221 5 minecraft:stone
setblock -28 220 6 minecraft:stone
fill -20 220 6 -20 220 8 minecraft:mossy_cobblestone
fill -16 220 6 -16 220 7 minecraft:mossy_cobblestone
fill -11 220 6 -11 221 6 minecraft:stone
fill -5 220 6 -5 220 7 minecraft:stone
fill -2 220 6 -2 220 7 minecraft:mossy_cobblestone
fill 1 220 6 2 221 6 minecraft:mossy_cobblestone
fill 3 220 6 3 221 6 minecraft:stone
setblock 21 220 6 minecraft:andesite
fill 23 220 6 24 220 6 minecraft:mossy_cobblestone
fill 25 220 6 26 220 6 minecraft:andesite
fill 28 220 6 29 220 6 minecraft:andesite
fill -11 220 7 -11 221 8 minecraft:tuff
fill 1 220 7 1 221 7 minecraft:mossy_cobblestone
setblock 13 220 7 minecraft:stone
fill 23 220 7 24 221 8 minecraft:andesite
setblock 29 220 7 minecraft:andesite
fill -27 220 8 -27 221 9 minecraft:stone
fill -17 220 8 -16 220 8 minecraft:andesite
setblock -15 220 8 minecraft:stone
fill -10 220 8 -9 221 8 minecraft:tuff
fill -8 220 8 -8 221 8 minecraft:stone
fill -2 220 8 -2 221 8 minecraft:stone
fill -1 220 8 -1 221 8 minecraft:tuff
setblock 11 220 8 minecraft:tuff
fill 25 220 8 25 221 8 minecraft:andesite
fill -22 220 9 -22 220 10 minecraft:stone
fill -21 220 9 -21 221 9 minecraft:mossy_cobblestone
setblock -18 220 9 minecraft:mossy_cobblestone
setblock -16 220 9 minecraft:andesite
setblock -10 220 9 minecraft:stone
fill 2 220 9 2 221 12 minecraft:stone
fill 5 220 9 5 221 9 minecraft:mossy_cobblestone
fill 26 220 9 26 221 9 minecraft:andesite
setblock 28 220 9 minecraft:andesite
setblock -27 220 10 minecraft:andesite
fill -25 220 10 -25 221 10 minecraft:stone
setblock -5 220 10 minecraft:andesite
setblock -3 220 10 minecraft:stone
fill 0 220 10 0 220 13 minecraft:tuff
setblock 5 220 10 minecraft:stone
fill 26 220 10 26 220 13 minecraft:stone
fill -26 220 11 -25 220 11 minecraft:andesite
setblock -13 220 11 minecraft:stone
fill -11 220 11 -11 220 12 minecraft:stone
setblock -3 220 11 minecraft:andesite
fill 11 220 11 11 220 12 minecraft:andesite
setblock 18 220 11 minecraft:stone
fill 19 220 11 21 220 13 minecraft:mossy_cobblestone
fill 22 220 11 22 221 11 minecraft:stone
fill 27 220 11 27 221 11 minecraft:andesite
setblock -26 220 12 minecraft:dripstone_block
setblock -13 220 12 minecraft:andesite
setblock 10 220 12 minecraft:stone
fill 17 220 12 18 220 13 minecraft:mossy_cobblestone
fill 22 220 12 23 220 12 minecraft:mossy_cobblestone
setblock -26 220 13 minecraft:andesite
fill -10 220 13 -10 220 14 minecraft:stone
setblock -1 220 13 minecraft:tuff
setblock 22 220 13 minecraft:mossy_cobblestone
fill 23 220 13 23 221 14 minecraft:stone
fill -25 220 14 -25 221 15 minecraft:stone
fill -18 220 14 -18 220 15 minecraft:mossy_cobblestone
fill -17 220 14 -17 221 14 minecraft:stone
fill -3 220 14 0 220 16 minecraft:mossy_cobblestone
fill 18 220 14 22 220 14 minecraft:stone
fill 25 220 14 25 221 14 minecraft:stone
fill -24 220 15 -24 221 16 minecraft:stone
fill -10 220 15 -10 220 16 minecraft:andesite
fill -5 220 15 -4 220 15 minecraft:mossy_cobblestone
fill 1 220 15 1 221 16 minecraft:mossy_cobblestone
fill 5 220 15 5 220 16 minecraft:stone
fill 9 220 15 9 220 19 minecraft:mossy_cobblestone
fill 11 220 15 14 220 15 minecraft:stone
setblock 15 220 15 minecraft:mossy_cobblestone
setblock 16 220 15 minecraft:stone
fill 19 220 15 20 220 15 minecraft:stone
fill 24 220 15 24 221 15 minecraft:stone
fill -18 220 16 -18 221 16 minecraft:stone
fill -13 220 16 -13 220 18 minecraft:andesite
setblock -5 220 16 minecraft:stone
setblock -4 220 16 minecraft:mossy_cobblestone
fill 3 220 16 3 220 17 minecraft:stone
setblock 19 220 16 minecraft:stone
setblock 24 220 16 minecraft:tuff
fill -23 220 17 -23 220 19 minecraft:stone
fill -15 220 17 -14 220 17 minecraft:stone
setblock -11 220 17 minecraft:andesite
fill 3 220 18 3 220 22 minecraft:mossy_cobblestone
setblock 8 220 18 minecraft:mossy_cobblestone
setblock 10 220 18 minecraft:mossy_cobblestone
setblock 23 220 18 minecraft:stone
fill -22 220 19 -22 220 20 minecraft:stone
fill 1 220 19 2 220 19 minecraft:stone
fill 4 220 19 6 220 19 minecraft:stone
fill 2 220 20 2 220 22 minecraft:mossy_cobblestone
fill 5 220 20 6 220 20 minecraft:stone
fill 7 220 20 8 220 20 minecraft:tuff
setblock 22 220 20 minecraft:stone
fill -18 220 21 -18 220 22 minecraft:mossy_cobblestone
fill 4 220 21 5 220 21 minecraft:stone
fill 8 220 21 8 220 22 minecraft:stone
fill 4 220 22 5 220 22 minecraft:tuff
fill 40 220 22 40 222 22 minecraft:stone
fill 42 220 22 42 222 23 minecraft:stone
setblock -20 220 23 minecraft:stone
setblock -18 220 23 minecraft:stone
fill -11 220 23 -11 221 23 minecraft:stone
fill -10 220 23 -9 221 26 minecraft:mossy_cobblestone
fill -8 220 23 -8 221 23 minecraft:stone
fill -4 220 23 -4 221 23 minecraft:stone
fill 2 220 23 4 220 23 minecraft:tuff
setblock 20 220 23 minecraft:stone
setblock 39 220 23 minecraft:amethyst_block
setblock -19 220 24 minecraft:stone
fill -13 220 24 -13 221 24 minecraft:stone
fill -12 220 24 -11 221 28 minecraft:mossy_cobblestone
fill -8 220 24 -8 220 26 minecraft:mossy_cobblestone
fill -7 220 24 -7 221 24 minecraft:stone
fill -4 220 24 -3 220 24 minecraft:mossy_cobblestone
fill 2 220 24 3 220 25 minecraft:tuff
setblock 6 220 24 minecraft:stone
fill 9 220 24 9 220 25 minecraft:mossy_cobblestone
fill 18 220 24 19 220 24 minecraft:stone
fill 41 220 24 41 222 25 minecraft:stone
setblock 42 220 24 minecraft:andesite
setblock -18 220 25 minecraft:stone
fill -14 220 25 -14 221 25 minecraft:stone
fill -13 220 25 -13 220 28 minecraft:mossy_cobblestone
fill -7 220 25 -7 221 27 minecraft:mossy_cobblestone
fill -4 220 25 -4 221 25 minecraft:stone
fill -2 220 25 -2 221 25 minecraft:stone
setblock 4 220 25 minecraft:tuff
setblock 5 220 25 minecraft:stone
fill 8 220 25 8 220 27 minecraft:stone
fill 16 220 25 17 221 25 minecraft:stone
fill 38 220 25 38 221 25 minecraft:cobblestone
fill 40 220 25 40 222 25 minecraft:stone
setblock -17 220 26 minecraft:stone
fill -15 220 26 -14 220 27 minecraft:mossy_cobblestone
fill -6 220 26 -6 220 30 minecraft:mossy_cobblestone
fill -5 220 26 -5 221 26 minecraft:stone
fill -2 220 26 -2 221 26 minecraft:tuff
fill 9 220 26 9 220 29 minecraft:stone
fill 15 220 26 16 221 26 minecraft:stone
fill 38 220 26 38 222 26 minecraft:stone
fill 42 220 26 42 222 26 minecraft:stone
