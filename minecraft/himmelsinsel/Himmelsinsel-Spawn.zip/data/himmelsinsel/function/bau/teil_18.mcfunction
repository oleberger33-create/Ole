fill -14 220 -27 -14 220 -26 minecraft:stone
fill -13 220 -27 -12 221 -27 minecraft:mossy_cobblestone
fill -8 220 -27 -6 220 -27 minecraft:stone
setblock -3 220 -27 minecraft:tuff
fill 5 220 -27 6 220 -27 minecraft:mossy_cobblestone
fill 11 220 -27 11 221 -27 minecraft:stone
fill 29 220 -27 29 221 -26 minecraft:mossy_cobblestone
fill 31 220 -27 31 220 -26 minecraft:mossy_cobblestone
setblock 40 220 -27 minecraft:stone
fill 44 220 -27 44 221 -27 minecraft:mossy_cobblestone
setblock 45 220 -27 minecraft:dripstone_block
setblock -16 220 -26 minecraft:stone
fill -12 220 -26 -12 221 -26 minecraft:mossy_cobblestone
setblock -10 220 -26 minecraft:stone
fill -8 220 -26 -7 220 -26 minecraft:tuff
fill -6 220 -26 -6 220 -25 minecraft:stone
fill -2 220 -26 -1 220 -26 minecraft:stone
fill 0 220 -26 1 220 -26 minecraft:mossy_cobblestone
setblock 2 220 -26 minecraft:stone
setblock 5 220 -26 minecraft:stone
setblock 6 220 -26 minecraft:mossy_cobblestone
fill 7 220 -26 8 220 -26 minecraft:stone
setblock 12 220 -26 minecraft:dripstone_block
fill 13 220 -26 13 221 -25 minecraft:stone
setblock 44 220 -26 minecraft:stone
fill -18 220 -25 -18 221 -25 minecraft:stone
fill 5 220 -25 5 220 -22 minecraft:andesite
fill 10 220 -25 11 221 -25 minecraft:stone
fill 14 220 -25 15 221 -24 minecraft:stone
fill 41 220 -25 42 220 -25 minecraft:mossy_cobblestone
fill 44 220 -25 44 221 -25 minecraft:andesite
fill -19 220 -24 -19 221 -24 minecraft:stone
fill 4 220 -24 4 221 -23 minecraft:andesite
fill 7 220 -24 7 220 -23 minecraft:tuff
fill 10 220 -24 10 221 -24 minecraft:stone
fill 12 220 -24 13 221 -23 minecraft:mossy_cobblestone
setblock 16 220 -24 minecraft:dripstone_block
setblock 42 220 -24 minecraft:mossy_cobblestone
fill 43 220 -24 43 221 -24 minecraft:andesite
fill -41 220 -23 -41 226 -23 minecraft:stone
fill -39 220 -23 -39 221 -23 minecraft:stone
fill -20 220 -23 -20 221 -22 minecraft:stone
setblock -19 220 -23 minecraft:dripstone_block
setblock -16 220 -23 minecraft:stone
fill -7 220 -23 -7 221 -23 minecraft:tuff
fill -6 220 -23 -4 221 -23 minecraft:stone
setblock 2 220 -23 minecraft:stone
fill 17 220 -23 18 221 -23 minecraft:stone
setblock 31 220 -23 minecraft:stone
fill 42 220 -23 42 220 -22 minecraft:andesite
setblock 43 220 -23 minecraft:dripstone_block
fill -21 220 -22 -21 221 -22 minecraft:stone
fill -19 220 -22 -18 220 -22 minecraft:stone
fill 2 220 -22 4 220 -20 minecraft:mossy_cobblestone
fill 12 220 -22 12 221 -21 minecraft:mossy_cobblestone
setblock 13 220 -22 minecraft:stone
fill 19 220 -22 20 221 -21 minecraft:stone
fill 32 220 -22 34 220 -22 minecraft:stone
setblock -40 220 -21 minecraft:andesite
fill -39 220 -21 -39 222 -21 minecraft:stone
fill -22 220 -21 -22 221 -21 minecraft:stone
setblock -18 220 -21 minecraft:mossy_cobblestone
setblock -3 220 -21 minecraft:mossy_cobblestone
fill 1 220 -21 1 221 -21 minecraft:mossy_cobblestone
fill 5 220 -21 5 220 -20 minecraft:mossy_cobblestone
setblock 13 220 -21 minecraft:andesite
fill 21 220 -21 21 221 -20 minecraft:mossy_cobblestone
setblock 22 220 -21 minecraft:amethyst_block
fill 23 220 -21 23 220 -20 minecraft:stone
fill 34 220 -21 41 220 -21 minecraft:stone
setblock -23 220 -20 minecraft:stone
fill -18 220 -20 -18 221 -19 minecraft:tuff
setblock 22 220 -20 minecraft:mossy_cobblestone
setblock 24 220 -20 minecraft:stone
setblock -24 220 -19 minecraft:stone
fill -14 220 -19 -14 220 -16 minecraft:stone
fill 2 220 -19 2 220 -18 minecraft:stone
setblock 3 220 -19 minecraft:mossy_cobblestone
setblock 4 220 -19 minecraft:andesite
fill 5 220 -19 8 220 -18 minecraft:stone
setblock 4 220 -18 minecraft:stone
setblock 19 220 -18 minecraft:tuff
fill 22 220 -18 22 221 -17 minecraft:stone
fill 26 220 -18 26 220 -17 minecraft:mossy_cobblestone
setblock -26 220 -17 minecraft:stone
fill 27 220 -17 27 221 -17 minecraft:mossy_cobblestone
fill -27 220 -16 -27 220 -14 minecraft:tuff
fill -6 220 -16 -5 220 -14 minecraft:mossy_cobblestone
setblock -4 220 -16 minecraft:stone
fill 1 220 -16 3 220 -15 minecraft:mossy_cobblestone
fill 15 220 -16 15 220 -15 minecraft:mossy_cobblestone
fill 18 220 -16 19 221 -16 minecraft:tuff
fill 27 220 -16 28 221 -15 minecraft:tuff
setblock -28 220 -15 minecraft:amethyst_block
setblock -16 220 -15 minecraft:tuff
fill -15 220 -15 -15 220 -11 minecraft:mossy_cobblestone
fill -9 220 -15 -8 221 -15 minecraft:stone
fill -7 220 -15 -7 221 -15 minecraft:mossy_cobblestone
setblock -4 220 -15 minecraft:mossy_cobblestone
fill -2 220 -15 0 221 -15 minecraft:mossy_cobblestone
fill 4 220 -15 4 220 -13 minecraft:mossy_cobblestone
fill 12 220 -15 14 220 -15 minecraft:mossy_cobblestone
setblock 16 220 -15 minecraft:mossy_cobblestone
fill 18 220 -15 18 220 -14 minecraft:stone
fill 19 220 -15 20 221 -15 minecraft:tuff
fill 21 220 -15 21 221 -13 minecraft:stone
setblock 24 220 -15 minecraft:stone
fill -14 220 -14 -12 221 -14 minecraft:stone
setblock -7 220 -14 minecraft:stone
setblock -4 220 -14 minecraft:stone
fill 0 220 -14 0 221 -14 minecraft:stone
fill 2 220 -14 3 221 -14 minecraft:mossy_cobblestone
fill 19 220 -14 20 220 -14 minecraft:stone
fill 22 220 -14 22 220 -12 minecraft:stone
fill 24 220 -14 24 220 -13 minecraft:andesite
fill 25 220 -14 25 221 -14 minecraft:stone
fill 27 220 -14 27 221 -14 minecraft:stone
fill 29 220 -14 29 221 -13 minecraft:stone
setblock -29 220 -13 minecraft:dripstone_block
setblock -28 220 -13 minecraft:stone
fill -27 220 -13 -27 220 -11 minecraft:mossy_cobblestone
setblock -26 220 -13 minecraft:stone
fill -14 220 -13 -14 220 -11 minecraft:mossy_cobblestone
fill -13 220 -13 -11 221 -13 minecraft:stone
fill 2 220 -13 2 220 -12 minecraft:stone
fill 3 220 -13 3 221 -12 minecraft:mossy_cobblestone
fill 5 220 -13 5 221 -13 minecraft:stone
setblock 14 220 -13 minecraft:stone
fill 18 220 -13 18 221 -11 minecraft:mossy_cobblestone
fill 20 220 -13 20 221 -13 minecraft:stone
fill 25 220 -13 25 220 -12 minecraft:andesite
fill 26 220 -13 26 221 -13 minecraft:stone
setblock -28 220 -12 minecraft:mossy_cobblestone
fill -26 220 -12 -26 220 -11 minecraft:mossy_cobblestone
fill -13 220 -12 -11 221 -12 minecraft:mossy_cobblestone
fill 11 220 -12 12 220 -12 minecraft:stone
setblock 13 220 -12 minecraft:tuff
fill 19 220 -12 21 220 -12 minecraft:mossy_cobblestone
fill 23 220 -12 23 221 -11 minecraft:andesite
fill 30 220 -12 30 220 -10 minecraft:stone
fill -30 220 -11 -30 221 -10 minecraft:stone
setblock -28 220 -11 minecraft:stone
fill -16 220 -11 -16 221 -11 minecraft:stone
fill -13 220 -11 -12 221 -11 minecraft:mossy_cobblestone
setblock 14 220 -11 minecraft:tuff
fill 19 220 -11 19 221 -11 minecraft:mossy_cobblestone
fill 20 220 -11 20 220 -10 minecraft:stone
fill 24 220 -11 24 221 -11 minecraft:andesite
fill 25 220 -11 25 221 -11 minecraft:stone
setblock -29 220 -10 minecraft:stone
setblock -28 220 -10 minecraft:tuff
setblock -27 220 -10 minecraft:stone
fill 19 220 -10 19 221 -10 minecraft:stone
fill -29 220 -9 -29 220 -6 minecraft:tuff
fill -27 220 -9 -27 220 -7 minecraft:tuff
fill -26 220 -9 -26 220 -8 minecraft:stone
fill -9 220 -9 -9 220 -2 minecraft:mossy_cobblestone
fill -7 220 -9 -7 221 -8 minecraft:andesite
setblock 7 220 -9 minecraft:stone
fill 8 220 -9 9 220 -8 minecraft:mossy_cobblestone
fill 10 220 -9 10 220 -8 minecraft:andesite
setblock 13 220 -9 minecraft:stone
fill 15 220 -9 15 220 -8 minecraft:tuff
fill 26 220 -9 30 220 -9 minecraft:mossy_cobblestone
fill 31 220 -9 31 220 -7 minecraft:stone
setblock -10 220 -8 minecraft:stone
fill -8 220 -8 -8 221 -8 minecraft:andesite
fill 26 220 -8 26 220 -7 minecraft:stone
fill 27 220 -8 28 220 -8 minecraft:mossy_cobblestone
fill 29 220 -8 30 220 -8 minecraft:stone
fill -4 220 -7 -3 220 -7 minecraft:stone
fill 0 220 -7 0 220 -5 minecraft:mossy_cobblestone
fill 9 220 -7 9 220 -6 minecraft:mossy_cobblestone
fill 11 220 -7 12 220 -7 minecraft:andesite
setblock 13 220 -7 minecraft:stone
setblock 15 220 -7 minecraft:stone
fill 27 220 -7 27 220 -6 minecraft:stone
fill 30 220 -7 30 220 -5 minecraft:stone
fill -27 220 -6 -27 221 -6 minecraft:mossy_cobblestone
setblock -20 220 -6 minecraft:stone
fill -19 220 -6 -17 220 0 minecraft:mossy_cobblestone
fill -16 220 -6 -16 221 -6 minecraft:stone
setblock -2 220 -6 minecraft:stone
setblock -1 220 -6 minecraft:mossy_cobblestone
setblock 1 220 -6 minecraft:mossy_cobblestone
fill 3 220 -6 3 221 -6 minecraft:tuff
fill 10 220 -6 11 220 -6 minecraft:stone
setblock 31 220 -6 minecraft:dripstone_block
setblock -30 220 -5 minecraft:amethyst_block
fill -29 220 -5 -29 220 -4 minecraft:stone
setblock -16 220 -5 minecraft:andesite
fill -6 220 -5 -6 220 -4 minecraft:stone
fill -5 220 -5 -5 220 -4 minecraft:andesite
fill -2 220 -5 -1 220 -5 minecraft:andesite
fill 11 220 -5 11 220 -4 minecraft:stone
setblock 31 220 -5 minecraft:stone
fill -30 220 -4 -30 221 -3 minecraft:stone
fill -20 220 -4 -20 220 -3 minecraft:andesite
fill -1 220 -4 0 220 -4 minecraft:andesite
fill 6 220 -4 6 221 -4 minecraft:tuff
setblock 24 220 -4 minecraft:stone
fill -29 220 -3 -29 221 -3 minecraft:tuff
setblock -2 220 -3 minecraft:andesite
fill 6 220 -3 6 221 -3 minecraft:stone
fill 15 220 -3 15 221 -3 minecraft:andesite
fill 22 220 -3 22 221 -2 minecraft:stone
fill 23 220 -3 25 220 5 minecraft:mossy_cobblestone
fill -20 220 -2 -20 221 -2 minecraft:mossy_cobblestone
setblock -1 220 -2 minecraft:andesite
fill 5 220 -2 5 221 -2 minecraft:stone
fill 18 220 -2 19 221 -2 minecraft:andesite
setblock -30 220 -1 minecraft:tuff
setblock -26 220 -1 minecraft:stone
fill -20 220 -1 -20 220 0 minecraft:andesite
setblock -1 220 -1 minecraft:stone
fill 0 220 -1 0 220 7 minecraft:mossy_cobblestone
setblock 18 220 -1 minecraft:stone
fill 19 220 -1 19 221 0 minecraft:andesite
setblock 22 220 -1 minecraft:andesite
fill 29 220 -1 30 221 -1 minecraft:stone
