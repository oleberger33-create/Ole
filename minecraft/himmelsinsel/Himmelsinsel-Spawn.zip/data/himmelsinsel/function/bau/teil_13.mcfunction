fill -24 217 -16 -21 220 -16 minecraft:stone
setblock -16 217 -16 minecraft:stone
fill -15 217 -16 -15 220 -16 minecraft:tuff
fill -13 217 -16 -13 221 -16 minecraft:stone
fill -5 217 -16 -5 219 -16 minecraft:cobblestone
fill 3 217 -16 4 218 -16 minecraft:cobblestone
fill 5 217 -16 6 220 -16 minecraft:stone
fill 21 217 -16 21 218 -15 minecraft:stone
setblock 24 217 -16 minecraft:dripstone_block
fill -25 217 -15 -25 217 -13 minecraft:cobblestone
fill -24 217 -15 -24 220 -15 minecraft:stone
fill -20 217 -15 -20 221 -13 minecraft:stone
setblock 5 217 -15 minecraft:cobblestone
setblock 22 217 -15 minecraft:dripstone_block
fill 23 217 -15 24 217 -15 minecraft:stone
fill 25 217 -15 25 218 -14 minecraft:andesite
setblock -24 217 -14 minecraft:cobblestone
fill -23 217 -14 -23 220 -13 minecraft:stone
fill -3 217 -14 -3 220 -14 minecraft:stone
fill 4 217 -14 4 219 -14 minecraft:cobblestone
fill 23 217 -14 23 218 -12 minecraft:stone
setblock 24 217 -14 minecraft:dripstone_block
fill -26 217 -13 -26 219 -13 minecraft:cobblestone
fill -24 217 -13 -24 220 -13 minecraft:stone
fill -13 217 -13 -13 217 -11 minecraft:stone
fill -12 217 -13 -12 219 -13 minecraft:cobblestone
fill 4 217 -13 4 217 -11 minecraft:stone
setblock 5 217 -13 minecraft:cobblestone
fill 14 217 -13 14 219 -13 minecraft:tuff
fill 24 217 -13 24 217 -10 minecraft:stone
fill -26 217 -12 -26 218 -11 minecraft:stone
fill -12 217 -12 -12 218 -11 minecraft:stone
fill -7 217 -12 -6 220 -12 minecraft:stone
fill 5 217 -12 6 218 -12 minecraft:tuff
fill 25 217 -12 25 218 -11 minecraft:stone
fill -27 217 -11 -27 217 -10 minecraft:stone
fill -25 217 -11 -25 220 -10 minecraft:stone
fill -6 217 -11 -6 217 -10 minecraft:cobblestone
fill 5 217 -11 5 220 -11 minecraft:tuff
fill 6 217 -11 7 221 -11 minecraft:stone
setblock 23 217 -11 minecraft:tuff
fill 26 217 -11 26 221 -10 minecraft:stone
fill -28 217 -10 -28 217 -6 minecraft:stone
fill -26 217 -10 -26 218 -10 minecraft:tuff
fill -18 217 -10 -18 221 -8 minecraft:stone
fill -7 217 -10 -7 218 -10 minecraft:cobblestone
fill 4 217 -10 4 221 -10 minecraft:tuff
fill 8 217 -10 8 221 -10 minecraft:stone
fill 9 217 -10 9 218 -10 minecraft:cobblestone
fill 10 217 -10 10 220 -10 minecraft:stone
fill 13 217 -10 13 220 -10 minecraft:stone
fill 16 217 -10 17 220 -10 minecraft:tuff
fill 23 217 -10 23 220 -10 minecraft:stone
fill -27 217 -9 -27 219 -6 minecraft:tuff
fill -25 217 -9 -25 217 -8 minecraft:tuff
fill -1 217 -9 -1 221 -9 minecraft:stone
fill 3 217 -9 3 220 -9 minecraft:tuff
fill 13 217 -9 13 219 -9 minecraft:andesite
fill 14 217 -9 14 220 -9 minecraft:stone
fill 27 217 -9 27 218 -6 minecraft:stone
fill -26 217 -8 -26 219 -8 minecraft:tuff
fill -21 217 -8 -20 220 -8 minecraft:stone
fill 0 217 -8 0 221 -8 minecraft:stone
fill 7 217 -8 7 220 -7 minecraft:stone
fill 14 217 -8 15 217 -8 minecraft:andesite
fill 16 217 -8 16 218 -7 minecraft:stone
fill -25 217 -7 -25 221 -4 minecraft:stone
setblock -21 217 -7 minecraft:andesite
fill 11 217 -7 12 218 -6 minecraft:stone
fill 13 217 -7 14 218 -7 minecraft:andesite
fill -26 217 -6 -26 218 -5 minecraft:tuff
fill -24 217 -6 -24 221 -4 minecraft:stone
fill -22 217 -6 -22 221 -6 minecraft:stone
fill -15 217 -6 -15 218 -6 minecraft:andesite
fill -3 217 -6 -3 220 -6 minecraft:andesite
fill 9 217 -6 10 219 -6 minecraft:stone
fill 13 217 -6 14 220 -6 minecraft:stone
fill 15 217 -6 16 218 -6 minecraft:andesite
setblock 17 217 -6 minecraft:stone
fill 26 217 -6 26 220 -5 minecraft:stone
fill 28 217 -6 28 220 -2 minecraft:stone
fill -23 217 -5 -23 221 -5 minecraft:stone
setblock -22 217 -5 minecraft:cobblestone
fill -21 217 -5 -21 217 -4 minecraft:stone
setblock -3 217 -5 minecraft:stone
setblock 4 217 -5 minecraft:stone
fill 5 217 -5 5 221 -5 minecraft:tuff
setblock 16 217 -5 minecraft:stone
fill 17 217 -5 17 221 -4 minecraft:andesite
fill 23 217 -5 24 220 -5 minecraft:stone
fill -20 217 -4 -20 219 -2 minecraft:andesite
fill -2 217 -4 -2 220 -4 minecraft:andesite
fill 1 217 -4 1 220 -4 minecraft:andesite
setblock 23 217 -4 minecraft:andesite
fill 24 217 -4 24 219 -4 minecraft:cobblestone
fill -26 217 -3 -25 217 -2 minecraft:tuff
fill 5 217 -3 5 221 -3 minecraft:tuff
setblock 19 217 -3 minecraft:stone
fill 20 217 -3 20 221 -3 minecraft:andesite
fill 24 217 -3 24 217 -1 minecraft:andesite
fill 27 217 -3 27 220 -3 minecraft:stone
fill -27 217 -2 -27 220 -2 minecraft:tuff
fill -24 217 -2 -24 220 -1 minecraft:stone
fill -19 217 -2 -19 219 -2 minecraft:andesite
fill -16 217 -2 -16 220 -2 minecraft:andesite
fill 26 217 -2 27 217 -1 minecraft:cobblestone
fill -28 217 -1 -27 217 0 minecraft:stone
setblock -25 217 -1 minecraft:tuff
fill -20 217 -1 -19 217 -1 minecraft:stone
fill 21 217 -1 21 220 1 minecraft:andesite
fill 25 217 -1 25 219 1 minecraft:cobblestone
fill -26 217 0 -26 218 0 minecraft:tuff
fill -23 217 0 -23 220 0 minecraft:stone
fill -19 217 0 -19 219 4 minecraft:stone
fill 0 217 0 0 219 0 minecraft:andesite
fill 11 217 0 11 219 0 minecraft:stone
fill 16 217 0 16 220 0 minecraft:stone
setblock 24 217 0 minecraft:dripstone_block
fill 26 217 0 26 218 1 minecraft:cobblestone
fill -27 217 1 -26 220 2 minecraft:stone
fill -3 217 1 -3 221 1 minecraft:stone
fill 11 217 1 11 217 2 minecraft:cobblestone
setblock 17 217 1 minecraft:tuff
fill 23 217 1 24 218 1 minecraft:stone
fill -3 217 2 -1 219 3 minecraft:andesite
fill 12 217 2 12 218 2 minecraft:cobblestone
setblock 17 217 2 minecraft:stone
fill 21 217 2 21 220 2 minecraft:stone
fill 24 217 2 24 217 3 minecraft:stone
setblock -27 217 3 minecraft:dripstone_block
fill -26 217 3 -25 220 4 minecraft:stone
fill -5 217 3 -4 220 3 minecraft:andesite
fill 0 217 3 1 219 3 minecraft:andesite
setblock 11 217 3 minecraft:stone
fill 23 217 3 23 217 7 minecraft:stone
fill -24 217 4 -24 221 9 minecraft:stone
fill -5 217 4 -3 217 4 minecraft:stone
fill -1 217 4 0 217 5 minecraft:stone
fill 12 217 4 12 220 5 minecraft:stone
setblock 24 217 4 minecraft:amethyst_block
setblock -25 217 5 minecraft:dripstone_block
setblock -19 217 5 minecraft:cobblestone
fill -18 217 5 -18 221 5 minecraft:stone
fill -16 217 5 -15 217 6 minecraft:andesite
fill -11 217 5 -10 217 6 minecraft:tuff
fill -5 217 5 -5 219 7 minecraft:stone
fill 11 217 5 11 220 5 minecraft:stone
fill -25 217 6 -25 221 6 minecraft:stone
setblock -12 217 6 minecraft:stone
fill 2 217 6 3 219 6 minecraft:stone
fill 11 217 6 12 218 6 minecraft:tuff
fill -23 217 7 -23 220 12 minecraft:stone
fill 2 217 7 2 221 7 minecraft:stone
fill 12 217 7 12 217 9 minecraft:stone
fill -13 217 8 -13 220 8 minecraft:stone
setblock 23 217 8 minecraft:amethyst_block
fill -17 217 9 -17 220 9 minecraft:stone
fill -12 217 9 -12 220 9 minecraft:stone
fill 18 217 9 19 220 9 minecraft:stone
fill 20 217 9 21 217 9 minecraft:cobblestone
fill 23 217 9 23 218 9 minecraft:cobblestone
fill -21 217 10 -21 220 11 minecraft:stone
fill -20 217 10 -19 217 10 minecraft:cobblestone
fill -18 217 10 -18 220 10 minecraft:stone
setblock -12 217 10 minecraft:andesite
setblock -4 217 10 minecraft:stone
fill -3 217 10 -3 219 11 minecraft:andesite
fill 0 217 10 0 219 14 minecraft:tuff
fill 22 217 10 22 218 11 minecraft:cobblestone
setblock 23 217 10 minecraft:dripstone_block
fill -22 217 11 -22 220 11 minecraft:stone
fill -20 217 11 -20 220 13 minecraft:stone
fill -14 217 11 -14 221 11 minecraft:stone
fill -4 217 11 -4 220 14 minecraft:andesite
fill 15 217 11 16 220 11 minecraft:stone
fill 17 217 11 19 218 11 minecraft:cobblestone
fill 23 217 11 23 218 11 minecraft:cobblestone
fill -22 217 12 -21 217 12 minecraft:andesite
fill -14 217 12 -14 218 12 minecraft:andesite
setblock -2 217 12 minecraft:andesite
fill -1 217 12 -1 218 12 minecraft:stone
fill 1 217 12 1 220 14 minecraft:tuff
fill 15 217 12 16 217 12 minecraft:andesite
fill 17 217 12 17 218 12 minecraft:stone
fill 22 217 12 22 217 14 minecraft:stone
setblock -22 217 13 minecraft:andesite
fill 2 217 13 2 218 13 minecraft:tuff
setblock 21 217 13 minecraft:amethyst_block
fill -21 217 14 -21 221 14 minecraft:stone
fill -13 217 14 -13 220 14 minecraft:andesite
fill -6 217 14 -5 217 14 minecraft:stone
fill 2 217 14 2 221 14 minecraft:stone
setblock 21 217 14 minecraft:dripstone_block
fill -20 217 15 -19 220 15 minecraft:stone
fill -13 217 15 -13 218 15 minecraft:stone
fill -6 217 15 -6 220 15 minecraft:stone
fill -5 217 15 -5 218 15 minecraft:andesite
setblock -4 217 15 minecraft:stone
fill 2 217 15 2 218 15 minecraft:cobblestone
fill 3 217 15 3 220 15 minecraft:stone
fill 21 217 15 21 220 16 minecraft:stone
fill -19 217 16 -19 221 16 minecraft:stone
fill -2 217 16 -2 219 16 minecraft:cobblestone
fill 20 217 16 20 220 16 minecraft:stone
setblock -19 217 17 minecraft:dripstone_block
fill -18 217 17 -18 220 18 minecraft:stone
fill -2 217 17 -2 221 17 minecraft:stone
fill 9 217 17 9 219 17 minecraft:cobblestone
fill 20 217 17 21 217 17 minecraft:andesite
setblock -19 217 18 minecraft:cobblestone
fill -13 217 18 -12 217 18 minecraft:stone
fill 8 217 18 8 219 18 minecraft:tuff
setblock 9 217 18 minecraft:stone
fill 20 217 18 20 218 18 minecraft:andesite
fill 21 217 18 21 220 18 minecraft:stone
fill -19 217 19 -19 220 19 minecraft:stone
setblock -18 217 19 minecraft:cobblestone
fill -13 217 19 -13 217 22 minecraft:stone
fill -12 217 19 -11 221 20 minecraft:andesite
fill -10 217 19 -10 221 19 minecraft:stone
