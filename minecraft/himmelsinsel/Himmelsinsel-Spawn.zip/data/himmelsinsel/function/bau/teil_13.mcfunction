fill 5 217 -3 5 221 -3 minecraft:tuff
setblock 19 217 -3 minecraft:stone
fill 20 217 -3 20 221 -3 minecraft:andesite
fill 24 217 -3 24 217 -1 minecraft:andesite
fill 27 217 -3 27 220 -3 minecraft:stone
fill -27 217 -2 -27 220 -2 minecraft:tuff
fill -24 217 -2 -24 220 -1 minecraft:stone
fill -19 217 -2 -19 219 -2 minecraft:andesite
fill -16 217 -2 -16 220 -2 minecraft:andesite
fill 26 217 -2 27 217 -1 minecraft:cobblestone
fill -28 217 -1 -27 217 0 minecraft:stone
setblock -25 217 -1 minecraft:tuff
fill -20 217 -1 -19 217 -1 minecraft:stone
fill 21 217 -1 21 220 1 minecraft:andesite
fill 25 217 -1 25 219 1 minecraft:cobblestone
fill -26 217 0 -26 218 0 minecraft:tuff
fill -23 217 0 -23 220 0 minecraft:stone
fill -19 217 0 -19 219 4 minecraft:stone
fill 0 217 0 0 219 0 minecraft:andesite
fill 11 217 0 11 219 0 minecraft:stone
fill 16 217 0 16 220 0 minecraft:stone
setblock 24 217 0 minecraft:dripstone_block
fill 26 217 0 26 218 1 minecraft:cobblestone
fill -27 217 1 -26 220 2 minecraft:stone
fill -3 217 1 -3 221 1 minecraft:stone
fill 11 217 1 11 217 2 minecraft:cobblestone
setblock 17 217 1 minecraft:tuff
fill 23 217 1 24 218 1 minecraft:stone
fill -3 217 2 -1 219 3 minecraft:andesite
fill 12 217 2 12 218 2 minecraft:cobblestone
setblock 17 217 2 minecraft:stone
fill 21 217 2 21 220 2 minecraft:stone
fill 24 217 2 24 217 3 minecraft:stone
setblock -27 217 3 minecraft:dripstone_block
fill -26 217 3 -25 220 4 minecraft:stone
fill -5 217 3 -4 220 3 minecraft:andesite
fill 0 217 3 1 219 3 minecraft:andesite
setblock 11 217 3 minecraft:stone
fill 23 217 3 23 217 7 minecraft:stone
fill -24 217 4 -24 221 9 minecraft:stone
fill -5 217 4 -3 217 4 minecraft:stone
fill -1 217 4 0 217 5 minecraft:stone
fill 12 217 4 12 220 5 minecraft:stone
setblock 24 217 4 minecraft:amethyst_block
setblock -25 217 5 minecraft:dripstone_block
setblock -19 217 5 minecraft:cobblestone
fill -18 217 5 -18 221 5 minecraft:stone
fill -16 217 5 -15 217 6 minecraft:andesite
fill -11 217 5 -10 217 6 minecraft:tuff
fill -5 217 5 -5 219 7 minecraft:stone
fill 11 217 5 11 220 5 minecraft:stone
fill -25 217 6 -25 221 6 minecraft:stone
setblock -12 217 6 minecraft:stone
fill 2 217 6 3 219 6 minecraft:stone
fill 11 217 6 12 218 6 minecraft:tuff
fill -23 217 7 -23 220 12 minecraft:stone
fill 2 217 7 2 221 7 minecraft:stone
fill 12 217 7 12 217 9 minecraft:stone
fill -13 217 8 -13 220 8 minecraft:stone
setblock 23 217 8 minecraft:amethyst_block
fill -17 217 9 -17 220 9 minecraft:stone
fill -12 217 9 -12 220 9 minecraft:stone
fill 18 217 9 19 220 9 minecraft:stone
fill 20 217 9 21 217 9 minecraft:cobblestone
fill 23 217 9 23 218 9 minecraft:cobblestone
fill -21 217 10 -21 220 11 minecraft:stone
fill -20 217 10 -19 217 10 minecraft:cobblestone
fill -18 217 10 -18 220 10 minecraft:stone
setblock -12 217 10 minecraft:andesite
setblock -4 217 10 minecraft:stone
fill -3 217 10 -3 219 11 minecraft:andesite
fill 0 217 10 0 219 14 minecraft:tuff
fill 22 217 10 22 218 11 minecraft:cobblestone
setblock 23 217 10 minecraft:dripstone_block
fill -22 217 11 -22 220 11 minecraft:stone
fill -20 217 11 -20 220 13 minecraft:stone
fill -14 217 11 -14 221 11 minecraft:stone
fill -4 217 11 -4 220 14 minecraft:andesite
fill 15 217 11 16 220 11 minecraft:stone
fill 17 217 11 19 218 11 minecraft:cobblestone
fill 23 217 11 23 218 11 minecraft:cobblestone
fill -22 217 12 -21 217 12 minecraft:andesite
fill -14 217 12 -14 218 12 minecraft:andesite
setblock -2 217 12 minecraft:andesite
fill -1 217 12 -1 218 12 minecraft:stone
fill 1 217 12 1 220 14 minecraft:tuff
fill 15 217 12 16 217 12 minecraft:andesite
fill 17 217 12 17 218 12 minecraft:stone
fill 22 217 12 22 217 14 minecraft:stone
setblock -22 217 13 minecraft:andesite
fill 2 217 13 2 218 13 minecraft:tuff
setblock 21 217 13 minecraft:amethyst_block
fill -21 217 14 -21 221 14 minecraft:stone
fill -13 217 14 -13 220 14 minecraft:andesite
fill -6 217 14 -5 217 14 minecraft:stone
fill 2 217 14 2 221 14 minecraft:stone
setblock 21 217 14 minecraft:dripstone_block
fill -20 217 15 -19 220 15 minecraft:stone
fill -13 217 15 -13 218 15 minecraft:stone
fill -6 217 15 -6 220 15 minecraft:stone
fill -5 217 15 -5 218 15 minecraft:andesite
setblock -4 217 15 minecraft:stone
fill 2 217 15 2 218 15 minecraft:cobblestone
fill 3 217 15 3 220 15 minecraft:stone
fill 21 217 15 21 220 16 minecraft:stone
fill -19 217 16 -19 221 16 minecraft:stone
fill -2 217 16 -2 219 16 minecraft:cobblestone
fill 20 217 16 20 220 16 minecraft:stone
setblock -19 217 17 minecraft:dripstone_block
fill -18 217 17 -18 220 18 minecraft:stone
fill -2 217 17 -2 221 17 minecraft:stone
fill 9 217 17 9 219 17 minecraft:cobblestone
fill 20 217 17 21 217 17 minecraft:andesite
setblock -19 217 18 minecraft:cobblestone
fill -13 217 18 -12 217 18 minecraft:stone
fill 8 217 18 8 219 18 minecraft:tuff
setblock 9 217 18 minecraft:stone
fill 20 217 18 20 218 18 minecraft:andesite
fill 21 217 18 21 220 18 minecraft:stone
fill -19 217 19 -19 220 19 minecraft:stone
setblock -18 217 19 minecraft:cobblestone
fill -13 217 19 -13 217 22 minecraft:stone
fill -12 217 19 -11 221 20 minecraft:andesite
fill -10 217 19 -10 221 19 minecraft:stone
fill 8 217 19 8 217 22 minecraft:stone
fill 20 217 19 20 220 20 minecraft:stone
setblock -19 217 20 minecraft:dripstone_block
fill -17 217 20 -17 220 20 minecraft:stone
fill -10 217 20 -9 217 21 minecraft:andesite
fill -8 217 20 -7 221 20 minecraft:stone
fill 5 217 20 7 219 20 minecraft:stone
fill 17 217 20 19 220 21 minecraft:stone
fill -18 217 21 -18 219 21 minecraft:stone
fill -12 217 21 -12 221 21 minecraft:andesite
fill -8 217 21 -8 221 21 minecraft:stone
fill 5 217 21 5 219 22 minecraft:tuff
fill 6 217 21 7 220 22 minecraft:stone
fill 16 217 21 16 220 21 minecraft:stone
fill -17 217 22 -17 220 22 minecraft:stone
fill -12 217 22 -12 221 22 minecraft:stone
fill -5 217 22 -5 221 23 minecraft:stone
fill 14 217 22 15 221 22 minecraft:stone
fill -16 217 23 -14 220 23 minecraft:stone
fill -13 217 23 -12 217 23 minecraft:cobblestone
fill -11 217 23 -11 219 24 minecraft:stone
fill -4 217 23 -4 219 25 minecraft:stone
fill 12 217 23 13 221 23 minecraft:stone
fill 41 217 23 41 222 23 minecraft:stone
fill 9 217 24 12 218 24 minecraft:stone
fill 40 217 24 40 220 24 minecraft:cobblestone
fill 41 217 24 41 219 25 minecraft:andesite
fill -10 217 25 -10 219 25 minecraft:stone
setblock -5 217 25 minecraft:tuff
fill -3 217 25 -3 221 26 minecraft:stone
setblock 9 217 25 minecraft:tuff
fill 10 217 25 11 220 25 minecraft:stone
setblock 39 217 25 minecraft:stone
fill -9 217 26 -9 219 26 minecraft:stone
fill -8 217 26 -8 219 26 minecraft:andesite
fill -7 217 26 -5 219 26 minecraft:stone
setblock -4 217 26 minecraft:cobblestone
setblock -1 217 26 minecraft:stone
fill 0 217 26 0 220 26 minecraft:tuff
fill 1 217 26 9 217 26 minecraft:stone
setblock 10 217 26 minecraft:amethyst_block
fill 11 217 26 11 220 26 minecraft:stone
fill 40 217 26 40 222 26 minecraft:stone
fill -2 217 27 -2 220 28 minecraft:tuff
setblock 2 217 27 minecraft:tuff
fill -1 217 28 -1 220 29 minecraft:tuff
fill 1 217 28 1 220 28 minecraft:tuff
fill 0 217 29 0 220 29 minecraft:tuff
fill -8 218 -28 -7 220 -28 minecraft:stone
fill -6 218 -28 -3 218 -28 minecraft:tuff
fill -2 218 -28 -2 220 -27 minecraft:stone
fill 2 218 -28 5 220 -28 minecraft:stone
setblock 6 218 -28 minecraft:cobblestone
fill -10 218 -27 -10 220 -27 minecraft:stone
setblock -9 218 -27 minecraft:tuff
setblock -1 218 -27 minecraft:amethyst_block
fill 0 218 -27 1 219 -27 minecraft:cobblestone
fill 6 218 -27 8 218 -27 minecraft:stone
fill -12 218 -26 -12 219 -26 minecraft:stone
setblock -11 218 -26 minecraft:dripstone_block
fill -10 218 -26 -10 219 -26 minecraft:tuff
fill -3 218 -26 -3 220 -26 minecraft:stone
fill 9 218 -26 9 220 -26 minecraft:stone
fill -16 218 -25 -13 220 -25 minecraft:stone
fill -6 218 -25 -6 219 -25 minecraft:tuff
fill 6 218 -25 7 220 -25 minecraft:stone
fill 8 218 -25 8 220 -23 minecraft:tuff
fill 10 218 -25 10 219 -24 minecraft:tuff
fill -17 218 -24 -17 218 -22 minecraft:stone
fill -13 218 -24 -11 220 -23 minecraft:stone
fill -10 218 -24 -10 220 -24 minecraft:tuff
fill -8 218 -24 -7 221 -24 minecraft:tuff
fill -6 218 -24 -6 221 -24 minecraft:stone
fill 11 218 -24 11 218 -23 minecraft:cobblestone
setblock -16 218 -23 minecraft:stone
setblock -15 218 -23 minecraft:tuff
fill -10 218 -23 -10 220 -23 minecraft:stone
fill 10 218 -23 10 221 -23 minecraft:stone
fill 12 218 -23 12 219 -23 minecraft:cobblestone
fill 13 218 -23 13 219 -23 minecraft:stone
fill -18 218 -22 -18 219 -21 minecraft:stone
fill -16 218 -22 -16 220 -22 minecraft:tuff
setblock 12 218 -22 minecraft:stone
setblock 13 218 -22 minecraft:andesite
fill 14 218 -22 15 221 -22 minecraft:stone
setblock 16 218 -22 minecraft:dripstone_block
fill 17 218 -22 17 221 -22 minecraft:stone
setblock -38 218 -21 minecraft:andesite
fill -17 218 -21 -17 220 -20 minecraft:tuff
fill -14 218 -21 -12 221 -21 minecraft:stone
setblock -1 218 -21 minecraft:cobblestone
fill 0 218 -21 0 221 -20 minecraft:stone
setblock 2 218 -21 minecraft:stone
fill 3 218 -21 3 219 -21 minecraft:andesite
fill 5 218 -21 5 219 -21 minecraft:andesite
fill 6 218 -21 6 220 -21 minecraft:stone
