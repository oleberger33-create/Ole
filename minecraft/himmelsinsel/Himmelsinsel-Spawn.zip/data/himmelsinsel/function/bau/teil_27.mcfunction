fill 43 222 22 43 223 22 minecraft:stone
fill -20 222 23 -20 223 23 minecraft:dirt
fill -16 222 23 -16 223 24 minecraft:dirt
fill -14 222 23 -14 223 28 minecraft:dirt
fill -13 222 23 -13 222 24 minecraft:rooted_dirt
fill -5 222 23 -5 223 28 minecraft:dirt
fill -4 222 23 -3 222 23 minecraft:rooted_dirt
fill 1 222 23 1 223 23 minecraft:dirt
fill 4 222 23 4 223 23 minecraft:dirt
fill 7 222 23 7 223 23 minecraft:dirt
fill 13 222 23 13 223 23 minecraft:dirt
setblock 14 222 23 minecraft:rooted_dirt
fill 15 222 23 17 223 23 minecraft:dirt
fill 37 222 23 37 222 25 minecraft:mossy_cobblestone
setblock 38 222 23 minecraft:stone
setblock 39 222 23 minecraft:andesite
fill -11 222 24 -10 222 24 minecraft:rooted_dirt
fill -9 222 24 -9 223 26 minecraft:dirt
fill -4 222 24 -4 223 25 minecraft:dirt
fill -3 222 24 -3 222 25 minecraft:rooted_dirt
fill 12 222 24 13 222 24 minecraft:rooted_dirt
fill 14 222 24 14 223 24 minecraft:dirt
fill 15 222 24 15 222 25 minecraft:rooted_dirt
fill 16 222 24 18 223 25 minecraft:dirt
fill 36 222 24 36 222 25 minecraft:mossy_cobblestone
fill 38 222 24 38 222 25 minecraft:mossy_cobblestone
fill 39 222 24 39 222 25 minecraft:stone
fill -13 222 25 -13 223 29 minecraft:dirt
fill -11 222 25 -10 223 25 minecraft:dirt
setblock -6 222 25 minecraft:rooted_dirt
fill 4 222 25 4 223 28 minecraft:dirt
fill 7 222 25 7 223 25 minecraft:dirt
setblock 11 222 25 minecraft:rooted_dirt
fill 12 222 25 13 223 25 minecraft:dirt
setblock 14 222 25 minecraft:rooted_dirt
fill -17 222 26 -17 223 26 minecraft:dirt
setblock -12 222 26 minecraft:rooted_dirt
fill -11 222 26 -11 223 30 minecraft:dirt
fill -10 222 26 -10 222 28 minecraft:rooted_dirt
fill -8 222 26 -8 223 28 minecraft:dirt
fill -6 222 26 -6 223 27 minecraft:dirt
setblock -4 222 26 minecraft:rooted_dirt
fill -3 222 26 -3 223 26 minecraft:dirt
fill -1 222 26 -1 223 27 minecraft:dirt
fill 2 222 26 2 223 26 minecraft:dirt
fill 14 222 26 17 223 26 minecraft:dirt
fill 36 222 26 37 222 26 minecraft:stone
fill -12 222 27 -12 223 30 minecraft:dirt
setblock -9 222 27 minecraft:rooted_dirt
fill -4 222 27 -4 223 29 minecraft:dirt
fill -3 222 27 -3 222 28 minecraft:rooted_dirt
fill 1 222 27 1 223 27 minecraft:dirt
setblock 3 222 27 minecraft:rooted_dirt
fill 5 222 27 5 223 30 minecraft:dirt
fill 6 222 27 7 222 27 minecraft:rooted_dirt
fill 8 222 27 12 223 27 minecraft:dirt
fill 14 222 27 14 223 28 minecraft:dirt
setblock 15 222 27 minecraft:rooted_dirt
setblock 37 222 27 minecraft:stone
fill 42 222 27 43 222 27 minecraft:andesite
fill -9 222 28 -9 223 29 minecraft:dirt
fill -7 222 28 -6 222 28 minecraft:rooted_dirt
fill 2 222 28 3 223 28 minecraft:dirt
fill 6 222 28 9 223 28 minecraft:dirt
fill 11 222 28 12 223 28 minecraft:dirt
setblock 39 222 28 minecraft:stone
setblock 42 222 28 minecraft:andesite
fill -10 222 29 -10 223 30 minecraft:dirt
setblock -8 222 29 minecraft:rooted_dirt
fill -7 222 29 -7 223 29 minecraft:dirt
fill -6 222 29 -5 222 29 minecraft:rooted_dirt
fill -3 222 29 -3 223 29 minecraft:dirt
fill 3 222 29 4 222 29 minecraft:rooted_dirt
setblock 6 222 29 minecraft:rooted_dirt
fill 7 222 29 7 223 30 minecraft:dirt
setblock 8 222 29 minecraft:rooted_dirt
fill 9 222 29 9 223 29 minecraft:dirt
setblock 40 222 29 minecraft:amethyst_block
setblock 41 222 29 minecraft:stone
setblock -9 222 30 minecraft:rooted_dirt
fill -8 222 30 -8 223 31 minecraft:dirt
setblock -7 222 30 minecraft:rooted_dirt
fill -6 222 30 -5 223 30 minecraft:dirt
fill -2 222 30 0 223 30 minecraft:dirt
fill 3 222 30 4 223 30 minecraft:dirt
fill 6 222 30 6 223 30 minecraft:dirt
fill -9 222 31 -9 223 31 minecraft:dirt
fill -7 222 31 -6 223 31 minecraft:dirt
fill -4 222 31 -3 223 31 minecraft:dirt
fill -1 222 31 -1 223 31 minecraft:dirt
fill 4 223 -30 4 223 -27 minecraft:dirt
fill -1 223 -29 -1 223 -28 minecraft:dirt
fill 1 223 -29 1 223 -28 minecraft:dirt
setblock -2 223 -28 minecraft:dirt
setblock 0 223 -28 minecraft:dirt
setblock 2 223 -28 minecraft:dirt
setblock 10 223 -28 minecraft:dirt
setblock -11 223 -27 minecraft:dirt
fill -5 223 -27 -4 223 -27 minecraft:dirt
fill -2 223 -27 2 223 -9 minecraft:stone
setblock -5 223 -26 minecraft:dirt
fill -4 223 -26 -3 223 -10 minecraft:stone
fill 3 223 -26 4 223 -10 minecraft:stone
fill 5 223 -26 6 223 -26 minecraft:dirt
setblock 10 223 -26 minecraft:dirt
setblock 13 223 -26 minecraft:dirt
fill -40 223 -25 -39 226 -25 minecraft:stone
setblock -18 223 -25 minecraft:dirt
fill -8 223 -25 -7 223 -25 minecraft:dirt
fill -6 223 -25 -5 223 -11 minecraft:stone
fill 5 223 -25 6 223 -11 minecraft:stone
setblock 7 223 -25 minecraft:dirt
fill 14 223 -25 15 223 -25 minecraft:dirt
fill -42 223 -24 -42 226 -24 minecraft:stone
setblock -38 223 -24 minecraft:tuff
fill -7 223 -24 -7 223 -12 minecraft:stone
fill 7 223 -24 7 223 -12 minecraft:stone
fill 13 223 -24 13 223 -22 minecraft:dirt
fill 16 223 -24 16 223 -23 minecraft:dirt
fill -40 223 -23 -40 226 -23 minecraft:tuff
fill -38 223 -23 -38 226 -23 minecraft:stone
setblock -21 223 -23 minecraft:dirt
setblock 8 223 -23 minecraft:dirt
setblock 12 223 -23 minecraft:dirt
fill -43 223 -22 -43 226 -22 minecraft:stone
fill -19 223 -22 -18 223 -22 minecraft:dirt
fill -9 223 -22 -9 223 -21 minecraft:dirt
fill -8 223 -22 -8 223 -14 minecraft:stone
fill 8 223 -22 8 223 -14 minecraft:stone
fill 9 223 -22 9 223 -21 minecraft:dirt
setblock 11 223 -22 minecraft:dirt
setblock -43 223 -21 minecraft:andesite
fill -42 223 -21 -42 224 -21 minecraft:cobblestone
fill -40 223 -21 -38 224 -21 minecraft:cobblestone
fill -37 223 -21 -37 227 -21 minecraft:stone
setblock -11 223 -21 minecraft:dirt
fill -40 223 -20 -40 224 -20 minecraft:stone
setblock -22 223 -20 minecraft:dirt
setblock -15 223 -20 minecraft:dirt
fill -9 223 -20 -9 223 -16 minecraft:stone
fill 9 223 -20 9 223 -16 minecraft:stone
fill 11 223 -20 12 223 -19 minecraft:dirt
setblock 19 223 -20 minecraft:dirt
setblock -20 223 -19 minecraft:dirt
fill -14 223 -19 -13 223 -19 minecraft:dirt
fill -10 223 -19 -10 223 -17 minecraft:dirt
setblock -19 223 -18 minecraft:dirt
fill -12 223 -18 -11 223 -18 minecraft:dirt
setblock 14 223 -18 minecraft:dirt
setblock 18 223 -18 minecraft:dirt
fill 20 223 -18 20 223 -17 minecraft:dirt
setblock -12 223 -17 minecraft:dirt
fill 13 223 -17 13 223 -16 minecraft:dirt
setblock 21 223 -17 minecraft:dirt
setblock -20 223 -16 minecraft:dirt
setblock 14 223 -16 minecraft:dirt
fill 16 223 -16 17 223 -16 minecraft:dirt
setblock 28 223 -16 minecraft:dirt
fill -21 223 -15 -21 223 -14 minecraft:dirt
fill -19 223 -15 -19 223 -14 minecraft:dirt
fill -13 223 -15 -13 223 -14 minecraft:dirt
setblock -9 223 -15 minecraft:dirt
setblock 17 223 -15 minecraft:dirt
setblock 20 223 -15 minecraft:dirt
fill 22 223 -15 22 223 -14 minecraft:dirt
setblock 27 223 -15 minecraft:dirt
fill 29 223 -15 29 223 -13 minecraft:dirt
fill -20 223 -14 -20 223 -12 minecraft:dirt
setblock 11 223 -14 minecraft:dirt
setblock 13 223 -14 minecraft:dirt
setblock 21 223 -14 minecraft:dirt
fill 25 223 -14 25 223 -12 minecraft:dirt
setblock 28 223 -14 minecraft:dirt
setblock -14 223 -13 minecraft:dirt
setblock -10 223 -13 minecraft:dirt
fill -8 223 -13 -8 223 -12 minecraft:dirt
fill 8 223 -13 8 223 -10 minecraft:dirt
setblock 10 223 -13 minecraft:dirt
setblock 16 223 -13 minecraft:dirt
setblock 26 223 -13 minecraft:dirt
fill 17 223 -12 18 223 -12 minecraft:dirt
setblock 27 223 -12 minecraft:dirt
fill -7 223 -11 -7 223 -9 minecraft:dirt
fill 7 223 -11 7 223 -9 minecraft:dirt
fill 16 223 -11 17 223 -7 minecraft:dirt
fill 19 223 -11 19 223 -7 minecraft:dirt
setblock -13 223 -10 minecraft:dirt
fill -9 223 -10 -8 223 -10 minecraft:dirt
fill -6 223 -10 -5 223 -10 minecraft:dirt
fill 5 223 -10 6 223 -10 minecraft:dirt
fill 21 223 -10 21 223 -7 minecraft:dirt
setblock 23 223 -10 minecraft:dirt
setblock 27 223 -10 minecraft:dirt
setblock -17 223 -9 minecraft:dirt
setblock -14 223 -9 minecraft:dirt
fill -3 223 -9 -3 223 -7 minecraft:dirt
setblock -9 223 -8 minecraft:dirt
fill -2 223 -8 -2 223 -7 minecraft:dirt
fill 0 223 -8 1 223 -8 minecraft:dirt
setblock -17 223 -7 minecraft:dirt
setblock -8 223 -7 minecraft:dirt
setblock 15 223 -7 minecraft:dirt
setblock 18 223 -7 minecraft:dirt
setblock 20 223 -7 minecraft:dirt
fill 23 223 -7 25 223 -7 minecraft:dirt
fill -30 223 -6 -28 223 -6 minecraft:dirt
fill -23 223 -6 -22 223 -6 minecraft:dirt
fill -1 223 -6 0 223 -4 minecraft:dirt
setblock 5 223 -6 minecraft:dirt
fill 7 223 -6 7 223 -5 minecraft:dirt
fill 13 223 -6 25 223 6 minecraft:stone
setblock -30 223 -5 minecraft:dirt
setblock -27 223 -5 minecraft:dirt
fill -20 223 -5 -19 223 -5 minecraft:dirt
fill -13 223 -5 -13 223 -4 minecraft:dirt
setblock 9 223 -5 minecraft:dirt
setblock -31 223 -4 minecraft:dirt
fill -29 223 -4 -28 223 -4 minecraft:dirt
setblock -26 223 -4 minecraft:dirt
fill -23 223 -4 -23 223 -2 minecraft:dirt
