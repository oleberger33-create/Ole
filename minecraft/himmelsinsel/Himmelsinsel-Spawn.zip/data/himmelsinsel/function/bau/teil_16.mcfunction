fill 38 219 -35 38 220 -35 minecraft:stone
fill 41 219 -35 42 220 -35 minecraft:stone
setblock 43 219 -35 minecraft:dripstone_block
setblock 31 219 -34 minecraft:amethyst_block
fill 32 219 -34 33 219 -33 minecraft:andesite
fill 42 219 -34 43 221 -34 minecraft:stone
fill 30 219 -33 31 220 -33 minecraft:andesite
fill 43 219 -33 43 221 -31 minecraft:stone
fill 30 219 -32 30 220 -32 minecraft:stone
fill 29 219 -31 29 220 -28 minecraft:stone
fill 39 219 -31 39 220 -30 minecraft:stone
fill 30 219 -30 30 220 -29 minecraft:stone
fill 42 219 -30 42 220 -29 minecraft:stone
fill 44 219 -30 44 219 -27 minecraft:stone
fill -8 219 -29 -6 220 -29 minecraft:stone
fill -5 219 -29 -3 220 -28 minecraft:tuff
fill -2 219 -29 -1 219 -29 minecraft:stone
setblock 1 219 -29 minecraft:amethyst_block
fill 2 219 -29 5 220 -29 minecraft:stone
fill -10 219 -28 -9 220 -28 minecraft:stone
fill -6 219 -28 -6 220 -28 minecraft:stone
fill -1 219 -28 -1 219 -27 minecraft:stone
fill 0 219 -28 1 219 -28 minecraft:cobblestone
fill 6 219 -28 6 220 -28 minecraft:stone
setblock 7 219 -28 minecraft:dripstone_block
fill 8 219 -28 8 220 -27 minecraft:stone
fill 30 219 -28 30 219 -27 minecraft:cobblestone
fill 42 219 -28 42 219 -26 minecraft:cobblestone
setblock -11 219 -27 minecraft:dripstone_block
fill -9 219 -27 -9 220 -27 minecraft:stone
fill -5 219 -27 -4 220 -27 minecraft:tuff
setblock -3 219 -27 minecraft:stone
fill 4 219 -27 4 220 -27 minecraft:stone
setblock 6 219 -27 minecraft:cobblestone
fill 7 219 -27 7 220 -27 minecraft:stone
fill 9 219 -27 10 220 -27 minecraft:stone
fill -15 219 -26 -15 220 -26 minecraft:stone
setblock -14 219 -26 minecraft:amethyst_block
fill -13 219 -26 -13 220 -26 minecraft:stone
fill -11 219 -26 -11 220 -26 minecraft:stone
fill 4 219 -26 4 220 -25 minecraft:andesite
fill 10 219 -26 11 221 -26 minecraft:stone
setblock 30 219 -26 minecraft:stone
setblock 43 219 -26 minecraft:cobblestone
fill -17 219 -25 -17 220 -23 minecraft:stone
setblock 11 219 -25 minecraft:amethyst_block
fill 12 219 -25 12 221 -25 minecraft:stone
fill 31 219 -25 31 220 -24 minecraft:stone
fill 43 219 -25 43 221 -25 minecraft:andesite
fill -18 219 -24 -18 220 -23 minecraft:stone
fill 11 219 -24 11 221 -23 minecraft:stone
setblock 12 219 -24 minecraft:cobblestone
fill 13 219 -24 14 219 -24 minecraft:stone
fill 32 219 -24 32 220 -23 minecraft:stone
fill 42 219 -24 42 219 -23 minecraft:andesite
fill -40 219 -23 -40 222 -23 minecraft:stone
setblock -16 219 -23 minecraft:tuff
fill -15 219 -23 -15 220 -23 minecraft:stone
fill -9 219 -23 -8 221 -23 minecraft:tuff
fill -7 219 -23 -4 219 -23 minecraft:stone
fill 14 219 -23 16 221 -23 minecraft:stone
fill 33 219 -23 36 220 -23 minecraft:stone
fill -41 219 -22 -41 226 -22 minecraft:stone
fill -39 219 -22 -39 221 -22 minecraft:stone
setblock -19 219 -22 minecraft:dripstone_block
fill -17 219 -22 -17 220 -22 minecraft:tuff
fill 12 219 -22 12 219 -21 minecraft:andesite
fill 13 219 -22 13 219 -21 minecraft:stone
fill 16 219 -22 16 220 -21 minecraft:stone
fill 18 219 -22 18 221 -22 minecraft:stone
fill 35 219 -22 41 220 -22 minecraft:stone
setblock -39 219 -21 minecraft:andesite
fill -38 219 -21 -38 221 -21 minecraft:stone
fill -21 219 -21 -19 220 -21 minecraft:stone
fill -5 219 -21 -5 220 -21 minecraft:stone
fill -4 219 -21 -4 220 -21 minecraft:andesite
fill -1 219 -21 -1 221 -21 minecraft:stone
setblock 2 219 -21 minecraft:cobblestone
fill 14 219 -21 15 220 -21 minecraft:stone
fill 17 219 -21 17 220 -21 minecraft:stone
fill 19 219 -21 21 219 -21 minecraft:stone
fill -22 219 -20 -20 221 -20 minecraft:stone
fill 3 219 -20 5 219 -20 minecraft:andesite
fill 6 219 -20 6 220 -20 minecraft:stone
fill 19 219 -20 19 221 -20 minecraft:stone
fill 21 219 -20 23 219 -20 minecraft:stone
fill -23 219 -19 -22 220 -19 minecraft:stone
fill -17 219 -19 -17 220 -16 minecraft:tuff
fill -6 219 -19 -6 220 -17 minecraft:stone
fill 24 219 -19 25 220 -19 minecraft:stone
fill -25 219 -18 -24 220 -18 minecraft:stone
fill -22 219 -18 -22 220 -18 minecraft:stone
fill -13 219 -18 -13 221 -18 minecraft:stone
setblock 19 219 -18 minecraft:stone
fill 20 219 -18 20 220 -18 minecraft:tuff
setblock 22 219 -18 minecraft:tuff
fill 23 219 -18 23 220 -18 minecraft:stone
fill 25 219 -18 25 220 -18 minecraft:stone
fill 14 219 -17 14 221 -16 minecraft:stone
fill 19 219 -17 19 221 -17 minecraft:tuff
setblock 26 219 -17 minecraft:dripstone_block
fill -26 219 -16 -26 220 -16 minecraft:stone
fill -6 219 -16 -6 219 -15 minecraft:cobblestone
setblock -4 219 -16 minecraft:cobblestone
fill -3 219 -16 -3 220 -15 minecraft:stone
setblock 3 219 -16 minecraft:cobblestone
fill 4 219 -16 4 220 -16 minecraft:stone
setblock 15 219 -16 minecraft:stone
setblock 19 219 -16 minecraft:stone
fill 20 219 -16 21 220 -16 minecraft:tuff
fill 26 219 -16 26 220 -16 minecraft:stone
fill -27 219 -15 -27 219 -14 minecraft:dripstone_block
fill -17 219 -15 -17 220 -15 minecraft:stone
fill -16 219 -15 -15 219 -15 minecraft:tuff
fill 14 219 -15 15 219 -15 minecraft:cobblestone
setblock 16 219 -15 minecraft:stone
fill 20 219 -15 21 219 -15 minecraft:stone
fill 25 219 -15 25 220 -15 minecraft:stone
fill 27 219 -15 27 219 -14 minecraft:stone
fill -28 219 -14 -28 220 -14 minecraft:tuff
fill -26 219 -14 -26 220 -14 minecraft:stone
setblock 3 219 -14 minecraft:cobblestone
fill 5 219 -14 6 221 -14 minecraft:stone
fill 23 219 -14 23 220 -13 minecraft:andesite
fill 25 219 -14 25 219 -12 minecraft:andesite
fill 26 219 -14 26 221 -14 minecraft:stone
fill 28 219 -14 28 221 -12 minecraft:stone
fill -28 219 -13 -28 219 -12 minecraft:stone
fill -25 219 -13 -25 220 -13 minecraft:stone
setblock -14 219 -13 minecraft:stone
fill -13 219 -13 -13 219 -12 minecraft:cobblestone
fill 3 219 -13 3 219 -12 minecraft:stone
setblock 4 219 -13 minecraft:tuff
fill 6 219 -13 6 221 -12 minecraft:stone
setblock 26 219 -13 minecraft:andesite
fill -29 219 -12 -29 220 -11 minecraft:stone
fill -27 219 -12 -26 219 -12 minecraft:cobblestone
setblock -14 219 -12 minecraft:cobblestone
setblock -12 219 -12 minecraft:cobblestone
fill 5 219 -12 5 220 -12 minecraft:tuff
setblock 23 219 -12 minecraft:stone
fill 24 219 -12 24 221 -12 minecraft:andesite
fill 29 219 -12 29 221 -10 minecraft:stone
fill -27 219 -11 -26 219 -11 minecraft:stone
setblock -12 219 -11 minecraft:stone
fill 3 219 -11 3 221 -10 minecraft:tuff
fill 24 219 -11 25 219 -11 minecraft:stone
fill -26 219 -10 -26 220 -10 minecraft:stone
fill -8 219 -10 -7 220 -10 minecraft:stone
fill 2 219 -10 2 220 -10 minecraft:stone
fill 9 219 -10 9 221 -10 minecraft:stone
fill 14 219 -10 14 220 -10 minecraft:stone
fill 15 219 -10 15 220 -10 minecraft:tuff
fill 24 219 -10 24 221 -10 minecraft:stone
fill 30 219 -10 30 219 -6 minecraft:stone
fill -30 219 -9 -30 220 -6 minecraft:stone
fill -8 219 -9 -8 221 -9 minecraft:andesite
setblock -7 219 -9 minecraft:stone
fill 2 219 -9 2 220 -8 minecraft:tuff
setblock 9 219 -9 minecraft:cobblestone
fill 10 219 -9 10 219 -8 minecraft:stone
fill 11 219 -9 11 220 -8 minecraft:andesite
setblock 27 219 -9 minecraft:cobblestone
fill 5 219 -8 5 220 -7 minecraft:tuff
fill 6 219 -8 6 220 -5 minecraft:stone
fill 14 219 -8 14 220 -7 minecraft:stone
fill 16 219 -8 17 220 -8 minecraft:tuff
fill 27 219 -8 27 219 -6 minecraft:stone
setblock -29 219 -7 minecraft:stone
fill -26 219 -7 -26 220 -2 minecraft:stone
fill -9 219 -7 -9 219 -5 minecraft:stone
setblock -4 219 -7 minecraft:andesite
fill -2 219 -7 -2 220 -7 minecraft:stone
fill 2 219 -7 2 220 -7 minecraft:stone
fill 3 219 -7 3 220 -7 minecraft:tuff
fill 11 219 -7 11 219 -4 minecraft:stone
fill 12 219 -7 13 219 -7 minecraft:andesite
fill 16 219 -7 17 220 -6 minecraft:stone
fill -21 219 -6 -21 220 -6 minecraft:stone
fill -15 219 -6 -15 221 -6 minecraft:stone
fill 12 219 -6 12 220 -4 minecraft:stone
fill 15 219 -6 15 220 -6 minecraft:stone
fill -29 219 -5 -29 219 -3 minecraft:stone
fill -4 219 -5 -4 220 -4 minecraft:andesite
fill 9 219 -5 10 221 -4 minecraft:stone
fill 13 219 -5 14 220 -3 minecraft:stone
fill 15 219 -5 15 220 -4 minecraft:andesite
setblock 30 219 -5 minecraft:dripstone_block
fill -28 219 -4 -28 221 -3 minecraft:tuff
fill -9 219 -4 -9 219 -3 minecraft:cobblestone
fill -6 219 -4 -5 219 -4 minecraft:stone
fill 6 219 -4 6 219 -3 minecraft:tuff
fill 22 219 -4 22 221 -4 minecraft:stone
fill 30 219 -4 30 220 -2 minecraft:stone
fill -21 219 -3 -21 220 -1 minecraft:andesite
fill -1 219 -3 -1 220 -3 minecraft:andesite
fill 1 219 -3 1 220 -3 minecraft:andesite
setblock 15 219 -3 minecraft:stone
fill 16 219 -3 16 221 -3 minecraft:andesite
setblock 22 219 -3 minecraft:andesite
setblock 23 219 -3 minecraft:cobblestone
fill -30 219 -2 -30 221 -2 minecraft:stone
fill -29 219 -2 -29 220 -1 minecraft:tuff
setblock -9 219 -2 minecraft:stone
fill -1 219 -2 -1 219 -1 minecraft:stone
fill 0 219 -2 0 220 -2 minecraft:andesite
fill 20 219 -2 20 221 -1 minecraft:andesite
setblock 23 219 -2 minecraft:andesite
setblock 24 219 -2 minecraft:cobblestone
fill 26 219 -2 26 220 4 minecraft:stone
setblock -30 219 -1 minecraft:dripstone_block
fill -28 219 -1 -28 220 0 minecraft:tuff
setblock -17 219 -1 minecraft:andesite
setblock 0 219 -1 minecraft:cobblestone
setblock 24 219 -1 minecraft:andesite
fill 29 219 -1 29 219 3 minecraft:stone
setblock -30 219 0 minecraft:cobblestone
fill -29 219 0 -29 219 2 minecraft:stone
fill -27 219 0 -27 220 0 minecraft:tuff
fill -26 219 0 -25 220 0 minecraft:stone
