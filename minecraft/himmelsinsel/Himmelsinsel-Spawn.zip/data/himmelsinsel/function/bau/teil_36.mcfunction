setblock 20 225 -11 minecraft:pink_petals[facing=west,flower_amount=4]
setblock 21 225 -11 minecraft:tall_grass[half=lower]
setblock 25 225 -11 minecraft:wildflowers[facing=west,flower_amount=2]
setblock 26 225 -11 minecraft:fern
setblock 30 225 -11 minecraft:fern
setblock -31 225 -10 minecraft:short_grass
setblock -28 225 -10 minecraft:fern
fill -26 225 -10 -25 225 -10 minecraft:short_grass
fill -23 225 -10 -23 225 -9 minecraft:short_grass
setblock -21 225 -10 minecraft:tall_grass[half=lower]
fill -10 225 -10 -9 225 -10 minecraft:fern
fill -8 225 -10 -8 225 -9 minecraft:short_grass
setblock -6 225 -10 minecraft:short_grass
setblock 9 225 -10 minecraft:lily_of_the_valley
fill 10 225 -10 11 225 -10 minecraft:short_grass
setblock 13 225 -10 minecraft:short_grass
fill 16 225 -10 18 225 -10 minecraft:short_grass
setblock 20 225 -10 minecraft:short_grass
fill 24 225 -10 24 225 -9 minecraft:short_grass
setblock 26 225 -10 minecraft:allium
fill 27 225 -10 27 225 -8 minecraft:short_grass
setblock -30 225 -9 minecraft:short_grass
setblock -27 225 -9 minecraft:short_grass
setblock -26 225 -9 minecraft:lily_of_the_valley
fill -24 225 -9 -24 225 -8 minecraft:short_grass
setblock -22 225 -9 minecraft:fern
fill -21 225 -9 -21 225 -8 minecraft:short_grass
fill -18 225 -9 -17 225 -8 minecraft:short_grass
setblock -13 225 -9 minecraft:short_grass
fill -12 225 -9 -11 225 -9 minecraft:fern
setblock -4 225 -9 minecraft:short_grass
setblock 3 225 -9 minecraft:pink_petals[facing=north,flower_amount=3]
fill 5 225 -9 5 225 -8 minecraft:short_grass
setblock 7 225 -9 minecraft:cornflower
setblock 9 225 -9 minecraft:azure_bluet
setblock 12 225 -9 minecraft:tall_grass[half=lower]
setblock 17 225 -9 minecraft:pink_petals[facing=west,flower_amount=4]
setblock 18 225 -9 minecraft:short_grass
setblock 19 225 -9 minecraft:fern
setblock 23 225 -9 minecraft:tall_grass[half=lower]
fill 29 225 -9 30 225 -9 minecraft:short_grass
setblock 31 225 -9 minecraft:pink_petals[facing=south,flower_amount=3]
setblock -25 225 -8 minecraft:pink_petals[facing=west,flower_amount=1]
setblock -19 225 -8 minecraft:cornflower
setblock -11 225 -8 minecraft:tall_grass[half=lower]
setblock -9 225 -8 minecraft:short_grass
fill -7 225 -8 -6 225 -8 minecraft:short_grass
setblock -2 225 -8 minecraft:short_grass
setblock 2 225 -8 minecraft:short_grass
setblock 11 225 -8 minecraft:lily_of_the_valley
setblock 14 225 -8 minecraft:tall_grass[half=lower]
fill 15 225 -8 15 225 -7 minecraft:short_grass
setblock 18 225 -8 minecraft:dandelion
setblock 21 225 -8 minecraft:short_grass
setblock 25 225 -8 minecraft:dandelion
setblock 29 225 -8 minecraft:lily_of_the_valley
setblock 30 225 -8 minecraft:short_grass
setblock -31 225 -7 minecraft:lily_of_the_valley
fill -29 225 -7 -28 225 -7 minecraft:short_grass
setblock -25 225 -7 minecraft:short_grass
setblock -22 225 -7 minecraft:poppy
setblock -20 225 -7 minecraft:short_grass
setblock -18 225 -7 minecraft:pink_petals[facing=west,flower_amount=1]
fill -17 225 -7 -17 225 -6 minecraft:short_grass
setblock -12 225 -7 minecraft:short_grass
setblock -10 225 -7 minecraft:short_grass
fill -6 225 -7 -6 225 -6 minecraft:short_grass
setblock -5 225 -7 minecraft:fern
fill -4 225 -7 -3 225 -7 minecraft:short_grass
setblock 3 225 -7 minecraft:short_grass
setblock 13 225 -7 minecraft:short_grass
setblock 17 225 -7 minecraft:short_grass
setblock 24 225 -7 minecraft:short_grass
setblock 26 225 -7 minecraft:pink_petals[facing=west,flower_amount=3]
setblock 28 225 -7 minecraft:tall_grass[half=lower]
setblock 29 225 -7 minecraft:short_grass
setblock 31 225 -7 minecraft:short_grass
fill -30 225 -6 -30 225 -5 minecraft:short_grass
setblock -25 225 -6 minecraft:tall_grass[half=lower]
fill -24 225 -6 -24 225 -5 minecraft:short_grass
fill -22 225 -6 -22 225 -5 minecraft:short_grass
setblock -21 225 -6 minecraft:tall_grass[half=lower]
setblock -19 225 -6 minecraft:short_grass
setblock -18 225 -6 minecraft:pink_petals[facing=north,flower_amount=1]
fill -15 225 -6 -15 225 -5 minecraft:allium
setblock -13 225 -6 minecraft:short_grass
setblock -11 225 -6 minecraft:short_grass
setblock 6 225 -6 minecraft:short_grass
fill 8 225 -6 9 225 -6 minecraft:short_grass
setblock 12 225 -6 minecraft:short_grass
setblock 26 225 -6 minecraft:tall_grass[half=lower]
setblock 28 225 -6 minecraft:pink_petals[facing=north,flower_amount=3]
setblock 31 225 -6 minecraft:oxeye_daisy
setblock -29 225 -5 minecraft:short_grass
setblock -26 225 -5 minecraft:short_grass
setblock -25 225 -5 minecraft:pink_petals[facing=east,flower_amount=1]
fill -21 225 -5 -20 225 -5 minecraft:short_grass
setblock -18 225 -5 minecraft:short_grass
setblock -14 225 -5 minecraft:tall_grass[half=lower]
setblock -12 225 -5 minecraft:azure_bluet
setblock -11 225 -5 minecraft:pink_petals[facing=west,flower_amount=3]
fill -10 225 -5 -9 225 -5 minecraft:allium
setblock -6 225 -5 minecraft:tall_grass[half=lower]
setblock 6 225 -5 minecraft:pink_petals[facing=south,flower_amount=4]
fill 8 225 -5 8 225 -4 minecraft:short_grass
setblock 10 225 -5 minecraft:azure_bluet
fill 11 225 -5 12 225 -5 minecraft:tall_grass[half=lower]
setblock 15 225 -5 minecraft:anvil[facing=east]
setblock 17 225 -5 minecraft:anvil[facing=east]
setblock 19 225 -5 minecraft:anvil[facing=east]
setblock 28 225 -5 minecraft:short_grass
setblock -28 225 -4 minecraft:short_grass
setblock -22 225 -4 minecraft:pink_petals[facing=east,flower_amount=4]
fill -20 225 -4 -19 225 -4 minecraft:fern
setblock -18 225 -4 minecraft:allium
fill -16 225 -4 -15 225 -4 minecraft:short_grass
setblock -12 225 -4 minecraft:short_grass
setblock -11 225 -4 minecraft:pink_petals[facing=south,flower_amount=2]
setblock 7 225 -4 minecraft:short_grass
setblock 9 225 -4 minecraft:wildflowers[facing=east,flower_amount=1]
setblock 12 225 -4 minecraft:short_grass
setblock 31 225 -4 minecraft:short_grass
setblock -25 225 -3 minecraft:tall_grass[half=lower]
setblock -24 225 -3 minecraft:short_grass
setblock -22 225 -3 minecraft:short_grass
fill -17 225 -3 -16 225 -3 minecraft:short_grass
setblock -14 225 -3 minecraft:short_grass
setblock -11 225 -3 minecraft:dandelion
setblock -7 225 -3 minecraft:short_grass
setblock 8 225 -3 minecraft:pink_petals[facing=north,flower_amount=1]
fill 9 225 -3 11 225 -3 minecraft:short_grass
setblock 29 225 -3 minecraft:fern
setblock 30 225 -3 minecraft:tall_grass[half=lower]
setblock -17 225 -2 minecraft:wildflowers[facing=south,flower_amount=3]
setblock -15 225 -2 minecraft:tall_grass[half=lower]
setblock -13 225 -2 minecraft:short_grass
fill -11 225 -2 -10 225 -2 minecraft:short_grass
setblock -8 225 -2 minecraft:short_grass
setblock 8 225 -2 minecraft:wildflowers[facing=north,flower_amount=1]
setblock 9 225 -2 minecraft:short_grass
setblock 27 225 -2 minecraft:short_grass
fill 28 225 -2 29 225 -2 minecraft:tall_grass[half=lower]
setblock 28 225 -1 minecraft:short_grass
setblock 30 225 -1 minecraft:wildflowers[facing=north,flower_amount=3]
setblock 31 225 -1 minecraft:short_grass
setblock 30 225 0 minecraft:pink_petals[facing=north,flower_amount=1]
setblock 26 225 1 minecraft:tall_grass[half=lower]
fill 27 225 1 28 225 1 minecraft:short_grass
fill -23 225 2 -22 225 3 minecraft:short_grass
fill -18 225 2 -16 225 2 minecraft:short_grass
fill -14 225 2 -13 225 2 minecraft:short_grass
fill -10 225 2 -10 225 3 minecraft:short_grass
setblock -8 225 2 minecraft:tall_grass[half=lower]
setblock 9 225 2 minecraft:short_grass
setblock 26 225 2 minecraft:oxeye_daisy
setblock 27 225 2 minecraft:short_grass
setblock 29 225 2 minecraft:short_grass
setblock -25 225 3 minecraft:azure_bluet
setblock -21 225 3 minecraft:short_grass
fill -20 225 3 -19 225 3 minecraft:tall_grass[half=lower]
setblock -18 225 3 minecraft:azure_bluet
setblock -17 225 3 minecraft:pink_petals[facing=west,flower_amount=3]
fill -15 225 3 -14 225 3 minecraft:short_grass
fill -12 225 3 -11 225 3 minecraft:fern
setblock -9 225 3 minecraft:short_grass
setblock 8 225 3 minecraft:poppy
setblock 11 225 3 minecraft:wildflowers[facing=west,flower_amount=4]
setblock 27 225 3 minecraft:tall_grass[half=lower]
setblock 28 225 3 minecraft:short_grass
setblock -26 225 4 minecraft:tall_grass[half=lower]
setblock -24 225 4 minecraft:tall_grass[half=lower]
setblock -23 225 4 minecraft:dandelion
setblock -20 225 4 minecraft:short_grass
fill -18 225 4 -18 225 5 minecraft:short_grass
setblock -17 225 4 minecraft:cornflower
setblock -14 225 4 minecraft:short_grass
setblock -12 225 4 minecraft:azure_bluet
setblock -11 225 4 minecraft:short_grass
setblock -10 225 4 minecraft:fern
setblock -9 225 4 minecraft:azure_bluet
setblock -7 225 4 minecraft:short_grass
fill 8 225 4 12 225 4 minecraft:short_grass
setblock 26 225 4 minecraft:lily_of_the_valley
fill 27 225 4 27 225 5 minecraft:short_grass
fill 29 225 4 30 225 4 minecraft:short_grass
fill -29 225 5 -27 225 5 minecraft:short_grass
setblock -26 225 5 minecraft:azure_bluet
fill -25 225 5 -25 225 7 minecraft:short_grass
setblock -24 225 5 minecraft:wildflowers[facing=west,flower_amount=3]
setblock -23 225 5 minecraft:short_grass
setblock -21 225 5 minecraft:tall_grass[half=lower]
fill -19 225 5 -19 225 7 minecraft:short_grass
setblock -17 225 5 minecraft:short_grass
setblock -16 225 5 minecraft:fern
setblock -15 225 5 minecraft:cornflower
fill 7 225 5 7 225 6 minecraft:short_grass
setblock 12 225 5 minecraft:short_grass
setblock -28 225 6 minecraft:poppy
fill -26 225 6 -26 225 7 minecraft:short_grass
setblock -24 225 6 minecraft:short_grass
setblock -22 225 6 minecraft:short_grass
setblock -20 225 6 minecraft:short_grass
setblock -18 225 6 minecraft:fern
setblock -17 225 6 minecraft:wildflowers[facing=south,flower_amount=2]
fill -13 225 6 -13 225 7 minecraft:short_grass
fill -11 225 6 -11 225 7 minecraft:short_grass
fill -8 225 6 -7 225 6 minecraft:short_grass
fill -5 225 6 -5 225 7 minecraft:short_grass
setblock 6 225 6 minecraft:wildflowers[facing=north,flower_amount=2]
fill 9 225 6 9 225 7 minecraft:short_grass
setblock 12 225 6 minecraft:lily_of_the_valley
setblock 28 225 6 minecraft:short_grass
setblock 29 225 6 minecraft:tall_grass[half=lower]
setblock -27 225 7 minecraft:oxeye_daisy
setblock -23 225 7 minecraft:short_grass
setblock -21 225 7 minecraft:short_grass
setblock -20 225 7 minecraft:tall_grass[half=lower]
setblock -18 225 7 minecraft:short_grass
setblock -14 225 7 minecraft:short_grass
setblock -12 225 7 minecraft:short_grass
