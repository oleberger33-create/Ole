# Händler und Schilder (alte vorher entfernen)
kill @e[tag=hs.wesen,type=!minecraft:player]
function himmelsinsel:haendler/meister
function himmelsinsel:haendler/werkzeuge
function himmelsinsel:haendler/schwert
function himmelsinsel:haendler/ruestung
function himmelsinsel:haendler/fernkampf
function himmelsinsel:haendler/kopf_fuss
function himmelsinsel:haendler/wasser
function himmelsinsel:haendler/streitkolben
function himmelsinsel:haendler/fluch
function himmelsinsel:markt/bauer
function himmelsinsel:markt/bergmann
function himmelsinsel:markt/jaeger
function himmelsinsel:markt/holz
function himmelsinsel:schilder
