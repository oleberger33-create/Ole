execute if score #stufe hs.state matches 1 run function himmelsinsel:bau/start
execute if score #stufe hs.state matches 2.. run function himmelsinsel:bau/schritt
