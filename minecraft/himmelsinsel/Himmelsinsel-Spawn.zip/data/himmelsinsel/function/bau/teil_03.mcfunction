fill 3 202 -3 4 202 -3 minecraft:cobblestone
fill -7 202 -2 -7 209 -1 minecraft:stone
fill -6 202 -1 -5 202 0 minecraft:andesite
fill -1 202 -1 -1 208 0 minecraft:stone
fill 0 202 -1 0 202 0 minecraft:tuff
fill 4 202 -1 5 202 0 minecraft:tuff
fill 6 202 -1 6 221 -1 minecraft:stone
fill -4 202 0 -4 205 0 minecraft:andesite
fill -3 202 0 -2 221 0 minecraft:stone
fill 6 202 0 6 203 0 minecraft:tuff
fill -12 202 1 -12 205 1 minecraft:andesite
fill -7 202 1 -6 221 1 minecraft:stone
fill -5 202 1 -5 205 1 minecraft:andesite
fill 6 202 1 6 209 1 minecraft:stone
fill -10 202 2 -10 220 4 minecraft:stone
setblock -7 202 2 minecraft:dripstone_block
fill -7 202 3 -7 217 3 minecraft:stone
fill 8 202 3 8 203 3 minecraft:stone
fill -11 202 4 -11 205 4 minecraft:andesite
setblock -8 202 4 minecraft:dripstone_block
fill -5 202 4 -5 206 4 minecraft:andesite
fill 0 202 4 0 206 5 minecraft:tuff
fill -7 202 5 -7 220 5 minecraft:stone
fill -4 202 5 -4 205 5 minecraft:andesite
setblock -1 202 5 minecraft:stone
fill 5 202 5 8 205 5 minecraft:stone
fill -3 202 6 -3 204 6 minecraft:cobblestone
setblock -1 202 6 minecraft:cobblestone
fill 0 202 6 3 203 6 minecraft:stone
setblock -4 202 7 minecraft:dripstone_block
setblock -3 202 7 minecraft:stone
fill -2 202 7 -2 203 7 minecraft:cobblestone
fill -8 203 -10 -8 205 -10 minecraft:stone
fill -6 203 -10 -6 215 -10 minecraft:stone
setblock -5 203 -9 minecraft:andesite
fill -8 203 -8 -8 207 -8 minecraft:stone
fill -1 203 -8 -1 205 -7 minecraft:andesite
fill 1 203 -8 2 203 -8 minecraft:amethyst_block
fill 3 203 -8 4 206 -7 minecraft:stone
setblock -6 203 -7 minecraft:stone
fill -5 203 -7 -5 206 -6 minecraft:andesite
fill -2 203 -7 -2 206 -7 minecraft:andesite
fill 0 203 -7 0 206 -7 minecraft:andesite
fill 1 203 -7 2 203 -7 minecraft:stone
fill -4 203 -6 -3 207 -6 minecraft:andesite
setblock -2 203 -6 minecraft:stone
setblock 3 203 -6 minecraft:dripstone_block
setblock -7 203 -5 minecraft:dripstone_block
fill -5 203 -5 -5 203 -3 minecraft:stone
setblock -4 203 -5 minecraft:cobblestone
fill 3 203 -5 3 209 -4 minecraft:stone
fill -8 203 -4 -8 204 -4 minecraft:stone
fill -6 203 -4 -6 205 0 minecraft:stone
fill -3 203 -4 -3 204 -4 minecraft:cobblestone
fill -7 203 -3 -7 207 -3 minecraft:stone
fill -4 203 -3 -4 204 -3 minecraft:stone
fill 3 203 -3 3 203 -2 minecraft:cobblestone
fill 4 203 -3 5 205 -3 minecraft:stone
setblock -14 203 -2 minecraft:amethyst_block
fill -13 203 -2 -13 205 0 minecraft:deepslate
fill -3 203 -2 -3 221 -1 minecraft:stone
setblock 6 203 -2 minecraft:amethyst_block
setblock -12 203 -1 minecraft:amethyst_block
fill -8 203 -1 -8 212 1 minecraft:stone
fill -5 203 -1 -5 203 0 minecraft:andesite
fill 0 203 -1 1 203 -1 minecraft:stone
fill 2 203 -1 4 203 0 minecraft:tuff
fill 5 203 -1 5 220 -1 minecraft:stone
setblock -14 203 0 minecraft:stone
fill -10 203 0 -10 220 0 minecraft:stone
fill -7 203 0 -7 221 0 minecraft:stone
fill 0 203 0 1 209 0 minecraft:tuff
setblock 5 203 0 minecraft:tuff
fill -3 203 1 -3 216 2 minecraft:stone
fill 1 203 1 2 207 1 minecraft:tuff
fill 5 203 1 5 220 1 minecraft:stone
fill 7 203 1 7 208 1 minecraft:stone
fill -7 203 2 -7 220 2 minecraft:stone
fill -2 203 3 -2 204 5 minecraft:stone
fill -1 203 3 -1 206 5 minecraft:tuff
fill 9 203 3 9 218 4 minecraft:stone
fill -8 203 4 -8 218 5 minecraft:stone
fill -5 203 5 -5 206 5 minecraft:andesite
setblock -3 203 5 minecraft:cobblestone
fill 1 203 5 1 204 5 minecraft:tuff
fill -6 203 6 -6 205 6 minecraft:stone
fill -4 203 6 -4 205 6 minecraft:andesite
setblock -2 203 6 minecraft:cobblestone
setblock -1 203 6 minecraft:stone
fill 4 203 6 8 220 6 minecraft:stone
fill -5 203 7 -4 204 7 minecraft:stone
fill -3 203 7 -3 204 7 minecraft:cobblestone
fill -4 203 8 -4 220 8 minecraft:stone
setblock -3 203 8 minecraft:amethyst_block
fill -4 204 -10 -3 220 -9 minecraft:stone
fill -7 204 -9 -7 204 -8 minecraft:deepslate
fill -6 204 -9 -5 209 -9 minecraft:stone
fill -2 204 -9 -2 212 -9 minecraft:stone
fill -6 204 -8 -6 205 -5 minecraft:andesite
fill 0 204 -8 1 204 -8 minecraft:andesite
fill 2 204 -8 2 218 -7 minecraft:stone
fill 5 204 -8 7 206 -7 minecraft:stone
fill -7 204 -7 -7 208 -5 minecraft:andesite
fill 1 204 -7 1 205 -7 minecraft:andesite
fill -2 204 -6 -2 207 -6 minecraft:andesite
fill 3 204 -6 4 217 -6 minecraft:stone
setblock 5 204 -6 minecraft:dripstone_block
fill -8 204 -5 -8 212 -5 minecraft:andesite
fill -5 204 -5 -4 208 -5 minecraft:andesite
setblock -3 204 -5 minecraft:cobblestone
fill -2 204 -5 -2 205 -5 minecraft:stone
setblock -9 204 -4 minecraft:deepslate
fill -5 204 -4 -5 204 -1 minecraft:stone
fill -4 204 -4 -4 205 -4 minecraft:cobblestone
fill -9 204 -3 -9 207 0 minecraft:stone
fill 3 204 -3 3 209 -2 minecraft:stone
fill 6 204 -3 6 206 -3 minecraft:andesite
fill -14 204 -2 -14 204 0 minecraft:deepslate
fill -4 204 -2 -4 221 -2 minecraft:stone
fill 6 204 -2 6 205 -2 minecraft:stone
setblock -15 204 -1 minecraft:stone
fill -12 204 -1 -12 205 -1 minecraft:deepslate
fill -10 204 -1 -10 220 -1 minecraft:stone
fill 0 204 -1 0 207 -1 minecraft:stone
fill 1 204 -1 3 204 -1 minecraft:tuff
fill 4 204 -1 4 220 -1 minecraft:stone
setblock -12 204 0 minecraft:andesite
setblock -11 204 0 minecraft:dripstone_block
setblock -5 204 0 minecraft:andesite
fill 2 204 0 4 204 0 minecraft:tuff
fill 5 204 0 6 209 0 minecraft:stone
fill 3 204 1 3 205 1 minecraft:tuff
setblock -2 204 2 minecraft:stone
fill -1 204 2 -1 206 2 minecraft:tuff
fill 1 204 2 1 204 3 minecraft:tuff
fill 7 204 2 7 206 3 minecraft:deepslate
fill 8 204 2 8 208 2 minecraft:stone
fill -4 204 3 -4 205 4 minecraft:andesite
fill -3 204 3 -3 204 5 minecraft:stone
fill 8 204 3 8 205 3 minecraft:deepslate
fill 1 204 4 1 217 4 minecraft:stone
fill 9 204 5 9 220 6 minecraft:stone
fill 20 204 5 20 220 5 minecraft:stone
setblock -7 204 6 minecraft:dripstone_block
fill -5 204 6 -5 206 6 minecraft:andesite
fill -2 204 6 -2 219 8 minecraft:stone
fill -1 204 6 0 208 6 minecraft:tuff
fill 1 204 6 3 204 6 minecraft:stone
fill 19 204 6 19 220 6 minecraft:stone
fill -1 204 7 -1 205 7 minecraft:stone
fill 2 204 7 8 214 7 minecraft:stone
fill -5 204 8 -5 220 8 minecraft:stone
fill -3 204 8 -3 220 9 minecraft:stone
fill -4 204 9 -4 220 9 minecraft:stone
fill -5 205 -10 -5 209 -10 minecraft:stone
fill -9 205 -9 -9 209 -9 minecraft:stone
fill -7 205 -9 -7 217 -8 minecraft:stone
fill -1 205 -9 0 205 -9 minecraft:stone
fill 1 205 -9 1 206 -9 minecraft:cobblestone
fill 2 205 -9 3 206 -9 minecraft:stone
fill 4 205 -9 5 207 -9 minecraft:deepslate
fill -5 205 -8 -2 209 -8 minecraft:stone
setblock 0 205 -8 minecraft:andesite
setblock 1 205 -8 minecraft:stone
fill 8 205 -8 8 219 -8 minecraft:stone
setblock 8 205 -7 minecraft:dripstone_block
setblock 9 205 -7 minecraft:stone
fill -8 205 -6 -8 211 -6 minecraft:andesite
fill -1 205 -6 0 207 -6 minecraft:andesite
fill 5 205 -6 8 206 -6 minecraft:stone
fill -9 205 -5 -9 212 -4 minecraft:andesite
fill -3 205 -5 -3 208 -5 minecraft:andesite
fill -1 205 -5 0 205 -4 minecraft:stone
fill 4 205 -5 6 215 -5 minecraft:stone
fill -8 205 -4 -7 211 -4 minecraft:andesite
fill -5 205 -4 -5 210 -4 minecraft:andesite
fill -3 205 -4 -3 206 -4 minecraft:stone
fill 1 205 -4 1 205 -3 minecraft:cobblestone
fill 4 205 -4 5 208 -4 minecraft:stone
setblock 6 205 -4 minecraft:andesite
setblock -10 205 -3 minecraft:deepslate
fill -5 205 -3 -5 207 0 minecraft:stone
setblock -4 205 -3 minecraft:cobblestone
setblock 0 205 -3 minecraft:stone
fill 7 205 -3 7 206 -3 minecraft:andesite
fill -15 205 -2 -14 220 -2 minecraft:stone
setblock -12 205 -2 minecraft:deepslate
fill -10 205 -2 -10 220 -2 minecraft:stone
setblock 7 205 -2 minecraft:deepslate
fill -15 205 -1 -14 206 -1 minecraft:deepslate
fill -11 205 -1 -11 220 0 minecraft:stone
fill -4 205 -1 -4 221 -1 minecraft:stone
fill 1 205 -1 2 205 -1 minecraft:tuff
fill 3 205 -1 3 220 -1 minecraft:stone
fill 7 205 -1 7 207 0 minecraft:stone
fill -14 205 0 -14 207 0 minecraft:deepslate
setblock -12 205 0 minecraft:deepslate
fill 2 205 0 3 205 0 minecraft:tuff
fill 4 205 0 4 220 0 minecraft:stone
setblock -13 205 1 minecraft:andesite
setblock -13 205 2 minecraft:dripstone_block
fill -2 205 2 -2 205 3 minecraft:deepslate
fill 1 205 2 1 207 2 minecraft:tuff
fill 6 205 2 6 207 4 minecraft:deepslate
fill 9 205 2 10 208 2 minecraft:stone
fill -3 205 3 -3 208 3 minecraft:deepslate
fill 1 205 3 1 216 3 minecraft:stone
setblock 5 205 3 minecraft:stone
fill 10 205 3 10 209 6 minecraft:stone
fill -12 205 4 -12 206 4 minecraft:andesite
fill -3 205 4 -2 206 5 minecraft:stone
fill 7 205 4 7 206 4 minecraft:deepslate
fill 8 205 4 8 220 4 minecraft:stone
fill 19 205 4 19 206 4 minecraft:stone
fill -9 205 5 -9 220 5 minecraft:stone
fill 1 205 5 1 217 5 minecraft:stone
fill -8 205 6 -7 220 6 minecraft:stone
fill -3 205 6 -3 220 7 minecraft:stone
fill 1 205 6 1 206 6 minecraft:tuff
fill 2 205 6 3 214 6 minecraft:stone
