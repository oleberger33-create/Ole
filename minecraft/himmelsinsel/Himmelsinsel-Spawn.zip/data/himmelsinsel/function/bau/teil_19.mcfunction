setblock -16 220 27 minecraft:mossy_cobblestone
fill -10 220 27 -10 221 27 minecraft:mossy_cobblestone
fill -8 220 27 -8 220 29 minecraft:andesite
fill -5 220 27 -5 221 29 minecraft:tuff
fill 4 220 27 4 220 28 minecraft:andesite
fill 5 220 27 5 221 27 minecraft:stone
fill 11 220 27 12 220 28 minecraft:tuff
setblock 13 220 27 minecraft:stone
setblock 14 220 27 minecraft:amethyst_block
fill 39 220 27 39 222 27 minecraft:stone
fill 41 220 27 41 222 27 minecraft:stone
fill -14 220 28 -14 221 28 minecraft:mossy_cobblestone
fill -10 220 28 -10 221 28 minecraft:andesite
setblock -7 220 28 minecraft:andesite
fill 3 220 28 3 220 30 minecraft:stone
fill 5 220 28 5 221 28 minecraft:andesite
fill 7 220 28 7 221 28 minecraft:stone
fill 10 220 28 10 220 29 minecraft:stone
setblock 13 220 28 minecraft:tuff
setblock -12 220 29 minecraft:dripstone_block
fill -11 220 29 -10 220 29 minecraft:stone
fill -9 220 29 -9 221 29 minecraft:andesite
fill -7 220 29 -7 221 31 minecraft:stone
fill -4 220 29 -4 221 29 minecraft:tuff
fill 4 220 29 6 220 29 minecraft:stone
setblock 7 220 29 minecraft:dripstone_block
fill 8 220 29 8 221 29 minecraft:stone
fill -10 220 30 -8 221 30 minecraft:stone
fill -5 220 30 -3 220 30 minecraft:mossy_cobblestone
setblock -2 220 30 minecraft:tuff
fill 1 220 30 1 220 31 minecraft:tuff
setblock 2 220 30 minecraft:stone
fill -6 220 31 -5 220 31 minecraft:stone
setblock -2 220 31 minecraft:stone
fill -1 220 31 0 220 31 minecraft:tuff
setblock -4 221 -30 minecraft:dripstone_block
setblock -3 221 -30 minecraft:tuff
setblock -2 221 -30 minecraft:stone
setblock -1 221 -30 minecraft:mossy_cobblestone
fill 0 221 -30 1 221 -30 minecraft:stone
fill 2 221 -30 2 223 -30 minecraft:dirt
setblock 3 221 -30 minecraft:rooted_dirt
fill 4 221 -30 4 222 -26 minecraft:dirt
setblock -10 221 -29 minecraft:rooted_dirt
fill -9 221 -29 -7 223 -29 minecraft:dirt
setblock -6 221 -29 minecraft:rooted_dirt
fill -5 221 -29 -3 223 -29 minecraft:dirt
setblock 2 221 -29 minecraft:rooted_dirt
fill 3 221 -29 3 223 -28 minecraft:dirt
fill 5 221 -29 8 223 -28 minecraft:dirt
fill -13 221 -28 -12 221 -28 minecraft:mossy_cobblestone
fill -11 221 -28 -11 221 -27 minecraft:stone
fill -10 221 -28 -9 223 -26 minecraft:dirt
fill -8 221 -28 -7 221 -27 minecraft:rooted_dirt
fill -6 221 -28 -4 223 -28 minecraft:dirt
setblock -3 221 -28 minecraft:rooted_dirt
fill -2 221 -28 -2 222 -19 minecraft:dirt
fill 2 221 -28 2 222 -22 minecraft:dirt
setblock 9 221 -28 minecraft:rooted_dirt
fill 10 221 -28 10 221 -27 minecraft:stone
fill -15 221 -27 -14 221 -27 minecraft:stone
fill -6 221 -27 -6 223 -26 minecraft:dirt
fill -5 221 -27 -4 221 -27 minecraft:rooted_dirt
fill -3 221 -27 -3 223 -27 minecraft:dirt
setblock 3 221 -27 minecraft:rooted_dirt
setblock 5 221 -27 minecraft:rooted_dirt
fill 6 221 -27 9 223 -27 minecraft:dirt
fill 12 221 -27 12 221 -26 minecraft:stone
fill -17 221 -26 -14 223 -26 minecraft:dirt
setblock -13 221 -26 minecraft:mossy_cobblestone
fill -11 221 -26 -11 223 -25 minecraft:dirt
fill -8 221 -26 -7 223 -26 minecraft:dirt
setblock -5 221 -26 minecraft:rooted_dirt
fill -4 221 -26 -4 221 -24 minecraft:stone
setblock -3 221 -26 minecraft:rooted_dirt
fill -1 221 -26 1 222 -26 minecraft:dirt
fill 3 221 -26 3 222 -25 minecraft:dirt
fill 5 221 -26 6 222 -25 minecraft:dirt
setblock 7 221 -26 minecraft:rooted_dirt
fill 8 221 -26 9 223 -24 minecraft:dirt
setblock 14 221 -26 minecraft:stone
fill -17 221 -25 -17 221 -24 minecraft:rooted_dirt
fill -16 221 -25 -16 223 -20 minecraft:dirt
fill -15 221 -25 -14 221 -25 minecraft:rooted_dirt
fill -13 221 -25 -13 223 -22 minecraft:dirt
fill -12 221 -25 -12 221 -24 minecraft:rooted_dirt
setblock -10 221 -25 minecraft:rooted_dirt
fill -9 221 -25 -9 223 -25 minecraft:dirt
fill -6 221 -25 -5 221 -25 minecraft:stone
fill -1 221 -25 0 222 -24 minecraft:dirt
fill 1 221 -25 1 221 -23 minecraft:rooted_dirt
setblock 4 221 -25 minecraft:andesite
fill 7 221 -25 7 222 -23 minecraft:dirt
setblock 16 221 -25 minecraft:mossy_cobblestone
fill -41 221 -24 -40 221 -24 minecraft:stone
fill -39 221 -24 -39 226 -24 minecraft:tuff
setblock -18 221 -24 minecraft:rooted_dirt
fill -15 221 -24 -14 223 -22 minecraft:dirt
setblock -11 221 -24 minecraft:rooted_dirt
fill -10 221 -24 -10 223 -23 minecraft:dirt
setblock -9 221 -24 minecraft:tuff
setblock -5 221 -24 minecraft:stone
fill 3 221 -24 3 221 -23 minecraft:andesite
fill 5 221 -24 5 221 -23 minecraft:stone
fill 6 221 -24 6 222 -22 minecraft:dirt
fill 16 221 -24 17 221 -24 minecraft:stone
setblock -21 221 -23 minecraft:stone
fill -19 221 -23 -18 221 -23 minecraft:stone
fill -17 221 -23 -17 223 -23 minecraft:dirt
fill -12 221 -23 -11 223 -23 minecraft:dirt
setblock -3 221 -23 minecraft:stone
setblock -1 221 -23 minecraft:rooted_dirt
fill 0 221 -23 0 222 -23 minecraft:dirt
fill 8 221 -23 8 222 -21 minecraft:dirt
setblock 9 221 -23 minecraft:rooted_dirt
setblock 19 221 -23 minecraft:stone
fill -42 221 -22 -42 226 -22 minecraft:stone
setblock -38 221 -22 minecraft:stone
setblock -22 221 -22 minecraft:stone
setblock -19 221 -22 minecraft:stone
fill -18 221 -22 -18 221 -21 minecraft:tuff
setblock -17 221 -22 minecraft:rooted_dirt
fill -7 221 -22 -7 221 -21 minecraft:stone
fill -6 221 -22 -5 221 -22 minecraft:rooted_dirt
fill -4 221 -22 -4 222 -20 minecraft:dirt
setblock -3 221 -22 minecraft:rooted_dirt
fill -1 221 -22 -1 222 -22 minecraft:dirt
setblock 0 221 -22 minecraft:rooted_dirt
fill 1 221 -22 1 222 -22 minecraft:dirt
fill 3 221 -22 5 222 -22 minecraft:dirt
setblock 7 221 -22 minecraft:rooted_dirt
fill 9 221 -22 9 222 -17 minecraft:dirt
setblock 10 221 -22 minecraft:rooted_dirt
fill 13 221 -22 13 221 -21 minecraft:mossy_cobblestone
setblock 16 221 -22 minecraft:stone
setblock 21 221 -22 minecraft:stone
setblock -41 221 -21 minecraft:andesite
fill -40 221 -21 -40 222 -21 minecraft:stone
fill -23 221 -21 -23 223 -18 minecraft:dirt
fill -21 221 -21 -20 221 -21 minecraft:stone
fill -19 221 -21 -19 221 -19 minecraft:tuff
fill -17 221 -21 -17 223 -21 minecraft:dirt
setblock -15 221 -21 minecraft:rooted_dirt
fill -6 221 -21 -5 222 -20 minecraft:dirt
fill -3 221 -21 -3 222 -18 minecraft:dirt
fill 2 221 -21 2 221 -18 minecraft:mossy_cobblestone
fill 3 221 -21 3 222 -21 minecraft:dirt
fill 4 221 -21 6 221 -21 minecraft:rooted_dirt
fill 7 221 -21 7 222 -17 minecraft:dirt
fill 10 221 -21 10 223 -19 minecraft:dirt
setblock 14 221 -21 minecraft:stone
fill 15 221 -21 16 223 -21 minecraft:dirt
setblock 17 221 -21 minecraft:rooted_dirt
fill 18 221 -21 18 223 -19 minecraft:dirt
fill 22 221 -21 22 223 -19 minecraft:dirt
setblock 23 221 -21 minecraft:rooted_dirt
setblock -24 221 -20 minecraft:rooted_dirt
setblock -17 221 -20 minecraft:tuff
fill -15 221 -20 -15 221 -19 minecraft:tuff
fill 1 221 -20 1 221 -19 minecraft:mossy_cobblestone
fill 3 221 -20 3 221 -19 minecraft:rooted_dirt
fill 4 221 -20 4 222 -15 minecraft:dirt
setblock 5 221 -20 minecraft:rooted_dirt
fill 6 221 -20 6 222 -20 minecraft:dirt
setblock 8 221 -20 minecraft:rooted_dirt
fill 12 221 -20 14 221 -20 minecraft:andesite
setblock 15 221 -20 minecraft:rooted_dirt
fill 16 221 -20 17 223 -20 minecraft:dirt
setblock 20 221 -20 minecraft:mossy_cobblestone
fill 23 221 -20 23 223 -17 minecraft:dirt
fill 24 221 -20 24 221 -19 minecraft:rooted_dirt
fill 25 221 -20 25 223 -18 minecraft:dirt
fill -25 221 -19 -24 223 -19 minecraft:dirt
setblock -22 221 -19 minecraft:stone
fill -17 221 -19 -17 223 -13 minecraft:dirt
setblock -16 221 -19 minecraft:rooted_dirt
fill -14 221 -19 -14 221 -17 minecraft:stone
fill -6 221 -19 -4 221 -19 minecraft:rooted_dirt
fill 5 221 -19 5 222 -17 minecraft:dirt
setblock 6 221 -19 minecraft:rooted_dirt
fill 8 221 -19 8 222 -16 minecraft:dirt
fill 15 221 -19 16 223 -19 minecraft:dirt
fill 17 221 -19 17 221 -18 minecraft:rooted_dirt
fill 20 221 -19 20 221 -18 minecraft:stone
setblock 21 221 -19 minecraft:mossy_cobblestone
setblock 26 221 -19 minecraft:rooted_dirt
fill -26 221 -18 -25 221 -18 minecraft:rooted_dirt
fill -24 221 -18 -24 223 -15 minecraft:dirt
fill -22 221 -18 -22 223 -18 minecraft:dirt
setblock -18 221 -18 minecraft:tuff
fill -16 221 -18 -15 223 -17 minecraft:dirt
fill -6 221 -18 -6 221 -17 minecraft:stone
fill -5 221 -18 -4 222 -18 minecraft:dirt
setblock -2 221 -18 minecraft:stone
setblock 1 221 -18 minecraft:stone
fill 3 221 -18 3 222 -17 minecraft:dirt
fill 6 221 -18 6 222 -16 minecraft:dirt
setblock 10 221 -18 minecraft:rooted_dirt
setblock 15 221 -18 minecraft:rooted_dirt
fill 16 221 -18 16 223 -17 minecraft:dirt
fill 18 221 -18 19 221 -18 minecraft:stone
fill 21 221 -18 21 221 -16 minecraft:stone
fill 24 221 -18 24 223 -15 minecraft:dirt
fill 26 221 -18 26 223 -18 minecraft:dirt
setblock 27 221 -18 minecraft:mossy_cobblestone
fill -26 221 -17 -25 223 -13 minecraft:dirt
fill -23 221 -17 -22 221 -17 minecraft:rooted_dirt
fill -21 221 -17 -20 221 -17 minecraft:stone
fill -18 221 -17 -18 223 -14 minecraft:dirt
fill -5 221 -17 -5 222 -17 minecraft:dirt
fill -4 221 -17 -3 221 -17 minecraft:rooted_dirt
fill -1 221 -17 0 221 -17 minecraft:stone
fill 1 221 -17 1 221 -14 minecraft:mossy_cobblestone
fill 10 221 -17 10 221 -15 minecraft:stone
fill 15 221 -17 15 221 -16 minecraft:stone
setblock 17 221 -17 minecraft:stone
setblock 18 221 -17 minecraft:tuff
setblock 25 221 -17 minecraft:rooted_dirt
fill 26 221 -17 26 221 -16 minecraft:mossy_cobblestone
setblock 28 221 -17 minecraft:tuff
