scoreboard players set #stufe hs.state 2
execute unless score #boden hs.state matches 1 run function himmelsinsel:bau/boden
tellraw @a {"text":"[Himmelsinsel] Baue die Insel … (dauert ein paar Sekunden)","color":"light_purple"}
