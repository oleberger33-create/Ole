fill -2 186 4 -1 202 4 minecraft:stone
fill -4 189 -4 -4 190 -4 minecraft:stone
fill -2 189 5 -1 199 5 minecraft:stone
fill -2 190 3 -1 202 3 minecraft:stone
fill -4 191 -4 -4 201 -4 minecraft:andesite
fill -3 191 4 -3 200 4 minecraft:stone
fill 3 192 0 3 202 0 minecraft:stone
fill -11 192 2 -11 197 2 minecraft:stone
fill 0 192 4 0 201 4 minecraft:stone
fill -5 193 -4 -5 194 -4 minecraft:stone
setblock -4 193 -3 minecraft:amethyst_block
fill 0 193 -3 0 194 -3 minecraft:cobblestone
fill 2 193 0 2 202 0 minecraft:stone
fill 4 193 0 4 200 0 minecraft:stone
setblock -10 193 2 minecraft:dripstone_block
fill -11 193 3 -11 194 3 minecraft:stone
fill 0 193 3 0 200 3 minecraft:stone
fill -3 193 5 -3 202 5 minecraft:stone
fill 0 194 -4 0 198 -4 minecraft:stone
fill -4 194 -3 -4 202 -3 minecraft:andesite
fill -1 194 -3 -1 207 -3 minecraft:stone
fill 0 194 -2 0 195 -2 minecraft:cobblestone
fill 2 194 -1 3 202 -1 minecraft:stone
fill 0 194 0 0 197 0 minecraft:cobblestone
setblock 2 194 1 minecraft:dripstone_block
fill 3 194 1 3 203 1 minecraft:stone
setblock 4 194 1 minecraft:amethyst_block
fill -10 194 2 -10 199 3 minecraft:stone
setblock -1 194 2 minecraft:dripstone_block
setblock 6 194 2 minecraft:stone
fill -3 194 3 -3 199 3 minecraft:stone
setblock 0 194 5 minecraft:dripstone_block
fill -5 195 -4 -5 202 -4 minecraft:andesite
fill -3 195 -4 -3 200 -4 minecraft:andesite
fill -1 195 -4 -1 198 -4 minecraft:stone
setblock -2 195 -3 minecraft:andesite
fill 0 195 -3 1 204 -3 minecraft:stone
setblock -1 195 -2 minecraft:cobblestone
fill 1 195 -2 1 195 -1 minecraft:cobblestone
fill 0 195 -1 0 196 -1 minecraft:cobblestone
fill 4 195 -1 4 201 -1 minecraft:stone
setblock 1 195 0 minecraft:dripstone_block
fill 0 195 1 0 196 1 minecraft:cobblestone
fill 1 195 1 2 200 2 minecraft:stone
fill 4 195 1 4 220 1 minecraft:stone
fill -2 195 2 -1 203 2 minecraft:stone
setblock 0 195 2 minecraft:amethyst_block
fill 5 195 2 5 211 2 minecraft:stone
setblock 6 195 2 minecraft:deepslate
fill -11 195 3 -11 205 3 minecraft:andesite
fill 0 195 5 0 198 5 minecraft:stone
fill -4 196 -5 -4 200 -5 minecraft:andesite
fill 0 196 -5 0 197 -5 minecraft:stone
fill -2 196 -4 -2 207 -3 minecraft:stone
fill 1 196 -4 1 204 -4 minecraft:stone
fill -5 196 -3 -5 202 -3 minecraft:andesite
fill -3 196 -3 -3 201 -3 minecraft:andesite
setblock -2 196 -2 minecraft:dripstone_block
fill -1 196 -2 2 206 -2 minecraft:stone
setblock -1 196 -1 minecraft:dripstone_block
fill 1 196 -1 1 202 0 minecraft:stone
fill -1 196 0 -1 197 1 minecraft:cobblestone
fill 5 196 0 5 198 1 minecraft:stone
fill 0 196 2 0 200 2 minecraft:stone
fill 3 196 2 4 220 2 minecraft:stone
fill 6 196 2 6 204 2 minecraft:stone
fill 1 196 3 2 200 3 minecraft:stone
setblock 6 196 3 minecraft:deepslate
fill -4 196 4 -4 200 4 minecraft:stone
fill 1 196 4 1 200 4 minecraft:stone
fill -2 196 6 -2 200 6 minecraft:stone
fill -7 197 -9 -7 203 -9 minecraft:stone
fill -2 197 -5 -1 197 -5 minecraft:stone
fill -2 197 -2 -2 220 -1 minecraft:stone
fill 3 197 -2 3 202 -2 minecraft:stone
fill -1 197 -1 0 201 -1 minecraft:stone
setblock 5 197 -1 minecraft:dripstone_block
fill 0 197 1 0 200 1 minecraft:stone
fill -12 197 2 -12 206 2 minecraft:andesite
setblock -3 197 2 minecraft:dripstone_block
fill -4 197 3 -4 199 3 minecraft:stone
fill 5 197 3 6 204 3 minecraft:stone
fill -1 197 6 -1 199 6 minecraft:stone
fill -5 198 -5 -5 200 -5 minecraft:andesite
fill -3 198 -5 -3 199 -5 minecraft:andesite
fill -2 198 -5 -2 200 -5 minecraft:stone
fill -1 198 -5 1 198 -5 minecraft:cobblestone
setblock 2 198 -3 minecraft:dripstone_block
fill -3 198 -2 -3 202 -2 minecraft:andesite
fill 4 198 -2 4 217 -2 minecraft:stone
fill 5 198 -1 5 199 -1 minecraft:stone
fill -2 198 0 0 201 0 minecraft:stone
setblock -11 198 1 minecraft:amethyst_block
fill -2 198 1 -1 217 1 minecraft:stone
fill -11 198 2 -11 205 2 minecraft:andesite
setblock -3 198 2 minecraft:stone
fill -5 198 3 -5 200 4 minecraft:stone
fill 3 198 3 3 220 3 minecraft:stone
fill 2 198 4 2 220 4 minecraft:stone
setblock -4 198 5 minecraft:amethyst_block
fill 1 198 5 1 202 5 minecraft:stone
fill -3 198 6 -3 201 6 minecraft:stone
fill -4 199 -6 -4 200 -6 minecraft:stone
setblock -3 199 -6 minecraft:amethyst_block
setblock -2 199 -6 minecraft:stone
fill -1 199 -6 0 200 -4 minecraft:cobblestone
fill 1 199 -5 1 215 -5 minecraft:stone
setblock 2 199 -4 minecraft:dripstone_block
fill 2 199 -3 2 221 -3 minecraft:stone
fill -4 199 -2 -4 203 -2 minecraft:andesite
fill -14 199 -1 -14 203 -1 minecraft:stone
fill -3 199 -1 -3 202 -1 minecraft:andesite
fill 5 199 0 5 200 0 minecraft:deepslate
setblock -11 199 1 minecraft:stone
fill -10 199 1 -10 200 1 minecraft:deepslate
fill -3 199 1 -3 202 2 minecraft:andesite
setblock 5 199 1 minecraft:stone
fill 6 199 1 6 201 1 minecraft:deepslate
fill -9 199 2 -9 220 2 minecraft:stone
fill -4 199 2 -4 206 2 minecraft:andesite
fill -12 199 3 -12 206 3 minecraft:andesite
setblock -9 199 3 minecraft:dripstone_block
fill 4 199 3 4 220 3 minecraft:stone
fill 7 199 3 7 203 3 minecraft:stone
fill -6 199 4 -6 217 4 minecraft:stone
fill 3 199 4 3 220 4 minecraft:stone
fill -4 199 5 -4 201 5 minecraft:stone
fill 0 199 5 0 200 5 minecraft:cobblestone
fill -8 200 -9 -8 207 -9 minecraft:stone
fill -4 200 -7 -4 201 -7 minecraft:stone
fill -3 200 -7 -2 201 -6 minecraft:cobblestone
fill 1 200 -6 1 217 -6 minecraft:stone
setblock -3 200 -5 minecraft:stone
fill 2 200 -5 2 221 -4 minecraft:stone
setblock -6 200 -4 minecraft:dripstone_block
fill -6 200 -3 -6 202 -3 minecraft:andesite
fill -5 200 -2 -5 203 -2 minecraft:andesite
setblock 5 200 -2 minecraft:dripstone_block
fill -4 200 -1 -4 204 -1 minecraft:andesite
setblock 5 200 -1 minecraft:deepslate
fill -3 200 0 -3 201 0 minecraft:andesite
fill -11 200 1 -11 205 1 minecraft:andesite
fill 5 200 1 5 202 1 minecraft:deepslate
fill -10 200 2 -10 201 3 minecraft:andesite
fill -5 200 2 -5 206 2 minecraft:andesite
fill 7 200 2 7 203 2 minecraft:stone
fill -9 200 3 -9 220 3 minecraft:stone
fill -6 200 3 -6 217 3 minecraft:stone
fill -4 200 3 -3 203 3 minecraft:andesite
setblock 4 200 4 minecraft:dripstone_block
fill 6 200 4 6 204 4 minecraft:stone
fill -5 200 5 -5 202 5 minecraft:stone
setblock -2 200 5 minecraft:stone
fill -1 200 5 -1 201 6 minecraft:cobblestone
fill 2 200 5 2 220 5 minecraft:stone
setblock 19 200 5 minecraft:amethyst_block
fill -4 200 6 -4 202 6 minecraft:stone
fill 0 200 6 0 201 6 minecraft:cobblestone
setblock -6 201 -9 minecraft:dripstone_block
fill -7 201 -8 -7 203 -8 minecraft:stone
setblock -4 201 -8 minecraft:amethyst_block
fill -3 201 -8 -3 204 -8 minecraft:andesite
fill -5 201 -7 -5 202 -5 minecraft:stone
fill -1 201 -7 -1 201 -4 minecraft:cobblestone
fill -4 201 -6 -4 202 -6 minecraft:cobblestone
fill 0 201 -6 0 204 -4 minecraft:stone
fill 2 201 -6 2 221 -6 minecraft:stone
fill -6 201 -5 -6 203 -5 minecraft:stone
fill -4 201 -5 -4 202 -5 minecraft:stone
fill -3 201 -5 -2 203 -5 minecraft:cobblestone
fill -6 201 -4 -6 202 -4 minecraft:andesite
fill -3 201 -4 -3 202 -4 minecraft:stone
fill -7 201 -3 -7 201 -2 minecraft:andesite
setblock 3 201 -3 minecraft:stone
fill -6 201 -2 -6 202 -2 minecraft:andesite
fill 5 201 -2 5 206 -2 minecraft:stone
fill -13 201 -1 -13 202 -1 minecraft:stone
setblock -5 201 -1 minecraft:dripstone_block
fill 5 201 -1 6 201 0 minecraft:tuff
setblock -4 201 0 minecraft:dripstone_block
setblock 4 201 0 minecraft:deepslate
fill -10 201 1 -9 220 1 minecraft:stone
fill -4 201 1 -4 205 1 minecraft:andesite
fill 0 201 1 0 206 3 minecraft:tuff
fill 1 201 1 2 202 1 minecraft:stone
fill -8 201 2 -8 218 3 minecraft:stone
fill -6 201 2 -6 220 2 minecraft:stone
fill 1 201 2 1 203 4 minecraft:tuff
fill 2 201 2 2 220 3 minecraft:stone
setblock -7 201 3 minecraft:dripstone_block
fill -5 201 3 -5 206 3 minecraft:andesite
setblock -10 201 4 minecraft:andesite
fill -9 201 4 -9 219 4 minecraft:stone
fill -7 201 4 -7 218 4 minecraft:stone
setblock -5 201 4 minecraft:stone
fill -4 201 4 -3 203 4 minecraft:andesite
fill 4 201 4 5 206 4 minecraft:stone
fill 7 201 4 8 204 4 minecraft:stone
fill -6 201 5 -6 219 5 minecraft:stone
fill -2 201 5 -2 202 6 minecraft:cobblestone
setblock 0 201 5 minecraft:stone
fill 3 201 5 4 213 5 minecraft:stone
fill 19 201 5 19 220 5 minecraft:stone
fill -5 201 6 -5 203 6 minecraft:stone
fill -7 202 -10 -7 205 -10 minecraft:stone
fill -6 202 -9 -6 203 -8 minecraft:deepslate
fill -4 202 -9 -3 203 -9 minecraft:andesite
fill -5 202 -8 -4 204 -8 minecraft:andesite
fill -2 202 -8 -2 204 -8 minecraft:andesite
fill -4 202 -7 -3 206 -7 minecraft:andesite
fill -2 202 -7 -2 202 -6 minecraft:cobblestone
fill -1 202 -7 2 202 -7 minecraft:stone
fill -6 202 -6 -6 203 -6 minecraft:stone
setblock -3 202 -6 minecraft:cobblestone
fill -1 202 -6 -1 204 -4 minecraft:stone
fill -7 202 -4 -7 204 -4 minecraft:stone
fill -4 202 -4 -4 203 -4 minecraft:stone
fill -8 202 -3 -8 207 -2 minecraft:stone
setblock -7 202 -3 minecraft:andesite
fill -3 202 -3 -3 210 -3 minecraft:stone
