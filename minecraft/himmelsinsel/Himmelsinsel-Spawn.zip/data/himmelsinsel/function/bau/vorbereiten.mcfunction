# Bauplatz laden (die Insel schwebt über x 0 / z 0)
forceload add -48 -48 47 47
scoreboard players set #stufe hs.state 1
tellraw @a {"text":"[Himmelsinsel] Lade den Bauplatz …","color":"light_purple"}
