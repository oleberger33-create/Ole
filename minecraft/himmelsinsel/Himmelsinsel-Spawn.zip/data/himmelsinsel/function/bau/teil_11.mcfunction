fill -1 215 23 -1 220 25 minecraft:stone
fill 2 215 23 2 219 23 minecraft:stone
fill 4 215 23 6 217 23 minecraft:stone
fill 7 215 23 7 215 24 minecraft:tuff
fill 9 215 23 9 215 24 minecraft:tuff
fill 0 215 24 1 220 25 minecraft:stone
fill 5 215 24 6 217 24 minecraft:stone
fill 8 215 24 8 217 24 minecraft:tuff
fill 2 215 25 2 219 25 minecraft:stone
setblock 3 215 25 minecraft:amethyst_block
fill 4 215 25 5 219 25 minecraft:stone
setblock 0 215 26 minecraft:dripstone_block
fill -2 216 -25 -1 220 -25 minecraft:stone
fill 1 216 -25 2 220 -25 minecraft:stone
fill 3 216 -25 3 220 -23 minecraft:andesite
fill 6 216 -25 8 217 -25 minecraft:stone
fill -13 216 -24 -10 217 -23 minecraft:stone
fill -3 216 -24 -3 221 -24 minecraft:stone
fill 4 216 -24 5 219 -22 minecraft:andesite
setblock 6 216 -24 minecraft:amethyst_block
fill 7 216 -24 7 219 -23 minecraft:stone
setblock 8 216 -24 minecraft:dripstone_block
fill 9 216 -24 9 220 -24 minecraft:tuff
fill -14 216 -23 -14 220 -22 minecraft:stone
fill -9 216 -23 -4 218 -23 minecraft:stone
fill 2 216 -23 2 219 -22 minecraft:stone
setblock 9 216 -23 minecraft:stone
setblock -40 216 -22 minecraft:dripstone_block
setblock -15 216 -22 minecraft:stone
fill -13 216 -22 -13 220 -22 minecraft:stone
setblock -12 216 -22 minecraft:cobblestone
fill -11 216 -22 -8 221 -22 minecraft:stone
fill -1 216 -22 -1 220 -22 minecraft:stone
setblock 3 216 -22 minecraft:stone
fill 10 216 -22 10 220 -21 minecraft:stone
fill -16 216 -21 -16 216 -16 minecraft:stone
fill -15 216 -21 -14 216 -21 minecraft:cobblestone
fill -11 216 -21 -10 221 -21 minecraft:stone
fill -9 216 -21 -9 216 -19 minecraft:tuff
fill -8 216 -21 -8 221 -20 minecraft:stone
fill -1 216 -21 0 217 -20 minecraft:cobblestone
fill 1 216 -21 1 219 -21 minecraft:stone
fill -15 216 -20 -14 217 -17 minecraft:tuff
fill -11 216 -20 -11 221 -19 minecraft:stone
fill -10 216 -20 -10 216 -19 minecraft:tuff
setblock 11 216 -20 minecraft:dripstone_block
setblock 14 216 -20 minecraft:dripstone_block
fill 15 216 -20 17 220 -20 minecraft:stone
fill -17 216 -19 -17 218 -17 minecraft:stone
fill -13 216 -19 -12 216 -19 minecraft:tuff
setblock 11 216 -19 minecraft:amethyst_block
setblock 12 216 -19 minecraft:dripstone_block
fill 13 216 -19 14 221 -18 minecraft:stone
fill 17 216 -19 17 220 -19 minecraft:stone
fill -18 216 -18 -18 220 -17 minecraft:stone
fill -12 216 -18 -12 221 -18 minecraft:stone
fill -10 216 -18 -10 221 -17 minecraft:stone
fill 12 216 -18 12 221 -18 minecraft:stone
fill 17 216 -18 18 216 -18 minecraft:dripstone_block
fill -19 216 -17 -19 221 -15 minecraft:stone
fill -13 216 -17 -13 216 -16 minecraft:tuff
fill -4 216 -17 -4 217 -15 minecraft:cobblestone
fill 13 216 -17 13 221 -17 minecraft:stone
fill 17 216 -17 18 220 -17 minecraft:stone
fill -20 216 -16 -20 221 -16 minecraft:stone
setblock -15 216 -16 minecraft:stone
fill -14 216 -16 -14 219 -16 minecraft:tuff
fill 18 216 -16 18 219 -15 minecraft:stone
setblock -24 216 -15 minecraft:cobblestone
fill -23 216 -15 -21 220 -15 minecraft:stone
fill -20 216 -15 -20 216 -13 minecraft:dripstone_block
fill -13 216 -15 -12 221 -15 minecraft:stone
fill -2 216 -15 -2 219 -15 minecraft:stone
fill 3 216 -15 3 219 -15 minecraft:cobblestone
fill 7 216 -15 7 220 -14 minecraft:stone
fill 19 216 -15 19 219 -14 minecraft:stone
setblock -24 216 -14 minecraft:amethyst_block
setblock -23 216 -14 minecraft:dripstone_block
fill -22 216 -14 -21 220 -13 minecraft:stone
fill -13 216 -14 -12 217 -14 minecraft:cobblestone
fill 16 216 -14 16 221 -14 minecraft:stone
fill 20 216 -14 22 219 -12 minecraft:stone
fill -25 216 -13 -23 216 -13 minecraft:stone
fill -13 216 -13 -12 216 -13 minecraft:stone
fill 6 216 -13 6 218 -13 minecraft:cobblestone
fill -25 216 -12 -25 220 -12 minecraft:stone
fill -21 216 -12 -20 221 -12 minecraft:stone
fill -6 216 -12 -6 216 -10 minecraft:cobblestone
fill -5 216 -12 -5 220 -11 minecraft:stone
setblock 6 216 -12 minecraft:stone
fill 14 216 -12 14 220 -12 minecraft:tuff
setblock -25 216 -11 minecraft:dripstone_block
fill -24 216 -11 -24 220 -11 minecraft:stone
fill -7 216 -11 -7 217 -11 minecraft:cobblestone
fill 14 216 -11 14 219 -11 minecraft:stone
fill 21 216 -11 22 220 -11 minecraft:stone
fill 23 216 -11 23 216 -10 minecraft:tuff
fill -26 216 -10 -25 216 -10 minecraft:stone
setblock -7 216 -10 minecraft:stone
fill 5 216 -10 5 220 -10 minecraft:tuff
fill 6 216 -10 7 220 -10 minecraft:stone
setblock 24 216 -10 minecraft:tuff
fill 25 216 -10 25 220 -8 minecraft:stone
fill -27 216 -9 -27 216 -7 minecraft:stone
fill -26 216 -9 -26 219 -9 minecraft:tuff
setblock -25 216 -9 minecraft:dripstone_block
fill -24 216 -9 -24 220 -7 minecraft:stone
fill -21 216 -9 -20 220 -9 minecraft:stone
fill -17 216 -9 -17 221 -9 minecraft:stone
fill -2 216 -9 -2 220 -9 minecraft:stone
fill 0 216 -9 0 221 -9 minecraft:stone
fill 15 216 -9 16 217 -9 minecraft:stone
fill 24 216 -9 24 220 -9 minecraft:stone
fill 26 216 -9 26 219 -7 minecraft:stone
setblock -26 216 -8 minecraft:amethyst_block
fill -25 216 -8 -25 216 -6 minecraft:tuff
fill -23 216 -8 -23 220 -8 minecraft:stone
setblock -20 216 -8 minecraft:andesite
fill -19 216 -8 -19 220 -7 minecraft:stone
fill -4 216 -8 -4 217 -5 minecraft:stone
fill -3 216 -8 -3 217 -7 minecraft:andesite
fill 3 216 -8 3 220 -8 minecraft:tuff
fill 12 216 -8 12 217 -8 minecraft:stone
fill 13 216 -8 13 220 -8 minecraft:andesite
fill 15 216 -8 16 216 -8 minecraft:andesite
fill 17 216 -8 17 218 -7 minecraft:stone
fill -26 216 -7 -26 218 -7 minecraft:tuff
fill -6 216 -7 -5 220 -6 minecraft:stone
fill 3 216 -7 3 218 -7 minecraft:stone
setblock -24 216 -6 minecraft:amethyst_block
fill -21 216 -6 -21 218 -6 minecraft:andesite
fill -3 216 -6 -3 216 -5 minecraft:stone
fill -2 216 -6 -2 219 -5 minecraft:andesite
fill 5 216 -6 5 221 -6 minecraft:tuff
fill 19 216 -6 19 217 -6 minecraft:stone
fill 24 216 -6 25 220 -6 minecraft:stone
setblock 26 216 -6 minecraft:dripstone_block
setblock -23 216 -5 minecraft:amethyst_block
fill -22 216 -5 -21 216 -5 minecraft:cobblestone
fill -20 216 -5 -20 221 -5 minecraft:andesite
fill 1 216 -5 1 220 -5 minecraft:andesite
fill 4 216 -5 5 216 -5 minecraft:stone
fill 6 216 -5 6 218 -3 minecraft:tuff
fill 18 216 -5 20 221 -5 minecraft:andesite
fill 23 216 -5 23 216 -4 minecraft:andesite
setblock 24 216 -5 minecraft:cobblestone
setblock 26 216 -5 minecraft:amethyst_block
fill 27 216 -5 27 220 -4 minecraft:stone
fill -23 216 -4 -22 220 -1 minecraft:stone
fill 5 216 -4 5 221 -4 minecraft:tuff
fill 18 216 -4 18 221 -4 minecraft:andesite
fill 24 216 -4 24 216 -2 minecraft:andesite
fill 25 216 -4 26 220 -4 minecraft:stone
fill -24 216 -3 -24 221 -3 minecraft:stone
fill -19 216 -3 -19 219 -3 minecraft:andesite
fill 0 216 -3 0 217 -3 minecraft:stone
fill 9 216 -3 9 221 -3 minecraft:stone
fill 18 216 -3 18 217 -3 minecraft:stone
fill 25 216 -3 26 217 -3 minecraft:cobblestone
fill -25 216 -2 -24 216 -2 minecraft:tuff
setblock -19 216 -2 minecraft:stone
fill -18 216 -2 -17 219 -2 minecraft:andesite
setblock -16 216 -2 minecraft:stone
fill 21 216 -2 21 221 -2 minecraft:andesite
fill 25 216 -2 25 219 -2 minecraft:cobblestone
fill -26 216 -1 -26 219 -1 minecraft:tuff
fill -18 216 -1 -18 217 0 minecraft:stone
fill 21 216 -1 21 216 0 minecraft:stone
fill 22 216 -1 23 219 -1 minecraft:andesite
fill -26 216 0 -26 216 1 minecraft:stone
setblock -23 216 0 minecraft:tuff
fill -22 216 0 -22 219 10 minecraft:stone
setblock 0 216 0 minecraft:stone
fill 1 216 0 1 218 2 minecraft:andesite
fill 22 216 0 22 221 0 minecraft:andesite
fill 23 216 0 23 218 0 minecraft:stone
fill -23 216 1 -23 220 6 minecraft:stone
fill 0 216 1 0 219 2 minecraft:andesite
fill 16 216 1 16 218 1 minecraft:tuff
setblock 23 216 1 minecraft:amethyst_block
fill -25 216 2 -25 220 2 minecraft:stone
fill 23 216 2 23 219 2 minecraft:stone
fill -24 216 3 -24 220 3 minecraft:stone
fill -20 216 3 -20 221 3 minecraft:stone
fill 12 216 3 12 219 3 minecraft:stone
setblock 23 216 3 minecraft:dripstone_block
fill 11 216 4 11 220 4 minecraft:stone
setblock 12 216 4 minecraft:tuff
fill 3 216 5 3 221 5 minecraft:stone
setblock 11 216 5 minecraft:tuff
fill -19 216 6 -18 217 7 minecraft:cobblestone
fill -17 216 6 -17 218 8 minecraft:stone
fill 2 216 6 3 216 6 minecraft:cobblestone
setblock 11 216 6 minecraft:stone
fill 22 216 6 22 217 8 minecraft:stone
fill -13 216 7 -12 218 7 minecraft:stone
fill 0 216 7 0 219 7 minecraft:stone
fill 1 216 7 1 218 7 minecraft:tuff
fill -21 216 8 -21 219 9 minecraft:stone
fill -12 216 8 -12 218 8 minecraft:stone
fill 4 216 8 4 220 9 minecraft:stone
setblock -17 216 9 minecraft:cobblestone
fill -1 216 9 -1 218 9 minecraft:stone
fill 0 216 9 0 221 9 minecraft:tuff
fill 22 216 9 22 218 9 minecraft:cobblestone
setblock -21 216 10 minecraft:dripstone_block
fill -20 216 10 -20 216 11 minecraft:stone
fill -19 216 10 -18 216 10 minecraft:cobblestone
fill -17 216 10 -16 221 10 minecraft:stone
fill -11 216 10 -11 220 10 minecraft:stone
fill 1 216 10 1 220 11 minecraft:tuff
fill 18 216 10 21 218 10 minecraft:cobblestone
fill -22 216 11 -21 216 12 minecraft:andesite
fill 2 216 11 2 219 12 minecraft:tuff
fill 15 216 11 17 216 11 minecraft:stone
fill 20 216 11 21 217 12 minecraft:stone
fill -20 216 12 -20 216 13 minecraft:andesite
fill -19 216 12 -19 220 12 minecraft:stone
fill -3 216 12 -3 220 13 minecraft:andesite
fill -2 216 12 1 216 12 minecraft:stone
