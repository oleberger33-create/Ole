setblock -21 215 11 minecraft:dripstone_block
fill -20 215 11 -20 215 13 minecraft:andesite
fill -19 215 11 -15 220 11 minecraft:stone
fill -14 215 11 -14 216 12 minecraft:andesite
fill -10 215 11 -10 221 11 minecraft:stone
fill 0 215 11 0 216 11 minecraft:stone
setblock 2 215 11 minecraft:stone
fill 18 215 11 19 216 11 minecraft:stone
setblock -19 215 12 minecraft:andesite
fill -18 215 12 -16 221 12 minecraft:stone
fill -10 215 12 -10 217 12 minecraft:andesite
fill 19 215 12 19 218 16 minecraft:stone
fill -19 215 13 -19 220 13 minecraft:stone
setblock -18 215 13 minecraft:dripstone_block
fill -17 215 13 -16 221 13 minecraft:stone
fill -14 215 13 -14 215 16 minecraft:stone
fill -10 215 13 -10 219 16 minecraft:stone
fill 15 215 13 17 217 13 minecraft:andesite
fill -18 215 14 -17 219 14 minecraft:stone
fill -4 215 14 -4 216 15 minecraft:stone
fill -3 215 14 -3 219 15 minecraft:cobblestone
fill 18 215 15 18 220 17 minecraft:stone
setblock -17 215 16 minecraft:amethyst_block
fill 0 215 16 0 219 16 minecraft:cobblestone
setblock 1 215 16 minecraft:stone
fill 12 215 16 13 221 18 minecraft:stone
fill -17 215 17 -17 220 17 minecraft:stone
fill 14 215 17 14 220 20 minecraft:stone
setblock 17 215 17 minecraft:dripstone_block
setblock -17 215 18 minecraft:cobblestone
fill -16 215 18 -16 220 20 minecraft:stone
fill -13 215 18 -12 216 19 minecraft:stone
fill 15 215 18 17 220 18 minecraft:stone
fill -17 215 19 -17 220 19 minecraft:stone
fill -14 215 19 -14 220 20 minecraft:stone
setblock -11 215 19 minecraft:dripstone_block
fill -10 215 19 -8 215 20 minecraft:andesite
fill -7 215 19 -7 221 19 minecraft:stone
fill 13 215 19 13 220 21 minecraft:stone
fill 15 215 19 15 220 19 minecraft:stone
fill -15 215 20 -15 220 21 minecraft:stone
fill -7 215 20 -7 215 21 minecraft:andesite
fill -6 215 20 -4 221 20 minecraft:stone
fill 1 215 20 1 220 20 minecraft:stone
fill -8 215 21 -8 215 22 minecraft:andesite
fill -6 215 21 -6 221 22 minecraft:stone
setblock -5 215 21 minecraft:dripstone_block
fill -4 215 21 -2 221 21 minecraft:stone
fill 10 215 21 12 220 21 minecraft:stone
fill -7 215 22 -7 221 23 minecraft:stone
setblock -3 215 22 minecraft:dripstone_block
fill -2 215 22 -2 221 22 minecraft:stone
fill 9 215 22 10 220 22 minecraft:stone
fill -8 215 23 -8 219 24 minecraft:stone
setblock -2 215 23 minecraft:dripstone_block
fill -1 215 23 -1 220 25 minecraft:stone
fill 2 215 23 2 219 23 minecraft:stone
fill 4 215 23 6 217 23 minecraft:stone
fill 7 215 23 7 215 24 minecraft:tuff
fill 9 215 23 9 215 24 minecraft:tuff
fill 0 215 24 1 220 25 minecraft:stone
fill 5 215 24 6 217 24 minecraft:stone
fill 8 215 24 8 217 24 minecraft:tuff
fill 2 215 25 2 219 25 minecraft:stone
setblock 3 215 25 minecraft:amethyst_block
fill 4 215 25 5 219 25 minecraft:stone
setblock 0 215 26 minecraft:dripstone_block
fill 36 216 -36 36 217 -36 minecraft:stone
fill 34 216 -34 34 220 -33 minecraft:stone
fill 38 216 -33 39 220 -33 minecraft:stone
fill 33 216 -32 33 219 -31 minecraft:stone
setblock 40 216 -32 minecraft:dripstone_block
fill 41 216 -31 41 217 -31 minecraft:andesite
fill 32 216 -30 32 220 -29 minecraft:stone
fill 41 216 -30 41 220 -29 minecraft:stone
fill 40 216 -29 40 220 -29 minecraft:stone
setblock 32 216 -28 minecraft:amethyst_block
fill 32 216 -27 33 220 -27 minecraft:stone
fill 34 216 -26 35 220 -26 minecraft:stone
fill 41 216 -26 41 219 -26 minecraft:stone
fill -2 216 -25 -1 220 -25 minecraft:stone
fill 1 216 -25 2 220 -25 minecraft:stone
fill 3 216 -25 3 220 -23 minecraft:andesite
fill 6 216 -25 8 217 -25 minecraft:stone
setblock 36 216 -25 minecraft:andesite
setblock 37 216 -25 minecraft:dripstone_block
fill 40 216 -25 40 220 -25 minecraft:stone
fill -13 216 -24 -10 217 -23 minecraft:stone
fill -3 216 -24 -3 221 -24 minecraft:stone
fill 4 216 -24 5 219 -22 minecraft:andesite
setblock 6 216 -24 minecraft:amethyst_block
fill 7 216 -24 7 219 -23 minecraft:stone
setblock 8 216 -24 minecraft:dripstone_block
fill 9 216 -24 9 220 -24 minecraft:tuff
setblock 38 216 -24 minecraft:andesite
fill 39 216 -24 39 220 -24 minecraft:stone
fill -14 216 -23 -14 220 -22 minecraft:stone
fill -9 216 -23 -4 218 -23 minecraft:stone
fill 2 216 -23 2 219 -22 minecraft:stone
setblock 9 216 -23 minecraft:stone
setblock -40 216 -22 minecraft:dripstone_block
setblock -15 216 -22 minecraft:stone
fill -13 216 -22 -13 220 -22 minecraft:stone
setblock -12 216 -22 minecraft:cobblestone
fill -11 216 -22 -8 221 -22 minecraft:stone
fill -1 216 -22 -1 220 -22 minecraft:stone
setblock 3 216 -22 minecraft:stone
fill 10 216 -22 10 220 -21 minecraft:stone
fill -16 216 -21 -16 216 -16 minecraft:stone
fill -15 216 -21 -14 216 -21 minecraft:cobblestone
fill -11 216 -21 -10 221 -21 minecraft:stone
fill -9 216 -21 -9 216 -19 minecraft:tuff
fill -8 216 -21 -8 221 -20 minecraft:stone
fill -1 216 -21 0 217 -20 minecraft:cobblestone
fill 1 216 -21 1 219 -21 minecraft:stone
fill -15 216 -20 -14 217 -17 minecraft:tuff
fill -11 216 -20 -11 221 -19 minecraft:stone
fill -10 216 -20 -10 216 -19 minecraft:tuff
setblock 11 216 -20 minecraft:dripstone_block
setblock 14 216 -20 minecraft:dripstone_block
fill 15 216 -20 17 220 -20 minecraft:stone
fill -17 216 -19 -17 218 -17 minecraft:stone
fill -13 216 -19 -12 216 -19 minecraft:tuff
setblock 11 216 -19 minecraft:amethyst_block
setblock 12 216 -19 minecraft:dripstone_block
fill 13 216 -19 14 221 -18 minecraft:stone
fill 17 216 -19 17 220 -19 minecraft:stone
fill -18 216 -18 -18 220 -17 minecraft:stone
fill -12 216 -18 -12 221 -18 minecraft:stone
fill -10 216 -18 -10 221 -17 minecraft:stone
fill 12 216 -18 12 221 -18 minecraft:stone
fill 17 216 -18 18 216 -18 minecraft:dripstone_block
fill -19 216 -17 -19 221 -15 minecraft:stone
fill -13 216 -17 -13 216 -16 minecraft:tuff
fill -4 216 -17 -4 217 -15 minecraft:cobblestone
fill 13 216 -17 13 221 -17 minecraft:stone
fill 17 216 -17 18 220 -17 minecraft:stone
fill -20 216 -16 -20 221 -16 minecraft:stone
setblock -15 216 -16 minecraft:stone
fill -14 216 -16 -14 219 -16 minecraft:tuff
fill 18 216 -16 18 219 -15 minecraft:stone
setblock -24 216 -15 minecraft:cobblestone
fill -23 216 -15 -21 220 -15 minecraft:stone
fill -20 216 -15 -20 216 -13 minecraft:dripstone_block
fill -13 216 -15 -12 221 -15 minecraft:stone
fill -2 216 -15 -2 219 -15 minecraft:stone
fill 3 216 -15 3 219 -15 minecraft:cobblestone
fill 7 216 -15 7 220 -14 minecraft:stone
fill 19 216 -15 19 219 -14 minecraft:stone
setblock -24 216 -14 minecraft:amethyst_block
setblock -23 216 -14 minecraft:dripstone_block
fill -22 216 -14 -21 220 -13 minecraft:stone
fill -13 216 -14 -12 217 -14 minecraft:cobblestone
fill 16 216 -14 16 221 -14 minecraft:stone
fill 20 216 -14 22 219 -12 minecraft:stone
fill -25 216 -13 -23 216 -13 minecraft:stone
fill -13 216 -13 -12 216 -13 minecraft:stone
fill 6 216 -13 6 218 -13 minecraft:cobblestone
fill -25 216 -12 -25 220 -12 minecraft:stone
fill -21 216 -12 -20 221 -12 minecraft:stone
fill -6 216 -12 -6 216 -10 minecraft:cobblestone
fill -5 216 -12 -5 220 -11 minecraft:stone
setblock 6 216 -12 minecraft:stone
fill 14 216 -12 14 220 -12 minecraft:tuff
setblock -25 216 -11 minecraft:dripstone_block
fill -24 216 -11 -24 220 -11 minecraft:stone
fill -7 216 -11 -7 217 -11 minecraft:cobblestone
fill 14 216 -11 14 219 -11 minecraft:stone
fill 21 216 -11 22 220 -11 minecraft:stone
fill 23 216 -11 23 216 -10 minecraft:tuff
fill -26 216 -10 -25 216 -10 minecraft:stone
setblock -7 216 -10 minecraft:stone
fill 5 216 -10 5 220 -10 minecraft:tuff
fill 6 216 -10 7 220 -10 minecraft:stone
setblock 24 216 -10 minecraft:tuff
fill 25 216 -10 25 220 -8 minecraft:stone
fill -27 216 -9 -27 216 -7 minecraft:stone
fill -26 216 -9 -26 219 -9 minecraft:tuff
setblock -25 216 -9 minecraft:dripstone_block
fill -24 216 -9 -24 220 -7 minecraft:stone
fill -21 216 -9 -20 220 -9 minecraft:stone
fill -17 216 -9 -17 221 -9 minecraft:stone
fill -2 216 -9 -2 220 -9 minecraft:stone
fill 0 216 -9 0 221 -9 minecraft:stone
fill 15 216 -9 16 217 -9 minecraft:stone
fill 24 216 -9 24 220 -9 minecraft:stone
fill 26 216 -9 26 219 -7 minecraft:stone
setblock -26 216 -8 minecraft:amethyst_block
fill -25 216 -8 -25 216 -6 minecraft:tuff
fill -23 216 -8 -23 220 -8 minecraft:stone
setblock -20 216 -8 minecraft:andesite
fill -19 216 -8 -19 220 -7 minecraft:stone
fill -4 216 -8 -4 217 -5 minecraft:stone
fill -3 216 -8 -3 217 -7 minecraft:andesite
fill 3 216 -8 3 220 -8 minecraft:tuff
fill 12 216 -8 12 217 -8 minecraft:stone
fill 13 216 -8 13 220 -8 minecraft:andesite
fill 15 216 -8 16 216 -8 minecraft:andesite
fill 17 216 -8 17 218 -7 minecraft:stone
fill -26 216 -7 -26 218 -7 minecraft:tuff
fill -6 216 -7 -5 220 -6 minecraft:stone
fill 3 216 -7 3 218 -7 minecraft:stone
setblock -24 216 -6 minecraft:amethyst_block
fill -21 216 -6 -21 218 -6 minecraft:andesite
fill -3 216 -6 -3 216 -5 minecraft:stone
fill -2 216 -6 -2 219 -5 minecraft:andesite
fill 5 216 -6 5 221 -6 minecraft:tuff
fill 19 216 -6 19 217 -6 minecraft:stone
fill 24 216 -6 25 220 -6 minecraft:stone
setblock 26 216 -6 minecraft:dripstone_block
setblock -23 216 -5 minecraft:amethyst_block
fill -22 216 -5 -21 216 -5 minecraft:cobblestone
fill -20 216 -5 -20 221 -5 minecraft:andesite
fill 1 216 -5 1 220 -5 minecraft:andesite
fill 4 216 -5 5 216 -5 minecraft:stone
fill 6 216 -5 6 218 -3 minecraft:tuff
fill 18 216 -5 20 221 -5 minecraft:andesite
fill 23 216 -5 23 216 -4 minecraft:andesite
setblock 24 216 -5 minecraft:cobblestone
setblock 26 216 -5 minecraft:amethyst_block
