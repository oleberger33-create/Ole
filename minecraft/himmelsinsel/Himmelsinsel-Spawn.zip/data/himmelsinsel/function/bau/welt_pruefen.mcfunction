# Ganz neue Welt (jünger als 5 Minuten): sofort bauen.
# Bestehende Welt: nichts anfassen, bis ein Admin den Bau startet.
execute store result score #zeit hs.state run time query gametime
execute if score #zeit hs.state matches 6001.. run scoreboard players set #stufe hs.state -1
execute if score #zeit hs.state matches 6001.. run tellraw @a ["",{"text":"[Himmelsinsel] ","color":"light_purple"},{"text":"Bestehende Welt erkannt – es wurde noch nichts gebaut. Ein Admin startet den Bau mit ","color":"white"},{"text":"/function himmelsinsel:admin/bauen","color":"aqua"},{"text":" (Einstellungen vorher mit /function himmelsinsel:admin/info prüfen).","color":"gray"}]
execute if score #zeit hs.state matches ..6000 run scoreboard players set #neue_welt hs.state 1
execute if score #zeit hs.state matches ..6000 run function himmelsinsel:bau/vorbereiten
