fill -11 208 -9 -10 208 -8 minecraft:stone
fill -8 208 -9 -8 208 -8 minecraft:andesite
fill -1 208 -9 -1 208 -7 minecraft:cobblestone
fill 3 208 -9 6 211 -9 minecraft:stone
fill 11 208 -9 12 217 -9 minecraft:stone
fill -12 208 -8 -12 211 -8 minecraft:tuff
fill 9 208 -8 9 219 -7 minecraft:stone
fill 12 208 -8 13 215 -8 minecraft:stone
fill -12 208 -7 -11 220 -7 minecraft:stone
fill -6 208 -7 -2 214 -7 minecraft:stone
fill 10 208 -7 10 220 -7 minecraft:stone
fill 11 208 -7 13 208 -7 minecraft:tuff
fill 14 208 -7 14 214 -7 minecraft:stone
setblock -12 208 -6 minecraft:deepslate
fill -11 208 -6 -11 220 -6 minecraft:stone
setblock -6 208 -6 minecraft:andesite
fill -5 208 -6 0 208 -6 minecraft:stone
fill 13 208 -6 14 209 -6 minecraft:tuff
fill -12 208 -5 -12 221 -5 minecraft:stone
setblock 8 208 -5 minecraft:cobblestone
fill 11 208 -5 11 210 -4 minecraft:tuff
fill 13 208 -5 13 210 -4 minecraft:tuff
setblock -16 208 -4 minecraft:dripstone_block
fill -15 208 -4 -14 212 -4 minecraft:stone
fill -12 208 -4 -12 209 -4 minecraft:andesite
setblock -2 208 -4 minecraft:andesite
fill 6 208 -4 6 215 -4 minecraft:stone
fill -16 208 -3 -16 213 -2 minecraft:stone
fill -12 208 -3 -12 221 -3 minecraft:stone
fill -10 208 -3 -5 211 -3 minecraft:andesite
fill -2 208 -3 -2 219 -3 minecraft:stone
fill -1 208 -3 -1 208 -2 minecraft:cobblestone
fill 0 208 -3 0 210 -2 minecraft:stone
fill 6 208 -3 6 209 -3 minecraft:deepslate
fill 7 208 -3 8 221 -3 minecraft:stone
fill 11 208 -3 11 208 -2 minecraft:stone
fill -9 208 -2 -8 209 -2 minecraft:stone
fill -6 208 -2 -5 210 0 minecraft:stone
setblock 8 208 -2 minecraft:andesite
fill 9 208 -2 9 221 -2 minecraft:stone
fill 13 208 -2 13 209 -2 minecraft:tuff
setblock -16 208 -1 minecraft:andesite
fill -9 208 -1 -9 220 0 minecraft:stone
setblock 0 208 -1 minecraft:tuff
fill 1 208 -1 1 221 -1 minecraft:stone
fill 7 208 -1 7 209 0 minecraft:andesite
fill 9 208 -1 9 208 1 minecraft:andesite
fill 11 208 -1 11 209 2 minecraft:deepslate
fill 12 208 -1 13 220 -1 minecraft:stone
fill -15 208 0 -14 208 0 minecraft:stone
fill 2 208 0 2 220 1 minecraft:stone
fill 10 208 0 10 208 1 minecraft:stone
fill 13 208 0 13 212 3 minecraft:stone
fill -14 208 1 -14 220 1 minecraft:stone
setblock 1 208 1 minecraft:tuff
fill 8 208 1 8 212 1 minecraft:andesite
fill 1 208 2 1 215 2 minecraft:stone
fill 6 208 2 6 209 2 minecraft:stone
fill 12 208 2 12 209 2 minecraft:deepslate
fill -2 208 3 -2 216 3 minecraft:stone
fill 6 208 3 6 208 4 minecraft:deepslate
fill 7 208 3 7 210 3 minecraft:stone
fill 11 208 3 12 209 3 minecraft:stone
setblock -4 208 4 minecraft:deepslate
fill 12 208 4 12 213 9 minecraft:stone
setblock 18 208 4 minecraft:cobblestone
fill 19 208 4 19 220 4 minecraft:stone
fill -4 208 5 -4 218 6 minecraft:stone
fill -11 208 6 -11 210 6 minecraft:stone
fill 13 208 6 13 218 8 minecraft:stone
fill -9 208 7 -8 221 7 minecraft:stone
fill -7 208 8 -7 221 8 minecraft:stone
fill 1 208 8 1 210 9 minecraft:tuff
fill 9 208 8 9 220 8 minecraft:stone
fill -1 208 9 0 212 9 minecraft:tuff
fill 9 208 9 9 208 10 minecraft:tuff
fill 10 208 9 11 220 9 minecraft:stone
fill -6 208 10 -6 221 10 minecraft:stone
fill 1 208 10 1 215 11 minecraft:stone
fill 4 208 10 6 209 10 minecraft:stone
fill 7 208 10 7 210 10 minecraft:tuff
fill 10 208 10 10 220 10 minecraft:stone
fill 3 208 11 3 221 11 minecraft:stone
fill 6 208 11 6 221 11 minecraft:stone
setblock 7 208 11 minecraft:dripstone_block
fill 8 208 11 8 210 11 minecraft:tuff
fill -5 208 12 -5 218 13 minecraft:stone
fill 2 208 12 2 209 12 minecraft:stone
fill 0 208 13 1 210 13 minecraft:stone
fill -4 208 14 -3 214 14 minecraft:stone
fill 36 209 -34 36 220 -34 minecraft:stone
fill 38 209 -29 38 220 -29 minecraft:stone
fill 4 209 -15 4 213 -15 minecraft:stone
fill -5 209 -14 -3 214 -14 minecraft:stone
fill -7 209 -13 -6 212 -13 minecraft:stone
fill -8 209 -12 -8 220 -12 minecraft:stone
fill -2 209 -12 -2 221 -12 minecraft:stone
fill -9 209 -11 -9 220 -11 minecraft:stone
setblock -1 209 -11 minecraft:stone
fill 0 209 -11 0 211 -11 minecraft:andesite
fill 1 209 -11 4 209 -11 minecraft:stone
fill 11 209 -11 12 220 -10 minecraft:stone
fill -10 209 -10 -10 211 -7 minecraft:stone
fill 8 209 -10 10 216 -10 minecraft:stone
fill 13 209 -10 13 216 -9 minecraft:stone
fill -12 209 -9 -12 210 -9 minecraft:tuff
fill -11 209 -9 -11 210 -9 minecraft:deepslate
fill -8 209 -9 -8 210 -8 minecraft:cobblestone
fill -1 209 -9 0 210 -9 minecraft:stone
fill 14 209 -9 15 212 -8 minecraft:stone
fill -13 209 -8 -13 211 -8 minecraft:tuff
fill -11 209 -8 -11 220 -8 minecraft:stone
fill -1 209 -8 -1 209 -6 minecraft:cobblestone
fill 0 209 -8 0 211 -8 minecraft:stone
fill 4 209 -8 5 209 -8 minecraft:stone
setblock 6 209 -8 minecraft:deepslate
fill 16 209 -8 16 211 -7 minecraft:stone
fill -13 209 -7 -13 220 -7 minecraft:stone
fill -9 209 -7 -9 212 -7 minecraft:cobblestone
fill -7 209 -7 -7 221 -7 minecraft:stone
fill 11 209 -7 13 216 -7 minecraft:stone
fill 15 209 -7 15 213 -7 minecraft:stone
fill -14 209 -6 -14 220 -5 minecraft:stone
setblock -13 209 -6 minecraft:deepslate
fill -12 209 -6 -12 220 -6 minecraft:stone
fill -7 209 -6 -7 209 -5 minecraft:andesite
fill -6 209 -6 -2 215 -6 minecraft:stone
fill 0 209 -6 0 213 -6 minecraft:stone
fill 8 209 -6 8 220 -5 minecraft:stone
fill 9 209 -6 10 209 -6 minecraft:cobblestone
setblock 15 209 -6 minecraft:tuff
fill -16 209 -5 -16 212 -4 minecraft:stone
setblock -15 209 -5 minecraft:amethyst_block
fill -13 209 -5 -13 221 -4 minecraft:stone
setblock -5 209 -5 minecraft:andesite
fill -4 209 -5 -1 214 -5 minecraft:stone
setblock 9 209 -5 minecraft:cobblestone
setblock 10 209 -5 minecraft:stone
fill 14 209 -5 14 210 -4 minecraft:tuff
fill -2 209 -4 -2 216 -4 minecraft:stone
fill 4 209 -4 4 210 -3 minecraft:deepslate
fill 5 209 -4 5 215 -4 minecraft:stone
fill -4 209 -3 -4 210 -3 minecraft:andesite
fill -1 209 -3 -1 218 -1 minecraft:stone
fill 11 209 -3 11 212 -3 minecraft:tuff
setblock 14 209 -3 minecraft:amethyst_block
fill 6 209 -2 8 221 -2 minecraft:stone
fill 11 209 -2 11 211 -2 minecraft:stone
fill 14 209 -2 14 213 -2 minecraft:tuff
fill -16 209 -1 -16 220 -1 minecraft:stone
fill 0 209 -1 0 218 -1 minecraft:stone
fill 9 209 -1 9 221 -1 minecraft:stone
fill 10 209 -1 10 210 2 minecraft:deepslate
setblock 14 209 -1 minecraft:dripstone_block
fill -16 209 0 -15 210 0 minecraft:andesite
fill -14 209 0 -14 220 0 minecraft:stone
fill -1 209 0 -1 210 0 minecraft:tuff
fill 9 209 0 9 210 1 minecraft:andesite
fill 12 209 0 12 219 0 minecraft:stone
fill 14 209 0 14 220 1 minecraft:stone
setblock -15 209 1 minecraft:stone
setblock 0 209 1 minecraft:tuff
fill 1 209 1 1 215 1 minecraft:stone
fill 7 209 1 7 212 1 minecraft:andesite
setblock 12 209 1 minecraft:deepslate
fill -14 209 2 -14 220 2 minecraft:stone
fill 0 209 2 0 215 2 minecraft:stone
fill 8 209 2 8 212 2 minecraft:andesite
setblock 9 209 2 minecraft:stone
fill -4 209 3 -3 216 4 minecraft:stone
fill 5 209 3 6 210 3 minecraft:stone
fill -13 209 4 -13 221 4 minecraft:stone
fill 6 209 4 6 220 5 minecraft:stone
fill 13 209 4 13 220 5 minecraft:stone
fill 18 209 4 18 221 4 minecraft:stone
fill -12 209 5 -12 221 5 minecraft:stone
setblock -12 209 6 minecraft:dripstone_block
fill -1 209 6 -1 219 6 minecraft:stone
fill 0 209 6 0 211 6 minecraft:tuff
fill -11 209 7 -10 209 8 minecraft:stone
fill 14 209 7 14 220 8 minecraft:stone
fill 19 209 7 19 217 7 minecraft:stone
fill -9 209 8 -8 219 8 minecraft:stone
fill -7 209 9 -7 221 10 minecraft:stone
fill 5 209 9 6 209 9 minecraft:stone
fill 7 209 9 7 210 9 minecraft:deepslate
fill 8 209 9 9 220 9 minecraft:stone
fill 13 209 9 13 220 9 minecraft:stone
setblock -1 209 10 minecraft:stone
fill 0 209 10 0 211 10 minecraft:tuff
fill 9 209 10 9 220 10 minecraft:stone
fill 11 209 10 12 220 10 minecraft:stone
setblock -6 209 11 minecraft:deepslate
fill 4 209 11 5 221 11 minecraft:stone
fill 7 209 11 7 210 13 minecraft:tuff
fill 9 209 11 9 209 12 minecraft:tuff
fill 10 209 11 10 220 11 minecraft:stone
setblock 11 209 11 minecraft:deepslate
fill -6 209 12 -6 220 12 minecraft:stone
fill 3 209 12 3 210 12 minecraft:andesite
fill 6 209 12 6 209 13 minecraft:stone
fill 8 209 12 8 211 13 minecraft:tuff
fill 2 209 13 2 209 14 minecraft:stone
fill -6 209 14 -5 216 15 minecraft:stone
fill -2 209 14 1 210 14 minecraft:stone
fill 7 209 14 8 210 14 minecraft:stone
fill -7 209 15 -7 220 16 minecraft:stone
fill -4 209 15 -3 214 15 minecraft:stone
fill 7 209 15 7 220 15 minecraft:stone
fill -8 209 16 -8 220 16 minecraft:stone
setblock 36 210 -35 minecraft:deepslate
fill 37 210 -30 38 220 -30 minecraft:stone
setblock 36 210 -29 minecraft:andesite
fill 37 210 -29 37 220 -29 minecraft:stone
setblock 37 210 -28 minecraft:amethyst_block
fill 38 210 -28 38 220 -28 minecraft:stone
setblock 4 210 -17 minecraft:amethyst_block
fill 3 210 -16 6 211 -16 minecraft:stone
fill -4 210 -15 -4 215 -15 minecraft:stone
setblock -3 210 -15 minecraft:dripstone_block
