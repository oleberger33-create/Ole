fill -27 221 -16 -27 223 -14 minecraft:dirt
setblock -23 221 -16 minecraft:rooted_dirt
fill -22 221 -16 -21 223 -16 minecraft:dirt
fill -16 221 -16 -15 221 -16 minecraft:rooted_dirt
setblock -14 221 -16 minecraft:mossy_cobblestone
fill -10 221 -16 -8 221 -16 minecraft:stone
fill -7 221 -16 -6 221 -16 minecraft:mossy_cobblestone
setblock -5 221 -16 minecraft:stone
fill -4 221 -16 -4 221 -15 minecraft:rooted_dirt
fill -3 221 -16 -3 222 -15 minecraft:dirt
fill -1 221 -16 0 221 -16 minecraft:mossy_cobblestone
fill 2 221 -16 2 222 -16 minecraft:dirt
fill 3 221 -16 3 221 -15 minecraft:rooted_dirt
setblock 5 221 -16 minecraft:rooted_dirt
setblock 7 221 -16 minecraft:rooted_dirt
setblock 9 221 -16 minecraft:rooted_dirt
setblock 20 221 -16 minecraft:tuff
setblock 23 221 -16 minecraft:rooted_dirt
fill 25 221 -16 25 223 -16 minecraft:dirt
fill -28 221 -15 -28 223 -11 minecraft:dirt
fill -23 221 -15 -22 223 -15 minecraft:dirt
fill -21 221 -15 -21 221 -13 minecraft:stone
setblock -16 221 -15 minecraft:rooted_dirt
fill -15 221 -15 -15 223 -12 minecraft:dirt
fill -6 221 -15 -6 221 -14 minecraft:mossy_cobblestone
fill -5 221 -15 -5 222 -13 minecraft:dirt
setblock 2 221 -15 minecraft:mossy_cobblestone
fill 5 221 -15 5 222 -15 minecraft:dirt
setblock 6 221 -15 minecraft:rooted_dirt
fill 7 221 -15 7 222 -15 minecraft:dirt
setblock 8 221 -15 minecraft:rooted_dirt
fill 9 221 -15 9 223 -15 minecraft:dirt
fill 12 221 -15 13 221 -15 minecraft:stone
fill 14 221 -15 15 221 -14 minecraft:mossy_cobblestone
setblock 16 221 -15 minecraft:stone
fill 18 221 -15 18 221 -14 minecraft:tuff
fill 23 221 -15 23 221 -14 minecraft:stone
setblock 25 221 -15 minecraft:rooted_dirt
setblock 26 221 -15 minecraft:tuff
setblock 29 221 -15 minecraft:tuff
fill -29 221 -14 -29 223 -14 minecraft:dirt
fill -24 221 -14 -23 221 -14 minecraft:rooted_dirt
fill -22 221 -14 -22 223 -7 minecraft:dirt
fill -16 221 -14 -16 223 -14 minecraft:dirt
setblock -7 221 -14 minecraft:mossy_cobblestone
fill -4 221 -14 -4 222 -14 minecraft:dirt
setblock -3 221 -14 minecraft:rooted_dirt
setblock -2 221 -14 minecraft:mossy_cobblestone
setblock 4 221 -14 minecraft:mossy_cobblestone
fill 7 221 -14 9 221 -14 minecraft:stone
fill 12 221 -14 12 223 -13 minecraft:dirt
setblock 13 221 -14 minecraft:stone
fill 17 221 -14 17 221 -13 minecraft:tuff
setblock 19 221 -14 minecraft:tuff
setblock 20 221 -14 minecraft:stone
fill 22 221 -14 22 221 -13 minecraft:stone
setblock 24 221 -14 minecraft:stone
setblock -29 221 -13 minecraft:rooted_dirt
fill -27 221 -13 -27 221 -12 minecraft:rooted_dirt
fill -24 221 -13 -23 223 -12 minecraft:dirt
setblock -18 221 -13 minecraft:stone
setblock -16 221 -13 minecraft:rooted_dirt
setblock -14 221 -13 minecraft:stone
fill -8 221 -13 -7 222 -12 minecraft:dirt
fill -6 221 -13 -6 221 -12 minecraft:rooted_dirt
setblock -4 221 -13 minecraft:rooted_dirt
fill -3 221 -13 -3 222 -13 minecraft:dirt
setblock -2 221 -13 minecraft:stone
fill 1 221 -13 1 221 -11 minecraft:stone
fill 2 221 -13 2 221 -12 minecraft:mossy_cobblestone
setblock 4 221 -13 minecraft:tuff
fill 9 221 -13 10 221 -13 minecraft:stone
fill 11 221 -13 11 223 -9 minecraft:dirt
fill 13 221 -13 15 223 -8 minecraft:dirt
fill 23 221 -13 24 221 -13 minecraft:andesite
setblock 25 221 -13 minecraft:stone
fill 30 221 -13 30 221 -11 minecraft:stone
setblock -30 221 -12 minecraft:dripstone_block
fill -29 221 -12 -29 223 -10 minecraft:dirt
fill -26 221 -12 -26 221 -11 minecraft:rooted_dirt
fill -25 221 -12 -25 223 -8 minecraft:dirt
setblock -17 221 -12 minecraft:rooted_dirt
fill -16 221 -12 -16 223 -12 minecraft:dirt
fill -14 221 -12 -14 221 -11 minecraft:mossy_cobblestone
fill -9 221 -12 -9 223 -11 minecraft:dirt
setblock -5 221 -12 minecraft:rooted_dirt
fill -4 221 -12 -4 222 -10 minecraft:dirt
setblock -3 221 -12 minecraft:rooted_dirt
fill 5 221 -12 5 221 -11 minecraft:stone
setblock 12 221 -12 minecraft:rooted_dirt
setblock 17 221 -12 minecraft:mossy_cobblestone
fill 19 221 -12 20 221 -12 minecraft:mossy_cobblestone
fill 21 221 -12 21 221 -11 minecraft:stone
fill 22 221 -12 22 221 -11 minecraft:andesite
setblock 25 221 -12 minecraft:andesite
fill -27 221 -11 -27 223 -10 minecraft:dirt
fill -24 221 -11 -24 221 -10 minecraft:rooted_dirt
fill -23 221 -11 -23 223 -10 minecraft:dirt
fill -21 221 -11 -20 221 -11 minecraft:stone
fill -15 221 -11 -15 221 -10 minecraft:mossy_cobblestone
setblock -11 221 -11 minecraft:mossy_cobblestone
setblock -8 221 -11 minecraft:rooted_dirt
fill -7 221 -11 -5 222 -10 minecraft:dirt
fill -3 221 -11 -3 222 -7 minecraft:dirt
fill 2 221 -11 2 221 -9 minecraft:tuff
fill 10 221 -11 10 223 -6 minecraft:dirt
fill 12 221 -11 12 223 -10 minecraft:dirt
fill 16 221 -11 17 222 -6 minecraft:dirt
setblock 20 221 -11 minecraft:mossy_cobblestone
setblock -28 221 -10 minecraft:rooted_dirt
fill -26 221 -10 -26 223 -9 minecraft:dirt
fill -21 221 -10 -20 223 -8 minecraft:dirt
setblock -19 221 -10 minecraft:rooted_dirt
setblock -16 221 -10 minecraft:stone
fill -13 221 -10 -11 221 -10 minecraft:stone
setblock -8 221 -10 minecraft:stone
fill -2 221 -10 -2 222 -7 minecraft:dirt
fill 5 221 -10 6 221 -10 minecraft:mossy_cobblestone
setblock 7 221 -10 minecraft:stone
fill 18 221 -10 18 223 -8 minecraft:dirt
fill 20 221 -10 20 221 -8 minecraft:stone
setblock 23 221 -10 minecraft:andesite
setblock 25 221 -10 minecraft:stone
fill 30 221 -10 30 223 -3 minecraft:dirt
setblock 31 221 -10 minecraft:rooted_dirt
fill -31 221 -9 -30 221 -9 minecraft:stone
fill -29 221 -9 -29 221 -7 minecraft:rooted_dirt
fill -28 221 -9 -28 223 -7 minecraft:dirt
fill -27 221 -9 -27 221 -8 minecraft:rooted_dirt
fill -24 221 -9 -24 223 -8 minecraft:dirt
fill -23 221 -9 -23 221 -8 minecraft:rooted_dirt
fill -19 221 -9 -19 223 -6 minecraft:dirt
fill -13 221 -9 -10 223 -9 minecraft:dirt
fill -9 221 -9 -9 221 -8 minecraft:andesite
fill -6 221 -9 -6 223 -7 minecraft:dirt
fill -5 221 -9 -4 221 -9 minecraft:rooted_dirt
setblock 1 221 -9 minecraft:stone
fill 3 221 -9 6 223 -9 minecraft:dirt
setblock 7 221 -9 minecraft:rooted_dirt
fill 8 221 -9 9 223 -7 minecraft:dirt
fill 12 221 -9 12 221 -8 minecraft:rooted_dirt
fill 21 221 -9 21 221 -7 minecraft:stone
fill 22 221 -9 22 223 -7 minecraft:dirt
fill 23 221 -9 25 221 -9 minecraft:rooted_dirt
fill 26 221 -9 26 223 -8 minecraft:dirt
fill 27 221 -9 27 221 -8 minecraft:mossy_cobblestone
fill 28 221 -9 28 221 -7 minecraft:stone
fill 29 221 -9 29 223 -7 minecraft:dirt
fill 31 221 -9 31 223 -5 minecraft:dirt
fill -31 221 -8 -31 221 -2 minecraft:stone
fill -30 221 -8 -30 223 -8 minecraft:dirt
fill -26 221 -8 -26 221 -7 minecraft:rooted_dirt
fill -13 221 -8 -11 221 -8 minecraft:rooted_dirt
fill -10 221 -8 -10 223 -8 minecraft:dirt
fill -5 221 -8 -4 223 -5 minecraft:dirt
fill -1 221 -8 -1 223 -8 minecraft:dirt
setblock 1 221 -8 minecraft:tuff
fill 2 221 -8 4 223 -7 minecraft:dirt
setblock 5 221 -8 minecraft:rooted_dirt
fill 6 221 -8 7 223 -8 minecraft:dirt
fill 11 221 -8 11 221 -7 minecraft:rooted_dirt
fill 23 221 -8 24 223 -8 minecraft:dirt
setblock 25 221 -8 minecraft:rooted_dirt
fill -30 221 -7 -30 221 -5 minecraft:stone
fill -27 221 -7 -27 223 -7 minecraft:dirt
fill -24 221 -7 -23 221 -7 minecraft:stone
fill -21 221 -7 -21 223 -6 minecraft:dirt
setblock -20 221 -7 minecraft:rooted_dirt
fill -13 221 -7 -11 223 -7 minecraft:dirt
setblock -10 221 -7 minecraft:rooted_dirt
fill -9 221 -7 -9 221 -6 minecraft:stone
fill -1 221 -7 0 221 -7 minecraft:rooted_dirt
fill 1 221 -7 1 223 -7 minecraft:dirt
fill 5 221 -7 5 223 -7 minecraft:dirt
setblock 6 221 -7 minecraft:rooted_dirt
fill 7 221 -7 7 223 -7 minecraft:dirt
fill 12 221 -7 14 223 -7 minecraft:dirt
fill 15 221 -7 15 221 -6 minecraft:rooted_dirt
setblock 18 221 -7 minecraft:rooted_dirt
fill 23 221 -7 23 221 -4 minecraft:rooted_dirt
fill 24 221 -7 25 222 -6 minecraft:dirt
setblock 26 221 -7 minecraft:rooted_dirt
fill 27 221 -7 27 223 -6 minecraft:dirt
fill -29 221 -6 -28 221 -5 minecraft:tuff
fill -26 221 -6 -26 221 -2 minecraft:stone
fill -20 221 -6 -20 223 -6 minecraft:dirt
fill -18 221 -6 -18 223 -2 minecraft:dirt
setblock -17 221 -6 minecraft:stone
fill -14 221 -6 -13 223 -6 minecraft:dirt
setblock -12 221 -6 minecraft:rooted_dirt
fill -11 221 -6 -10 223 -6 minecraft:dirt
fill -7 221 -6 -7 223 -5 minecraft:dirt
setblock -6 221 -6 minecraft:rooted_dirt
fill -3 221 -6 -2 221 -6 minecraft:rooted_dirt
fill -1 221 -6 0 222 -3 minecraft:dirt
setblock 1 221 -6 minecraft:rooted_dirt
fill 4 221 -6 4 221 -3 minecraft:tuff
fill 6 221 -6 6 221 -5 minecraft:stone
setblock 8 221 -6 minecraft:mossy_cobblestone
setblock 9 221 -6 minecraft:stone
fill 11 221 -6 11 223 -2 minecraft:dirt
setblock 12 221 -6 minecraft:rooted_dirt
fill 13 221 -6 14 222 -2 minecraft:dirt
setblock 18 221 -6 minecraft:stone
setblock 22 221 -6 minecraft:rooted_dirt
fill 26 221 -6 26 223 -2 minecraft:dirt
fill 28 221 -6 28 223 -3 minecraft:dirt
setblock 29 221 -6 minecraft:rooted_dirt
fill -27 221 -5 -27 221 -2 minecraft:stone
fill -19 221 -5 -19 221 0 minecraft:mossy_cobblestone
setblock -17 221 -5 minecraft:rooted_dirt
fill -16 221 -5 -14 223 -4 minecraft:dirt
fill -9 221 -5 -8 223 -2 minecraft:dirt
fill -6 221 -5 -6 223 -3 minecraft:dirt
fill -3 221 -5 -3 223 -3 minecraft:dirt
setblock -2 221 -5 minecraft:rooted_dirt
fill 1 221 -5 1 223 -4 minecraft:dirt
setblock 3 221 -5 minecraft:tuff
setblock 8 221 -5 minecraft:stone
fill 12 221 -5 12 223 -5 minecraft:dirt
