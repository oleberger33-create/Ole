fill -10 220 30 -8 221 30 minecraft:stone
fill -5 220 30 -3 220 30 minecraft:mossy_cobblestone
setblock -2 220 30 minecraft:tuff
fill 1 220 30 1 220 31 minecraft:tuff
setblock 2 220 30 minecraft:stone
fill -6 220 31 -5 220 31 minecraft:stone
setblock -2 220 31 minecraft:stone
fill -1 220 31 0 220 31 minecraft:tuff
fill 35 221 -38 35 223 -29 minecraft:dirt
setblock 36 221 -38 minecraft:rooted_dirt
fill 37 221 -38 37 223 -36 minecraft:dirt
setblock 38 221 -38 minecraft:rooted_dirt
setblock 33 221 -37 minecraft:stone
setblock 34 221 -37 minecraft:tuff
fill 36 221 -37 36 223 -36 minecraft:dirt
fill 38 221 -37 42 223 -37 minecraft:dirt
fill 31 221 -36 32 221 -36 minecraft:stone
setblock 33 221 -36 minecraft:tuff
fill 38 221 -36 41 223 -35 minecraft:dirt
setblock 42 221 -36 minecraft:rooted_dirt
fill 43 221 -36 44 223 -36 minecraft:dirt
setblock 30 221 -35 minecraft:stone
setblock 34 221 -35 minecraft:tuff
fill 36 221 -35 37 221 -35 minecraft:rooted_dirt
fill 42 221 -35 43 223 -35 minecraft:dirt
setblock 44 221 -35 minecraft:rooted_dirt
fill 29 221 -34 29 221 -33 minecraft:rooted_dirt
fill 30 221 -34 30 223 -33 minecraft:dirt
fill 34 221 -34 34 223 -25 minecraft:dirt
fill 36 221 -34 39 223 -33 minecraft:dirt
setblock 40 221 -34 minecraft:stone
setblock 45 221 -34 minecraft:dripstone_block
fill 31 221 -33 33 223 -33 minecraft:dirt
fill 45 221 -33 45 221 -32 minecraft:stone
fill 28 221 -32 29 223 -30 minecraft:dirt
fill 30 221 -32 31 221 -32 minecraft:rooted_dirt
fill 32 221 -32 33 223 -32 minecraft:dirt
fill 36 221 -32 38 223 -31 minecraft:dirt
fill 30 221 -31 31 223 -29 minecraft:dirt
fill 32 221 -31 32 221 -30 minecraft:rooted_dirt
fill 33 221 -31 33 223 -31 minecraft:dirt
fill 39 221 -31 39 223 -31 minecraft:dirt
fill 40 221 -31 40 221 -30 minecraft:rooted_dirt
setblock 41 221 -31 minecraft:stone
fill 46 221 -31 46 221 -28 minecraft:stone
setblock -4 221 -30 minecraft:dripstone_block
setblock -3 221 -30 minecraft:tuff
setblock -2 221 -30 minecraft:stone
setblock -1 221 -30 minecraft:mossy_cobblestone
fill 0 221 -30 1 221 -30 minecraft:stone
fill 2 221 -30 2 223 -30 minecraft:dirt
setblock 3 221 -30 minecraft:rooted_dirt
fill 4 221 -30 4 222 -26 minecraft:dirt
setblock 33 221 -30 minecraft:rooted_dirt
fill 36 221 -30 36 223 -30 minecraft:dirt
setblock 37 221 -30 minecraft:rooted_dirt
fill 38 221 -30 38 223 -25 minecraft:dirt
setblock 39 221 -30 minecraft:rooted_dirt
fill 41 221 -30 41 223 -30 minecraft:dirt
setblock 42 221 -30 minecraft:stone
setblock -10 221 -29 minecraft:rooted_dirt
fill -9 221 -29 -7 223 -29 minecraft:dirt
setblock -6 221 -29 minecraft:rooted_dirt
fill -5 221 -29 -3 223 -29 minecraft:dirt
setblock 2 221 -29 minecraft:rooted_dirt
fill 3 221 -29 3 223 -28 minecraft:dirt
fill 5 221 -29 8 223 -28 minecraft:dirt
fill 28 221 -29 29 221 -28 minecraft:stone
fill 32 221 -29 33 223 -28 minecraft:dirt
setblock 36 221 -29 minecraft:stone
fill 37 221 -29 37 223 -29 minecraft:dirt
fill 39 221 -29 40 223 -29 minecraft:dirt
setblock 41 221 -29 minecraft:rooted_dirt
fill 42 221 -29 42 223 -25 minecraft:dirt
fill -13 221 -28 -12 221 -28 minecraft:mossy_cobblestone
fill -11 221 -28 -11 221 -27 minecraft:stone
fill -10 221 -28 -9 223 -26 minecraft:dirt
fill -8 221 -28 -7 221 -27 minecraft:rooted_dirt
fill -6 221 -28 -4 223 -28 minecraft:dirt
setblock -3 221 -28 minecraft:rooted_dirt
fill -2 221 -28 -2 222 -19 minecraft:dirt
fill 2 221 -28 2 222 -22 minecraft:dirt
setblock 9 221 -28 minecraft:rooted_dirt
fill 10 221 -28 10 221 -27 minecraft:stone
fill 30 221 -28 30 223 -28 minecraft:dirt
setblock 31 221 -28 minecraft:rooted_dirt
fill 39 221 -28 39 223 -23 minecraft:dirt
setblock 40 221 -28 minecraft:rooted_dirt
fill 41 221 -28 41 223 -28 minecraft:dirt
setblock 43 221 -28 minecraft:stone
fill -15 221 -27 -14 221 -27 minecraft:stone
fill -6 221 -27 -6 223 -26 minecraft:dirt
fill -5 221 -27 -4 221 -27 minecraft:rooted_dirt
fill -3 221 -27 -3 223 -27 minecraft:dirt
setblock 3 221 -27 minecraft:rooted_dirt
setblock 5 221 -27 minecraft:rooted_dirt
fill 6 221 -27 9 223 -27 minecraft:dirt
fill 12 221 -27 12 221 -26 minecraft:stone
setblock 28 221 -27 minecraft:stone
setblock 30 221 -27 minecraft:rooted_dirt
fill 31 221 -27 32 223 -27 minecraft:dirt
fill 33 221 -27 33 221 -26 minecraft:rooted_dirt
fill 40 221 -27 40 223 -24 minecraft:dirt
setblock 41 221 -27 minecraft:rooted_dirt
fill 43 221 -27 43 221 -26 minecraft:mossy_cobblestone
fill 45 221 -27 45 221 -25 minecraft:stone
fill -17 221 -26 -14 223 -26 minecraft:dirt
setblock -13 221 -26 minecraft:mossy_cobblestone
fill -11 221 -26 -11 223 -25 minecraft:dirt
fill -8 221 -26 -7 223 -26 minecraft:dirt
setblock -5 221 -26 minecraft:rooted_dirt
fill -4 221 -26 -4 221 -24 minecraft:stone
setblock -3 221 -26 minecraft:rooted_dirt
fill -1 221 -26 1 222 -26 minecraft:dirt
fill 3 221 -26 3 222 -25 minecraft:dirt
fill 5 221 -26 6 222 -25 minecraft:dirt
setblock 7 221 -26 minecraft:rooted_dirt
fill 8 221 -26 9 223 -24 minecraft:dirt
setblock 14 221 -26 minecraft:stone
fill 30 221 -26 30 223 -25 minecraft:dirt
setblock 31 221 -26 minecraft:rooted_dirt
fill 32 221 -26 32 223 -26 minecraft:dirt
setblock 35 221 -26 minecraft:stone
setblock 37 221 -26 minecraft:stone
fill 41 221 -26 41 223 -25 minecraft:dirt
setblock 44 221 -26 minecraft:andesite
fill -17 221 -25 -17 221 -24 minecraft:rooted_dirt
fill -16 221 -25 -16 223 -20 minecraft:dirt
fill -15 221 -25 -14 221 -25 minecraft:rooted_dirt
fill -13 221 -25 -13 223 -22 minecraft:dirt
fill -12 221 -25 -12 221 -24 minecraft:rooted_dirt
setblock -10 221 -25 minecraft:rooted_dirt
fill -9 221 -25 -9 223 -25 minecraft:dirt
fill -6 221 -25 -5 221 -25 minecraft:stone
fill -1 221 -25 0 222 -24 minecraft:dirt
fill 1 221 -25 1 221 -23 minecraft:rooted_dirt
setblock 4 221 -25 minecraft:andesite
fill 7 221 -25 7 222 -23 minecraft:dirt
setblock 16 221 -25 minecraft:mossy_cobblestone
setblock 29 221 -25 minecraft:mossy_cobblestone
fill 31 221 -25 31 223 -25 minecraft:dirt
fill 32 221 -25 32 221 -24 minecraft:rooted_dirt
fill 33 221 -25 33 223 -23 minecraft:dirt
fill -41 221 -24 -40 221 -24 minecraft:stone
fill -39 221 -24 -39 226 -24 minecraft:tuff
setblock -18 221 -24 minecraft:rooted_dirt
fill -15 221 -24 -14 223 -22 minecraft:dirt
setblock -11 221 -24 minecraft:rooted_dirt
fill -10 221 -24 -10 223 -23 minecraft:dirt
setblock -9 221 -24 minecraft:tuff
setblock -5 221 -24 minecraft:stone
fill 3 221 -24 3 221 -23 minecraft:andesite
fill 5 221 -24 5 221 -23 minecraft:stone
fill 6 221 -24 6 222 -22 minecraft:dirt
fill 16 221 -24 17 221 -24 minecraft:stone
fill 30 221 -24 31 221 -24 minecraft:rooted_dirt
fill 34 221 -24 34 221 -21 minecraft:stone
setblock 38 221 -24 minecraft:rooted_dirt
fill 41 221 -24 42 221 -24 minecraft:rooted_dirt
fill 44 221 -24 44 221 -23 minecraft:andesite
setblock -21 221 -23 minecraft:stone
fill -19 221 -23 -18 221 -23 minecraft:stone
fill -17 221 -23 -17 223 -23 minecraft:dirt
fill -12 221 -23 -11 223 -23 minecraft:dirt
setblock -3 221 -23 minecraft:stone
setblock -1 221 -23 minecraft:rooted_dirt
fill 0 221 -23 0 222 -23 minecraft:dirt
fill 8 221 -23 8 222 -21 minecraft:dirt
setblock 9 221 -23 minecraft:rooted_dirt
setblock 19 221 -23 minecraft:stone
fill 31 221 -23 32 223 -23 minecraft:dirt
fill 35 221 -23 37 221 -20 minecraft:stone
fill 38 221 -23 38 223 -23 minecraft:dirt
fill 40 221 -23 40 221 -22 minecraft:rooted_dirt
fill 41 221 -23 42 223 -22 minecraft:dirt
fill 43 221 -23 43 221 -22 minecraft:andesite
fill -42 221 -22 -42 226 -22 minecraft:stone
setblock -38 221 -22 minecraft:stone
setblock -22 221 -22 minecraft:stone
setblock -19 221 -22 minecraft:stone
fill -18 221 -22 -18 221 -21 minecraft:tuff
setblock -17 221 -22 minecraft:rooted_dirt
fill -7 221 -22 -7 221 -21 minecraft:stone
fill -6 221 -22 -5 221 -22 minecraft:rooted_dirt
fill -4 221 -22 -4 222 -20 minecraft:dirt
setblock -3 221 -22 minecraft:rooted_dirt
fill -1 221 -22 -1 222 -22 minecraft:dirt
setblock 0 221 -22 minecraft:rooted_dirt
fill 1 221 -22 1 222 -22 minecraft:dirt
fill 3 221 -22 5 222 -22 minecraft:dirt
setblock 7 221 -22 minecraft:rooted_dirt
fill 9 221 -22 9 222 -17 minecraft:dirt
setblock 10 221 -22 minecraft:rooted_dirt
fill 13 221 -22 13 221 -21 minecraft:mossy_cobblestone
setblock 16 221 -22 minecraft:stone
setblock 21 221 -22 minecraft:stone
setblock 32 221 -22 minecraft:rooted_dirt
fill 33 221 -22 33 221 -21 minecraft:stone
fill 38 221 -22 38 221 -20 minecraft:stone
setblock 39 221 -22 minecraft:rooted_dirt
setblock -41 221 -21 minecraft:andesite
fill -40 221 -21 -40 222 -21 minecraft:stone
fill -23 221 -21 -23 223 -18 minecraft:dirt
fill -21 221 -21 -20 221 -21 minecraft:stone
fill -19 221 -21 -19 221 -19 minecraft:tuff
fill -17 221 -21 -17 223 -21 minecraft:dirt
setblock -15 221 -21 minecraft:rooted_dirt
fill -6 221 -21 -5 222 -20 minecraft:dirt
fill -3 221 -21 -3 222 -18 minecraft:dirt
fill 2 221 -21 2 221 -18 minecraft:mossy_cobblestone
fill 3 221 -21 3 222 -21 minecraft:dirt
fill 4 221 -21 6 221 -21 minecraft:rooted_dirt
fill 7 221 -21 7 222 -17 minecraft:dirt
fill 10 221 -21 10 223 -19 minecraft:dirt
setblock 14 221 -21 minecraft:stone
fill 15 221 -21 16 223 -21 minecraft:dirt
setblock 17 221 -21 minecraft:rooted_dirt
fill 18 221 -21 18 223 -19 minecraft:dirt
fill 22 221 -21 22 223 -19 minecraft:dirt
setblock 23 221 -21 minecraft:rooted_dirt
