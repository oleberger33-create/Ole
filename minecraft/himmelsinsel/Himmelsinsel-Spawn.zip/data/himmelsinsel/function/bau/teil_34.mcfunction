setblock -43 227 -23 minecraft:rooted_dirt
fill -42 227 -23 -42 229 -21 minecraft:dirt
setblock -38 227 -23 minecraft:rooted_dirt
fill -7 227 -23 -7 229 -23 minecraft:purple_stained_glass
fill 7 227 -23 7 229 -23 minecraft:purple_stained_glass
fill 30 227 -23 30 230 -22 minecraft:cherry_leaves[persistent=true]
fill -45 227 -22 -44 227 -21 minecraft:rooted_dirt
fill -43 227 -22 -43 229 -19 minecraft:dirt
fill -41 227 -22 -40 229 -22 minecraft:dirt
setblock -39 227 -22 minecraft:rooted_dirt
fill -38 227 -22 -36 227 -22 minecraft:stone
fill 29 227 -22 29 229 -22 minecraft:cherry_leaves[persistent=true]
fill -41 227 -21 -40 227 -21 minecraft:stone
setblock -35 227 -21 minecraft:dripstone_block
fill -45 227 -20 -44 229 -20 minecraft:dirt
setblock -42 227 -20 minecraft:rooted_dirt
fill -41 227 -20 -41 227 -19 minecraft:mossy_cobblestone
fill -40 227 -20 -39 227 -20 minecraft:stone
setblock -35 227 -20 minecraft:stone
fill -8 227 -20 -8 230 -20 minecraft:deepslate_bricks
fill 8 227 -20 8 229 -20 minecraft:deepslate_bricks
fill -44 227 -19 -44 229 -19 minecraft:dirt
fill -42 227 -19 -42 229 -18 minecraft:dirt
fill -40 227 -19 -38 227 -19 minecraft:mossy_cobblestone
fill -37 227 -19 -36 227 -19 minecraft:stone
fill -8 227 -19 -8 229 -17 minecraft:purple_stained_glass
fill 8 227 -19 8 229 -17 minecraft:purple_stained_glass
setblock -41 227 -18 minecraft:rooted_dirt
fill -40 227 -18 -40 229 -18 minecraft:dirt
fill -39 227 -18 -38 227 -18 minecraft:mossy_cobblestone
setblock -37 227 -18 minecraft:stone
fill -8 227 -16 -8 230 -16 minecraft:deepslate_bricks
fill 8 227 -16 8 230 -16 minecraft:deepslate_bricks
fill -7 227 -14 -7 230 -14 minecraft:deepslate_bricks
fill 7 227 -14 7 230 -14 minecraft:deepslate_bricks
fill -7 227 -13 -6 229 -13 minecraft:purple_stained_glass
fill 6 227 -13 7 229 -13 minecraft:purple_stained_glass
fill -6 227 -12 -5 229 -12 minecraft:purple_stained_glass
fill 5 227 -12 6 229 -12 minecraft:purple_stained_glass
fill -16 227 -11 -16 231 -11 minecraft:cherry_leaves[persistent=true]
fill -5 227 -11 -5 229 -11 minecraft:purple_stained_glass
fill 4 227 -11 4 230 -11 minecraft:deepslate_bricks
fill 5 227 -11 5 229 -11 minecraft:purple_stained_glass
fill -13 227 -10 -12 231 -10 minecraft:cherry_leaves[persistent=true]
fill -13 227 -8 -13 231 -8 minecraft:cherry_leaves[persistent=true]
fill -24 227 10 -24 231 10 minecraft:cherry_leaves[persistent=true]
fill -21 227 11 -21 231 11 minecraft:cherry_leaves[persistent=true]
fill -22 227 14 -22 231 14 minecraft:cherry_leaves[persistent=true]
fill -17 227 15 -17 228 15 minecraft:dark_oak_planks
fill 11 227 16 11 228 16 minecraft:cherry_leaves[persistent=true]
fill -19 227 17 -19 228 17 minecraft:dark_oak_planks
fill -15 227 17 -15 228 17 minecraft:dark_oak_planks
fill 10 227 17 10 231 18 minecraft:cherry_leaves[persistent=true]
fill -17 227 19 -17 228 19 minecraft:dark_oak_planks
fill 39 227 24 39 227 25 minecraft:azalea_leaves[persistent=true]
fill 40 227 24 41 227 24 minecraft:flowering_azalea_leaves[persistent=true]
setblock 40 227 25 minecraft:azalea_leaves[persistent=true]
fill 41 227 25 41 228 25 minecraft:flowering_azalea_leaves[persistent=true]
fill 39 227 26 40 227 26 minecraft:flowering_azalea_leaves[persistent=true]
setblock 41 227 26 minecraft:azalea_leaves[persistent=true]
fill 33 228 -36 33 228 -34 minecraft:white_wool
fill 34 228 -36 34 228 -34 minecraft:lime_wool
fill 35 228 -36 35 228 -34 minecraft:white_wool
fill 39 228 -36 39 228 -34 minecraft:white_wool
fill 40 228 -36 40 228 -34 minecraft:orange_wool
fill 41 228 -36 41 228 -34 minecraft:white_wool
fill 30 228 -30 32 228 -30 minecraft:black_wool
fill 42 228 -30 44 228 -30 minecraft:white_wool
fill 30 228 -29 32 228 -29 minecraft:red_wool
fill 42 228 -29 44 228 -29 minecraft:brown_wool
fill 30 228 -28 32 228 -28 minecraft:black_wool
fill 42 228 -28 44 228 -28 minecraft:white_wool
fill -42 228 -27 -41 229 -27 minecraft:dirt
setblock -40 228 -27 minecraft:rooted_dirt
fill -39 228 -27 -39 229 -27 minecraft:dirt
setblock -38 228 -27 minecraft:rooted_dirt
fill -40 228 -26 -40 229 -26 minecraft:dirt
setblock -39 228 -26 minecraft:rooted_dirt
fill 30 228 -26 31 229 -25 minecraft:cherry_leaves[persistent=true]
fill -38 228 -25 -38 229 -25 minecraft:dirt
fill -36 228 -25 -36 229 -25 minecraft:dirt
fill 29 228 -25 29 230 -25 minecraft:cherry_leaves[persistent=true]
fill -44 228 -24 -44 229 -24 minecraft:dirt
fill -41 228 -24 -41 229 -23 minecraft:dirt
fill 28 228 -24 28 229 -24 minecraft:cherry_leaves[persistent=true]
setblock 29 228 -24 minecraft:cherry_log[axis=y]
fill 30 228 -24 30 231 -24 minecraft:cherry_leaves[persistent=true]
fill -43 228 -23 -43 229 -23 minecraft:dirt
fill -38 228 -23 -38 229 -18 minecraft:dirt
fill 29 228 -23 29 230 -23 minecraft:cherry_leaves[persistent=true]
fill 31 228 -23 31 230 -23 minecraft:cherry_leaves[persistent=true]
fill -45 228 -22 -44 229 -21 minecraft:dirt
fill -39 228 -22 -39 229 -18 minecraft:dirt
fill -37 228 -22 -37 229 -21 minecraft:dirt
fill -36 228 -22 -36 228 -21 minecraft:rooted_dirt
fill -7 228 -22 -7 229 -22 minecraft:deepslate_bricks
fill -41 228 -21 -40 229 -21 minecraft:dirt
fill -35 228 -21 -35 229 -20 minecraft:dirt
fill -42 228 -20 -42 229 -20 minecraft:dirt
fill -41 228 -20 -41 228 -19 minecraft:rooted_dirt
fill -40 228 -20 -40 229 -19 minecraft:dirt
fill -37 228 -20 -37 228 -19 minecraft:rooted_dirt
fill -36 228 -20 -36 229 -20 minecraft:dirt
setblock -36 228 -19 minecraft:rooted_dirt
fill -41 228 -18 -41 229 -18 minecraft:dirt
fill -37 228 -18 -37 229 -18 minecraft:dirt
fill 19 228 -16 19 232 -16 minecraft:cherry_leaves[persistent=true]
fill 15 228 -13 15 232 -12 minecraft:cherry_leaves[persistent=true]
fill 17 228 -13 18 232 -13 minecraft:cherry_leaves[persistent=true]
fill 34 228 -13 40 228 -13 minecraft:spruce_slab[type=bottom]
fill 34 228 -12 34 228 -7 minecraft:spruce_slab[type=bottom]
fill 35 228 -12 39 228 -8 minecraft:spruce_planks
fill 40 228 -12 40 228 -7 minecraft:spruce_slab[type=bottom]
fill -14 228 -11 -14 231 -10 minecraft:cherry_leaves[persistent=true]
setblock -4 228 -11 minecraft:cracked_deepslate_bricks
fill -15 228 -10 -15 231 -10 minecraft:cherry_leaves[persistent=true]
fill -16 228 -9 -16 232 -9 minecraft:cherry_leaves[persistent=true]
setblock -14 228 -9 minecraft:cherry_log[axis=x]
setblock -13 228 -9 minecraft:cherry_leaves[persistent=true]
fill -17 228 -8 -17 230 -8 minecraft:cherry_leaves[persistent=true]
fill -15 228 -8 -15 231 -7 minecraft:cherry_leaves[persistent=true]
fill -12 228 -7 -12 231 -7 minecraft:cherry_leaves[persistent=true]
fill 35 228 -7 39 228 -7 minecraft:spruce_slab[type=bottom]
fill -24 228 8 -24 230 8 minecraft:cherry_leaves[persistent=true]
fill -22 228 9 -22 231 9 minecraft:cherry_leaves[persistent=true]
fill -23 228 11 -23 232 11 minecraft:cherry_leaves[persistent=true]
setblock -22 228 11 minecraft:cherry_log[axis=z]
fill -22 228 12 -21 228 12 minecraft:cherry_leaves[persistent=true]
fill -20 228 13 -20 231 13 minecraft:cherry_leaves[persistent=true]
fill -20 228 14 -20 228 20 minecraft:dark_oak_stairs[facing=east,half=bottom]
fill -19 228 14 -15 228 14 minecraft:dark_oak_stairs[facing=south,half=bottom]
fill -14 228 14 -14 228 20 minecraft:dark_oak_stairs[facing=west,half=bottom]
setblock -19 228 15 minecraft:dark_oak_planks
setblock -15 228 15 minecraft:dark_oak_planks
fill 12 228 15 12 232 15 minecraft:cherry_leaves[persistent=true]
fill -18 228 16 -16 229 18 minecraft:dark_oak_planks
setblock 12 228 16 minecraft:cherry_log[axis=x]
fill 11 228 17 12 231 17 minecraft:cherry_leaves[persistent=true]
setblock -19 228 19 minecraft:dark_oak_planks
setblock -15 228 19 minecraft:dark_oak_planks
fill 13 228 19 13 230 19 minecraft:cherry_leaves[persistent=true]
fill -19 228 20 -15 228 20 minecraft:dark_oak_stairs[facing=north,half=bottom]
fill 40 228 24 40 228 26 minecraft:flowering_azalea_leaves[persistent=true]
setblock 39 228 25 minecraft:flowering_azalea_leaves[persistent=true]
fill -2 228 31 2 228 31 minecraft:stripped_spruce_log[axis=x]
setblock -40 229 -27 minecraft:dirt
setblock -38 229 -27 minecraft:dirt
setblock -39 229 -26 minecraft:dirt
setblock -2 229 -26 minecraft:cracked_deepslate_bricks
fill 29 229 -26 29 230 -26 minecraft:cherry_leaves[persistent=true]
setblock 4 229 -25 minecraft:cracked_deepslate_bricks
fill 32 229 -25 32 229 -24 minecraft:cherry_leaves[persistent=true]
fill 29 229 -24 29 231 -24 minecraft:cherry_leaves[persistent=true]
fill 31 229 -24 31 231 -24 minecraft:cherry_leaves[persistent=true]
fill -36 229 -22 -36 229 -21 minecraft:dirt
fill -41 229 -20 -41 229 -19 minecraft:dirt
fill -37 229 -20 -37 229 -19 minecraft:dirt
setblock -36 229 -19 minecraft:dirt
fill 16 229 -17 16 232 -16 minecraft:cherry_leaves[persistent=true]
fill 14 229 -16 14 232 -16 minecraft:cherry_leaves[persistent=true]
fill 17 229 -16 17 229 -14 minecraft:cherry_leaves[persistent=true]
setblock 16 229 -15 minecraft:cherry_log[axis=x]
fill 15 229 -14 16 232 -14 minecraft:cherry_leaves[persistent=true]
fill 18 229 -14 18 232 -14 minecraft:cherry_leaves[persistent=true]
fill 14 229 -13 14 232 -13 minecraft:cherry_leaves[persistent=true]
fill -15 229 -12 -13 230 -12 minecraft:cherry_leaves[persistent=true]
fill -15 229 -11 -15 231 -11 minecraft:cherry_leaves[persistent=true]
fill -13 229 -11 -12 231 -11 minecraft:cherry_leaves[persistent=true]
fill -4 229 -11 -4 230 -11 minecraft:deepslate_bricks
fill -17 229 -10 -16 231 -10 minecraft:cherry_leaves[persistent=true]
fill -11 229 -10 -11 230 -9 minecraft:cherry_leaves[persistent=true]
fill -1 229 -10 1 229 -10 minecraft:chiseled_deepslate
setblock 37 229 -10 minecraft:spruce_slab[type=bottom]
fill -14 229 -9 -14 231 -6 minecraft:cherry_leaves[persistent=true]
setblock -13 229 -9 minecraft:cherry_log[axis=y]
fill -12 229 -9 -12 231 -8 minecraft:cherry_leaves[persistent=true]
fill -16 229 -8 -16 231 -7 minecraft:cherry_leaves[persistent=true]
fill -13 229 -7 -13 230 -6 minecraft:cherry_leaves[persistent=true]
fill 12 229 -7 12 229 7 minecraft:spruce_stairs[facing=east,half=bottom]
fill 13 229 -7 25 229 -7 minecraft:spruce_stairs[facing=south,half=bottom]
fill 26 229 -7 26 229 7 minecraft:spruce_stairs[facing=west,half=bottom]
fill -15 229 -6 -15 231 -6 minecraft:cherry_leaves[persistent=true]
fill 13 229 -6 25 229 6 minecraft:spruce_planks
fill 13 229 7 25 229 7 minecraft:spruce_stairs[facing=north,half=bottom]
fill -23 229 8 -21 229 8 minecraft:cherry_leaves[persistent=true]
fill -23 229 9 -23 231 10 minecraft:cherry_leaves[persistent=true]
fill -21 229 9 -21 231 10 minecraft:cherry_leaves[persistent=true]
fill -20 229 10 -20 231 12 minecraft:cherry_leaves[persistent=true]
fill -25 229 11 -24 230 11 minecraft:cherry_leaves[persistent=true]
fill -22 229 11 -22 232 11 minecraft:cherry_leaves[persistent=true]
fill -19 229 11 -19 230 11 minecraft:cherry_leaves[persistent=true]
fill -24 229 12 -23 231 13 minecraft:cherry_leaves[persistent=true]
setblock -22 229 12 minecraft:cherry_log[axis=y]
fill -21 229 12 -21 231 13 minecraft:cherry_leaves[persistent=true]
fill -22 229 13 -22 231 13 minecraft:cherry_leaves[persistent=true]
fill 10 229 14 14 231 14 minecraft:cherry_leaves[persistent=true]
fill -19 229 15 -19 229 19 minecraft:dark_oak_stairs[facing=east,half=bottom]
fill -18 229 15 -16 229 15 minecraft:dark_oak_stairs[facing=south,half=bottom]
fill -15 229 15 -15 229 19 minecraft:dark_oak_stairs[facing=west,half=bottom]
fill 10 229 15 11 231 15 minecraft:cherry_leaves[persistent=true]
fill 13 229 15 14 231 15 minecraft:cherry_leaves[persistent=true]
fill 10 229 16 10 231 16 minecraft:cherry_leaves[persistent=true]
setblock 11 229 16 minecraft:cherry_log[axis=y]
fill 12 229 16 12 232 16 minecraft:cherry_leaves[persistent=true]
fill 14 229 16 15 230 17 minecraft:cherry_leaves[persistent=true]
fill 13 229 17 13 231 18 minecraft:cherry_leaves[persistent=true]
fill 11 229 18 12 231 18 minecraft:cherry_leaves[persistent=true]
fill 14 229 18 14 230 19 minecraft:cherry_leaves[persistent=true]
fill -18 229 19 -16 229 19 minecraft:dark_oak_stairs[facing=north,half=bottom]
fill -42 230 -27 -38 230 -18 minecraft:grass_block
fill -43 230 -26 -43 230 -19 minecraft:grass_block
fill -37 230 -26 -37 230 -18 minecraft:grass_block
fill -2 230 -26 1 230 -26 minecraft:deepslate_bricks
fill -36 230 -25 -36 230 -19 minecraft:grass_block
setblock -5 230 -25 minecraft:deepslate_bricks
fill 4 230 -25 5 230 -25 minecraft:deepslate_bricks
fill 30 230 -25 31 230 -25 minecraft:cherry_leaves[persistent=true]
fill -44 230 -24 -44 230 -19 minecraft:grass_block
fill -6 230 -24 -6 230 -23 minecraft:deepslate_bricks
setblock -5 230 -24 minecraft:cracked_deepslate_bricks
