fill -2 212 14 -2 212 15 minecraft:stone
fill 0 212 14 0 216 14 minecraft:cobblestone
fill 7 212 14 7 220 14 minecraft:stone
setblock 11 212 14 minecraft:amethyst_block
fill -11 212 15 -11 217 15 minecraft:stone
fill -1 212 15 0 212 15 minecraft:stone
fill 1 212 15 1 219 15 minecraft:cobblestone
fill 10 212 15 10 221 15 minecraft:stone
fill -1 212 16 -1 215 17 minecraft:stone
setblock 2 212 16 minecraft:tuff
fill 3 212 16 3 219 18 minecraft:stone
fill 9 212 16 9 219 16 minecraft:stone
fill -10 212 17 -10 220 17 minecraft:stone
fill -8 212 17 -8 220 18 minecraft:stone
fill 0 212 17 0 221 17 minecraft:stone
setblock 1 212 17 minecraft:tuff
setblock 2 212 17 minecraft:dripstone_block
setblock 9 212 17 minecraft:dripstone_block
fill -7 212 18 -6 220 18 minecraft:stone
fill -3 212 18 -2 221 18 minecraft:stone
setblock -1 212 18 minecraft:dripstone_block
fill 1 212 18 2 220 18 minecraft:stone
fill 4 212 18 7 220 18 minecraft:stone
setblock 8 212 18 minecraft:amethyst_block
fill -5 213 -21 -4 213 -21 minecraft:tuff
fill -3 213 -21 -3 219 -21 minecraft:stone
fill 7 213 -21 8 220 -20 minecraft:stone
setblock -6 213 -20 minecraft:tuff
fill -2 213 -20 -2 220 -18 minecraft:stone
fill 3 213 -20 6 218 -20 minecraft:stone
fill -6 213 -19 -6 218 -16 minecraft:stone
fill 2 213 -19 2 213 -18 minecraft:amethyst_block
fill 3 213 -19 3 219 -19 minecraft:stone
fill 9 213 -19 9 220 -18 minecraft:stone
setblock -1 213 -18 minecraft:amethyst_block
setblock 1 213 -18 minecraft:dripstone_block
fill -5 213 -17 -5 220 -17 minecraft:stone
fill -1 213 -17 1 220 -17 minecraft:stone
fill 8 213 -17 8 220 -17 minecraft:stone
setblock 9 213 -17 minecraft:andesite
fill 0 213 -16 0 220 -16 minecraft:stone
fill 3 213 -16 4 216 -16 minecraft:stone
fill 5 213 -16 5 216 -15 minecraft:cobblestone
fill 7 213 -16 7 214 -15 minecraft:cobblestone
fill 10 213 -16 10 213 -15 minecraft:andesite
fill -16 213 -15 -15 218 -15 minecraft:stone
fill -9 213 -15 -7 219 -15 minecraft:stone
setblock -3 213 -15 minecraft:stone
fill -2 213 -15 -2 215 -15 minecraft:cobblestone
fill -1 213 -15 -1 219 -15 minecraft:stone
fill 6 213 -15 6 217 -15 minecraft:cobblestone
fill -16 213 -14 -16 213 -13 minecraft:tuff
fill -15 213 -14 -14 217 -12 minecraft:stone
fill -11 213 -14 -10 221 -14 minecraft:stone
fill -7 213 -14 -6 219 -14 minecraft:stone
setblock 7 213 -14 minecraft:stone
fill 8 213 -14 9 213 -14 minecraft:cobblestone
fill 10 213 -14 10 221 -14 minecraft:stone
fill 12 213 -14 14 220 -14 minecraft:stone
fill -13 213 -13 -13 213 -12 minecraft:stone
fill -12 213 -13 -10 213 -13 minecraft:andesite
fill -7 213 -13 -4 213 -13 minecraft:cobblestone
fill -3 213 -13 -3 220 -13 minecraft:stone
fill 8 213 -13 8 214 -12 minecraft:cobblestone
setblock 15 213 -13 minecraft:amethyst_block
fill 16 213 -13 16 221 -12 minecraft:tuff
fill -17 213 -12 -16 220 -12 minecraft:stone
fill -12 213 -12 -11 214 -12 minecraft:andesite
fill -10 213 -12 -10 221 -12 minecraft:stone
fill 9 213 -12 9 221 -12 minecraft:stone
setblock 17 213 -12 minecraft:amethyst_block
fill -17 213 -11 -17 221 -11 minecraft:stone
setblock -16 213 -11 minecraft:amethyst_block
fill -7 213 -11 -7 215 -10 minecraft:stone
fill 17 213 -11 18 214 -11 minecraft:stone
fill -18 213 -10 -18 216 -10 minecraft:cobblestone
setblock -17 213 -10 minecraft:dripstone_block
fill -16 213 -10 -15 220 -10 minecraft:stone
fill -10 213 -10 -9 221 -10 minecraft:stone
setblock -8 213 -10 minecraft:tuff
fill 18 213 -10 18 220 -10 minecraft:stone
setblock -21 213 -9 minecraft:stone
fill -20 213 -9 -18 213 -9 minecraft:andesite
fill -15 213 -9 -15 221 -8 minecraft:stone
fill -9 213 -9 -9 219 -9 minecraft:stone
fill -2 213 -9 -2 215 -9 minecraft:andesite
setblock 5 213 -9 minecraft:stone
fill 14 213 -9 14 214 -8 minecraft:stone
fill 15 213 -9 15 215 -8 minecraft:andesite
fill 19 213 -9 19 221 -7 minecraft:stone
fill -21 213 -8 -21 213 -7 minecraft:cobblestone
fill -18 213 -8 -18 214 -8 minecraft:andesite
setblock -9 213 -8 minecraft:cobblestone
fill -4 213 -8 -2 213 -8 minecraft:stone
fill -1 213 -8 -1 217 -8 minecraft:andesite
fill 7 213 -8 7 216 -8 minecraft:tuff
fill -20 213 -7 -20 217 -7 minecraft:andesite
setblock -17 213 -7 minecraft:dripstone_block
fill -16 213 -7 -16 221 -7 minecraft:stone
setblock -10 213 -7 minecraft:cobblestone
fill -9 213 -7 -9 218 -4 minecraft:stone
setblock -1 213 -7 minecraft:stone
fill 0 213 -7 0 217 -7 minecraft:andesite
fill 16 213 -7 16 216 -7 minecraft:andesite
setblock -20 213 -6 minecraft:cobblestone
fill -18 213 -6 -18 219 -6 minecraft:andesite
fill -19 213 -5 -19 214 -2 minecraft:stone
fill -17 213 -5 -16 219 -5 minecraft:andesite
fill -8 213 -5 -8 220 -5 minecraft:stone
fill 18 213 -5 18 215 -3 minecraft:stone
fill -17 213 -4 -17 213 -1 minecraft:stone
fill -16 213 -4 -15 220 -4 minecraft:andesite
fill -14 213 -4 -14 220 -4 minecraft:stone
fill 9 213 -4 16 217 -4 minecraft:stone
fill -10 213 -3 -10 220 -3 minecraft:stone
setblock -9 213 -3 minecraft:andesite
fill -7 213 -3 -6 220 -3 minecraft:stone
setblock 9 213 -3 minecraft:tuff
fill 10 213 -3 11 214 -3 minecraft:cobblestone
fill 12 213 -3 12 220 -2 minecraft:stone
fill 17 213 -3 17 217 -3 minecraft:stone
fill -6 213 -2 -6 221 -2 minecraft:stone
setblock 11 213 -2 minecraft:cobblestone
fill 19 213 -2 19 219 -2 minecraft:stone
fill -8 213 -1 -7 213 -1 minecraft:andesite
setblock 15 213 -1 minecraft:stone
fill 16 213 -1 16 214 -1 minecraft:tuff
fill 17 213 -1 17 221 -1 minecraft:stone
fill 19 213 -1 19 213 0 minecraft:dripstone_block
fill -8 213 0 -8 220 1 minecraft:stone
fill 13 213 0 13 220 2 minecraft:stone
fill 18 213 0 18 221 1 minecraft:stone
fill 20 213 0 20 217 1 minecraft:stone
fill -18 213 1 -18 219 2 minecraft:stone
fill -16 213 1 -16 220 4 minecraft:stone
fill 6 213 1 8 220 1 minecraft:stone
fill 19 213 1 19 220 1 minecraft:stone
fill -17 213 2 -17 221 3 minecraft:stone
fill 5 213 2 5 220 2 minecraft:stone
setblock 6 213 2 minecraft:andesite
fill 8 213 2 8 221 2 minecraft:stone
fill 12 213 2 12 216 2 minecraft:stone
setblock 20 213 2 minecraft:amethyst_block
fill -15 213 3 -15 221 4 minecraft:stone
setblock 5 213 3 minecraft:andesite
fill 12 213 3 13 213 3 minecraft:tuff
setblock 16 213 3 minecraft:dripstone_block
fill 17 213 3 17 221 3 minecraft:stone
fill 21 213 3 21 220 3 minecraft:stone
fill 15 213 4 15 220 4 minecraft:stone
setblock -16 213 5 minecraft:dripstone_block
fill -13 213 5 -13 213 7 minecraft:stone
fill 16 213 5 16 221 5 minecraft:stone
setblock -17 213 6 minecraft:amethyst_block
fill -18 213 7 -18 213 8 minecraft:stone
fill -17 213 7 -16 213 7 minecraft:cobblestone
fill -15 213 7 -15 217 10 minecraft:stone
fill -11 213 7 -11 214 9 minecraft:andesite
fill -10 213 7 -10 217 10 minecraft:stone
fill -1 213 7 -1 219 7 minecraft:stone
fill -17 213 8 -17 215 9 minecraft:cobblestone
fill -13 213 8 -13 216 8 minecraft:andesite
setblock 3 213 8 minecraft:stone
fill 4 213 8 5 214 8 minecraft:tuff
fill 6 213 8 6 220 8 minecraft:stone
setblock 18 213 8 minecraft:cobblestone
fill 19 213 8 19 218 8 minecraft:stone
fill -1 213 9 0 215 9 minecraft:stone
fill 18 213 9 18 213 10 minecraft:stone
setblock -16 213 10 minecraft:dripstone_block
fill -1 213 10 -1 218 10 minecraft:stone
fill -13 213 11 -13 219 12 minecraft:andesite
fill 16 213 11 17 215 12 minecraft:andesite
fill -14 213 12 -14 214 16 minecraft:stone
fill -1 213 12 -1 215 12 minecraft:cobblestone
fill -13 213 13 -13 213 14 minecraft:stone
fill -12 213 13 -12 220 13 minecraft:andesite
fill -11 213 13 -11 213 14 minecraft:stone
fill 2 213 13 2 216 13 minecraft:stone
fill 6 213 13 7 220 13 minecraft:stone
fill 15 213 13 17 214 13 minecraft:stone
fill -12 213 14 -12 215 16 minecraft:stone
fill -2 213 14 -2 219 14 minecraft:cobblestone
fill 11 213 14 16 217 14 minecraft:stone
fill -15 213 15 -15 220 16 minecraft:stone
setblock -13 213 15 minecraft:amethyst_block
setblock -2 213 15 minecraft:stone
fill -1 213 15 0 217 15 minecraft:cobblestone
fill 15 213 15 16 213 16 minecraft:stone
fill -13 213 16 -13 219 16 minecraft:stone
fill -11 213 16 -11 218 17 minecraft:stone
fill 2 213 16 2 221 17 minecraft:stone
fill 10 213 16 10 221 16 minecraft:stone
fill 1 213 17 1 220 17 minecraft:stone
fill 9 213 17 9 216 18 minecraft:stone
setblock 10 213 17 minecraft:amethyst_block
fill -9 213 18 -9 220 18 minecraft:stone
fill -5 213 18 -4 221 18 minecraft:stone
fill -1 213 18 0 221 19 minecraft:stone
fill 8 213 18 8 216 19 minecraft:stone
fill 10 213 18 10 219 18 minecraft:stone
fill -2 213 19 -2 221 19 minecraft:stone
fill 1 213 19 7 217 19 minecraft:stone
setblock 9 213 19 minecraft:dripstone_block
fill 3 213 20 4 218 20 minecraft:stone
fill 40 213 25 40 218 25 minecraft:stone
fill 0 214 -24 0 220 -23 minecraft:stone
fill -1 214 -23 -1 220 -23 minecraft:stone
fill 1 214 -23 1 220 -23 minecraft:stone
fill -4 214 -22 -2 220 -22 minecraft:stone
fill 6 214 -22 8 220 -22 minecraft:stone
setblock -6 214 -21 minecraft:tuff
fill -5 214 -21 -4 218 -21 minecraft:stone
fill -2 214 -21 -2 220 -21 minecraft:stone
fill 2 214 -21 6 216 -21 minecraft:stone
fill 9 214 -21 9 220 -21 minecraft:stone
setblock -7 214 -20 minecraft:amethyst_block
fill -6 214 -20 -6 220 -20 minecraft:stone
fill 2 214 -20 2 219 -18 minecraft:stone
setblock 9 214 -20 minecraft:amethyst_block
