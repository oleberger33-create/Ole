# Wird am Boden unter dem Sprungbrett ausgeführt (~ ~ ~ = erste Luft über dem Gelände)
fill ~-6 ~ ~-6 ~6 ~7 ~6 minecraft:air
# Fundament: Löcher und Wasser unter der Plattform füllen
fill ~-1 ~-6 ~-5 ~1 ~-2 ~-5 minecraft:dirt replace #minecraft:replaceable
fill ~-3 ~-6 ~-4 ~3 ~-2 ~-4 minecraft:dirt replace #minecraft:replaceable
fill ~-4 ~-6 ~-3 ~4 ~-2 ~-3 minecraft:dirt replace #minecraft:replaceable
fill ~-4 ~-6 ~-2 ~4 ~-2 ~-2 minecraft:dirt replace #minecraft:replaceable
fill ~-5 ~-6 ~-1 ~5 ~-2 ~-1 minecraft:dirt replace #minecraft:replaceable
fill ~-5 ~-6 ~ ~5 ~-2 ~ minecraft:dirt replace #minecraft:replaceable
fill ~-5 ~-6 ~1 ~5 ~-2 ~1 minecraft:dirt replace #minecraft:replaceable
fill ~-4 ~-6 ~2 ~4 ~-2 ~2 minecraft:dirt replace #minecraft:replaceable
fill ~-4 ~-6 ~3 ~4 ~-2 ~3 minecraft:dirt replace #minecraft:replaceable
fill ~-3 ~-6 ~4 ~3 ~-2 ~4 minecraft:dirt replace #minecraft:replaceable
fill ~-1 ~-6 ~5 ~1 ~-2 ~5 minecraft:dirt replace #minecraft:replaceable
fill ~-1 ~-1 ~-5 ~1 ~-1 ~-5 minecraft:polished_andesite
fill ~-3 ~-1 ~-4 ~-2 ~-1 ~-4 minecraft:polished_andesite
fill ~-1 ~-1 ~-4 ~1 ~-1 ~-4 minecraft:mossy_stone_bricks
fill ~2 ~-1 ~-4 ~3 ~-1 ~-4 minecraft:polished_andesite
fill ~-4 ~-1 ~-3 ~-4 ~-1 ~-2 minecraft:polished_andesite
fill ~-3 ~-1 ~-3 ~ ~-1 ~-3 minecraft:stone_bricks
fill ~1 ~-1 ~-3 ~2 ~-1 ~-3 minecraft:mossy_stone_bricks
fill ~3 ~-1 ~-3 ~3 ~-1 ~-2 minecraft:stone_bricks
fill ~4 ~-1 ~-3 ~4 ~-1 ~-2 minecraft:polished_andesite
setblock ~-3 ~-1 ~-2 minecraft:mossy_stone_bricks
setblock ~-2 ~-1 ~-2 minecraft:stone_bricks
fill ~-1 ~-1 ~-2 ~1 ~-1 ~-2 minecraft:polished_deepslate
setblock ~2 ~-1 ~-2 minecraft:stone_bricks
fill ~-5 ~-1 ~-1 ~-5 ~-1 ~1 minecraft:polished_andesite
fill ~-4 ~-1 ~-1 ~-3 ~-1 ~ minecraft:stone_bricks
fill ~-2 ~-1 ~-1 ~-2 ~-1 ~1 minecraft:polished_deepslate
setblock ~-1 ~-1 ~-1 minecraft:stone_bricks
fill ~ ~-1 ~-1 ~ ~-1 ~1 minecraft:chiseled_stone_bricks
setblock ~1 ~-1 ~-1 minecraft:mossy_stone_bricks
fill ~2 ~-1 ~-1 ~2 ~-1 ~1 minecraft:polished_deepslate
fill ~3 ~-1 ~-1 ~4 ~-1 ~-1 minecraft:mossy_stone_bricks
fill ~5 ~-1 ~-1 ~5 ~-1 ~1 minecraft:polished_andesite
setblock ~-1 ~-1 ~ minecraft:chiseled_stone_bricks
setblock ~1 ~-1 ~ minecraft:chiseled_stone_bricks
fill ~3 ~-1 ~ ~4 ~-1 ~ minecraft:stone_bricks
setblock ~-4 ~-1 ~1 minecraft:mossy_stone_bricks
setblock ~-3 ~-1 ~1 minecraft:stone_bricks
setblock ~-1 ~-1 ~1 minecraft:stone_bricks
setblock ~1 ~-1 ~1 minecraft:stone_bricks
setblock ~3 ~-1 ~1 minecraft:mossy_stone_bricks
setblock ~4 ~-1 ~1 minecraft:stone_bricks
fill ~-4 ~-1 ~2 ~-4 ~-1 ~3 minecraft:polished_andesite
fill ~-3 ~-1 ~2 ~-2 ~-1 ~2 minecraft:mossy_stone_bricks
fill ~-1 ~-1 ~2 ~1 ~-1 ~2 minecraft:polished_deepslate
fill ~2 ~-1 ~2 ~3 ~-1 ~3 minecraft:stone_bricks
fill ~4 ~-1 ~2 ~4 ~-1 ~3 minecraft:polished_andesite
fill ~-3 ~-1 ~3 ~-2 ~-1 ~3 minecraft:stone_bricks
setblock ~-1 ~-1 ~3 minecraft:mossy_stone_bricks
fill ~ ~-1 ~3 ~1 ~-1 ~3 minecraft:stone_bricks
fill ~-3 ~-1 ~4 ~-2 ~-1 ~4 minecraft:polished_andesite
setblock ~-1 ~-1 ~4 minecraft:stone_bricks
setblock ~ ~-1 ~4 minecraft:mossy_stone_bricks
setblock ~1 ~-1 ~4 minecraft:stone_bricks
fill ~2 ~-1 ~4 ~3 ~-1 ~4 minecraft:polished_andesite
fill ~-1 ~-1 ~5 ~1 ~-1 ~5 minecraft:polished_andesite
fill ~ ~ ~-5 ~ ~2 ~-5 minecraft:crying_obsidian
fill ~-1 ~ ~-4 ~-1 ~2 ~-4 minecraft:crying_obsidian
fill ~1 ~ ~-4 ~1 ~2 ~-4 minecraft:crying_obsidian
fill ~-3 ~ ~-3 ~-3 ~1 ~-3 minecraft:spruce_fence
fill ~3 ~ ~-3 ~3 ~1 ~-3 minecraft:spruce_fence
fill ~-4 ~ ~1 ~-4 ~1 ~1 minecraft:spruce_fence
fill ~4 ~ ~1 ~4 ~1 ~1 minecraft:spruce_fence
setblock ~ ~2 ~-4 minecraft:crying_obsidian
fill ~-1 ~3 ~-4 ~1 ~3 ~-4 minecraft:amethyst_block
setblock ~-3 ~2 ~-3 minecraft:lantern[hanging=false]
setblock ~3 ~2 ~-3 minecraft:lantern[hanging=false]
setblock ~-4 ~2 ~1 minecraft:lantern[hanging=false]
setblock ~4 ~2 ~1 minecraft:lantern[hanging=false]
setblock ~ ~ ~-4 minecraft:end_gateway{ExactTeleport:1b,exit_portal:[I;0,225,6]}
setblock ~ ~1 ~-4 minecraft:end_gateway{ExactTeleport:1b,exit_portal:[I;0,225,6]}
kill @e[type=minecraft:text_display,tag=hs.bodenschild,distance=..12]
summon minecraft:text_display ~0.5 ~4.7 ~-3.5 {Tags:["hs.bodenschild"],billboard:"vertical",shadow:1b,text:["",{"text":"Himmelstor ↑","color":"light_purple","bold":true},{"text":"\nHinein und zurück zur Spawn-Insel","color":"white"}]}
