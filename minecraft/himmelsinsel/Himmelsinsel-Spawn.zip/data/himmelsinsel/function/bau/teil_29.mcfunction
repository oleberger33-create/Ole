fill 23 224 -21 23 224 -7 minecraft:grass_block
fill -43 224 -20 -43 225 -20 minecraft:andesite
fill -42 224 -20 -41 224 -20 minecraft:stone
fill -37 224 -20 -37 227 -20 minecraft:stone
fill -24 224 -20 -24 224 -2 minecraft:grass_block
fill -10 224 -20 -10 224 -2 minecraft:grass_block
fill -9 224 -20 -9 224 -16 minecraft:polished_deepslate
fill -7 224 -20 -7 224 -16 minecraft:dark_oak_planks
setblock -2 224 -20 minecraft:polished_deepslate
fill -1 224 -20 1 224 -16 minecraft:dark_oak_planks
setblock 2 224 -20 minecraft:polished_deepslate
fill 7 224 -20 7 224 -16 minecraft:dark_oak_planks
fill 9 224 -20 9 224 -16 minecraft:polished_deepslate
fill 10 224 -20 10 224 -2 minecraft:grass_block
fill 24 224 -20 25 224 -7 minecraft:grass_block
fill -25 224 -19 -25 224 -2 minecraft:grass_block
fill -4 224 -19 -4 224 -12 minecraft:dark_oak_planks
fill -3 224 -19 -3 224 -17 minecraft:polished_deepslate
fill -2 224 -19 -2 224 -17 minecraft:dark_oak_planks
fill 2 224 -19 2 224 -17 minecraft:dark_oak_planks
fill 3 224 -19 3 224 -17 minecraft:polished_deepslate
fill 4 224 -19 4 224 -12 minecraft:dark_oak_planks
fill 26 224 -19 26 224 14 minecraft:grass_block
fill -26 224 -18 -26 224 -4 minecraft:grass_block
fill 27 224 -18 27 224 12 minecraft:grass_block
fill -27 224 -17 -27 224 -4 minecraft:grass_block
fill 28 224 -17 28 224 10 minecraft:grass_block
fill -3 224 -16 -3 224 -12 minecraft:dark_oak_planks
setblock -2 224 -16 minecraft:polished_deepslate
setblock 2 224 -16 minecraft:polished_deepslate
fill 3 224 -16 3 224 -12 minecraft:dark_oak_planks
fill -28 224 -15 -28 224 -4 minecraft:grass_block
fill -9 224 -15 -9 224 -2 minecraft:grass_block
fill -7 224 -15 -7 224 -12 minecraft:polished_deepslate
fill -2 224 -15 -2 224 -11 minecraft:dark_oak_planks
fill -1 224 -15 1 224 -15 minecraft:polished_deepslate
fill 2 224 -15 2 224 -11 minecraft:dark_oak_planks
fill 7 224 -15 7 224 -12 minecraft:polished_deepslate
fill 9 224 -15 9 224 -2 minecraft:grass_block
fill 29 224 -15 29 224 8 minecraft:grass_block
fill -29 224 -14 -29 224 -4 minecraft:grass_block
fill -1 224 -14 1 224 -11 minecraft:dark_oak_planks
fill -8 224 -13 -8 224 -2 minecraft:grass_block
fill -6 224 -13 -6 224 -11 minecraft:polished_deepslate
fill 6 224 -13 6 224 -11 minecraft:polished_deepslate
fill 8 224 -13 8 224 -2 minecraft:grass_block
fill 30 224 -13 30 224 4 minecraft:grass_block
fill -30 224 -12 -30 224 -4 minecraft:grass_block
fill -5 224 -12 -5 225 -11 minecraft:polished_deepslate
fill 5 224 -12 5 225 -11 minecraft:polished_deepslate
fill -7 224 -11 -7 224 -3 minecraft:grass_block
fill -4 224 -11 -3 224 -10 minecraft:polished_deepslate
fill 3 224 -11 4 224 -10 minecraft:polished_deepslate
fill 7 224 -11 7 224 -3 minecraft:grass_block
fill -31 224 -10 -31 224 -4 minecraft:grass_block
fill -6 224 -10 -5 224 -6 minecraft:grass_block
fill -2 224 -10 2 224 -9 minecraft:polished_deepslate
fill 5 224 -10 6 224 -6 minecraft:grass_block
fill 31 224 -10 31 224 -1 minecraft:grass_block
fill -4 224 -9 -3 224 -7 minecraft:grass_block
fill 3 224 -9 4 224 -7 minecraft:grass_block
setblock -2 224 -8 minecraft:grass_block
fill -1 224 -8 1 224 -8 minecraft:dirt_path
setblock 2 224 -8 minecraft:grass_block
fill -2 224 -7 -1 224 -7 minecraft:mossy_stone_bricks
setblock 0 224 -7 minecraft:chiseled_stone_bricks
fill 1 224 -7 2 224 -7 minecraft:stone_bricks
setblock -4 224 -6 minecraft:stone_bricks
setblock -3 224 -6 minecraft:mossy_stone_bricks
fill -2 224 -6 2 224 -6 minecraft:polished_andesite
fill 3 224 -6 4 224 -6 minecraft:stone_bricks
fill 13 224 -6 25 224 -6 minecraft:stone_bricks
setblock -6 224 -5 minecraft:grass_block
setblock -5 224 -5 minecraft:stone_bricks
fill -4 224 -5 -3 224 -5 minecraft:polished_andesite
fill -2 224 -5 2 224 -5 minecraft:stone_bricks
fill 3 224 -5 4 224 -5 minecraft:polished_andesite
setblock 5 224 -5 minecraft:stone_bricks
setblock 6 224 -5 minecraft:grass_block
fill 13 224 -5 13 224 6 minecraft:stone_bricks
fill 14 224 -5 24 224 5 minecraft:spruce_planks
fill 25 224 -5 25 224 6 minecraft:stone_bricks
setblock -6 224 -4 minecraft:stone_bricks
fill -5 224 -4 -4 224 -4 minecraft:polished_andesite
setblock -3 224 -4 minecraft:stone_bricks
fill -2 224 -4 2 224 -4 minecraft:polished_deepslate
setblock 3 224 -4 minecraft:stone_bricks
fill 4 224 -4 5 224 -4 minecraft:polished_andesite
setblock 6 224 -4 minecraft:mossy_stone_bricks
fill -34 224 -3 -26 224 3 minecraft:spruce_planks
setblock -6 224 -3 minecraft:mossy_stone_bricks
setblock -5 224 -3 minecraft:polished_andesite
setblock -4 224 -3 minecraft:stone_bricks
fill -3 224 -3 -2 224 -3 minecraft:polished_deepslate
fill 2 224 -3 3 224 -3 minecraft:polished_deepslate
setblock 4 224 -3 minecraft:stone_bricks
setblock 5 224 -3 minecraft:polished_andesite
setblock 6 224 -3 minecraft:stone_bricks
setblock -7 224 -2 minecraft:stone_bricks
fill -6 224 -2 -6 224 2 minecraft:polished_andesite
fill -5 224 -2 -5 224 2 minecraft:stone_bricks
fill -4 224 -2 -3 224 -2 minecraft:polished_deepslate
fill 3 224 -2 4 224 -2 minecraft:polished_deepslate
fill 5 224 -2 5 224 2 minecraft:stone_bricks
fill 6 224 -2 6 224 2 minecraft:polished_andesite
fill 7 224 -2 7 224 -1 minecraft:stone_bricks
fill -25 224 -1 -8 224 1 minecraft:dirt_path
setblock -7 224 -1 minecraft:mossy_stone_bricks
fill -4 224 -1 -4 224 2 minecraft:polished_deepslate
fill -1 224 -1 1 224 1 minecraft:emerald_block
fill 4 224 -1 4 224 2 minecraft:polished_deepslate
fill 8 224 -1 12 224 1 minecraft:dirt_path
setblock -7 224 0 minecraft:chiseled_stone_bricks
setblock 7 224 0 minecraft:chiseled_stone_bricks
setblock -7 224 1 minecraft:mossy_stone_bricks
fill 7 224 1 7 224 2 minecraft:mossy_stone_bricks
fill -25 224 2 -8 224 7 minecraft:grass_block
setblock -7 224 2 minecraft:stone_bricks
fill -3 224 2 -3 224 3 minecraft:polished_deepslate
fill 3 224 2 3 224 3 minecraft:polished_deepslate
fill 8 224 2 12 224 28 minecraft:grass_block
fill -7 224 3 -7 224 6 minecraft:grass_block
fill -6 224 3 -6 224 4 minecraft:stone_bricks
fill -5 224 3 -5 224 4 minecraft:polished_andesite
setblock -4 224 3 minecraft:stone_bricks
fill -2 224 3 -2 224 4 minecraft:polished_deepslate
fill 2 224 3 2 224 4 minecraft:polished_deepslate
setblock 4 224 3 minecraft:stone_bricks
fill 5 224 3 5 224 4 minecraft:polished_andesite
fill 6 224 3 6 224 4 minecraft:stone_bricks
fill 7 224 3 7 224 30 minecraft:grass_block
fill -29 224 4 -26 224 5 minecraft:grass_block
fill -4 224 4 -4 224 5 minecraft:polished_andesite
setblock -3 224 4 minecraft:stone_bricks
fill -1 224 4 1 224 4 minecraft:polished_deepslate
setblock 3 224 4 minecraft:stone_bricks
fill 4 224 4 4 224 5 minecraft:polished_andesite
setblock -6 224 5 minecraft:grass_block
setblock -5 224 5 minecraft:stone_bricks
setblock -3 224 5 minecraft:polished_andesite
fill -2 224 5 2 224 5 minecraft:stone_bricks
setblock 3 224 5 minecraft:polished_andesite
setblock 5 224 5 minecraft:stone_bricks
fill 6 224 5 6 224 30 minecraft:grass_block
fill -28 224 6 -26 224 8 minecraft:grass_block
setblock -6 224 6 minecraft:dirt_path
fill -5 224 6 -5 224 31 minecraft:grass_block
fill -4 224 6 -3 224 6 minecraft:stone_bricks
fill -2 224 6 2 224 6 minecraft:polished_andesite
fill 3 224 6 4 224 6 minecraft:stone_bricks
fill 5 224 6 5 224 30 minecraft:grass_block
fill 14 224 6 24 224 6 minecraft:stone_bricks
fill -7 224 7 -7 224 8 minecraft:dirt_path
fill -6 224 7 -6 224 31 minecraft:grass_block
fill -4 224 7 -3 224 31 minecraft:grass_block
setblock -2 224 7 minecraft:mossy_stone_bricks
setblock -1 224 7 minecraft:stone_bricks
setblock 0 224 7 minecraft:chiseled_stone_bricks
fill 1 224 7 2 224 7 minecraft:stone_bricks
fill 3 224 7 4 224 30 minecraft:grass_block
fill 13 224 7 25 224 15 minecraft:grass_block
fill -25 224 8 -9 224 9 minecraft:grass_block
fill -8 224 8 -8 224 9 minecraft:dirt_path
fill -2 224 8 -2 224 26 minecraft:grass_block
fill -1 224 8 1 224 26 minecraft:dirt_path
fill 2 224 8 2 224 26 minecraft:grass_block
fill -27 224 9 -26 224 11 minecraft:grass_block
fill -7 224 9 -7 224 31 minecraft:grass_block
fill -25 224 10 -10 224 10 minecraft:grass_block
setblock -9 224 10 minecraft:dirt_path
fill -8 224 10 -8 224 31 minecraft:grass_block
fill -25 224 11 -11 224 11 minecraft:grass_block
setblock -10 224 11 minecraft:dirt_path
fill -9 224 11 -9 224 31 minecraft:grass_block
fill -26 224 12 -12 224 12 minecraft:grass_block
fill -11 224 12 -11 224 13 minecraft:dirt_path
fill -10 224 12 -10 224 30 minecraft:grass_block
fill -26 224 13 -13 224 14 minecraft:grass_block
fill -12 224 13 -12 224 15 minecraft:dirt_path
fill -11 224 14 -11 224 30 minecraft:grass_block
fill -25 224 15 -20 224 16 minecraft:grass_block
fill -19 224 15 -15 224 19 minecraft:spruce_planks
fill -14 224 15 -14 224 16 minecraft:grass_block
fill -13 224 15 -13 224 16 minecraft:dirt_path
fill -12 224 16 -12 224 30 minecraft:grass_block
fill 13 224 16 24 224 17 minecraft:grass_block
fill -24 224 17 -20 224 18 minecraft:grass_block
setblock -14 224 17 minecraft:dirt_path
fill -13 224 17 -13 224 29 minecraft:grass_block
fill -14 224 18 -14 224 28 minecraft:grass_block
fill 13 224 18 23 224 19 minecraft:grass_block
fill -23 224 19 -20 224 19 minecraft:grass_block
fill -22 224 20 -15 224 21 minecraft:grass_block
fill 13 224 20 22 224 20 minecraft:grass_block
fill 13 224 21 21 224 22 minecraft:grass_block
fill 41 224 21 41 225 21 minecraft:dirt
fill -21 224 22 -15 224 22 minecraft:grass_block
setblock 43 224 22 minecraft:rooted_dirt
fill -20 224 23 -15 224 23 minecraft:grass_block
fill 13 224 23 20 224 23 minecraft:grass_block
fill 40 224 23 40 225 23 minecraft:dirt
fill -19 224 24 -15 224 24 minecraft:grass_block
fill 13 224 24 19 224 24 minecraft:grass_block
fill 38 224 24 38 225 25 minecraft:dirt
fill 43 224 24 43 225 24 minecraft:dirt
fill -18 224 25 -15 224 25 minecraft:grass_block
fill 13 224 25 18 224 25 minecraft:grass_block
fill 36 224 25 36 225 25 minecraft:dirt
fill 41 224 25 42 225 25 minecraft:dirt
fill 44 224 25 44 225 25 minecraft:dirt
fill -17 224 26 -15 224 26 minecraft:grass_block
fill 13 224 26 17 224 26 minecraft:grass_block
fill 39 224 26 40 225 26 minecraft:dirt
fill -16 224 27 -15 224 27 minecraft:grass_block
fill -2 224 27 2 224 31 minecraft:spruce_planks
fill 13 224 27 15 224 27 minecraft:grass_block
fill 42 224 27 43 225 27 minecraft:dirt
setblock -15 224 28 minecraft:grass_block
fill 13 224 28 14 224 28 minecraft:grass_block
fill 39 224 28 40 225 28 minecraft:dirt
