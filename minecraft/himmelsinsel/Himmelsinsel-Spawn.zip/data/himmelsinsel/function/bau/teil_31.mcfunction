fill 8 226 -20 8 226 -16 minecraft:deepslate_bricks
setblock -44 226 -19 minecraft:andesite
fill -43 226 -19 -42 226 -19 minecraft:stone
fill -40 226 -19 -40 226 -18 minecraft:stone
fill -38 226 -19 -37 226 -19 minecraft:mossy_cobblestone
fill -42 226 -18 -41 226 -18 minecraft:stone
setblock -39 226 -18 minecraft:stone
setblock -38 226 -18 minecraft:dripstone_block
setblock 24 226 -15 minecraft:flowering_azalea_leaves[persistent=true]
fill -11 226 -14 -11 226 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill -7 226 -14 -7 226 -13 minecraft:deepslate_bricks
fill 7 226 -14 7 226 -13 minecraft:deepslate_bricks
setblock 25 226 -14 minecraft:flowering_azalea_leaves[persistent=true]
setblock -12 226 -13 minecraft:azalea_leaves[persistent=true]
setblock -10 226 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill -6 226 -13 -6 226 -12 minecraft:deepslate_bricks
setblock 6 226 -13 minecraft:cracked_deepslate_bricks
setblock -25 226 -12 minecraft:azalea_leaves[persistent=true]
setblock -23 226 -12 minecraft:flowering_azalea_leaves[persistent=true]
setblock -11 226 -12 minecraft:azalea_leaves[persistent=true]
fill -5 226 -12 -5 226 -11 minecraft:deepslate_bricks
fill 5 226 -12 6 226 -12 minecraft:deepslate_bricks
fill -4 226 -11 -4 227 -11 minecraft:deepslate_bricks
fill 4 226 -11 5 226 -11 minecraft:deepslate_bricks
setblock 26 226 -5 minecraft:azalea_leaves[persistent=true]
fill 25 226 -4 27 226 -4 minecraft:flowering_azalea_leaves[persistent=true]
setblock -34 226 -3 minecraft:spruce_fence
setblock 26 226 -3 minecraft:azalea_leaves[persistent=true]
setblock 0 226 0 minecraft:purple_stained_glass
setblock -34 226 3 minecraft:spruce_fence
setblock 22 226 11 minecraft:azalea_leaves[persistent=true]
setblock 21 226 12 minecraft:flowering_azalea_leaves[persistent=true]
setblock 22 226 13 minecraft:azalea_leaves[persistent=true]
fill -18 226 15 -18 228 15 minecraft:dark_oak_planks
setblock -17 226 15 minecraft:purple_stained_glass
fill -16 226 15 -16 228 15 minecraft:dark_oak_planks
fill -19 226 16 -19 228 16 minecraft:dark_oak_planks
fill -15 226 16 -15 228 16 minecraft:dark_oak_planks
setblock -19 226 17 minecraft:purple_stained_glass
fill -19 226 18 -19 228 18 minecraft:dark_oak_planks
fill -15 226 18 -15 228 18 minecraft:dark_oak_planks
fill -18 226 19 -18 228 19 minecraft:dark_oak_planks
setblock -17 226 19 minecraft:purple_stained_glass
fill -16 226 19 -16 228 19 minecraft:dark_oak_planks
fill 41 226 21 42 226 29 minecraft:grass_block
fill 37 226 22 40 226 27 minecraft:grass_block
fill 43 226 22 43 226 27 minecraft:grass_block
setblock -6 226 23 minecraft:azalea_leaves[persistent=true]
setblock 8 226 23 minecraft:azalea_leaves[persistent=true]
fill 36 226 23 36 226 26 minecraft:grass_block
fill -7 226 24 -5 226 24 minecraft:flowering_azalea_leaves[persistent=true]
setblock 7 226 24 minecraft:azalea_leaves[persistent=true]
setblock 8 226 24 minecraft:flowering_azalea_leaves[persistent=true]
setblock 9 226 24 minecraft:azalea_leaves[persistent=true]
fill 44 226 24 44 226 25 minecraft:grass_block
setblock -6 226 25 minecraft:flowering_azalea_leaves[persistent=true]
fill 38 226 28 40 226 28 minecraft:grass_block
setblock 40 226 29 minecraft:grass_block
fill -41 227 -27 -40 227 -27 minecraft:stone
fill -39 227 -27 -39 227 -26 minecraft:mossy_cobblestone
setblock -38 227 -27 minecraft:dripstone_block
fill -43 227 -26 -41 229 -25 minecraft:dirt
setblock -40 227 -26 minecraft:stone
fill -38 227 -26 -37 229 -26 minecraft:dirt
fill -2 227 -26 -2 228 -26 minecraft:deepslate_bricks
fill -1 227 -26 1 229 -26 minecraft:purple_stained_glass
fill 2 227 -26 2 230 -26 minecraft:deepslate_bricks
fill -40 227 -25 -39 229 -23 minecraft:dirt
setblock -38 227 -25 minecraft:rooted_dirt
fill -37 227 -25 -37 229 -23 minecraft:dirt
setblock -36 227 -25 minecraft:rooted_dirt
fill -5 227 -25 -5 229 -24 minecraft:purple_stained_glass
fill -4 227 -25 -4 230 -25 minecraft:deepslate_bricks
fill 4 227 -25 4 228 -25 minecraft:deepslate_bricks
fill 5 227 -25 5 229 -24 minecraft:purple_stained_glass
setblock -44 227 -24 minecraft:rooted_dirt
fill -43 227 -24 -42 229 -24 minecraft:dirt
fill -41 227 -24 -41 227 -23 minecraft:rooted_dirt
fill -38 227 -24 -38 229 -24 minecraft:dirt
fill -36 227 -24 -36 229 -23 minecraft:dirt
fill -6 227 -24 -6 229 -23 minecraft:purple_stained_glass
fill 6 227 -24 6 229 -23 minecraft:purple_stained_glass
fill -44 227 -23 -44 229 -23 minecraft:dirt
setblock -43 227 -23 minecraft:rooted_dirt
fill -42 227 -23 -42 229 -21 minecraft:dirt
setblock -38 227 -23 minecraft:rooted_dirt
fill -7 227 -23 -7 229 -23 minecraft:purple_stained_glass
fill 7 227 -23 7 229 -23 minecraft:purple_stained_glass
fill -45 227 -22 -44 227 -21 minecraft:rooted_dirt
fill -43 227 -22 -43 229 -19 minecraft:dirt
fill -41 227 -22 -40 229 -22 minecraft:dirt
setblock -39 227 -22 minecraft:rooted_dirt
fill -38 227 -22 -36 227 -22 minecraft:stone
fill -41 227 -21 -40 227 -21 minecraft:stone
setblock -35 227 -21 minecraft:dripstone_block
fill -45 227 -20 -44 229 -20 minecraft:dirt
setblock -42 227 -20 minecraft:rooted_dirt
fill -41 227 -20 -41 227 -19 minecraft:mossy_cobblestone
fill -40 227 -20 -39 227 -20 minecraft:stone
setblock -35 227 -20 minecraft:stone
fill -8 227 -20 -8 230 -20 minecraft:deepslate_bricks
fill 8 227 -20 8 229 -20 minecraft:deepslate_bricks
fill -44 227 -19 -44 229 -19 minecraft:dirt
fill -42 227 -19 -42 229 -18 minecraft:dirt
fill -40 227 -19 -38 227 -19 minecraft:mossy_cobblestone
fill -37 227 -19 -36 227 -19 minecraft:stone
fill -8 227 -19 -8 229 -17 minecraft:purple_stained_glass
fill 8 227 -19 8 229 -17 minecraft:purple_stained_glass
setblock -41 227 -18 minecraft:rooted_dirt
fill -40 227 -18 -40 229 -18 minecraft:dirt
fill -39 227 -18 -38 227 -18 minecraft:mossy_cobblestone
setblock -37 227 -18 minecraft:stone
fill -8 227 -16 -8 230 -16 minecraft:deepslate_bricks
fill 8 227 -16 8 230 -16 minecraft:deepslate_bricks
fill -7 227 -14 -7 230 -14 minecraft:deepslate_bricks
fill 7 227 -14 7 230 -14 minecraft:deepslate_bricks
fill -7 227 -13 -6 229 -13 minecraft:purple_stained_glass
fill 6 227 -13 7 229 -13 minecraft:purple_stained_glass
fill -6 227 -12 -5 229 -12 minecraft:purple_stained_glass
fill 5 227 -12 6 229 -12 minecraft:purple_stained_glass
fill -16 227 -11 -16 231 -11 minecraft:cherry_leaves[persistent=true]
fill -5 227 -11 -5 229 -11 minecraft:purple_stained_glass
fill 4 227 -11 4 230 -11 minecraft:deepslate_bricks
fill 5 227 -11 5 229 -11 minecraft:purple_stained_glass
fill -13 227 -10 -12 231 -10 minecraft:cherry_leaves[persistent=true]
fill -13 227 -8 -13 231 -8 minecraft:cherry_leaves[persistent=true]
fill -24 227 10 -24 231 10 minecraft:cherry_leaves[persistent=true]
fill -21 227 11 -21 231 11 minecraft:cherry_leaves[persistent=true]
fill -22 227 14 -22 231 14 minecraft:cherry_leaves[persistent=true]
fill -17 227 15 -17 228 15 minecraft:dark_oak_planks
fill 11 227 16 11 228 16 minecraft:cherry_leaves[persistent=true]
fill -19 227 17 -19 228 17 minecraft:dark_oak_planks
fill -15 227 17 -15 228 17 minecraft:dark_oak_planks
fill 10 227 17 10 231 18 minecraft:cherry_leaves[persistent=true]
fill -17 227 19 -17 228 19 minecraft:dark_oak_planks
fill 39 227 24 39 227 25 minecraft:azalea_leaves[persistent=true]
fill 40 227 24 41 227 24 minecraft:flowering_azalea_leaves[persistent=true]
setblock 40 227 25 minecraft:azalea_leaves[persistent=true]
fill 41 227 25 41 228 25 minecraft:flowering_azalea_leaves[persistent=true]
fill 39 227 26 40 227 26 minecraft:flowering_azalea_leaves[persistent=true]
setblock 41 227 26 minecraft:azalea_leaves[persistent=true]
fill -42 228 -27 -41 229 -27 minecraft:dirt
setblock -40 228 -27 minecraft:rooted_dirt
fill -39 228 -27 -39 229 -27 minecraft:dirt
setblock -38 228 -27 minecraft:rooted_dirt
fill -40 228 -26 -40 229 -26 minecraft:dirt
setblock -39 228 -26 minecraft:rooted_dirt
fill -38 228 -25 -38 229 -25 minecraft:dirt
fill -36 228 -25 -36 229 -25 minecraft:dirt
fill -44 228 -24 -44 229 -24 minecraft:dirt
fill -41 228 -24 -41 229 -23 minecraft:dirt
fill -43 228 -23 -43 229 -23 minecraft:dirt
fill -38 228 -23 -38 229 -18 minecraft:dirt
fill -45 228 -22 -44 229 -21 minecraft:dirt
fill -39 228 -22 -39 229 -18 minecraft:dirt
fill -37 228 -22 -37 229 -21 minecraft:dirt
fill -36 228 -22 -36 228 -21 minecraft:rooted_dirt
fill -7 228 -22 -7 229 -22 minecraft:deepslate_bricks
fill -41 228 -21 -40 229 -21 minecraft:dirt
fill -35 228 -21 -35 229 -20 minecraft:dirt
fill -42 228 -20 -42 229 -20 minecraft:dirt
fill -41 228 -20 -41 228 -19 minecraft:rooted_dirt
fill -40 228 -20 -40 229 -19 minecraft:dirt
fill -37 228 -20 -37 228 -19 minecraft:rooted_dirt
fill -36 228 -20 -36 229 -20 minecraft:dirt
setblock -36 228 -19 minecraft:rooted_dirt
fill -41 228 -18 -41 229 -18 minecraft:dirt
fill -37 228 -18 -37 229 -18 minecraft:dirt
fill 19 228 -16 19 232 -16 minecraft:cherry_leaves[persistent=true]
fill 15 228 -13 15 232 -12 minecraft:cherry_leaves[persistent=true]
fill 17 228 -13 18 232 -13 minecraft:cherry_leaves[persistent=true]
fill -14 228 -11 -14 231 -10 minecraft:cherry_leaves[persistent=true]
setblock -4 228 -11 minecraft:cracked_deepslate_bricks
fill -15 228 -10 -15 231 -10 minecraft:cherry_leaves[persistent=true]
fill -16 228 -9 -16 232 -9 minecraft:cherry_leaves[persistent=true]
setblock -14 228 -9 minecraft:cherry_log[axis=x]
setblock -13 228 -9 minecraft:cherry_leaves[persistent=true]
fill -17 228 -8 -17 230 -8 minecraft:cherry_leaves[persistent=true]
fill -15 228 -8 -15 231 -7 minecraft:cherry_leaves[persistent=true]
fill -12 228 -7 -12 231 -7 minecraft:cherry_leaves[persistent=true]
fill -24 228 8 -24 230 8 minecraft:cherry_leaves[persistent=true]
fill -22 228 9 -22 231 9 minecraft:cherry_leaves[persistent=true]
fill -23 228 11 -23 232 11 minecraft:cherry_leaves[persistent=true]
setblock -22 228 11 minecraft:cherry_log[axis=z]
fill -22 228 12 -21 228 12 minecraft:cherry_leaves[persistent=true]
fill -20 228 13 -20 231 13 minecraft:cherry_leaves[persistent=true]
fill -20 228 14 -20 228 20 minecraft:dark_oak_stairs[facing=east,half=bottom]
fill -19 228 14 -15 228 14 minecraft:dark_oak_stairs[facing=south,half=bottom]
fill -14 228 14 -14 228 20 minecraft:dark_oak_stairs[facing=west,half=bottom]
setblock -19 228 15 minecraft:dark_oak_planks
setblock -15 228 15 minecraft:dark_oak_planks
fill 12 228 15 12 232 15 minecraft:cherry_leaves[persistent=true]
fill -18 228 16 -16 229 18 minecraft:dark_oak_planks
setblock 12 228 16 minecraft:cherry_log[axis=x]
fill 11 228 17 12 231 17 minecraft:cherry_leaves[persistent=true]
setblock -19 228 19 minecraft:dark_oak_planks
setblock -15 228 19 minecraft:dark_oak_planks
fill 13 228 19 13 230 19 minecraft:cherry_leaves[persistent=true]
fill -19 228 20 -15 228 20 minecraft:dark_oak_stairs[facing=north,half=bottom]
fill 40 228 24 40 228 26 minecraft:flowering_azalea_leaves[persistent=true]
setblock 39 228 25 minecraft:flowering_azalea_leaves[persistent=true]
fill -2 228 31 2 228 31 minecraft:stripped_spruce_log[axis=x]
setblock -40 229 -27 minecraft:dirt
setblock -38 229 -27 minecraft:dirt
setblock -39 229 -26 minecraft:dirt
setblock -2 229 -26 minecraft:cracked_deepslate_bricks
setblock 4 229 -25 minecraft:cracked_deepslate_bricks
fill -36 229 -22 -36 229 -21 minecraft:dirt
fill -41 229 -20 -41 229 -19 minecraft:dirt
fill -37 229 -20 -37 229 -19 minecraft:dirt
setblock -36 229 -19 minecraft:dirt
fill 16 229 -17 16 232 -16 minecraft:cherry_leaves[persistent=true]
fill 14 229 -16 14 232 -16 minecraft:cherry_leaves[persistent=true]
fill 17 229 -16 17 229 -14 minecraft:cherry_leaves[persistent=true]
setblock 16 229 -15 minecraft:cherry_log[axis=x]
fill 15 229 -14 16 232 -14 minecraft:cherry_leaves[persistent=true]
fill 18 229 -14 18 232 -14 minecraft:cherry_leaves[persistent=true]
fill 14 229 -13 14 232 -13 minecraft:cherry_leaves[persistent=true]
fill -15 229 -12 -13 230 -12 minecraft:cherry_leaves[persistent=true]
fill -15 229 -11 -15 231 -11 minecraft:cherry_leaves[persistent=true]
