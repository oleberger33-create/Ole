fill -20 224 -24 -19 224 -2 minecraft:grass_block
fill -10 224 -24 -8 224 -23 minecraft:grass_block
fill -7 224 -24 -7 224 -21 minecraft:polished_deepslate
fill -4 224 -24 -3 224 -20 minecraft:dark_oak_planks
fill 3 224 -24 4 224 -20 minecraft:dark_oak_planks
fill 7 224 -24 7 224 -21 minecraft:polished_deepslate
fill 8 224 -24 8 224 -23 minecraft:grass_block
fill 17 224 -24 18 224 -12 minecraft:grass_block
fill 35 224 -24 35 224 -23 minecraft:grass_block
fill 36 224 -24 38 224 -23 minecraft:dirt_path
fill 39 224 -24 39 224 -23 minecraft:grass_block
fill -43 224 -23 -43 226 -23 minecraft:stone
fill -21 224 -23 -21 224 -2 minecraft:grass_block
fill -6 224 -23 -6 225 -23 minecraft:polished_deepslate
fill -5 224 -23 -5 224 -13 minecraft:dark_oak_planks
fill 5 224 -23 5 224 -13 minecraft:dark_oak_planks
fill 6 224 -23 6 225 -23 minecraft:polished_deepslate
fill 19 224 -23 20 224 -12 minecraft:grass_block
fill 31 224 -23 32 224 -23 minecraft:grass_block
fill -39 224 -22 -37 226 -22 minecraft:stone
fill -22 224 -22 -22 224 -2 minecraft:grass_block
fill -10 224 -22 -9 224 -21 minecraft:grass_block
fill -8 224 -22 -8 224 -14 minecraft:polished_deepslate
fill -6 224 -22 -6 224 -14 minecraft:dark_oak_planks
fill 6 224 -22 6 224 -14 minecraft:dark_oak_planks
fill 8 224 -22 8 224 -14 minecraft:polished_deepslate
fill 21 224 -22 22 224 -12 minecraft:grass_block
setblock 32 224 -22 minecraft:grass_block
fill 35 224 -22 39 224 -13 minecraft:spruce_planks
fill 42 224 -22 43 224 -22 minecraft:grass_block
fill -44 224 -21 -43 226 -21 minecraft:stone
fill -23 224 -21 -23 224 -2 minecraft:grass_block
setblock -2 224 -21 minecraft:dark_oak_planks
fill -1 224 -21 1 224 -21 minecraft:polished_deepslate
setblock 2 224 -21 minecraft:dark_oak_planks
fill 23 224 -21 23 224 -12 minecraft:grass_block
setblock 42 224 -21 minecraft:grass_block
fill -43 224 -20 -43 225 -20 minecraft:andesite
fill -42 224 -20 -41 224 -20 minecraft:stone
fill -37 224 -20 -37 227 -20 minecraft:stone
fill -24 224 -20 -24 224 -2 minecraft:grass_block
fill -10 224 -20 -10 224 -2 minecraft:grass_block
fill -9 224 -20 -9 224 -16 minecraft:polished_deepslate
fill -7 224 -20 -7 224 -16 minecraft:dark_oak_planks
setblock -2 224 -20 minecraft:polished_deepslate
fill -1 224 -20 1 224 -16 minecraft:dark_oak_planks
setblock 2 224 -20 minecraft:polished_deepslate
fill 7 224 -20 7 224 -16 minecraft:dark_oak_planks
fill 9 224 -20 9 224 -16 minecraft:polished_deepslate
fill 10 224 -20 10 224 -11 minecraft:grass_block
fill 24 224 -20 25 224 -12 minecraft:grass_block
fill -25 224 -19 -25 224 -2 minecraft:grass_block
fill -4 224 -19 -4 224 -12 minecraft:dark_oak_planks
fill -3 224 -19 -3 224 -17 minecraft:polished_deepslate
fill -2 224 -19 -2 224 -17 minecraft:dark_oak_planks
fill 2 224 -19 2 224 -17 minecraft:dark_oak_planks
fill 3 224 -19 3 224 -17 minecraft:polished_deepslate
fill 4 224 -19 4 224 -12 minecraft:dark_oak_planks
fill 26 224 -19 26 224 -12 minecraft:grass_block
fill -26 224 -18 -26 224 -4 minecraft:grass_block
fill 27 224 -18 27 224 -12 minecraft:grass_block
fill -27 224 -17 -27 224 -4 minecraft:grass_block
fill 28 224 -17 28 224 -13 minecraft:grass_block
fill -3 224 -16 -3 224 -12 minecraft:dark_oak_planks
setblock -2 224 -16 minecraft:polished_deepslate
setblock 2 224 -16 minecraft:polished_deepslate
fill 3 224 -16 3 224 -12 minecraft:dark_oak_planks
fill -28 224 -15 -28 224 -4 minecraft:grass_block
fill -9 224 -15 -9 224 -2 minecraft:grass_block
fill -7 224 -15 -7 224 -12 minecraft:polished_deepslate
fill -2 224 -15 -2 224 -11 minecraft:dark_oak_planks
fill -1 224 -15 1 224 -15 minecraft:polished_deepslate
fill 2 224 -15 2 224 -11 minecraft:dark_oak_planks
fill 7 224 -15 7 224 -12 minecraft:polished_deepslate
fill 9 224 -15 9 224 -10 minecraft:grass_block
fill 29 224 -15 29 224 -13 minecraft:grass_block
fill -29 224 -14 -29 224 -4 minecraft:grass_block
fill -1 224 -14 1 224 -11 minecraft:dark_oak_planks
fill -8 224 -13 -8 224 -2 minecraft:grass_block
fill -6 224 -13 -6 224 -11 minecraft:polished_deepslate
fill 6 224 -13 6 224 -11 minecraft:polished_deepslate
fill 8 224 -13 8 224 -10 minecraft:grass_block
setblock 30 224 -13 minecraft:grass_block
fill -30 224 -12 -30 224 -4 minecraft:grass_block
fill -5 224 -12 -5 225 -11 minecraft:polished_deepslate
fill 5 224 -12 5 225 -11 minecraft:polished_deepslate
fill 28 224 -12 35 224 -12 minecraft:spruce_planks
setblock 39 224 -12 minecraft:spruce_planks
fill -7 224 -11 -7 224 -3 minecraft:grass_block
fill -4 224 -11 -3 224 -10 minecraft:polished_deepslate
fill 3 224 -11 4 224 -10 minecraft:polished_deepslate
fill 7 224 -11 7 224 -9 minecraft:grass_block
setblock 11 224 -11 minecraft:grass_block
fill 12 224 -11 27 224 -9 minecraft:dirt_path
fill 28 224 -11 34 224 -8 minecraft:spruce_planks
fill -31 224 -10 -31 224 -4 minecraft:grass_block
fill -6 224 -10 -5 224 -6 minecraft:grass_block
fill -2 224 -10 2 224 -9 minecraft:polished_deepslate
fill 5 224 -10 6 224 -8 minecraft:grass_block
fill 10 224 -10 11 224 -8 minecraft:dirt_path
fill -4 224 -9 -3 224 -7 minecraft:grass_block
fill 3 224 -9 4 224 -7 minecraft:grass_block
fill 8 224 -9 9 224 -7 minecraft:dirt_path
setblock -2 224 -8 minecraft:grass_block
fill -1 224 -8 1 224 -8 minecraft:dirt_path
setblock 2 224 -8 minecraft:grass_block
fill 7 224 -8 7 224 -6 minecraft:dirt_path
fill 12 224 -8 27 224 -7 minecraft:grass_block
setblock 35 224 -8 minecraft:spruce_planks
setblock 39 224 -8 minecraft:spruce_planks
fill -2 224 -7 -1 224 -7 minecraft:mossy_stone_bricks
setblock 0 224 -7 minecraft:chiseled_stone_bricks
fill 1 224 -7 2 224 -7 minecraft:stone_bricks
setblock 5 224 -7 minecraft:grass_block
fill 6 224 -7 6 224 -5 minecraft:dirt_path
setblock 10 224 -7 minecraft:dirt_path
fill 11 224 -7 11 224 -2 minecraft:grass_block
fill 28 224 -7 31 224 -1 minecraft:grass_block
setblock -4 224 -6 minecraft:stone_bricks
setblock -3 224 -6 minecraft:mossy_stone_bricks
fill -2 224 -6 2 224 -6 minecraft:polished_andesite
fill 3 224 -6 4 224 -6 minecraft:stone_bricks
setblock 5 224 -6 minecraft:dirt_path
setblock 8 224 -6 minecraft:dirt_path
fill 9 224 -6 10 224 -2 minecraft:grass_block
fill 12 224 -6 12 224 -2 minecraft:grass_block
fill 13 224 -6 25 224 -6 minecraft:stone_bricks
fill 26 224 -6 27 224 12 minecraft:grass_block
setblock -6 224 -5 minecraft:grass_block
setblock -5 224 -5 minecraft:stone_bricks
fill -4 224 -5 -3 224 -5 minecraft:polished_andesite
fill -2 224 -5 2 224 -5 minecraft:stone_bricks
fill 3 224 -5 4 224 -5 minecraft:polished_andesite
setblock 5 224 -5 minecraft:stone_bricks
fill 7 224 -5 8 224 -3 minecraft:grass_block
fill 13 224 -5 13 224 6 minecraft:stone_bricks
fill 14 224 -5 24 224 5 minecraft:spruce_planks
fill 25 224 -5 25 224 6 minecraft:stone_bricks
setblock -6 224 -4 minecraft:stone_bricks
fill -5 224 -4 -4 224 -4 minecraft:polished_andesite
setblock -3 224 -4 minecraft:stone_bricks
fill -2 224 -4 2 224 -4 minecraft:polished_deepslate
setblock 3 224 -4 minecraft:stone_bricks
fill 4 224 -4 5 224 -4 minecraft:polished_andesite
setblock 6 224 -4 minecraft:mossy_stone_bricks
fill -34 224 -3 -26 224 3 minecraft:spruce_planks
setblock -6 224 -3 minecraft:mossy_stone_bricks
setblock -5 224 -3 minecraft:polished_andesite
setblock -4 224 -3 minecraft:stone_bricks
fill -3 224 -3 -2 224 -3 minecraft:polished_deepslate
fill 2 224 -3 3 224 -3 minecraft:polished_deepslate
setblock 4 224 -3 minecraft:stone_bricks
setblock 5 224 -3 minecraft:polished_andesite
setblock 6 224 -3 minecraft:stone_bricks
setblock -7 224 -2 minecraft:stone_bricks
fill -6 224 -2 -6 224 2 minecraft:polished_andesite
fill -5 224 -2 -5 224 2 minecraft:stone_bricks
fill -4 224 -2 -3 224 -2 minecraft:polished_deepslate
fill 3 224 -2 4 224 -2 minecraft:polished_deepslate
fill 5 224 -2 5 224 2 minecraft:stone_bricks
fill 6 224 -2 6 224 2 minecraft:polished_andesite
fill 7 224 -2 7 224 -1 minecraft:stone_bricks
setblock 8 224 -2 minecraft:grass_block
fill -25 224 -1 -8 224 1 minecraft:dirt_path
setblock -7 224 -1 minecraft:mossy_stone_bricks
fill -4 224 -1 -4 224 2 minecraft:polished_deepslate
fill -1 224 -1 1 224 1 minecraft:emerald_block
fill 4 224 -1 4 224 2 minecraft:polished_deepslate
fill 8 224 -1 12 224 1 minecraft:dirt_path
setblock -7 224 0 minecraft:chiseled_stone_bricks
setblock 7 224 0 minecraft:chiseled_stone_bricks
fill 28 224 0 30 224 4 minecraft:grass_block
setblock -7 224 1 minecraft:mossy_stone_bricks
fill 7 224 1 7 224 2 minecraft:mossy_stone_bricks
fill -25 224 2 -8 224 7 minecraft:grass_block
setblock -7 224 2 minecraft:stone_bricks
fill -3 224 2 -3 224 3 minecraft:polished_deepslate
fill 3 224 2 3 224 3 minecraft:polished_deepslate
fill 8 224 2 12 224 28 minecraft:grass_block
fill -7 224 3 -7 224 6 minecraft:grass_block
fill -6 224 3 -6 224 4 minecraft:stone_bricks
fill -5 224 3 -5 224 4 minecraft:polished_andesite
setblock -4 224 3 minecraft:stone_bricks
fill -2 224 3 -2 224 4 minecraft:polished_deepslate
fill 2 224 3 2 224 4 minecraft:polished_deepslate
setblock 4 224 3 minecraft:stone_bricks
fill 5 224 3 5 224 4 minecraft:polished_andesite
fill 6 224 3 6 224 4 minecraft:stone_bricks
fill 7 224 3 7 224 30 minecraft:grass_block
fill -29 224 4 -26 224 5 minecraft:grass_block
fill -4 224 4 -4 224 5 minecraft:polished_andesite
setblock -3 224 4 minecraft:stone_bricks
fill -1 224 4 1 224 4 minecraft:polished_deepslate
setblock 3 224 4 minecraft:stone_bricks
fill 4 224 4 4 224 5 minecraft:polished_andesite
setblock -6 224 5 minecraft:grass_block
setblock -5 224 5 minecraft:stone_bricks
setblock -3 224 5 minecraft:polished_andesite
fill -2 224 5 2 224 5 minecraft:stone_bricks
setblock 3 224 5 minecraft:polished_andesite
setblock 5 224 5 minecraft:stone_bricks
fill 6 224 5 6 224 30 minecraft:grass_block
fill 28 224 5 29 224 8 minecraft:grass_block
fill -28 224 6 -26 224 8 minecraft:grass_block
setblock -6 224 6 minecraft:dirt_path
fill -5 224 6 -5 224 31 minecraft:grass_block
fill -4 224 6 -3 224 6 minecraft:stone_bricks
fill -2 224 6 2 224 6 minecraft:polished_andesite
fill 3 224 6 4 224 6 minecraft:stone_bricks
fill 5 224 6 5 224 30 minecraft:grass_block
fill 14 224 6 24 224 6 minecraft:stone_bricks
fill -7 224 7 -7 224 8 minecraft:dirt_path
fill -6 224 7 -6 224 31 minecraft:grass_block
fill -4 224 7 -3 224 31 minecraft:grass_block
setblock -2 224 7 minecraft:mossy_stone_bricks
setblock -1 224 7 minecraft:stone_bricks
setblock 0 224 7 minecraft:chiseled_stone_bricks
fill 1 224 7 2 224 7 minecraft:stone_bricks
fill 3 224 7 4 224 30 minecraft:grass_block
fill 13 224 7 25 224 15 minecraft:grass_block
