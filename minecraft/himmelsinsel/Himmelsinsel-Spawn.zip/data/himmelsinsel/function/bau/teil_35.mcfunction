fill 2 225 -30 4 225 -30 minecraft:short_grass
setblock -9 225 -29 minecraft:short_grass
setblock -7 225 -29 minecraft:azure_bluet
setblock -6 225 -29 minecraft:tall_grass[half=lower]
setblock -1 225 -29 minecraft:pink_petals[facing=east,flower_amount=2]
fill 0 225 -29 0 225 -28 minecraft:short_grass
setblock 2 225 -29 minecraft:short_grass
setblock 7 225 -29 minecraft:allium
setblock -12 225 -28 minecraft:oxeye_daisy
fill -11 225 -28 -11 225 -27 minecraft:short_grass
setblock -9 225 -28 minecraft:wildflowers[facing=west,flower_amount=4]
setblock -8 225 -28 minecraft:short_grass
setblock -7 225 -28 minecraft:lily_of_the_valley
fill -6 225 -28 -6 225 -27 minecraft:short_grass
setblock -1 225 -28 minecraft:short_grass
setblock 1 225 -28 minecraft:short_grass
setblock 6 225 -28 minecraft:pink_petals[facing=south,flower_amount=1]
fill 9 225 -28 9 225 -26 minecraft:short_grass
setblock -15 225 -27 minecraft:short_grass
setblock -12 225 -27 minecraft:short_grass
fill -10 225 -27 -9 225 -27 minecraft:short_grass
setblock 7 225 -27 minecraft:short_grass
setblock 11 225 -27 minecraft:short_grass
setblock -42 225 -26 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock -41 225 -26 minecraft:glow_lichen[up=true]
fill -17 225 -26 -16 225 -26 minecraft:short_grass
setblock -12 225 -26 minecraft:allium
setblock -11 225 -26 minecraft:cornflower
setblock -5 225 -26 minecraft:short_grass
setblock 6 225 -26 minecraft:short_grass
setblock 10 225 -26 minecraft:wildflowers[facing=west,flower_amount=1]
setblock 11 225 -26 minecraft:tall_grass[half=lower]
setblock 13 225 -26 minecraft:short_grass
setblock -18 225 -25 minecraft:dandelion
setblock -16 225 -25 minecraft:short_grass
setblock -15 225 -25 minecraft:fern
setblock -14 225 -25 minecraft:short_grass
setblock -13 225 -25 minecraft:wildflowers[facing=north,flower_amount=2]
setblock -12 225 -25 minecraft:short_grass
fill -10 225 -25 -9 225 -25 minecraft:short_grass
setblock -8 225 -25 minecraft:dandelion
setblock -7 225 -25 minecraft:fern
setblock 8 225 -25 minecraft:tall_grass[half=lower]
setblock 13 225 -25 minecraft:pink_petals[facing=south,flower_amount=4]
fill 14 225 -25 16 225 -25 minecraft:short_grass
fill -19 225 -24 -19 225 -22 minecraft:short_grass
setblock -15 225 -24 minecraft:short_grass
fill -13 225 -24 -13 225 -23 minecraft:short_grass
setblock -10 225 -24 minecraft:tall_grass[half=lower]
setblock -9 225 -24 minecraft:pink_petals[facing=west,flower_amount=2]
setblock 9 225 -24 minecraft:allium
fill 10 225 -24 11 225 -24 minecraft:short_grass
setblock 13 225 -24 minecraft:short_grass
setblock 14 225 -24 minecraft:pink_petals[facing=north,flower_amount=3]
fill 15 225 -24 15 225 -21 minecraft:short_grass
setblock 18 225 -24 minecraft:short_grass
setblock -21 225 -23 minecraft:tall_grass[half=lower]
setblock -20 225 -23 minecraft:short_grass
setblock -8 225 -23 minecraft:short_grass
setblock 0 225 -23 minecraft:yellow_carpet
setblock 12 225 -23 minecraft:dandelion
fill 17 225 -23 17 225 -21 minecraft:short_grass
setblock 20 225 -23 minecraft:fern
setblock -45 225 -22 minecraft:cave_vines_plant[berries=false]
setblock -36 225 -22 minecraft:amethyst_cluster[facing=down]
setblock -21 225 -22 minecraft:short_grass
setblock -20 225 -22 minecraft:cornflower
fill -18 225 -22 -17 225 -22 minecraft:short_grass
setblock -16 225 -22 minecraft:poppy
fill -15 225 -22 -15 225 -21 minecraft:short_grass
setblock -14 225 -22 minecraft:cornflower
setblock -11 225 -22 minecraft:oxeye_daisy
setblock -10 225 -22 minecraft:short_grass
setblock -9 225 -22 minecraft:fern
setblock -4 225 -22 minecraft:light_blue_carpet
setblock 4 225 -22 minecraft:red_carpet
setblock 10 225 -22 minecraft:pink_petals[facing=west,flower_amount=4]
setblock 11 225 -22 minecraft:short_grass
setblock 14 225 -22 minecraft:short_grass
setblock 19 225 -22 minecraft:pink_petals[facing=west,flower_amount=3]
setblock 20 225 -22 minecraft:short_grass
setblock -45 225 -21 minecraft:glow_lichen[up=true]
setblock -35 225 -21 minecraft:pointed_dripstone[thickness=middle,vertical_direction=down]
setblock -20 225 -21 minecraft:short_grass
setblock -19 225 -21 minecraft:lily_of_the_valley
setblock -18 225 -21 minecraft:poppy
setblock -17 225 -21 minecraft:short_grass
setblock -14 225 -21 minecraft:dandelion
fill -13 225 -21 -13 225 -20 minecraft:short_grass
setblock -12 225 -21 minecraft:dandelion
setblock -11 225 -21 minecraft:tall_grass[half=lower]
setblock -9 225 -21 minecraft:lily_of_the_valley
fill 10 225 -21 10 225 -20 minecraft:short_grass
setblock 13 225 -21 minecraft:short_grass
setblock 16 225 -21 minecraft:wildflowers[facing=west,flower_amount=4]
setblock 21 225 -21 minecraft:allium
setblock 23 225 -21 minecraft:azure_bluet
setblock -21 225 -20 minecraft:short_grass
fill -12 225 -20 -10 225 -20 minecraft:short_grass
setblock 14 225 -20 minecraft:cornflower
setblock 16 225 -20 minecraft:pink_petals[facing=east,flower_amount=2]
fill 22 225 -20 24 225 -20 minecraft:short_grass
fill -23 225 -19 -22 225 -19 minecraft:short_grass
setblock -20 225 -19 minecraft:short_grass
setblock -18 225 -19 minecraft:pink_petals[facing=south,flower_amount=4]
setblock -15 225 -19 minecraft:short_grass
setblock -13 225 -19 minecraft:tall_grass[half=lower]
setblock -12 225 -19 minecraft:oxeye_daisy
setblock -11 225 -19 minecraft:tall_grass[half=lower]
setblock -10 225 -19 minecraft:short_grass
fill 11 225 -19 12 225 -19 minecraft:short_grass
setblock 14 225 -19 minecraft:pink_petals[facing=north,flower_amount=1]
setblock 17 225 -19 minecraft:pink_petals[facing=south,flower_amount=4]
setblock 20 225 -19 minecraft:pink_petals[facing=east,flower_amount=2]
fill 21 225 -19 21 225 -18 minecraft:short_grass
setblock 22 225 -19 minecraft:pink_petals[facing=west,flower_amount=4]
fill 23 225 -19 24 225 -18 minecraft:short_grass
setblock -40 225 -18 minecraft:glow_lichen[up=true]
setblock -38 225 -18 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock -25 225 -18 minecraft:short_grass
setblock -23 225 -18 minecraft:short_grass
setblock -20 225 -18 minecraft:allium
setblock -19 225 -18 minecraft:wildflowers[facing=south,flower_amount=3]
fill -17 225 -18 -16 225 -18 minecraft:short_grass
setblock -15 225 -18 minecraft:dandelion
setblock -14 225 -18 minecraft:short_grass
setblock -13 225 -18 minecraft:lily_of_the_valley
setblock -12 225 -18 minecraft:short_grass
setblock -11 225 -18 minecraft:lily_of_the_valley
setblock -5 225 -18 minecraft:lime_carpet
setblock 5 225 -18 minecraft:orange_carpet
fill 10 225 -18 11 225 -18 minecraft:short_grass
fill 13 225 -18 17 225 -18 minecraft:short_grass
setblock 20 225 -18 minecraft:short_grass
setblock 22 225 -18 minecraft:short_grass
setblock 25 225 -18 minecraft:oxeye_daisy
setblock 26 225 -18 minecraft:short_grass
setblock 27 225 -18 minecraft:tall_grass[half=lower]
setblock -26 225 -17 minecraft:tall_grass[half=lower]
setblock -22 225 -17 minecraft:dandelion
setblock -21 225 -17 minecraft:pink_petals[facing=east,flower_amount=2]
setblock -20 225 -17 minecraft:short_grass
setblock -11 225 -17 minecraft:short_grass
setblock 12 225 -17 minecraft:short_grass
setblock 13 225 -17 minecraft:tall_grass[half=lower]
setblock 19 225 -17 minecraft:short_grass
setblock 20 225 -17 minecraft:azure_bluet
setblock 21 225 -17 minecraft:oxeye_daisy
setblock 22 225 -17 minecraft:azure_bluet
setblock 25 225 -17 minecraft:short_grass
setblock 26 225 -17 minecraft:tall_grass[half=lower]
setblock 28 225 -17 minecraft:short_grass
fill -18 225 -16 -17 225 -16 minecraft:short_grass
setblock -16 225 -16 minecraft:pink_petals[facing=south,flower_amount=1]
setblock -15 225 -16 minecraft:pink_petals[facing=south,flower_amount=3]
setblock -14 225 -16 minecraft:short_grass
setblock 11 225 -16 minecraft:wildflowers[facing=south,flower_amount=3]
setblock 19 225 -16 minecraft:wildflowers[facing=south,flower_amount=2]
setblock 21 225 -16 minecraft:short_grass
setblock 23 225 -16 minecraft:pink_petals[facing=north,flower_amount=3]
setblock 24 225 -16 minecraft:short_grass
fill 26 225 -16 27 225 -16 minecraft:short_grass
fill -27 225 -15 -22 225 -15 minecraft:short_grass
fill -21 225 -15 -20 225 -15 minecraft:tall_grass[half=lower]
setblock -18 225 -15 minecraft:allium
fill -16 225 -15 -15 225 -15 minecraft:short_grass
setblock -12 225 -15 minecraft:short_grass
setblock -10 225 -15 minecraft:lily_of_the_valley
setblock 9 225 -15 minecraft:short_grass
setblock 12 225 -15 minecraft:oxeye_daisy
setblock 18 225 -15 minecraft:pink_petals[facing=east,flower_amount=2]
fill 20 225 -15 20 225 -14 minecraft:short_grass
setblock 21 225 -15 minecraft:allium
fill 26 225 -15 26 225 -14 minecraft:short_grass
fill 28 225 -15 28 225 -8 minecraft:short_grass
setblock -28 225 -14 minecraft:tall_grass[half=lower]
setblock -25 225 -14 minecraft:tall_grass[half=lower]
setblock -23 225 -14 minecraft:short_grass
fill -20 225 -14 -19 225 -14 minecraft:short_grass
setblock -13 225 -14 minecraft:fern
setblock -9 225 -14 minecraft:short_grass
setblock -4 225 -14 minecraft:green_carpet
setblock 4 225 -14 minecraft:cyan_carpet
fill 17 225 -14 19 225 -14 minecraft:short_grass
setblock 21 225 -14 minecraft:short_grass
fill 27 225 -14 27 225 -12 minecraft:short_grass
setblock -27 225 -13 minecraft:tall_grass[half=lower]
fill -20 225 -13 -20 225 -10 minecraft:short_grass
setblock -14 225 -13 minecraft:pink_petals[facing=north,flower_amount=4]
setblock -13 225 -13 minecraft:short_grass
setblock -8 225 -13 minecraft:fern
fill 10 225 -13 11 225 -13 minecraft:short_grass
setblock 12 225 -13 minecraft:tall_grass[half=lower]
setblock 13 225 -13 minecraft:short_grass
setblock 17 225 -13 minecraft:pink_petals[facing=south,flower_amount=1]
fill 18 225 -13 18 225 -12 minecraft:short_grass
setblock 21 225 -13 minecraft:oxeye_daisy
fill -17 225 -12 -16 225 -12 minecraft:short_grass
fill -9 225 -12 -8 225 -12 minecraft:short_grass
setblock 9 225 -12 minecraft:short_grass
setblock 11 225 -12 minecraft:short_grass
setblock 12 225 -12 minecraft:fern
setblock 13 225 -12 minecraft:pink_petals[facing=north,flower_amount=2]
setblock 15 225 -12 minecraft:short_grass
setblock 19 225 -12 minecraft:short_grass
setblock 21 225 -12 minecraft:pink_petals[facing=south,flower_amount=1]
setblock 22 225 -12 minecraft:short_grass
fill 23 225 -12 23 225 -11 minecraft:fern
setblock 24 225 -12 minecraft:pink_petals[facing=south,flower_amount=4]
setblock 29 225 -12 minecraft:short_grass
setblock -27 225 -11 minecraft:pink_petals[facing=south,flower_amount=4]
setblock -22 225 -11 minecraft:short_grass
fill -19 225 -11 -18 225 -11 minecraft:short_grass
fill -16 225 -11 -15 225 -11 minecraft:short_grass
setblock -14 225 -11 minecraft:wildflowers[facing=north,flower_amount=2]
setblock -11 225 -11 minecraft:lily_of_the_valley
setblock -10 225 -11 minecraft:short_grass
setblock -9 225 -11 minecraft:wildflowers[facing=west,flower_amount=1]
setblock 11 225 -11 minecraft:tall_grass[half=lower]
fill 12 225 -11 13 225 -11 minecraft:short_grass
