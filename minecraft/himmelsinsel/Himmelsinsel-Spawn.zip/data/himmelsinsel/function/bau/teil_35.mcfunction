fill 5 230 -24 6 230 -24 minecraft:deepslate_bricks
fill 32 230 -24 32 230 -23 minecraft:cherry_leaves[persistent=true]
setblock -7 230 -23 minecraft:deepslate_bricks
fill 6 230 -23 7 230 -23 minecraft:deepslate_bricks
fill -45 230 -22 -45 230 -20 minecraft:grass_block
setblock -7 230 -22 minecraft:cracked_deepslate_bricks
setblock 31 230 -22 minecraft:cherry_leaves[persistent=true]
fill -35 230 -21 -35 230 -20 minecraft:grass_block
setblock 8 230 -20 minecraft:cracked_deepslate_bricks
fill -8 230 -19 -8 230 -17 minecraft:deepslate_bricks
fill 8 230 -19 8 230 -17 minecraft:deepslate_bricks
fill 14 230 -18 14 232 -17 minecraft:cherry_leaves[persistent=true]
fill 16 230 -18 17 232 -18 minecraft:cherry_leaves[persistent=true]
fill 13 230 -17 13 231 -14 minecraft:cherry_leaves[persistent=true]
fill 15 230 -17 15 232 -16 minecraft:cherry_leaves[persistent=true]
fill 17 230 -17 19 232 -17 minecraft:cherry_leaves[persistent=true]
fill 17 230 -16 18 232 -16 minecraft:cherry_leaves[persistent=true]
fill 14 230 -15 14 232 -14 minecraft:cherry_leaves[persistent=true]
fill 16 230 -15 16 233 -15 minecraft:cherry_leaves[persistent=true]
setblock 17 230 -15 minecraft:cherry_log[axis=y]
fill 18 230 -15 19 232 -15 minecraft:cherry_leaves[persistent=true]
fill 17 230 -14 17 232 -14 minecraft:cherry_leaves[persistent=true]
fill -7 230 -13 -6 230 -13 minecraft:deepslate_bricks
fill 6 230 -13 7 230 -13 minecraft:deepslate_bricks
fill 16 230 -13 16 232 -12 minecraft:cherry_leaves[persistent=true]
setblock -12 230 -12 minecraft:cherry_leaves[persistent=true]
fill -6 230 -12 -5 230 -12 minecraft:deepslate_bricks
fill 5 230 -12 6 230 -12 minecraft:deepslate_bricks
fill 14 230 -12 14 231 -12 minecraft:cherry_leaves[persistent=true]
fill 17 230 -12 17 232 -12 minecraft:cherry_leaves[persistent=true]
setblock -5 230 -11 minecraft:deepslate_bricks
setblock 5 230 -11 minecraft:deepslate_bricks
fill -2 230 -10 2 230 -10 minecraft:deepslate_bricks
fill -17 230 -9 -17 231 -9 minecraft:cherry_leaves[persistent=true]
fill -15 230 -9 -15 232 -9 minecraft:cherry_leaves[persistent=true]
fill -13 230 -9 -13 232 -9 minecraft:cherry_leaves[persistent=true]
setblock -11 230 -8 minecraft:cherry_leaves[persistent=true]
setblock -17 230 -7 minecraft:cherry_leaves[persistent=true]
setblock -16 230 -6 minecraft:cherry_leaves[persistent=true]
fill 13 230 -6 13 230 6 minecraft:spruce_stairs[facing=east,half=bottom]
fill 14 230 -6 24 230 -6 minecraft:spruce_stairs[facing=south,half=bottom]
fill 25 230 -6 25 230 6 minecraft:spruce_stairs[facing=west,half=bottom]
fill 14 230 -5 24 230 5 minecraft:spruce_planks
fill 14 230 6 24 230 6 minecraft:spruce_stairs[facing=north,half=bottom]
fill -23 230 8 -22 230 8 minecraft:cherry_leaves[persistent=true]
fill -24 230 9 -24 231 9 minecraft:cherry_leaves[persistent=true]
fill -20 230 9 -19 230 9 minecraft:cherry_leaves[persistent=true]
fill -25 230 10 -25 231 10 minecraft:cherry_leaves[persistent=true]
fill -22 230 10 -22 231 10 minecraft:cherry_leaves[persistent=true]
setblock -19 230 10 minecraft:cherry_leaves[persistent=true]
setblock -25 230 12 minecraft:cherry_leaves[persistent=true]
fill -22 230 12 -22 232 12 minecraft:cherry_leaves[persistent=true]
setblock -19 230 12 minecraft:cherry_leaves[persistent=true]
fill 11 230 13 13 230 13 minecraft:cherry_leaves[persistent=true]
setblock -23 230 14 minecraft:cherry_leaves[persistent=true]
setblock -20 230 14 minecraft:cherry_leaves[persistent=true]
fill 9 230 15 9 230 16 minecraft:cherry_leaves[persistent=true]
fill 15 230 15 15 231 15 minecraft:cherry_leaves[persistent=true]
fill -18 230 16 -18 230 18 minecraft:dark_oak_stairs[facing=east,half=bottom]
setblock -17 230 16 minecraft:dark_oak_stairs[facing=south,half=bottom]
fill -16 230 16 -16 230 18 minecraft:dark_oak_stairs[facing=west,half=bottom]
fill 11 230 16 11 232 16 minecraft:cherry_leaves[persistent=true]
fill 13 230 16 13 232 16 minecraft:cherry_leaves[persistent=true]
setblock -17 230 17 minecraft:dark_oak_planks
setblock -17 230 18 minecraft:dark_oak_stairs[facing=north,half=bottom]
fill 11 230 19 12 230 19 minecraft:cherry_leaves[persistent=true]
fill -2 231 -26 2 231 -26 minecraft:dark_oak_planks
fill -5 231 -25 -4 231 -25 minecraft:dark_oak_planks
fill 4 231 -25 5 231 -25 minecraft:dark_oak_planks
setblock 30 231 -25 minecraft:cherry_leaves[persistent=true]
fill -6 231 -24 -5 231 -24 minecraft:dark_oak_planks
fill 5 231 -24 6 231 -24 minecraft:dark_oak_planks
fill -7 231 -23 -6 231 -23 minecraft:dark_oak_planks
fill 6 231 -23 7 231 -23 minecraft:dark_oak_planks
setblock 30 231 -23 minecraft:cherry_leaves[persistent=true]
fill -40 231 -22 -40 234 -22 minecraft:cherry_log[axis=y]
setblock -7 231 -22 minecraft:dark_oak_planks
setblock 7 231 -22 minecraft:dark_oak_planks
fill -8 231 -20 -8 231 -16 minecraft:dark_oak_planks
fill 8 231 -20 8 231 -16 minecraft:dark_oak_planks
fill 15 231 -18 15 232 -18 minecraft:cherry_leaves[persistent=true]
setblock 18 231 -18 minecraft:cherry_leaves[persistent=true]
fill 15 231 -15 15 232 -15 minecraft:cherry_leaves[persistent=true]
fill 17 231 -15 17 232 -15 minecraft:cherry_leaves[persistent=true]
setblock 20 231 -15 minecraft:cherry_leaves[persistent=true]
fill -7 231 -14 -7 231 -13 minecraft:dark_oak_planks
fill 7 231 -14 7 231 -13 minecraft:dark_oak_planks
fill 19 231 -14 19 231 -13 minecraft:cherry_leaves[persistent=true]
fill -6 231 -13 -6 231 -12 minecraft:dark_oak_planks
fill 6 231 -13 6 231 -12 minecraft:dark_oak_planks
fill 13 231 -13 13 232 -13 minecraft:cherry_leaves[persistent=true]
fill -14 231 -12 -13 231 -12 minecraft:cherry_leaves[persistent=true]
fill -5 231 -12 -5 231 -11 minecraft:dark_oak_planks
fill 5 231 -12 5 231 -11 minecraft:dark_oak_planks
setblock 18 231 -12 minecraft:cherry_leaves[persistent=true]
setblock -4 231 -11 minecraft:dark_oak_planks
setblock 4 231 -11 minecraft:dark_oak_planks
fill -2 231 -10 2 231 -10 minecraft:dark_oak_planks
setblock -11 231 -9 minecraft:cherry_leaves[persistent=true]
setblock -13 231 -7 minecraft:cherry_leaves[persistent=true]
fill 14 231 -5 14 231 5 minecraft:spruce_stairs[facing=east,half=bottom]
fill 15 231 -5 23 231 -5 minecraft:spruce_stairs[facing=south,half=bottom]
fill 24 231 -5 24 231 5 minecraft:spruce_stairs[facing=west,half=bottom]
fill 15 231 -4 23 231 4 minecraft:spruce_planks
fill 15 231 5 23 231 5 minecraft:spruce_stairs[facing=north,half=bottom]
setblock -20 231 9 minecraft:cherry_leaves[persistent=true]
setblock -24 231 11 minecraft:cherry_leaves[persistent=true]
setblock 11 231 13 minecraft:cherry_leaves[persistent=true]
setblock -21 231 14 minecraft:cherry_leaves[persistent=true]
fill 14 231 16 14 231 18 minecraft:cherry_leaves[persistent=true]
setblock -17 231 17 minecraft:dark_oak_slab[type=bottom]
setblock 11 231 19 minecraft:cherry_leaves[persistent=true]
fill -4 232 -27 -2 232 -27 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -1 232 -27 1 232 -27 minecraft:deepslate_tiles
fill 2 232 -27 4 232 -27 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -5 232 -26 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -4 232 -26 -3 232 -26 minecraft:deepslate_tiles
fill 3 232 -26 4 232 -26 minecraft:deepslate_tiles
setblock 5 232 -26 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -7 232 -25 -7 232 -24 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -6 232 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -5 232 -25 minecraft:deepslate_tiles
setblock 5 232 -25 minecraft:deepslate_tiles
setblock 6 232 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill 7 232 -25 7 232 -24 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -6 232 -24 minecraft:deepslate_tiles
setblock 6 232 -24 minecraft:deepslate_tiles
setblock -8 232 -23 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -7 232 -23 minecraft:deepslate_tiles
setblock 7 232 -23 minecraft:deepslate_tiles
setblock 8 232 -23 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -9 232 -22 -9 232 -20 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill -8 232 -22 -8 232 -21 minecraft:deepslate_tiles
fill 8 232 -22 8 232 -21 minecraft:deepslate_tiles
fill 9 232 -22 9 232 -20 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -9 232 -19 -9 232 -17 minecraft:deepslate_tiles
fill 9 232 -19 9 232 -17 minecraft:deepslate_tiles
fill -9 232 -16 -9 232 -14 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill 9 232 -16 9 232 -14 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill 13 232 -16 13 232 -14 minecraft:cherry_leaves[persistent=true]
fill -8 232 -15 -8 232 -14 minecraft:deepslate_tiles
fill 8 232 -15 8 232 -14 minecraft:deepslate_tiles
setblock -8 232 -13 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -7 232 -13 minecraft:deepslate_tiles
setblock 7 232 -13 minecraft:deepslate_tiles
setblock 8 232 -13 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -7 232 -12 -7 232 -11 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -6 232 -12 minecraft:deepslate_tiles
setblock 6 232 -12 minecraft:deepslate_tiles
fill 7 232 -12 7 232 -11 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -6 232 -11 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
setblock -5 232 -11 minecraft:deepslate_tiles
setblock 5 232 -11 minecraft:deepslate_tiles
setblock 6 232 -11 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
setblock -5 232 -10 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -4 232 -10 -3 232 -10 minecraft:deepslate_tiles
fill 3 232 -10 4 232 -10 minecraft:deepslate_tiles
setblock 5 232 -10 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -14 232 -9 -14 232 -8 minecraft:cherry_leaves[persistent=true]
fill -4 232 -9 -2 232 -9 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
fill -1 232 -9 1 232 -9 minecraft:deepslate_tiles
fill 2 232 -9 4 232 -9 minecraft:deepslate_tile_stairs[facing=north,half=bottom]
setblock -15 232 -8 minecraft:cherry_leaves[persistent=true]
fill 15 232 -4 15 232 4 minecraft:spruce_stairs[facing=east,half=bottom]
fill 16 232 -4 22 232 -4 minecraft:spruce_stairs[facing=south,half=bottom]
fill 23 232 -4 23 232 4 minecraft:spruce_stairs[facing=west,half=bottom]
fill 16 232 -3 22 232 3 minecraft:spruce_planks
fill 16 232 4 22 232 4 minecraft:spruce_stairs[facing=north,half=bottom]
setblock -21 232 10 minecraft:cherry_leaves[persistent=true]
setblock -23 232 12 minecraft:cherry_leaves[persistent=true]
setblock 11 232 15 minecraft:cherry_leaves[persistent=true]
setblock 13 232 17 minecraft:cherry_leaves[persistent=true]
fill -1 233 -27 1 233 -27 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -4 233 -26 -3 233 -26 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
fill -2 233 -26 2 233 -26 minecraft:deepslate_tiles
fill 3 233 -26 4 233 -26 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -5 233 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -4 233 -25 minecraft:deepslate_tiles
setblock 4 233 -25 minecraft:deepslate_tiles
setblock 5 233 -25 minecraft:deepslate_tile_stairs[facing=south,half=bottom]
setblock -6 233 -24 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -5 233 -24 minecraft:deepslate_tiles
setblock 5 233 -24 minecraft:deepslate_tiles
setblock 6 233 -24 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -42 233 -23 -40 236 -23 minecraft:cherry_leaves[persistent=true]
setblock -7 233 -23 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -6 233 -23 minecraft:deepslate_tiles
setblock 6 233 -23 minecraft:deepslate_tiles
setblock 7 233 -23 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -43 233 -22 -42 233 -22 minecraft:cherry_leaves[persistent=true]
setblock -41 233 -22 minecraft:cherry_log[axis=x]
fill -8 233 -22 -8 233 -21 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -7 233 -22 minecraft:deepslate_tiles
setblock 7 233 -22 minecraft:deepslate_tiles
fill 8 233 -22 8 233 -21 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
fill -41 233 -21 -41 236 -21 minecraft:cherry_leaves[persistent=true]
fill -8 233 -20 -8 233 -16 minecraft:deepslate_tiles
setblock 0 233 -20 minecraft:dark_oak_fence[south=true]
fill 8 233 -20 8 233 -16 minecraft:deepslate_tiles
fill -9 233 -19 -9 233 -17 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock 0 233 -19 minecraft:dark_oak_fence[north=true,south=true]
fill 9 233 -19 9 233 -17 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -2 233 -18 minecraft:dark_oak_fence[east=true]
setblock -1 233 -18 minecraft:dark_oak_fence[east=true,west=true]
setblock 0 233 -18 minecraft:dark_oak_fence[north=true,east=true,south=true,west=true]
setblock 1 233 -18 minecraft:dark_oak_fence[east=true,west=true]
setblock 2 233 -18 minecraft:dark_oak_fence[west=true]
setblock 0 233 -17 minecraft:dark_oak_fence[north=true,south=true]
setblock 16 233 -17 minecraft:cherry_leaves[persistent=true]
setblock 0 233 -16 minecraft:dark_oak_fence[north=true]
setblock 15 233 -16 minecraft:cherry_leaves[persistent=true]
fill -8 233 -15 -8 233 -14 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
fill 8 233 -15 8 233 -14 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
setblock -7 233 -14 minecraft:deepslate_tiles
setblock 7 233 -14 minecraft:deepslate_tiles
setblock 16 233 -14 minecraft:cherry_leaves[persistent=true]
setblock -7 233 -13 minecraft:deepslate_tile_stairs[facing=east,half=bottom]
setblock -6 233 -13 minecraft:deepslate_tiles
setblock 6 233 -13 minecraft:deepslate_tiles
setblock 7 233 -13 minecraft:deepslate_tile_stairs[facing=west,half=bottom]
