function himmelsinsel:bau/wesen
# Der volle Bau enthält schon alle Erweiterungen
scoreboard players set #ausbau hs.state 1
function himmelsinsel:version/spawnpunkt
forceload remove -48 -48 47 47
scoreboard players set #fertig hs.state 1
scoreboard players set #stufe hs.state 0
# Neue Welt: wer schon unten am alten Spawn steht, kommt mit nach oben
execute if score #neue_welt hs.state matches 1 in minecraft:overworld as @a[x=-100,y=-64,z=-100,dx=200,dy=384,dz=200] run function himmelsinsel:spiel/zum_spawn_still
scoreboard players set #neue_welt hs.state 0
tellraw @a ["",{"text":"[Himmelsinsel] ","color":"light_purple"},{"text":"Fertig! Die Spawn-Insel schwebt jetzt über x 0 / z 0.","color":"white"},{"text":"\nAdmins: In server.properties spawn-protection=0 setzen, sonst können Spieler ohne OP Ambosse und Werkbänke am Spawn nicht benutzen. Die Insel schützt sich selbst.","color":"gray","italic":true}]
