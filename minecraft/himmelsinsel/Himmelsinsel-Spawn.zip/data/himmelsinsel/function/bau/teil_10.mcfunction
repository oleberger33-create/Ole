fill 9 215 -22 9 220 -22 minecraft:stone
fill -9 215 -21 -8 215 -20 minecraft:tuff
fill -7 215 -21 -6 220 -21 minecraft:stone
fill -1 215 -21 -1 215 -20 minecraft:stone
fill 0 215 -21 1 215 -21 minecraft:cobblestone
setblock 10 215 -21 minecraft:dripstone_block
fill -7 215 -20 -7 221 -20 minecraft:stone
setblock 0 215 -20 minecraft:amethyst_block
fill 1 215 -20 1 220 -20 minecraft:stone
fill 9 215 -20 10 220 -20 minecraft:stone
fill -10 215 -19 -10 215 -17 minecraft:stone
setblock -9 215 -19 minecraft:dripstone_block
fill -8 215 -19 -8 221 -19 minecraft:stone
fill 0 215 -19 0 221 -19 minecraft:stone
fill 15 215 -19 16 217 -16 minecraft:stone
fill -16 215 -18 -14 215 -18 minecraft:stone
fill -13 215 -18 -13 218 -18 minecraft:tuff
fill -11 215 -18 -11 221 -15 minecraft:stone
fill -9 215 -18 -9 221 -17 minecraft:stone
fill 11 215 -18 11 221 -17 minecraft:stone
setblock -17 215 -17 minecraft:dripstone_block
setblock -13 215 -17 minecraft:dripstone_block
fill -12 215 -17 -12 221 -16 minecraft:stone
fill -8 215 -17 -7 221 -17 minecraft:stone
fill -4 215 -17 -4 215 -16 minecraft:stone
fill -3 215 -17 -3 217 -16 minecraft:cobblestone
fill 12 215 -17 12 221 -16 minecraft:stone
fill 14 215 -17 14 218 -15 minecraft:stone
fill -18 215 -16 -18 220 -13 minecraft:stone
setblock -13 215 -16 minecraft:stone
fill 7 215 -16 8 220 -16 minecraft:stone
fill 13 215 -16 13 221 -16 minecraft:stone
fill 17 215 -16 17 221 -15 minecraft:stone
fill -13 215 -15 -12 215 -15 minecraft:cobblestone
fill -10 215 -15 -10 221 -15 minecraft:stone
setblock 7 215 -15 minecraft:cobblestone
fill -19 215 -14 -19 221 -11 minecraft:stone
fill -17 215 -14 -17 220 -13 minecraft:stone
setblock -13 215 -14 minecraft:stone
fill -5 215 -14 -4 219 -14 minecraft:stone
fill -3 215 -14 -3 216 -14 minecraft:cobblestone
fill 4 215 -14 4 216 -14 minecraft:stone
fill 5 215 -14 6 218 -14 minecraft:cobblestone
fill 18 215 -14 18 219 -13 minecraft:stone
setblock 19 215 -14 minecraft:dripstone_block
fill -16 215 -13 -16 220 -13 minecraft:stone
fill -13 215 -13 -12 215 -13 minecraft:andesite
fill -11 215 -13 -11 219 -12 minecraft:stone
fill -6 215 -13 -5 220 -13 minecraft:stone
fill 6 215 -13 6 215 -12 minecraft:stone
fill 8 215 -13 8 221 -12 minecraft:stone
fill 19 215 -13 19 221 -13 minecraft:stone
fill 20 215 -13 20 215 -12 minecraft:dripstone_block
fill -24 215 -12 -22 220 -12 minecraft:stone
fill -12 215 -12 -12 216 -12 minecraft:andesite
fill -6 215 -12 -5 215 -11 minecraft:cobblestone
fill -4 215 -12 -4 220 -11 minecraft:stone
fill 21 215 -12 21 215 -11 minecraft:dripstone_block
setblock -24 215 -11 minecraft:dripstone_block
fill -23 215 -11 -20 220 -11 minecraft:stone
fill -16 215 -11 -14 219 -11 minecraft:stone
fill -13 215 -11 -13 216 -11 minecraft:andesite
fill 15 215 -11 17 220 -11 minecraft:tuff
fill 18 215 -11 18 219 -11 minecraft:stone
fill -24 215 -10 -22 220 -10 minecraft:stone
fill -17 215 -10 -17 221 -10 minecraft:stone
fill 0 215 -10 0 221 -10 minecraft:stone
fill 21 215 -10 22 221 -10 minecraft:stone
setblock 23 215 -10 minecraft:dripstone_block
fill -23 215 -9 -23 220 -9 minecraft:stone
fill -21 215 -9 -20 215 -9 minecraft:andesite
fill -19 215 -9 -19 217 -9 minecraft:cobblestone
setblock -17 215 -9 minecraft:cobblestone
fill 1 215 -9 1 220 -7 minecraft:stone
fill 6 215 -9 6 217 -9 minecraft:tuff
fill 14 215 -9 14 216 -7 minecraft:andesite
fill 17 215 -9 17 217 -9 minecraft:stone
fill 23 215 -9 23 220 -9 minecraft:stone
setblock 24 215 -9 minecraft:amethyst_block
setblock -23 215 -8 minecraft:amethyst_block
fill -18 215 -8 -18 216 -8 minecraft:cobblestone
fill 0 215 -8 0 216 -8 minecraft:andesite
setblock 17 215 -8 minecraft:andesite
setblock 25 215 -8 minecraft:dripstone_block
fill -23 215 -7 -22 220 -7 minecraft:stone
setblock -19 215 -7 minecraft:andesite
fill -18 215 -7 -18 221 -7 minecraft:stone
fill -6 215 -7 -3 215 -7 minecraft:stone
fill -2 215 -7 -2 218 -7 minecraft:andesite
fill 21 215 -7 22 220 -7 minecraft:stone
fill 24 215 -7 25 220 -7 minecraft:stone
fill -23 215 -6 -23 221 -6 minecraft:stone
fill -22 215 -6 -22 216 -6 minecraft:cobblestone
fill -17 215 -6 -16 219 -6 minecraft:andesite
fill -15 215 -6 -15 216 -6 minecraft:stone
fill -1 215 -6 -1 219 -4 minecraft:andesite
setblock 5 215 -6 minecraft:stone
fill 6 215 -6 6 218 -6 minecraft:tuff
fill 19 215 -6 19 215 -5 minecraft:stone
fill 21 215 -6 21 221 -6 minecraft:stone
setblock 24 215 -6 minecraft:cobblestone
setblock 25 215 -6 minecraft:dripstone_block
fill -22 215 -5 -22 215 3 minecraft:stone
fill -19 215 -5 -19 219 -4 minecraft:andesite
fill -4 215 -5 -2 215 -5 minecraft:stone
setblock 20 215 -5 minecraft:stone
fill 21 215 -5 22 217 -3 minecraft:andesite
fill 25 215 -5 25 220 -5 minecraft:stone
fill -21 215 -4 -20 216 -4 minecraft:stone
fill 19 215 -4 20 221 -4 minecraft:andesite
fill 25 215 -4 25 215 -3 minecraft:andesite
fill -21 215 -3 -21 218 7 minecraft:stone
fill -19 215 -3 -19 215 -2 minecraft:stone
fill -18 215 -3 -17 219 -3 minecraft:andesite
fill -15 215 -3 -15 220 -3 minecraft:andesite
fill 1 215 -3 1 218 -3 minecraft:stone
setblock 9 215 -3 minecraft:cobblestone
fill 10 215 -3 11 220 -3 minecraft:stone
fill 19 215 -3 20 216 -3 minecraft:stone
fill 23 215 -3 23 218 -2 minecraft:andesite
setblock 24 215 -3 minecraft:dripstone_block
fill -23 215 -2 -23 215 1 minecraft:tuff
fill -8 215 -2 -8 220 -1 minecraft:stone
fill 0 215 -2 0 218 -2 minecraft:stone
fill 10 215 -2 10 221 -2 minecraft:stone
fill 16 215 -2 16 220 -1 minecraft:stone
setblock 21 215 -2 minecraft:dripstone_block
fill 22 215 -2 22 219 -2 minecraft:andesite
fill -25 215 -1 -24 216 -1 minecraft:tuff
fill 15 215 -1 15 220 -1 minecraft:stone
fill 21 215 -1 22 215 0 minecraft:stone
fill -25 215 0 -25 217 1 minecraft:tuff
fill -20 215 0 -20 219 2 minecraft:stone
fill -24 215 1 -24 217 1 minecraft:tuff
fill 22 215 1 22 220 5 minecraft:stone
fill -24 215 2 -24 220 2 minecraft:stone
setblock -23 215 2 minecraft:dripstone_block
setblock -20 215 3 minecraft:dripstone_block
fill -18 215 3 -18 221 4 minecraft:stone
fill -20 215 4 -20 217 8 minecraft:stone
fill -18 215 5 -18 216 5 minecraft:cobblestone
fill 3 215 5 3 215 6 minecraft:cobblestone
fill 4 215 5 4 221 5 minecraft:stone
fill 12 215 5 12 216 5 minecraft:tuff
fill -19 215 6 -19 215 7 minecraft:stone
setblock 2 215 6 minecraft:stone
fill 12 215 6 12 216 9 minecraft:stone
setblock 22 215 6 minecraft:dripstone_block
fill -11 215 7 -11 217 9 minecraft:stone
fill 2 215 7 2 216 7 minecraft:tuff
fill 3 215 7 8 220 7 minecraft:stone
fill -19 215 8 -19 218 8 minecraft:cobblestone
fill -14 215 8 -14 220 10 minecraft:stone
fill -1 215 8 -1 219 8 minecraft:stone
fill 0 215 8 0 221 8 minecraft:tuff
setblock 4 215 8 minecraft:tuff
fill 5 215 8 5 221 8 minecraft:stone
fill 21 215 8 21 218 8 minecraft:stone
fill -20 215 9 -20 218 9 minecraft:cobblestone
fill -16 215 9 -16 219 9 minecraft:stone
fill 1 215 9 3 217 9 minecraft:tuff
fill 19 215 9 21 216 9 minecraft:cobblestone
fill -20 215 10 -19 215 10 minecraft:stone
fill 2 215 10 3 217 10 minecraft:tuff
fill 19 215 10 20 215 10 minecraft:stone
setblock -21 215 11 minecraft:dripstone_block
fill -20 215 11 -20 215 13 minecraft:andesite
fill -19 215 11 -15 220 11 minecraft:stone
fill -14 215 11 -14 216 12 minecraft:andesite
fill -10 215 11 -10 221 11 minecraft:stone
fill 0 215 11 0 216 11 minecraft:stone
setblock 2 215 11 minecraft:stone
fill 18 215 11 19 216 11 minecraft:stone
setblock -19 215 12 minecraft:andesite
fill -18 215 12 -16 221 12 minecraft:stone
fill -10 215 12 -10 217 12 minecraft:andesite
fill 19 215 12 19 218 16 minecraft:stone
fill -19 215 13 -19 220 13 minecraft:stone
setblock -18 215 13 minecraft:dripstone_block
fill -17 215 13 -16 221 13 minecraft:stone
fill -14 215 13 -14 215 16 minecraft:stone
fill -10 215 13 -10 219 16 minecraft:stone
fill 15 215 13 17 217 13 minecraft:andesite
fill -18 215 14 -17 219 14 minecraft:stone
fill -4 215 14 -4 216 15 minecraft:stone
fill -3 215 14 -3 219 15 minecraft:cobblestone
fill 18 215 15 18 220 17 minecraft:stone
setblock -17 215 16 minecraft:amethyst_block
fill 0 215 16 0 219 16 minecraft:cobblestone
setblock 1 215 16 minecraft:stone
fill 12 215 16 13 221 18 minecraft:stone
fill -17 215 17 -17 220 17 minecraft:stone
fill 14 215 17 14 220 20 minecraft:stone
setblock 17 215 17 minecraft:dripstone_block
setblock -17 215 18 minecraft:cobblestone
fill -16 215 18 -16 220 20 minecraft:stone
fill -13 215 18 -12 216 19 minecraft:stone
fill 15 215 18 17 220 18 minecraft:stone
fill -17 215 19 -17 220 19 minecraft:stone
fill -14 215 19 -14 220 20 minecraft:stone
setblock -11 215 19 minecraft:dripstone_block
fill -10 215 19 -8 215 20 minecraft:andesite
fill -7 215 19 -7 221 19 minecraft:stone
fill 13 215 19 13 220 21 minecraft:stone
fill 15 215 19 15 220 19 minecraft:stone
fill -15 215 20 -15 220 21 minecraft:stone
fill -7 215 20 -7 215 21 minecraft:andesite
fill -6 215 20 -4 221 20 minecraft:stone
fill 1 215 20 1 220 20 minecraft:stone
fill -8 215 21 -8 215 22 minecraft:andesite
fill -6 215 21 -6 221 22 minecraft:stone
setblock -5 215 21 minecraft:dripstone_block
fill -4 215 21 -2 221 21 minecraft:stone
fill 10 215 21 12 220 21 minecraft:stone
fill -7 215 22 -7 221 23 minecraft:stone
setblock -3 215 22 minecraft:dripstone_block
fill -2 215 22 -2 221 22 minecraft:stone
fill 9 215 22 10 220 22 minecraft:stone
fill -8 215 23 -8 219 24 minecraft:stone
setblock -2 215 23 minecraft:dripstone_block
