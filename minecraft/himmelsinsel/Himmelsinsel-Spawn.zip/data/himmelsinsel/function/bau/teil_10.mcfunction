fill 15 214 17 16 220 17 minecraft:stone
setblock -16 214 18 minecraft:dripstone_block
fill -15 214 18 -14 220 18 minecraft:stone
fill -11 214 18 -10 218 18 minecraft:stone
fill -15 214 19 -15 220 19 minecraft:stone
fill -9 214 19 -7 214 19 minecraft:andesite
fill -6 214 19 -3 221 19 minecraft:stone
fill 9 214 19 10 218 20 minecraft:stone
fill 12 214 19 12 220 20 minecraft:stone
fill -3 214 20 0 221 20 minecraft:stone
setblock 1 214 20 minecraft:amethyst_block
fill 2 214 20 2 219 22 minecraft:stone
fill 5 214 20 8 216 22 minecraft:stone
setblock -2 214 21 minecraft:dripstone_block
fill -1 214 21 1 220 22 minecraft:stone
fill 3 214 21 4 217 22 minecraft:stone
fill 9 214 21 9 220 21 minecraft:stone
fill 0 214 23 1 220 23 minecraft:stone
setblock 2 214 23 minecraft:amethyst_block
fill 3 214 23 3 218 24 minecraft:stone
setblock 4 214 23 minecraft:dripstone_block
fill 5 214 23 7 214 23 minecraft:stone
fill 8 214 23 8 215 23 minecraft:tuff
fill 2 214 24 2 219 24 minecraft:stone
fill 4 214 24 4 218 24 minecraft:stone
setblock 5 214 24 minecraft:amethyst_block
fill 35 215 -33 35 220 -33 minecraft:stone
fill 37 215 -33 37 220 -33 minecraft:stone
fill 34 215 -32 34 220 -32 minecraft:stone
fill 39 215 -32 39 217 -32 minecraft:andesite
fill 40 215 -31 40 217 -31 minecraft:andesite
fill 33 215 -30 33 220 -28 minecraft:stone
fill 39 215 -30 39 217 -29 minecraft:andesite
setblock 41 215 -30 minecraft:amethyst_block
setblock 40 215 -29 minecraft:andesite
setblock 41 215 -29 minecraft:dripstone_block
fill 39 215 -28 41 219 -28 minecraft:stone
fill 34 215 -27 34 220 -27 minecraft:stone
fill 40 215 -27 41 219 -27 minecraft:stone
setblock 35 215 -26 minecraft:amethyst_block
fill 36 215 -26 36 221 -26 minecraft:stone
fill 40 215 -26 40 220 -26 minecraft:stone
fill 0 215 -25 0 220 -25 minecraft:stone
fill 38 215 -25 39 220 -25 minecraft:stone
fill -2 215 -24 -1 220 -24 minecraft:stone
fill 1 215 -24 2 220 -24 minecraft:stone
fill -3 215 -23 -2 220 -23 minecraft:stone
fill 2 215 -23 3 215 -22 minecraft:stone
fill 6 215 -23 6 220 -23 minecraft:stone
setblock 7 215 -23 minecraft:dripstone_block
fill 8 215 -23 8 217 -23 minecraft:stone
fill -7 215 -22 -5 220 -22 minecraft:stone
setblock -1 215 -22 minecraft:dripstone_block
fill 0 215 -22 1 220 -22 minecraft:stone
fill 4 215 -22 5 215 -22 minecraft:stone
fill 9 215 -22 9 220 -22 minecraft:stone
fill -9 215 -21 -8 215 -20 minecraft:tuff
fill -7 215 -21 -6 220 -21 minecraft:stone
fill -1 215 -21 -1 215 -20 minecraft:stone
fill 0 215 -21 1 215 -21 minecraft:cobblestone
setblock 10 215 -21 minecraft:dripstone_block
fill -7 215 -20 -7 221 -20 minecraft:stone
setblock 0 215 -20 minecraft:amethyst_block
fill 1 215 -20 1 220 -20 minecraft:stone
fill 9 215 -20 10 220 -20 minecraft:stone
fill -10 215 -19 -10 215 -17 minecraft:stone
setblock -9 215 -19 minecraft:dripstone_block
fill -8 215 -19 -8 221 -19 minecraft:stone
fill 0 215 -19 0 221 -19 minecraft:stone
fill 15 215 -19 16 217 -16 minecraft:stone
fill -16 215 -18 -14 215 -18 minecraft:stone
fill -13 215 -18 -13 218 -18 minecraft:tuff
fill -11 215 -18 -11 221 -15 minecraft:stone
fill -9 215 -18 -9 221 -17 minecraft:stone
fill 11 215 -18 11 221 -17 minecraft:stone
setblock -17 215 -17 minecraft:dripstone_block
setblock -13 215 -17 minecraft:dripstone_block
fill -12 215 -17 -12 221 -16 minecraft:stone
fill -8 215 -17 -7 221 -17 minecraft:stone
fill -4 215 -17 -4 215 -16 minecraft:stone
fill -3 215 -17 -3 217 -16 minecraft:cobblestone
fill 12 215 -17 12 221 -16 minecraft:stone
fill 14 215 -17 14 218 -15 minecraft:stone
fill -18 215 -16 -18 220 -13 minecraft:stone
setblock -13 215 -16 minecraft:stone
fill 7 215 -16 8 220 -16 minecraft:stone
fill 13 215 -16 13 221 -16 minecraft:stone
fill 17 215 -16 17 221 -15 minecraft:stone
fill -13 215 -15 -12 215 -15 minecraft:cobblestone
fill -10 215 -15 -10 221 -15 minecraft:stone
setblock 7 215 -15 minecraft:cobblestone
fill -19 215 -14 -19 221 -11 minecraft:stone
fill -17 215 -14 -17 220 -13 minecraft:stone
setblock -13 215 -14 minecraft:stone
fill -5 215 -14 -4 219 -14 minecraft:stone
fill -3 215 -14 -3 216 -14 minecraft:cobblestone
fill 4 215 -14 4 216 -14 minecraft:stone
fill 5 215 -14 6 218 -14 minecraft:cobblestone
fill 18 215 -14 18 219 -13 minecraft:stone
setblock 19 215 -14 minecraft:dripstone_block
fill -16 215 -13 -16 220 -13 minecraft:stone
fill -13 215 -13 -12 215 -13 minecraft:andesite
fill -11 215 -13 -11 219 -12 minecraft:stone
fill -6 215 -13 -5 220 -13 minecraft:stone
fill 6 215 -13 6 215 -12 minecraft:stone
fill 8 215 -13 8 221 -12 minecraft:stone
fill 19 215 -13 19 221 -13 minecraft:stone
fill 20 215 -13 20 215 -12 minecraft:dripstone_block
fill -24 215 -12 -22 220 -12 minecraft:stone
fill -12 215 -12 -12 216 -12 minecraft:andesite
fill -6 215 -12 -5 215 -11 minecraft:cobblestone
fill -4 215 -12 -4 220 -11 minecraft:stone
fill 21 215 -12 21 215 -11 minecraft:dripstone_block
setblock -24 215 -11 minecraft:dripstone_block
fill -23 215 -11 -20 220 -11 minecraft:stone
fill -16 215 -11 -14 219 -11 minecraft:stone
fill -13 215 -11 -13 216 -11 minecraft:andesite
fill 15 215 -11 17 220 -11 minecraft:tuff
fill 18 215 -11 18 219 -11 minecraft:stone
fill -24 215 -10 -22 220 -10 minecraft:stone
fill -17 215 -10 -17 221 -10 minecraft:stone
fill 0 215 -10 0 221 -10 minecraft:stone
fill 21 215 -10 22 221 -10 minecraft:stone
setblock 23 215 -10 minecraft:dripstone_block
fill -23 215 -9 -23 220 -9 minecraft:stone
fill -21 215 -9 -20 215 -9 minecraft:andesite
fill -19 215 -9 -19 217 -9 minecraft:cobblestone
setblock -17 215 -9 minecraft:cobblestone
fill 1 215 -9 1 220 -7 minecraft:stone
fill 6 215 -9 6 217 -9 minecraft:tuff
fill 14 215 -9 14 216 -7 minecraft:andesite
fill 17 215 -9 17 217 -9 minecraft:stone
fill 23 215 -9 23 220 -9 minecraft:stone
setblock 24 215 -9 minecraft:amethyst_block
setblock -23 215 -8 minecraft:amethyst_block
fill -18 215 -8 -18 216 -8 minecraft:cobblestone
fill 0 215 -8 0 216 -8 minecraft:andesite
setblock 17 215 -8 minecraft:andesite
setblock 25 215 -8 minecraft:dripstone_block
fill -23 215 -7 -22 220 -7 minecraft:stone
setblock -19 215 -7 minecraft:andesite
fill -18 215 -7 -18 221 -7 minecraft:stone
fill -6 215 -7 -3 215 -7 minecraft:stone
fill -2 215 -7 -2 218 -7 minecraft:andesite
fill 21 215 -7 22 220 -7 minecraft:stone
fill 24 215 -7 25 220 -7 minecraft:stone
fill -23 215 -6 -23 221 -6 minecraft:stone
fill -22 215 -6 -22 216 -6 minecraft:cobblestone
fill -17 215 -6 -16 219 -6 minecraft:andesite
fill -15 215 -6 -15 216 -6 minecraft:stone
fill -1 215 -6 -1 219 -4 minecraft:andesite
setblock 5 215 -6 minecraft:stone
fill 6 215 -6 6 218 -6 minecraft:tuff
fill 19 215 -6 19 215 -5 minecraft:stone
fill 21 215 -6 21 221 -6 minecraft:stone
setblock 24 215 -6 minecraft:cobblestone
setblock 25 215 -6 minecraft:dripstone_block
fill -22 215 -5 -22 215 3 minecraft:stone
fill -19 215 -5 -19 219 -4 minecraft:andesite
fill -4 215 -5 -2 215 -5 minecraft:stone
setblock 20 215 -5 minecraft:stone
fill 21 215 -5 22 217 -3 minecraft:andesite
fill 25 215 -5 25 220 -5 minecraft:stone
fill -21 215 -4 -20 216 -4 minecraft:stone
fill 19 215 -4 20 221 -4 minecraft:andesite
fill 25 215 -4 25 215 -3 minecraft:andesite
fill -21 215 -3 -21 218 7 minecraft:stone
fill -19 215 -3 -19 215 -2 minecraft:stone
fill -18 215 -3 -17 219 -3 minecraft:andesite
fill -15 215 -3 -15 220 -3 minecraft:andesite
fill 1 215 -3 1 218 -3 minecraft:stone
setblock 9 215 -3 minecraft:cobblestone
fill 10 215 -3 11 220 -3 minecraft:stone
fill 19 215 -3 20 216 -3 minecraft:stone
fill 23 215 -3 23 218 -2 minecraft:andesite
setblock 24 215 -3 minecraft:dripstone_block
fill -23 215 -2 -23 215 1 minecraft:tuff
fill -8 215 -2 -8 220 -1 minecraft:stone
fill 0 215 -2 0 218 -2 minecraft:stone
fill 10 215 -2 10 221 -2 minecraft:stone
fill 16 215 -2 16 220 -1 minecraft:stone
setblock 21 215 -2 minecraft:dripstone_block
fill 22 215 -2 22 219 -2 minecraft:andesite
fill -25 215 -1 -24 216 -1 minecraft:tuff
fill 15 215 -1 15 220 -1 minecraft:stone
fill 21 215 -1 22 215 0 minecraft:stone
fill -25 215 0 -25 217 1 minecraft:tuff
fill -20 215 0 -20 219 2 minecraft:stone
fill -24 215 1 -24 217 1 minecraft:tuff
fill 22 215 1 22 220 5 minecraft:stone
fill -24 215 2 -24 220 2 minecraft:stone
setblock -23 215 2 minecraft:dripstone_block
setblock -20 215 3 minecraft:dripstone_block
fill -18 215 3 -18 221 4 minecraft:stone
fill -20 215 4 -20 217 8 minecraft:stone
fill -18 215 5 -18 216 5 minecraft:cobblestone
fill 3 215 5 3 215 6 minecraft:cobblestone
fill 4 215 5 4 221 5 minecraft:stone
fill 12 215 5 12 216 5 minecraft:tuff
fill -19 215 6 -19 215 7 minecraft:stone
setblock 2 215 6 minecraft:stone
fill 12 215 6 12 216 9 minecraft:stone
setblock 22 215 6 minecraft:dripstone_block
fill -11 215 7 -11 217 9 minecraft:stone
fill 2 215 7 2 216 7 minecraft:tuff
fill 3 215 7 8 220 7 minecraft:stone
fill -19 215 8 -19 218 8 minecraft:cobblestone
fill -14 215 8 -14 220 10 minecraft:stone
fill -1 215 8 -1 219 8 minecraft:stone
fill 0 215 8 0 221 8 minecraft:tuff
setblock 4 215 8 minecraft:tuff
fill 5 215 8 5 221 8 minecraft:stone
fill 21 215 8 21 218 8 minecraft:stone
fill -20 215 9 -20 218 9 minecraft:cobblestone
fill -16 215 9 -16 219 9 minecraft:stone
fill 1 215 9 3 217 9 minecraft:tuff
fill 19 215 9 21 216 9 minecraft:cobblestone
fill -20 215 10 -19 215 10 minecraft:stone
fill 2 215 10 3 217 10 minecraft:tuff
fill 19 215 10 20 215 10 minecraft:stone
