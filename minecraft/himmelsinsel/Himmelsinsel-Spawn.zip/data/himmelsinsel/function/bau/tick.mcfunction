# -1 = wartet auf /function himmelsinsel:admin/bauen, 0 = neu, 1 = lädt, 2+ = baut
execute if score #stufe hs.state matches 0 run function himmelsinsel:bau/welt_pruefen
execute if score #stufe hs.state matches 1.. run function himmelsinsel:bau/warten
