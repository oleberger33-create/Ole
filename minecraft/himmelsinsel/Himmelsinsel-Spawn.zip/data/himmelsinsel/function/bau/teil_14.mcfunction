fill 8 217 19 8 217 22 minecraft:stone
fill 20 217 19 20 220 20 minecraft:stone
setblock -19 217 20 minecraft:dripstone_block
fill -17 217 20 -17 220 20 minecraft:stone
fill -10 217 20 -9 217 21 minecraft:andesite
fill -8 217 20 -7 221 20 minecraft:stone
fill 5 217 20 7 219 20 minecraft:stone
fill 17 217 20 19 220 21 minecraft:stone
fill -18 217 21 -18 219 21 minecraft:stone
fill -12 217 21 -12 221 21 minecraft:andesite
fill -8 217 21 -8 221 21 minecraft:stone
fill 5 217 21 5 219 22 minecraft:tuff
fill 6 217 21 7 220 22 minecraft:stone
fill 16 217 21 16 220 21 minecraft:stone
fill -17 217 22 -17 220 22 minecraft:stone
fill -12 217 22 -12 221 22 minecraft:stone
fill -5 217 22 -5 221 23 minecraft:stone
fill 14 217 22 15 221 22 minecraft:stone
fill -16 217 23 -14 220 23 minecraft:stone
fill -13 217 23 -12 217 23 minecraft:cobblestone
fill -11 217 23 -11 219 24 minecraft:stone
fill -4 217 23 -4 219 25 minecraft:stone
fill 12 217 23 13 221 23 minecraft:stone
fill 41 217 23 41 222 23 minecraft:stone
fill 9 217 24 12 218 24 minecraft:stone
fill 40 217 24 40 220 24 minecraft:cobblestone
fill 41 217 24 41 219 25 minecraft:andesite
fill -10 217 25 -10 219 25 minecraft:stone
setblock -5 217 25 minecraft:tuff
fill -3 217 25 -3 221 26 minecraft:stone
setblock 9 217 25 minecraft:tuff
fill 10 217 25 11 220 25 minecraft:stone
setblock 39 217 25 minecraft:stone
fill -9 217 26 -9 219 26 minecraft:stone
fill -8 217 26 -8 219 26 minecraft:andesite
fill -7 217 26 -5 219 26 minecraft:stone
setblock -4 217 26 minecraft:cobblestone
setblock -1 217 26 minecraft:stone
fill 0 217 26 0 220 26 minecraft:tuff
fill 1 217 26 9 217 26 minecraft:stone
setblock 10 217 26 minecraft:amethyst_block
fill 11 217 26 11 220 26 minecraft:stone
fill 40 217 26 40 222 26 minecraft:stone
fill -2 217 27 -2 220 28 minecraft:tuff
setblock 2 217 27 minecraft:tuff
fill -1 217 28 -1 220 29 minecraft:tuff
fill 1 217 28 1 220 28 minecraft:tuff
fill 0 217 29 0 220 29 minecraft:tuff
fill 36 218 -36 37 220 -36 minecraft:tuff
fill 36 218 -35 36 220 -35 minecraft:tuff
setblock 38 218 -35 minecraft:dripstone_block
fill 39 218 -35 40 220 -35 minecraft:stone
setblock 33 218 -34 minecraft:dripstone_block
fill 41 218 -34 41 221 -34 minecraft:stone
setblock 32 218 -33 minecraft:stone
fill 42 218 -33 42 221 -31 minecraft:stone
fill 31 218 -32 31 219 -31 minecraft:stone
fill 39 218 -32 40 221 -32 minecraft:stone
fill 30 218 -31 30 220 -31 minecraft:stone
fill 40 218 -31 41 220 -31 minecraft:stone
setblock 30 218 -30 minecraft:dripstone_block
setblock 39 218 -30 minecraft:andesite
fill 40 218 -30 40 220 -30 minecraft:stone
fill 43 218 -30 43 221 -29 minecraft:stone
fill 30 218 -29 30 218 -28 minecraft:stone
fill 39 218 -29 39 220 -29 minecraft:stone
fill -8 218 -28 -7 220 -28 minecraft:stone
fill -6 218 -28 -3 218 -28 minecraft:tuff
fill -2 218 -28 -2 220 -27 minecraft:stone
fill 2 218 -28 5 220 -28 minecraft:stone
setblock 6 218 -28 minecraft:cobblestone
fill 43 218 -28 43 219 -27 minecraft:cobblestone
fill -10 218 -27 -10 220 -27 minecraft:stone
setblock -9 218 -27 minecraft:tuff
setblock -1 218 -27 minecraft:amethyst_block
fill 0 218 -27 1 219 -27 minecraft:cobblestone
fill 6 218 -27 8 218 -27 minecraft:stone
fill 31 218 -27 31 219 -26 minecraft:stone
setblock 42 218 -27 minecraft:stone
fill -12 218 -26 -12 219 -26 minecraft:stone
setblock -11 218 -26 minecraft:dripstone_block
fill -10 218 -26 -10 219 -26 minecraft:tuff
fill -3 218 -26 -3 220 -26 minecraft:stone
fill 9 218 -26 9 220 -26 minecraft:stone
fill -16 218 -25 -13 220 -25 minecraft:stone
fill -6 218 -25 -6 219 -25 minecraft:tuff
fill 6 218 -25 7 220 -25 minecraft:stone
fill 8 218 -25 8 220 -23 minecraft:tuff
fill 10 218 -25 10 219 -24 minecraft:tuff
fill 32 218 -25 32 220 -25 minecraft:stone
fill 34 218 -25 34 220 -24 minecraft:stone
fill 42 218 -25 42 219 -25 minecraft:stone
fill -17 218 -24 -17 218 -22 minecraft:stone
fill -13 218 -24 -11 220 -23 minecraft:stone
fill -10 218 -24 -10 220 -24 minecraft:tuff
fill -8 218 -24 -7 221 -24 minecraft:tuff
fill -6 218 -24 -6 221 -24 minecraft:stone
fill 11 218 -24 11 218 -23 minecraft:cobblestone
fill 33 218 -24 33 220 -24 minecraft:stone
fill 35 218 -24 37 221 -24 minecraft:stone
fill 40 218 -24 41 220 -23 minecraft:stone
setblock -16 218 -23 minecraft:stone
setblock -15 218 -23 minecraft:tuff
fill -10 218 -23 -10 220 -23 minecraft:stone
fill 10 218 -23 10 221 -23 minecraft:stone
fill 12 218 -23 12 219 -23 minecraft:cobblestone
fill 13 218 -23 13 219 -23 minecraft:stone
setblock 36 218 -23 minecraft:andesite
fill 37 218 -23 38 220 -23 minecraft:stone
fill -18 218 -22 -18 219 -21 minecraft:stone
fill -16 218 -22 -16 220 -22 minecraft:tuff
setblock 12 218 -22 minecraft:stone
setblock 13 218 -22 minecraft:andesite
fill 14 218 -22 15 221 -22 minecraft:stone
setblock 16 218 -22 minecraft:dripstone_block
fill 17 218 -22 17 221 -22 minecraft:stone
setblock -38 218 -21 minecraft:andesite
fill -17 218 -21 -17 220 -20 minecraft:tuff
fill -14 218 -21 -12 221 -21 minecraft:stone
setblock -1 218 -21 minecraft:cobblestone
fill 0 218 -21 0 221 -20 minecraft:stone
setblock 2 218 -21 minecraft:stone
fill 3 218 -21 3 219 -21 minecraft:andesite
fill 5 218 -21 5 219 -21 minecraft:andesite
fill 6 218 -21 6 220 -21 minecraft:stone
fill 18 218 -21 18 220 -21 minecraft:stone
fill -19 218 -20 -19 220 -19 minecraft:stone
fill -15 218 -20 -15 220 -17 minecraft:tuff
fill -14 218 -20 -13 221 -20 minecraft:stone
fill -1 218 -20 -1 221 -20 minecraft:stone
setblock 19 218 -20 minecraft:amethyst_block
fill 20 218 -20 20 220 -19 minecraft:stone
fill -21 218 -19 -20 221 -18 minecraft:stone
fill -14 218 -19 -14 219 -17 minecraft:tuff
fill -13 218 -19 -13 221 -19 minecraft:stone
fill 15 218 -19 16 220 -17 minecraft:stone
fill 19 218 -19 19 221 -19 minecraft:stone
fill 21 218 -19 23 220 -19 minecraft:stone
fill -23 218 -18 -23 220 -18 minecraft:stone
setblock -22 218 -18 minecraft:amethyst_block
setblock 20 218 -18 minecraft:amethyst_block
fill 21 218 -18 21 220 -17 minecraft:tuff
setblock 22 218 -18 minecraft:amethyst_block
setblock 23 218 -18 minecraft:tuff
fill 24 218 -18 24 220 -16 minecraft:stone
fill -25 218 -17 -24 220 -17 minecraft:stone
fill -13 218 -17 -13 221 -17 minecraft:stone
fill -4 218 -17 -3 220 -17 minecraft:stone
fill 20 218 -17 20 221 -17 minecraft:tuff
fill 22 218 -17 22 219 -17 minecraft:tuff
fill 23 218 -17 23 220 -15 minecraft:stone
fill 25 218 -17 25 220 -16 minecraft:stone
fill -25 218 -16 -25 220 -14 minecraft:stone
fill -16 218 -16 -16 220 -16 minecraft:tuff
fill -4 218 -16 -3 218 -16 minecraft:cobblestone
fill 2 218 -16 2 219 -16 minecraft:stone
setblock 15 218 -16 minecraft:cobblestone
fill 16 218 -16 16 221 -16 minecraft:stone
fill 20 218 -16 20 218 -15 minecraft:stone
fill 22 218 -16 22 221 -15 minecraft:stone
fill -26 218 -15 -26 220 -15 minecraft:stone
setblock -6 218 -15 minecraft:stone
fill -5 218 -15 -4 219 -15 minecraft:cobblestone
fill 2 218 -15 2 219 -15 minecraft:cobblestone
fill 5 218 -15 6 220 -15 minecraft:stone
fill 24 218 -15 24 219 -13 minecraft:andesite
fill 26 218 -15 26 220 -15 minecraft:stone
setblock -26 218 -14 minecraft:cobblestone
fill -24 218 -14 -24 220 -14 minecraft:stone
fill -15 218 -14 -12 219 -14 minecraft:stone
fill 2 218 -14 2 219 -12 minecraft:stone
fill 26 218 -14 26 218 -13 minecraft:andesite
fill -27 218 -13 -27 219 -13 minecraft:cobblestone
setblock -25 218 -13 minecraft:cobblestone
fill -15 218 -13 -15 219 -12 minecraft:stone
fill -14 218 -13 -13 218 -13 minecraft:cobblestone
setblock 4 218 -13 minecraft:cobblestone
fill 5 218 -13 5 219 -13 minecraft:tuff
setblock 25 218 -13 minecraft:dripstone_block
fill 27 218 -13 27 221 -10 minecraft:stone
fill -27 218 -12 -27 218 -11 minecraft:stone
fill -14 218 -12 -13 218 -12 minecraft:stone
fill 4 218 -12 4 221 -11 minecraft:tuff
fill 24 218 -12 24 218 -10 minecraft:stone
fill 26 218 -12 26 221 -12 minecraft:stone
fill -28 218 -11 -28 219 -10 minecraft:stone
fill -13 218 -11 -13 219 -11 minecraft:stone
fill -7 218 -11 -6 220 -11 minecraft:stone
fill 23 218 -11 23 219 -11 minecraft:stone
fill 28 218 -11 28 221 -10 minecraft:stone
fill -29 218 -10 -29 219 -8 minecraft:stone
fill -27 218 -10 -27 219 -10 minecraft:tuff
fill -8 218 -10 -8 218 -9 minecraft:cobblestone
fill -6 218 -10 -6 220 -10 minecraft:stone
fill -28 218 -9 -28 220 -5 minecraft:tuff
fill -25 218 -9 -25 220 -8 minecraft:stone
fill -19 218 -9 -19 220 -9 minecraft:stone
setblock -7 218 -9 minecraft:cobblestone
fill 6 218 -9 6 220 -9 minecraft:stone
setblock 11 218 -9 minecraft:stone
fill 12 218 -9 12 220 -8 minecraft:andesite
fill 15 218 -9 15 219 -7 minecraft:stone
fill 16 218 -9 17 220 -9 minecraft:tuff
fill 28 218 -9 29 219 -8 minecraft:cobblestone
fill -8 218 -8 -7 219 -8 minecraft:stone
fill -4 218 -8 -1 220 -8 minecraft:stone
setblock 14 218 -8 minecraft:andesite
setblock -29 218 -7 minecraft:dripstone_block
fill -21 218 -7 -20 220 -7 minecraft:stone
fill -8 218 -7 -8 221 -7 minecraft:stone
setblock -4 218 -7 minecraft:stone
fill -3 218 -7 -3 219 -7 minecraft:andesite
fill -1 218 -7 -1 220 -7 minecraft:stone
fill 0 218 -7 0 219 -7 minecraft:cobblestone
fill 20 218 -7 20 221 -7 minecraft:stone
fill 28 218 -7 29 220 -7 minecraft:stone
fill -29 218 -6 -29 219 -6 minecraft:stone
fill -4 218 -6 -4 220 -6 minecraft:andesite
fill 1 218 -6 1 219 -6 minecraft:cobblestone
fill 3 218 -6 3 219 -6 minecraft:stone
