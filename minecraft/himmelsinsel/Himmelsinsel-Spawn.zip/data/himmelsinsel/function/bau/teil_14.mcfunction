fill 18 218 -21 18 220 -21 minecraft:stone
fill -19 218 -20 -19 220 -19 minecraft:stone
fill -15 218 -20 -15 220 -17 minecraft:tuff
fill -14 218 -20 -13 221 -20 minecraft:stone
fill -1 218 -20 -1 221 -20 minecraft:stone
setblock 19 218 -20 minecraft:amethyst_block
fill 20 218 -20 20 220 -19 minecraft:stone
fill -21 218 -19 -20 221 -18 minecraft:stone
fill -14 218 -19 -14 219 -17 minecraft:tuff
fill -13 218 -19 -13 221 -19 minecraft:stone
fill 15 218 -19 16 220 -17 minecraft:stone
fill 19 218 -19 19 221 -19 minecraft:stone
fill 21 218 -19 23 220 -19 minecraft:stone
fill -23 218 -18 -23 220 -18 minecraft:stone
setblock -22 218 -18 minecraft:amethyst_block
setblock 20 218 -18 minecraft:amethyst_block
fill 21 218 -18 21 220 -17 minecraft:tuff
setblock 22 218 -18 minecraft:amethyst_block
setblock 23 218 -18 minecraft:tuff
fill 24 218 -18 24 220 -16 minecraft:stone
fill -25 218 -17 -24 220 -17 minecraft:stone
fill -13 218 -17 -13 221 -17 minecraft:stone
fill -4 218 -17 -3 220 -17 minecraft:stone
fill 20 218 -17 20 221 -17 minecraft:tuff
fill 22 218 -17 22 219 -17 minecraft:tuff
fill 23 218 -17 23 220 -15 minecraft:stone
fill 25 218 -17 25 220 -16 minecraft:stone
fill -25 218 -16 -25 220 -14 minecraft:stone
fill -16 218 -16 -16 220 -16 minecraft:tuff
fill -4 218 -16 -3 218 -16 minecraft:cobblestone
fill 2 218 -16 2 219 -16 minecraft:stone
setblock 15 218 -16 minecraft:cobblestone
fill 16 218 -16 16 221 -16 minecraft:stone
fill 20 218 -16 20 218 -15 minecraft:stone
fill 22 218 -16 22 221 -15 minecraft:stone
fill -26 218 -15 -26 220 -15 minecraft:stone
setblock -6 218 -15 minecraft:stone
fill -5 218 -15 -4 219 -15 minecraft:cobblestone
fill 2 218 -15 2 219 -15 minecraft:cobblestone
fill 5 218 -15 6 220 -15 minecraft:stone
fill 24 218 -15 24 219 -13 minecraft:andesite
fill 26 218 -15 26 220 -15 minecraft:stone
setblock -26 218 -14 minecraft:cobblestone
fill -24 218 -14 -24 220 -14 minecraft:stone
fill -15 218 -14 -12 219 -14 minecraft:stone
fill 2 218 -14 2 219 -12 minecraft:stone
fill 26 218 -14 26 218 -13 minecraft:andesite
fill -27 218 -13 -27 219 -13 minecraft:cobblestone
setblock -25 218 -13 minecraft:cobblestone
fill -15 218 -13 -15 219 -12 minecraft:stone
fill -14 218 -13 -13 218 -13 minecraft:cobblestone
setblock 4 218 -13 minecraft:cobblestone
fill 5 218 -13 5 219 -13 minecraft:tuff
setblock 25 218 -13 minecraft:dripstone_block
fill 27 218 -13 27 221 -10 minecraft:stone
fill -27 218 -12 -27 218 -11 minecraft:stone
fill -14 218 -12 -13 218 -12 minecraft:stone
fill 4 218 -12 4 221 -11 minecraft:tuff
fill 24 218 -12 24 218 -10 minecraft:stone
fill 26 218 -12 26 221 -12 minecraft:stone
fill -28 218 -11 -28 219 -10 minecraft:stone
fill -13 218 -11 -13 219 -11 minecraft:stone
fill -7 218 -11 -6 220 -11 minecraft:stone
fill 23 218 -11 23 219 -11 minecraft:stone
fill 28 218 -11 28 221 -10 minecraft:stone
fill -29 218 -10 -29 219 -8 minecraft:stone
fill -27 218 -10 -27 219 -10 minecraft:tuff
fill -8 218 -10 -8 218 -9 minecraft:cobblestone
fill -6 218 -10 -6 220 -10 minecraft:stone
fill -28 218 -9 -28 220 -5 minecraft:tuff
fill -25 218 -9 -25 220 -8 minecraft:stone
fill -19 218 -9 -19 220 -9 minecraft:stone
setblock -7 218 -9 minecraft:cobblestone
fill 6 218 -9 6 220 -9 minecraft:stone
setblock 11 218 -9 minecraft:stone
fill 12 218 -9 12 220 -8 minecraft:andesite
fill 15 218 -9 15 219 -7 minecraft:stone
fill 16 218 -9 17 220 -9 minecraft:tuff
fill 28 218 -9 29 219 -8 minecraft:cobblestone
fill -8 218 -8 -7 219 -8 minecraft:stone
fill -4 218 -8 -1 220 -8 minecraft:stone
setblock 14 218 -8 minecraft:andesite
setblock -29 218 -7 minecraft:dripstone_block
fill -21 218 -7 -20 220 -7 minecraft:stone
fill -8 218 -7 -8 221 -7 minecraft:stone
setblock -4 218 -7 minecraft:stone
fill -3 218 -7 -3 219 -7 minecraft:andesite
fill -1 218 -7 -1 220 -7 minecraft:stone
fill 0 218 -7 0 219 -7 minecraft:cobblestone
fill 20 218 -7 20 221 -7 minecraft:stone
fill 28 218 -7 29 220 -7 minecraft:stone
fill -29 218 -6 -29 219 -6 minecraft:stone
fill -4 218 -6 -4 220 -6 minecraft:andesite
fill 1 218 -6 1 219 -6 minecraft:cobblestone
fill 3 218 -6 3 219 -6 minecraft:stone
fill 4 218 -6 4 220 -2 minecraft:tuff
setblock 17 218 -6 minecraft:andesite
fill 19 218 -6 20 221 -6 minecraft:andesite
fill 29 218 -6 29 220 -2 minecraft:stone
fill -27 218 -5 -27 220 -3 minecraft:tuff
fill -22 218 -5 -22 221 -5 minecraft:stone
fill -21 218 -5 -21 221 -4 minecraft:andesite
setblock -4 218 -5 minecraft:stone
fill -3 218 -5 -3 220 -4 minecraft:andesite
fill 16 218 -5 16 220 -4 minecraft:andesite
fill 21 218 -5 21 221 -3 minecraft:andesite
fill 22 218 -5 22 221 -5 minecraft:stone
fill -26 218 -4 -26 218 -2 minecraft:tuff
fill 3 218 -4 3 221 -3 minecraft:stone
fill 9 218 -4 15 218 -4 minecraft:stone
fill 22 218 -4 22 218 -3 minecraft:andesite
fill 23 218 -4 23 220 -4 minecraft:stone
setblock -28 218 -3 minecraft:dripstone_block
fill -25 218 -3 -25 220 -1 minecraft:stone
fill 0 218 -3 0 220 -3 minecraft:andesite
fill 17 218 -3 19 221 -3 minecraft:andesite
fill 24 218 -3 25 219 -3 minecraft:cobblestone
fill 26 218 -3 26 220 -3 minecraft:stone
fill -28 218 -2 -28 221 -2 minecraft:tuff
fill 5 218 -2 5 219 -2 minecraft:tuff
fill 24 218 -2 24 218 -1 minecraft:andesite
fill 26 218 -2 26 218 -1 minecraft:cobblestone
fill 27 218 -2 27 220 1 minecraft:stone
fill -29 218 -1 -28 218 -1 minecraft:stone
fill -27 218 -1 -27 220 -1 minecraft:tuff
fill -20 218 -1 -18 219 -1 minecraft:andesite
setblock -17 218 -1 minecraft:cobblestone
fill 10 218 -1 10 221 1 minecraft:stone
fill 28 218 -1 28 221 -1 minecraft:stone
setblock -29 218 0 minecraft:amethyst_block
fill -28 218 0 -27 218 0 minecraft:stone
setblock -25 218 0 minecraft:tuff
fill -24 218 0 -24 220 1 minecraft:stone
fill -18 218 0 -18 219 0 minecraft:cobblestone
fill 9 218 0 9 221 1 minecraft:stone
fill 20 218 0 20 220 1 minecraft:andesite
setblock 24 218 0 minecraft:stone
setblock 28 218 0 minecraft:amethyst_block
fill -28 218 1 -28 220 2 minecraft:stone
fill -25 218 1 -25 220 1 minecraft:stone
fill -2 218 1 -2 221 1 minecraft:stone
fill -1 218 1 -1 219 1 minecraft:andesite
fill 11 218 1 11 219 1 minecraft:stone
fill 17 218 1 17 221 1 minecraft:stone
fill 28 218 1 28 219 2 minecraft:andesite
fill -5 218 2 -5 220 2 minecraft:stone
setblock -4 218 2 minecraft:andesite
fill 9 218 2 11 219 2 minecraft:cobblestone
fill 16 218 2 17 218 2 minecraft:tuff
fill 24 218 2 26 218 3 minecraft:cobblestone
fill 27 218 2 27 218 3 minecraft:andesite
setblock -28 218 3 minecraft:amethyst_block
fill -27 218 3 -27 220 4 minecraft:andesite
fill -7 218 3 -6 220 3 minecraft:andesite
fill 10 218 3 11 219 3 minecraft:cobblestone
fill 23 218 3 23 219 5 minecraft:stone
fill -20 218 4 -20 221 4 minecraft:stone
fill -6 218 4 1 219 4 minecraft:andesite
setblock 24 218 4 minecraft:stone
setblock 25 218 4 minecraft:dripstone_block
fill 26 218 4 26 218 7 minecraft:andesite
setblock 27 218 4 minecraft:dripstone_block
fill -27 218 5 -25 219 5 minecraft:stone
fill -20 218 5 -20 219 7 minecraft:cobblestone
fill -19 218 5 -19 221 5 minecraft:stone
fill -16 218 5 -15 219 5 minecraft:stone
fill -11 218 5 -11 218 7 minecraft:tuff
fill -10 218 5 -10 220 5 minecraft:stone
fill -2 218 5 -1 219 5 minecraft:stone
fill 0 218 5 1 218 6 minecraft:cobblestone
fill 24 218 5 25 218 6 minecraft:andesite
fill 27 218 5 27 218 8 minecraft:andesite
fill -26 218 6 -26 220 7 minecraft:stone
fill -19 218 6 -19 218 7 minecraft:cobblestone
fill -18 218 6 -18 220 8 minecraft:stone
fill -16 218 6 -15 219 7 minecraft:andesite
fill -12 218 6 -12 220 6 minecraft:tuff
fill -10 218 6 -10 218 7 minecraft:tuff
setblock 22 218 6 minecraft:stone
fill 23 218 6 23 219 7 minecraft:andesite
fill -25 218 7 -25 221 9 minecraft:stone
fill 11 218 7 12 220 7 minecraft:tuff
fill 19 218 7 22 220 7 minecraft:andesite
fill 24 218 7 24 218 12 minecraft:stone
fill 25 218 7 25 221 7 minecraft:andesite
fill -20 218 8 -20 219 8 minecraft:stone
fill -16 218 8 -15 218 8 minecraft:stone
fill -11 218 8 -10 218 9 minecraft:stone
fill 1 218 8 2 218 9 minecraft:tuff
fill 3 218 8 3 221 10 minecraft:stone
fill 11 218 8 12 218 8 minecraft:stone
fill 22 218 8 23 218 8 minecraft:stone
setblock 25 218 8 minecraft:dripstone_block
fill 26 218 8 26 218 9 minecraft:stone
setblock -18 218 9 minecraft:cobblestone
fill -15 218 9 -15 220 10 minecraft:stone
fill -13 218 9 -13 220 10 minecraft:stone
fill 12 218 9 12 220 9 minecraft:stone
fill 20 218 9 21 220 9 minecraft:stone
fill 25 218 9 25 220 10 minecraft:stone
fill -25 218 10 -25 219 11 minecraft:andesite
fill -24 218 10 -24 221 13 minecraft:stone
fill -20 218 10 -19 220 10 minecraft:stone
fill -12 218 10 -12 220 10 minecraft:stone
fill -10 218 10 -10 221 10 minecraft:stone
fill -4 218 10 -4 220 10 minecraft:andesite
fill 2 218 10 2 219 10 minecraft:tuff
setblock 23 218 10 minecraft:cobblestone
fill 11 218 11 11 219 11 minecraft:stone
fill 12 218 11 13 220 11 minecraft:andesite
fill 14 218 11 14 220 11 minecraft:stone
fill 20 218 11 21 219 11 minecraft:cobblestone
fill -22 218 12 -21 220 13 minecraft:stone
fill -10 218 12 -10 221 12 minecraft:stone
fill -2 218 12 -2 220 13 minecraft:stone
fill 15 218 12 16 220 12 minecraft:stone
fill 20 218 12 21 218 12 minecraft:stone
fill 22 218 12 23 219 12 minecraft:cobblestone
fill -23 218 13 -23 221 14 minecraft:stone
fill -1 218 13 -1 219 13 minecraft:stone
