setblock 22 225 20 minecraft:short_grass
fill 41 223 20 41 225 20 minecraft:vine[south=true]
fill -19 225 21 -19 225 22 minecraft:short_grass
fill -17 225 21 -16 225 21 minecraft:short_grass
setblock -15 225 21 minecraft:fern
fill -14 225 21 -14 225 22 minecraft:short_grass
setblock -10 225 21 minecraft:tall_grass[half=lower]
fill -7 225 21 -6 225 21 minecraft:short_grass
setblock -5 225 21 minecraft:pink_petals[facing=north,flower_amount=4]
setblock -2 225 21 minecraft:short_grass
setblock 2 225 21 minecraft:dandelion
setblock 5 225 21 minecraft:tall_grass[half=lower]
setblock 6 225 21 minecraft:pink_petals[facing=east,flower_amount=4]
setblock 7 225 21 minecraft:tall_grass[half=lower]
fill 8 225 21 8 225 22 minecraft:short_grass
setblock 9 225 21 minecraft:pink_petals[facing=east,flower_amount=4]
setblock 19 225 21 minecraft:short_grass
setblock 20 225 21 minecraft:pink_petals[facing=north,flower_amount=1]
fill -17 225 22 -17 225 23 minecraft:short_grass
setblock -5 225 22 minecraft:short_grass
setblock -2 225 22 minecraft:tall_grass[half=lower]
fill 4 225 22 5 225 22 minecraft:short_grass
fill 9 225 22 11 225 22 minecraft:short_grass
setblock 12 225 22 minecraft:fern
setblock 13 225 22 minecraft:short_grass
setblock 15 225 22 minecraft:tall_grass[half=lower]
setblock 16 225 22 minecraft:short_grass
setblock 19 225 22 minecraft:tall_grass[half=lower]
fill 36 222 22 36 225 22 minecraft:vine[south=true]
setblock -20 225 23 minecraft:tall_grass[half=lower]
setblock -15 225 23 minecraft:short_grass
setblock -14 225 23 minecraft:lily_of_the_valley
fill -13 225 23 -13 225 25 minecraft:short_grass
setblock -11 225 23 minecraft:pink_petals[facing=north,flower_amount=2]
setblock -10 225 23 minecraft:short_grass
setblock -9 225 23 minecraft:allium
setblock -3 225 23 minecraft:short_grass
setblock 2 225 23 minecraft:short_grass
setblock 3 225 23 minecraft:tall_grass[half=lower]
setblock 4 225 23 minecraft:fern
setblock 12 225 23 minecraft:short_grass
setblock 19 225 23 minecraft:pink_petals[facing=west,flower_amount=4]
fill 44 221 23 44 225 23 minecraft:vine[west=true]
setblock -19 225 24 minecraft:pink_petals[facing=west,flower_amount=1]
fill -16 225 24 -16 225 26 minecraft:short_grass
fill -15 225 24 -15 225 25 minecraft:fern
setblock -14 225 24 minecraft:short_grass
setblock -11 225 24 minecraft:tall_grass[half=lower]
setblock -9 225 24 minecraft:tall_grass[half=lower]
setblock -8 225 24 minecraft:wildflowers[facing=east,flower_amount=4]
setblock -3 225 24 minecraft:tall_grass[half=lower]
setblock 2 225 24 minecraft:lily_of_the_valley
fill 4 225 24 5 225 24 minecraft:short_grass
setblock 6 225 24 minecraft:cornflower
setblock 10 225 24 minecraft:tall_grass[half=lower]
fill 13 225 24 17 225 24 minecraft:short_grass
setblock 19 225 24 minecraft:short_grass
setblock -14 225 25 minecraft:fern
fill -10 225 25 -10 225 26 minecraft:short_grass
setblock 4 225 25 minecraft:wildflowers[facing=north,flower_amount=4]
setblock 5 225 25 minecraft:short_grass
setblock 14 225 25 minecraft:short_grass
setblock 16 225 25 minecraft:short_grass
setblock 17 225 25 minecraft:tall_grass[half=lower]
setblock 18 225 25 minecraft:short_grass
setblock -17 225 26 minecraft:short_grass
setblock -15 225 26 minecraft:short_grass
setblock -14 225 26 minecraft:tall_grass[half=lower]
setblock -12 225 26 minecraft:pink_petals[facing=south,flower_amount=2]
fill -11 225 26 -11 225 28 minecraft:short_grass
setblock -8 225 26 minecraft:short_grass
fill -6 225 26 -6 225 27 minecraft:short_grass
setblock -2 225 26 minecraft:allium
setblock 2 225 26 minecraft:short_grass
setblock 4 225 26 minecraft:short_grass
setblock 10 225 26 minecraft:short_grass
setblock 12 225 26 minecraft:fern
setblock 13 225 26 minecraft:short_grass
setblock 15 225 26 minecraft:short_grass
fill 35 223 26 35 225 26 minecraft:vine[east=true]
setblock -16 225 27 minecraft:fern
setblock -15 225 27 minecraft:tall_grass[half=lower]
setblock -14 225 27 minecraft:fern
setblock -13 225 27 minecraft:pink_petals[facing=east,flower_amount=3]
setblock -12 225 27 minecraft:pink_petals[facing=west,flower_amount=1]
setblock -7 225 27 minecraft:short_grass
fill -4 225 27 -3 225 27 minecraft:short_grass
setblock 5 225 27 minecraft:short_grass
setblock 6 225 27 minecraft:pink_petals[facing=south,flower_amount=3]
setblock 7 225 27 minecraft:pink_petals[facing=east,flower_amount=2]
fill -15 225 28 -13 225 28 minecraft:short_grass
setblock -8 225 28 minecraft:short_grass
setblock -4 225 28 minecraft:short_grass
setblock -3 225 28 minecraft:wildflowers[facing=west,flower_amount=3]
setblock 3 225 28 minecraft:short_grass
setblock 8 225 28 minecraft:short_grass
setblock 12 225 28 minecraft:short_grass
fill 43 220 28 43 225 28 minecraft:vine[west=true]
setblock -13 225 29 minecraft:short_grass
setblock -10 225 29 minecraft:tall_grass[half=lower]
setblock -7 225 29 minecraft:short_grass
setblock -5 225 29 minecraft:dandelion
setblock 4 225 29 minecraft:short_grass
setblock 6 225 29 minecraft:dandelion
setblock 11 225 29 minecraft:short_grass
fill 43 222 29 43 225 29 minecraft:vine[west=true]
setblock -11 225 30 minecraft:short_grass
setblock -8 225 30 minecraft:wildflowers[facing=south,flower_amount=3]
setblock -7 225 30 minecraft:pink_petals[facing=west,flower_amount=1]
setblock -6 225 30 minecraft:short_grass
setblock -4 225 30 minecraft:wildflowers[facing=north,flower_amount=3]
setblock -3 225 30 minecraft:tall_grass[half=lower]
setblock 7 225 30 minecraft:short_grass
fill 40 224 30 40 225 30 minecraft:vine[north=true]
setblock -9 225 31 minecraft:short_grass
setblock -7 225 31 minecraft:short_grass
setblock -6 225 31 minecraft:tall_grass[half=lower]
setblock -4 225 31 minecraft:pink_petals[facing=south,flower_amount=1]
setblock -42 224 -26 minecraft:pointed_dripstone[thickness=middle,vertical_direction=down]
setblock -37 224 -24 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock -37 224 -23 minecraft:glow_lichen[up=true]
setblock -45 224 -22 minecraft:cave_vines_plant[berries=true]
setblock -44 224 -22 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock -35 224 -21 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock -40 224 -19 minecraft:amethyst_cluster[facing=down]
setblock -38 224 -18 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
fill 45 222 -35 45 223 -35 minecraft:vine[west=true]
fill 28 221 -34 28 223 -33 minecraft:vine[east=true]
fill -3 219 -31 -3 223 -31 minecraft:vine[south=true]
fill 0 220 -31 0 223 -31 minecraft:vine[south=true]
fill -6 219 -30 -6 223 -30 minecraft:vine[east=true]
fill 5 218 -30 5 223 -30 minecraft:vine[west=true]
fill -14 222 -28 -14 223 -28 minecraft:vine[south=true]
fill 47 222 -28 47 223 -28 minecraft:vine[west=true]
fill -17 221 -27 -17 223 -27 minecraft:vine[south=true]
setblock -42 223 -26 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock -42 223 -25 minecraft:cave_vines_plant[berries=false]
fill 17 220 -25 17 223 -25 minecraft:vine[south=true]
setblock -37 223 -24 minecraft:pointed_dripstone[thickness=middle,vertical_direction=down]
fill -21 218 -24 -21 223 -24 minecraft:vine[east=true]
setblock -45 223 -22 minecraft:cave_vines_plant[berries=false]
setblock -44 223 -22 minecraft:pointed_dripstone[thickness=middle,vertical_direction=down]
setblock -37 223 -22 minecraft:glow_lichen[up=true]
fill -23 220 -22 -23 223 -22 minecraft:vine[south=true]
setblock -44 223 -21 minecraft:glow_lichen[up=true]
setblock -35 223 -21 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
fill 24 222 -21 24 223 -21 minecraft:vine[west=true]
fill 32 222 -21 32 223 -21 minecraft:vine[north=true]
setblock -43 223 -20 minecraft:glow_lichen[up=true]
setblock -37 223 -20 minecraft:glow_lichen[up=true]
fill 41 219 -20 41 223 -20 minecraft:vine[west=true]
setblock -38 223 -18 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
fill 31 220 -11 31 223 -11 minecraft:vine[west=true]
fill -32 221 -9 -32 223 -9 minecraft:vine[east=true]
fill -32 219 -5 -32 223 -5 minecraft:vine[east=true]
fill 32 219 -5 32 223 -5 minecraft:vine[west=true]
fill 31 219 0 31 223 0 minecraft:vine[north=true]
fill -30 219 5 -30 223 5 minecraft:vine[east=true]
fill -28 219 10 -28 223 10 minecraft:vine[east=true]
fill 28 221 11 28 223 11 minecraft:vine[west=true]
fill -27 219 12 -27 223 12 minecraft:vine[east=true]
fill 23 218 20 23 223 20 minecraft:vine[west=true]
fill -21 220 23 -21 223 23 minecraft:vine[north=true]
fill 20 218 24 20 223 24 minecraft:vine[west=true]
fill 18 219 26 18 223 26 minecraft:vine[west=true]
fill 16 218 27 16 223 27 minecraft:vine[west=true]
fill 12 221 29 12 223 29 minecraft:vine[west=true]
fill 14 218 29 14 223 29 minecraft:vine[north=true]
fill 2 218 32 2 223 32 minecraft:vine[north=true]
setblock -42 222 -26 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock -42 222 -25 minecraft:cave_vines[age=25,berries=true]
setblock -39 222 -25 minecraft:glow_lichen[up=true]
setblock -37 222 -24 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock -45 222 -22 minecraft:cave_vines_plant[berries=true]
setblock -44 222 -22 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 36 222 23 minecraft:hanging_roots
setblock 44 222 25 minecraft:hanging_roots
setblock 42 222 29 minecraft:hanging_roots
setblock 39 221 -38 minecraft:hanging_roots
setblock 28 221 -26 minecraft:hanging_roots
setblock -37 221 -24 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 18 221 -24 minecraft:hanging_roots
setblock -42 221 -23 minecraft:glow_lichen[up=true]
setblock -45 221 -22 minecraft:cave_vines[age=25,berries=true]
setblock -44 221 -22 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 22 221 -22 minecraft:hanging_roots
setblock 29 221 8 minecraft:hanging_roots
setblock -26 221 14 minecraft:hanging_roots
setblock 26 221 14 minecraft:hanging_roots
setblock 36 221 25 minecraft:cave_vines_plant[berries=false]
setblock 43 221 27 minecraft:glow_lichen[up=true]
setblock 40 221 29 minecraft:amethyst_cluster[facing=down]
fill 36 220 -38 38 220 -38 minecraft:hanging_roots
setblock 32 220 -36 minecraft:glow_lichen[up=true]
setblock 45 220 -34 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 46 220 -31 minecraft:glow_lichen[up=true]
setblock -4 220 -30 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
fill -2 217 -30 -2 220 -30 minecraft:cave_vines_plant[berries=false]
setblock 3 220 -30 minecraft:hanging_roots
setblock -10 220 -29 minecraft:hanging_roots
setblock 14 220 -26 minecraft:glow_lichen[up=true]
setblock 17 220 -24 minecraft:glow_lichen[up=true]
setblock -21 220 -23 minecraft:glow_lichen[up=true]
setblock 44 220 -23 minecraft:glow_lichen[up=true]
fill -38 218 -22 -38 220 -22 minecraft:cave_vines_plant[berries=false]
setblock -22 220 -22 minecraft:glow_lichen[up=true]
setblock 43 220 -22 minecraft:glow_lichen[up=true]
setblock -41 220 -21 minecraft:glow_lichen[up=true]
setblock -24 220 -20 minecraft:hanging_roots
setblock 27 220 -18 minecraft:glow_lichen[up=true]
setblock -30 220 -12 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock -31 220 -4 minecraft:glow_lichen[up=true]
setblock -31 220 -2 minecraft:glow_lichen[up=true]
setblock 31 220 -1 minecraft:glow_lichen[up=true]
setblock 30 220 4 minecraft:hanging_roots
setblock 28 220 10 minecraft:hanging_roots
setblock 25 220 15 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock -25 220 16 minecraft:glow_lichen[up=true]
setblock 24 220 17 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock -24 220 18 minecraft:glow_lichen[up=true]
