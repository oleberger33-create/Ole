setblock 8 223 1 minecraft:dirt
setblock 28 223 1 minecraft:dirt
fill -34 223 2 -31 223 2 minecraft:spruce_log[axis=x]
fill -19 223 2 -18 223 2 minecraft:dirt
fill -3 223 2 -3 223 3 minecraft:dirt
setblock 27 223 2 minecraft:dirt
setblock 29 223 2 minecraft:dirt
setblock -21 223 3 minecraft:dirt
fill -19 223 3 -19 223 4 minecraft:dirt
fill -13 223 3 -13 223 4 minecraft:dirt
setblock -2 223 3 minecraft:dirt
fill -1 223 3 1 223 3 minecraft:dark_prismarine
fill 2 223 3 3 223 3 minecraft:dirt
fill 28 223 3 28 223 5 minecraft:dirt
fill -20 223 4 -20 223 5 minecraft:dirt
fill 26 223 4 27 223 5 minecraft:dirt
setblock -24 223 5 minecraft:dirt
setblock -18 223 5 minecraft:dirt
setblock -14 223 5 minecraft:dirt
setblock -23 223 6 minecraft:dirt
setblock -15 223 6 minecraft:dirt
fill 2 223 6 3 223 6 minecraft:dirt
setblock 26 223 6 minecraft:dirt
setblock -21 223 7 minecraft:dirt
setblock -10 223 7 minecraft:dirt
fill -8 223 7 -7 223 7 minecraft:dirt
fill 4 223 7 5 223 7 minecraft:dirt
fill 13 223 7 15 223 8 minecraft:dirt
fill 17 223 7 22 223 7 minecraft:dirt
fill 24 223 7 25 223 7 minecraft:dirt
fill -23 223 8 -23 223 9 minecraft:dirt
setblock -19 223 8 minecraft:dirt
setblock -6 223 8 minecraft:dirt
setblock -2 223 8 minecraft:dirt
fill 17 223 8 21 223 8 minecraft:dirt
fill 24 223 8 24 223 9 minecraft:dirt
fill -27 223 9 -26 223 9 minecraft:dirt
setblock -22 223 9 minecraft:dirt
setblock -11 223 9 minecraft:dirt
fill -1 223 9 -1 223 10 minecraft:dirt
setblock 1 223 9 minecraft:dirt
fill 4 223 9 5 223 9 minecraft:dirt
fill 17 223 9 18 223 12 minecraft:dirt
fill -17 223 10 -17 223 13 minecraft:dirt
fill -7 223 10 -6 223 10 minecraft:dirt
fill 5 223 10 6 223 10 minecraft:dirt
setblock 21 223 10 minecraft:dirt
fill -16 223 11 -16 223 12 minecraft:dirt
setblock -14 223 11 minecraft:dirt
setblock -8 223 11 minecraft:dirt
setblock 4 223 11 minecraft:dirt
setblock 22 223 11 minecraft:dirt
setblock 24 223 11 minecraft:dirt
setblock -24 223 12 minecraft:dirt
setblock -6 223 12 minecraft:dirt
setblock 21 223 12 minecraft:dirt
setblock 23 223 12 minecraft:dirt
setblock 25 223 12 minecraft:dirt
setblock 2 223 13 minecraft:dirt
fill 24 223 13 24 223 14 minecraft:dirt
setblock -25 223 14 minecraft:dirt
setblock -22 223 14 minecraft:dirt
setblock -9 223 14 minecraft:dirt
setblock 4 223 14 minecraft:dirt
setblock 25 223 14 minecraft:dirt
setblock -24 223 15 minecraft:dirt
setblock -21 223 15 minecraft:dirt
setblock -1 223 15 minecraft:dirt
fill 2 223 15 2 223 16 minecraft:dirt
setblock 23 223 15 minecraft:dirt
setblock -22 223 16 minecraft:dirt
setblock -12 223 16 minecraft:dirt
setblock 1 223 16 minecraft:dirt
setblock 13 223 16 minecraft:dirt
fill -3 223 17 -3 223 18 minecraft:dirt
fill -1 223 17 0 223 17 minecraft:dirt
setblock -22 223 18 minecraft:dirt
setblock -19 223 18 minecraft:dirt
setblock -6 223 19 minecraft:dirt
fill -1 223 19 0 223 19 minecraft:dirt
setblock -12 223 20 minecraft:dirt
setblock -8 223 20 minecraft:dirt
setblock 2 223 20 minecraft:dirt
setblock -10 223 21 minecraft:dirt
fill -6 223 21 -4 223 21 minecraft:dirt
setblock 41 223 21 minecraft:rooted_dirt
fill 42 223 21 42 225 24 minecraft:dirt
fill -9 223 22 -8 223 23 minecraft:dirt
setblock -5 223 22 minecraft:dirt
setblock -1 223 22 minecraft:dirt
setblock 16 223 22 minecraft:dirt
fill 37 223 22 41 225 22 minecraft:dirt
fill -13 223 23 -13 223 24 minecraft:dirt
fill -4 223 23 -3 223 23 minecraft:dirt
setblock 14 223 23 minecraft:dirt
fill 36 223 23 39 225 23 minecraft:dirt
setblock 40 223 23 minecraft:rooted_dirt
fill 41 223 23 41 225 24 minecraft:dirt
fill 43 223 23 43 225 23 minecraft:dirt
fill -11 223 24 -10 223 24 minecraft:dirt
fill -3 223 24 -3 223 25 minecraft:dirt
fill 12 223 24 13 223 24 minecraft:dirt
fill 15 223 24 15 223 25 minecraft:dirt
fill 36 223 24 37 225 24 minecraft:dirt
fill 38 223 24 38 223 25 minecraft:rooted_dirt
fill 39 223 24 40 225 25 minecraft:dirt
setblock 43 223 24 minecraft:rooted_dirt
fill 44 223 24 44 225 24 minecraft:dirt
setblock -6 223 25 minecraft:dirt
setblock 11 223 25 minecraft:dirt
setblock 14 223 25 minecraft:dirt
setblock 36 223 25 minecraft:rooted_dirt
fill 37 223 25 37 225 27 minecraft:dirt
fill 41 223 25 42 223 25 minecraft:rooted_dirt
fill 43 223 25 43 225 26 minecraft:dirt
setblock 44 223 25 minecraft:rooted_dirt
setblock -12 223 26 minecraft:dirt
fill -10 223 26 -10 223 28 minecraft:dirt
setblock -4 223 26 minecraft:dirt
fill 36 223 26 36 225 26 minecraft:dirt
fill 38 223 26 38 225 28 minecraft:dirt
fill 39 223 26 40 223 26 minecraft:rooted_dirt
fill 41 223 26 42 225 26 minecraft:dirt
setblock -9 223 27 minecraft:dirt
fill -3 223 27 -3 223 28 minecraft:dirt
setblock 3 223 27 minecraft:dirt
fill 6 223 27 7 223 27 minecraft:dirt
setblock 15 223 27 minecraft:dirt
fill 39 223 27 41 225 27 minecraft:dirt
fill 42 223 27 43 223 27 minecraft:rooted_dirt
fill -7 223 28 -6 223 28 minecraft:dirt
fill 39 223 28 40 223 28 minecraft:rooted_dirt
fill 41 223 28 42 225 29 minecraft:dirt
setblock -8 223 29 minecraft:dirt
fill -6 223 29 -5 223 29 minecraft:dirt
fill 3 223 29 4 223 29 minecraft:dirt
setblock 6 223 29 minecraft:dirt
setblock 8 223 29 minecraft:dirt
fill 40 223 29 40 225 29 minecraft:dirt
setblock -9 223 30 minecraft:dirt
setblock -7 223 30 minecraft:dirt
fill 35 224 -38 39 224 -37 minecraft:grass_block
fill 33 224 -37 34 224 -37 minecraft:grass_block
fill 40 224 -37 42 224 -37 minecraft:grass_block
fill 31 224 -36 32 224 -31 minecraft:grass_block
fill 33 224 -36 35 224 -34 minecraft:spruce_planks
fill 36 224 -36 38 224 -34 minecraft:grass_block
fill 39 224 -36 41 224 -34 minecraft:spruce_planks
fill 42 224 -36 44 224 -31 minecraft:grass_block
fill 30 224 -35 30 224 -31 minecraft:grass_block
fill 29 224 -34 29 224 -25 minecraft:grass_block
fill 45 224 -34 45 224 -24 minecraft:grass_block
fill 33 224 -33 34 224 -33 minecraft:grass_block
fill 35 224 -33 39 224 -33 minecraft:polished_andesite
fill 40 224 -33 41 224 -33 minecraft:grass_block
fill 28 224 -32 28 224 -26 minecraft:grass_block
setblock 33 224 -32 minecraft:grass_block
fill 34 224 -32 35 224 -32 minecraft:polished_andesite
fill 36 224 -32 38 224 -31 minecraft:stone_bricks
fill 39 224 -32 40 224 -32 minecraft:polished_andesite
setblock 41 224 -32 minecraft:grass_block
fill 33 224 -31 34 224 -31 minecraft:polished_andesite
fill 35 224 -31 35 224 -27 minecraft:stone_bricks
setblock 39 224 -31 minecraft:cracked_stone_bricks
fill 40 224 -31 41 224 -31 minecraft:polished_andesite
fill 46 224 -31 46 224 -28 minecraft:grass_block
fill -5 224 -30 4 224 -28 minecraft:grass_block
fill 30 224 -30 32 224 -28 minecraft:spruce_planks
fill 33 224 -30 33 224 -27 minecraft:polished_andesite
setblock 34 224 -30 minecraft:mossy_stone_bricks
fill 36 224 -30 38 224 -30 minecraft:polished_andesite
fill 39 224 -30 40 224 -29 minecraft:stone_bricks
fill 41 224 -30 41 224 -27 minecraft:polished_andesite
fill 42 224 -30 44 224 -28 minecraft:spruce_planks
fill -10 224 -29 -6 224 -26 minecraft:grass_block
fill 5 224 -29 8 224 -26 minecraft:grass_block
fill 34 224 -29 34 224 -28 minecraft:stone_bricks
fill 36 224 -29 36 224 -28 minecraft:polished_andesite
setblock 37 224 -29 minecraft:chiseled_stone_bricks
fill 38 224 -29 38 224 -28 minecraft:polished_andesite
fill -13 224 -28 -11 224 -2 minecraft:grass_block
fill 9 224 -28 10 224 -21 minecraft:grass_block
setblock 37 224 -28 minecraft:polished_andesite
setblock 39 224 -28 minecraft:stone_bricks
setblock 40 224 -28 minecraft:cracked_stone_bricks
fill -15 224 -27 -14 224 -2 minecraft:grass_block
fill -5 224 -27 -3 224 -27 minecraft:grass_block
fill -2 224 -27 2 224 -26 minecraft:polished_deepslate
fill 3 224 -27 4 224 -27 minecraft:grass_block
fill 11 224 -27 12 224 -12 minecraft:grass_block
fill 30 224 -27 32 224 -24 minecraft:grass_block
fill 34 224 -27 34 224 -26 minecraft:polished_andesite
fill 36 224 -27 37 224 -27 minecraft:stone_bricks
fill 38 224 -27 39 224 -27 minecraft:mossy_stone_bricks
fill 40 224 -27 40 224 -26 minecraft:polished_andesite
fill 42 224 -27 44 224 -23 minecraft:grass_block
fill -17 224 -26 -16 224 -2 minecraft:grass_block
setblock -5 224 -26 minecraft:grass_block
fill -4 224 -26 -3 224 -25 minecraft:polished_deepslate
fill 3 224 -26 4 224 -25 minecraft:polished_deepslate
fill 13 224 -26 14 224 -12 minecraft:grass_block
fill 33 224 -26 33 224 -21 minecraft:grass_block
fill 35 224 -26 35 224 -25 minecraft:polished_andesite
setblock 36 224 -26 minecraft:stone_bricks
setblock 37 224 -26 minecraft:mossy_stone_bricks
setblock 38 224 -26 minecraft:stone_bricks
fill 39 224 -26 39 224 -25 minecraft:polished_andesite
fill 41 224 -26 41 224 -21 minecraft:grass_block
fill -42 224 -25 -41 226 -25 minecraft:stone
fill -38 224 -25 -38 226 -24 minecraft:stone
fill -18 224 -25 -18 224 -2 minecraft:grass_block
fill -10 224 -25 -7 224 -25 minecraft:grass_block
fill -6 224 -25 -5 224 -24 minecraft:polished_deepslate
fill -2 224 -25 2 224 -22 minecraft:dark_oak_planks
fill 5 224 -25 6 224 -24 minecraft:polished_deepslate
fill 7 224 -25 8 224 -25 minecraft:grass_block
fill 15 224 -25 16 224 -12 minecraft:grass_block
fill 34 224 -25 34 224 -20 minecraft:grass_block
fill 36 224 -25 38 224 -25 minecraft:polished_andesite
fill 40 224 -25 40 224 -20 minecraft:grass_block
