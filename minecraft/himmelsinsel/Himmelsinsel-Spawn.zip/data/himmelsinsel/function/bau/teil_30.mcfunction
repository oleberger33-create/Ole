fill 8 224 29 11 224 29 minecraft:grass_block
fill 0 224 32 0 224 38 minecraft:spruce_slab[type=top]
fill -5 225 -29 -3 225 -28 minecraft:flowering_azalea_leaves[persistent=true]
setblock -5 225 -27 minecraft:azalea_leaves[persistent=true]
fill -4 225 -27 -4 226 -27 minecraft:flowering_azalea_leaves[persistent=true]
setblock -3 225 -27 minecraft:azalea_leaves[persistent=true]
fill -40 225 -26 -39 225 -26 minecraft:stone
fill -3 225 -26 -3 231 -25 minecraft:stripped_dark_oak_log[axis=y]
fill -2 225 -26 2 225 -26 minecraft:polished_deepslate
fill 3 225 -26 3 231 -25 minecraft:stripped_dark_oak_log[axis=y]
fill -5 225 -25 -4 225 -25 minecraft:polished_deepslate
fill -2 225 -25 -2 227 -25 minecraft:bookshelf
fill 2 225 -25 2 227 -25 minecraft:bookshelf
fill 4 225 -25 5 225 -25 minecraft:polished_deepslate
fill -43 225 -24 -43 226 -24 minecraft:stone
setblock -37 225 -24 minecraft:dripstone_block
fill -6 225 -24 -5 225 -24 minecraft:polished_deepslate
fill -3 225 -24 -3 227 -24 minecraft:bookshelf
fill 3 225 -24 3 227 -24 minecraft:bookshelf
fill 5 225 -24 6 225 -24 minecraft:polished_deepslate
setblock -44 225 -23 minecraft:stone
fill -37 225 -23 -37 226 -23 minecraft:stone
fill -7 225 -23 -7 225 -22 minecraft:polished_deepslate
fill 7 225 -23 7 225 -22 minecraft:polished_deepslate
setblock -44 225 -22 minecraft:dripstone_block
fill -42 225 -21 -42 225 -19 minecraft:stone
fill -40 225 -21 -39 225 -20 minecraft:cobblestone
fill -38 225 -21 -38 225 -19 minecraft:stone
fill -36 225 -21 -36 227 -21 minecraft:stone
fill -8 225 -21 -7 231 -21 minecraft:stripped_dark_oak_log[axis=y]
fill -6 225 -21 -6 227 -21 minecraft:bookshelf
fill 6 225 -21 6 227 -21 minecraft:bookshelf
fill 7 225 -21 8 231 -21 minecraft:stripped_dark_oak_log[axis=y]
setblock -44 225 -20 minecraft:andesite
setblock -41 225 -20 minecraft:cobblestone
fill -8 225 -20 -8 225 -16 minecraft:polished_deepslate
fill -7 225 -20 -7 227 -20 minecraft:bookshelf
setblock 0 225 -20 minecraft:polished_deepslate_stairs[facing=south,half=bottom]
fill 7 225 -20 7 227 -20 minecraft:bookshelf
fill 8 225 -20 8 225 -16 minecraft:polished_deepslate
setblock -43 225 -19 minecraft:andesite
fill -41 225 -19 -41 226 -19 minecraft:stone
setblock -40 225 -19 minecraft:amethyst_block
setblock -39 225 -19 minecraft:stone
fill -1 225 -19 1 225 -17 minecraft:polished_deepslate
setblock -2 225 -18 minecraft:polished_deepslate_stairs[facing=east,half=bottom]
setblock 2 225 -18 minecraft:polished_deepslate_stairs[facing=west,half=bottom]
fill -7 225 -16 -7 227 -16 minecraft:bookshelf
setblock 0 225 -16 minecraft:polished_deepslate_stairs[facing=north,half=bottom]
fill 7 225 -16 7 227 -16 minecraft:bookshelf
fill -8 225 -15 -7 231 -15 minecraft:stripped_dark_oak_log[axis=y]
fill -6 225 -15 -6 227 -15 minecraft:bookshelf
fill 6 225 -15 6 227 -15 minecraft:bookshelf
fill 7 225 -15 8 231 -15 minecraft:stripped_dark_oak_log[axis=y]
fill 15 225 -15 15 230 -15 minecraft:cherry_log[axis=y]
setblock 23 225 -15 minecraft:azalea_leaves[persistent=true]
fill 24 225 -15 25 225 -15 minecraft:flowering_azalea_leaves[persistent=true]
fill -12 225 -14 -11 225 -13 minecraft:azalea_leaves[persistent=true]
fill -10 225 -14 -10 225 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill -7 225 -14 -7 225 -13 minecraft:polished_deepslate
fill 7 225 -14 7 225 -13 minecraft:polished_deepslate
fill 23 225 -14 24 226 -14 minecraft:flowering_azalea_leaves[persistent=true]
setblock 25 225 -14 minecraft:azalea_leaves[persistent=true]
fill -25 225 -13 -25 225 -11 minecraft:flowering_azalea_leaves[persistent=true]
fill -24 225 -13 -24 226 -13 minecraft:azalea_leaves[persistent=true]
fill -23 225 -13 -23 225 -12 minecraft:flowering_azalea_leaves[persistent=true]
fill -6 225 -13 -6 225 -12 minecraft:polished_deepslate
fill 6 225 -13 6 225 -12 minecraft:polished_deepslate
setblock 23 225 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill 24 225 -13 24 226 -13 minecraft:azalea_leaves[persistent=true]
setblock 25 225 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill -24 225 -12 -24 226 -11 minecraft:flowering_azalea_leaves[persistent=true]
fill -12 225 -12 -11 225 -12 minecraft:flowering_azalea_leaves[persistent=true]
setblock -10 225 -12 minecraft:azalea_leaves[persistent=true]
fill -3 225 -12 -3 227 -12 minecraft:bookshelf
fill 3 225 -12 3 227 -12 minecraft:bookshelf
setblock -23 225 -11 minecraft:azalea_leaves[persistent=true]
setblock -4 225 -11 minecraft:polished_deepslate
fill -3 225 -11 -3 231 -10 minecraft:stripped_dark_oak_log[axis=y]
fill 3 225 -11 3 231 -10 minecraft:stripped_dark_oak_log[axis=y]
setblock 4 225 -11 minecraft:polished_deepslate
fill -2 225 -10 -2 229 -10 minecraft:polished_deepslate
fill 2 225 -10 2 229 -10 minecraft:polished_deepslate
fill -15 225 -9 -15 229 -9 minecraft:cherry_log[axis=y]
fill 13 225 -6 13 228 -6 minecraft:stripped_spruce_log[axis=y]
fill 14 225 -6 18 225 -6 minecraft:spruce_fence[east=true,west=true]
fill 19 225 -6 19 228 -6 minecraft:stripped_spruce_log[axis=y]
fill 20 225 -6 22 225 -6 minecraft:spruce_fence[east=true,west=true]
setblock 23 225 -6 minecraft:spruce_fence[east=true,south=true,west=true]
setblock 24 225 -6 minecraft:spruce_fence[east=true,west=true]
fill 25 225 -6 25 228 -6 minecraft:stripped_spruce_log[axis=y]
fill -5 225 -5 -5 226 -5 minecraft:spruce_fence
fill 5 225 -5 5 226 -5 minecraft:spruce_fence
setblock 21 225 -5 minecraft:grindstone[face=floor,facing=north]
setblock 23 225 -5 minecraft:smithing_table
fill 25 225 -5 25 225 -1 minecraft:spruce_fence[north=true,south=true]
fill 26 225 -5 26 225 -3 minecraft:azalea_leaves[persistent=true]
setblock 27 225 -5 minecraft:flowering_azalea_leaves[persistent=true]
fill -2 225 -4 2 225 -4 minecraft:polished_deepslate_slab[type=bottom]
setblock 27 225 -4 minecraft:azalea_leaves[persistent=true]
setblock -34 225 -3 minecraft:spruce_fence[east=true,south=true]
fill -33 225 -3 -29 225 -3 minecraft:spruce_fence[east=true,west=true]
setblock -28 225 -3 minecraft:spruce_fence[west=true]
fill -3 225 -3 -2 225 -3 minecraft:polished_deepslate_slab[type=bottom]
fill 2 225 -3 3 225 -3 minecraft:polished_deepslate_slab[type=bottom]
setblock 27 225 -3 minecraft:flowering_azalea_leaves[persistent=true]
fill -34 225 -2 -34 225 2 minecraft:spruce_fence[north=true,south=true]
fill -19 225 -2 -19 226 -2 minecraft:spruce_fence
fill -4 225 -2 -3 225 -2 minecraft:polished_deepslate_slab[type=bottom]
fill 3 225 -2 4 225 -2 minecraft:polished_deepslate_slab[type=bottom]
fill 17 225 -2 21 226 -2 minecraft:bookshelf
fill -4 225 -1 -4 225 2 minecraft:polished_deepslate_slab[type=bottom]
fill 4 225 -1 4 225 2 minecraft:polished_deepslate_slab[type=bottom]
fill 17 225 -1 17 226 -1 minecraft:bookshelf
fill 21 225 -1 21 226 -1 minecraft:bookshelf
setblock 0 225 0 minecraft:beacon
setblock 19 225 0 minecraft:enchanting_table
fill 25 225 0 25 228 0 minecraft:stripped_spruce_log[axis=y]
fill 17 225 1 17 226 2 minecraft:bookshelf
fill 21 225 1 21 226 2 minecraft:bookshelf
fill 25 225 1 25 225 5 minecraft:spruce_fence[north=true,south=true]
fill -25 225 2 -25 226 2 minecraft:spruce_fence
fill -12 225 2 -12 226 2 minecraft:spruce_fence
fill -3 225 2 -3 225 3 minecraft:polished_deepslate_slab[type=bottom]
fill 3 225 2 3 225 3 minecraft:polished_deepslate_slab[type=bottom]
fill 10 225 2 10 226 2 minecraft:spruce_fence
fill 18 225 2 20 226 2 minecraft:bookshelf
setblock -34 225 3 minecraft:spruce_fence[north=true,east=true]
fill -33 225 3 -29 225 3 minecraft:spruce_fence[east=true,west=true]
setblock -28 225 3 minecraft:spruce_fence[west=true]
fill -2 225 3 -2 225 4 minecraft:polished_deepslate_slab[type=bottom]
fill 2 225 3 2 225 4 minecraft:polished_deepslate_slab[type=bottom]
fill -1 225 4 1 225 4 minecraft:polished_deepslate_slab[type=bottom]
fill -5 225 5 -5 226 5 minecraft:spruce_fence
fill 5 225 5 5 226 5 minecraft:spruce_fence
setblock 15 225 5 minecraft:crafting_table
setblock 17 225 5 minecraft:crafting_table
setblock 19 225 5 minecraft:ender_chest[facing=north]
setblock 21 225 5 minecraft:ender_chest[facing=north]
setblock 23 225 5 minecraft:stonecutter[facing=north]
fill 13 225 6 13 228 6 minecraft:stripped_spruce_log[axis=y]
setblock 14 225 6 minecraft:spruce_fence[east=true,west=true]
setblock 15 225 6 minecraft:spruce_fence[north=true,east=true,west=true]
setblock 16 225 6 minecraft:spruce_fence[east=true,west=true]
setblock 17 225 6 minecraft:spruce_fence[north=true,east=true,west=true]
setblock 18 225 6 minecraft:spruce_fence[east=true,west=true]
fill 19 225 6 19 228 6 minecraft:stripped_spruce_log[axis=y]
fill 20 225 6 24 225 6 minecraft:spruce_fence[east=true,west=true]
fill 25 225 6 25 228 6 minecraft:stripped_spruce_log[axis=y]
fill -22 225 10 -22 229 10 minecraft:cherry_log[axis=y]
fill 21 225 11 21 225 12 minecraft:azalea_leaves[persistent=true]
fill 22 225 11 23 225 11 minecraft:flowering_azalea_leaves[persistent=true]
fill 22 225 12 22 226 12 minecraft:azalea_leaves[persistent=true]
fill 23 225 12 23 226 12 minecraft:flowering_azalea_leaves[persistent=true]
fill -10 225 13 -10 226 13 minecraft:spruce_fence
fill -2 225 13 -2 226 13 minecraft:spruce_fence
fill 21 225 13 22 225 13 minecraft:flowering_azalea_leaves[persistent=true]
setblock 23 225 13 minecraft:azalea_leaves[persistent=true]
fill -19 225 15 -19 227 15 minecraft:dark_oak_log[axis=y]
fill -18 225 15 -16 225 15 minecraft:mossy_cobblestone
fill -15 225 15 -15 227 15 minecraft:dark_oak_log[axis=y]
fill -19 225 16 -19 225 18 minecraft:mossy_cobblestone
setblock -18 225 16 minecraft:water_cauldron[level=3]
setblock -15 225 16 minecraft:mossy_cobblestone
fill 13 225 16 13 229 16 minecraft:cherry_log[axis=y]
setblock -18 225 18 minecraft:brewing_stand
setblock -15 225 18 minecraft:mossy_cobblestone
fill -19 225 19 -19 227 19 minecraft:dark_oak_log[axis=y]
fill -18 225 19 -16 225 19 minecraft:mossy_cobblestone
fill -15 225 19 -15 227 19 minecraft:dark_oak_log[axis=y]
fill 2 225 20 2 226 20 minecraft:spruce_fence
setblock 43 225 22 minecraft:dirt
fill -7 225 23 -6 225 23 minecraft:azalea_leaves[persistent=true]
setblock -5 225 23 minecraft:flowering_azalea_leaves[persistent=true]
setblock 7 225 23 minecraft:azalea_leaves[persistent=true]
setblock 8 225 23 minecraft:flowering_azalea_leaves[persistent=true]
fill 9 225 23 9 225 25 minecraft:azalea_leaves[persistent=true]
fill -7 225 24 -6 225 25 minecraft:flowering_azalea_leaves[persistent=true]
fill -5 225 24 -5 225 25 minecraft:azalea_leaves[persistent=true]
fill 7 225 24 7 225 25 minecraft:flowering_azalea_leaves[persistent=true]
fill 8 225 24 8 225 25 minecraft:azalea_leaves[persistent=true]
fill -2 225 25 -2 226 25 minecraft:spruce_fence
setblock -2 225 27 minecraft:spruce_fence[south=true]
setblock 2 225 27 minecraft:spruce_fence[south=true]
fill -2 225 28 -2 225 30 minecraft:spruce_fence[north=true,south=true]
fill 2 225 28 2 225 30 minecraft:spruce_fence[north=true,south=true]
fill -2 225 31 -2 227 31 minecraft:stripped_spruce_log[axis=y]
fill 2 225 31 2 227 31 minecraft:stripped_spruce_log[axis=y]
setblock -4 226 -29 minecraft:azalea_leaves[persistent=true]
fill -5 226 -28 -4 226 -28 minecraft:flowering_azalea_leaves[persistent=true]
setblock -3 226 -28 minecraft:azalea_leaves[persistent=true]
setblock -42 226 -26 minecraft:dripstone_block
fill -41 226 -26 -40 226 -26 minecraft:stone
fill -39 226 -26 -38 226 -26 minecraft:mossy_cobblestone
fill -2 226 -26 2 226 -26 minecraft:deepslate_bricks
setblock -43 226 -25 minecraft:stone
fill -37 226 -25 -37 226 -24 minecraft:stone
fill -5 226 -25 -4 226 -25 minecraft:deepslate_bricks
fill 4 226 -25 5 226 -25 minecraft:deepslate_bricks
fill -44 226 -24 -44 226 -23 minecraft:andesite
setblock -6 226 -24 minecraft:cracked_deepslate_bricks
setblock -5 226 -24 minecraft:deepslate_bricks
fill 5 226 -24 6 226 -24 minecraft:deepslate_bricks
fill -7 226 -23 -6 226 -23 minecraft:deepslate_bricks
fill 6 226 -23 7 226 -23 minecraft:deepslate_bricks
fill -45 226 -22 -44 226 -22 minecraft:stone
setblock -36 226 -22 minecraft:amethyst_block
fill -7 226 -22 -7 227 -22 minecraft:cracked_deepslate_bricks
fill 7 226 -22 7 230 -22 minecraft:deepslate_bricks
setblock -45 226 -21 minecraft:stone
setblock -42 226 -21 minecraft:stone
fill -41 226 -21 -40 226 -20 minecraft:mossy_cobblestone
fill -39 226 -21 -38 227 -21 minecraft:stone
setblock -45 226 -20 minecraft:andesite
fill -44 226 -20 -43 226 -20 minecraft:stone
setblock -42 226 -20 minecraft:mossy_cobblestone
fill -39 226 -20 -39 226 -19 minecraft:mossy_cobblestone
fill -38 226 -20 -38 227 -20 minecraft:stone
fill -36 226 -20 -36 227 -20 minecraft:stone
fill -8 226 -20 -8 226 -16 minecraft:deepslate_bricks
