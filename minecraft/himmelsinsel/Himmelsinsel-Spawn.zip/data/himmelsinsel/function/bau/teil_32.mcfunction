fill -25 224 8 -9 224 9 minecraft:grass_block
fill -8 224 8 -8 224 9 minecraft:dirt_path
fill -2 224 8 -2 224 26 minecraft:grass_block
fill -1 224 8 1 224 26 minecraft:dirt_path
fill 2 224 8 2 224 26 minecraft:grass_block
fill -27 224 9 -26 224 11 minecraft:grass_block
fill -7 224 9 -7 224 31 minecraft:grass_block
fill 28 224 9 28 224 10 minecraft:grass_block
fill -25 224 10 -10 224 10 minecraft:grass_block
setblock -9 224 10 minecraft:dirt_path
fill -8 224 10 -8 224 31 minecraft:grass_block
fill -25 224 11 -11 224 11 minecraft:grass_block
setblock -10 224 11 minecraft:dirt_path
fill -9 224 11 -9 224 31 minecraft:grass_block
fill -26 224 12 -12 224 12 minecraft:grass_block
fill -11 224 12 -11 224 13 minecraft:dirt_path
fill -10 224 12 -10 224 30 minecraft:grass_block
fill -26 224 13 -13 224 14 minecraft:grass_block
fill -12 224 13 -12 224 15 minecraft:dirt_path
fill 26 224 13 26 224 14 minecraft:grass_block
fill -11 224 14 -11 224 30 minecraft:grass_block
fill -25 224 15 -20 224 16 minecraft:grass_block
fill -19 224 15 -15 224 19 minecraft:spruce_planks
fill -14 224 15 -14 224 16 minecraft:grass_block
fill -13 224 15 -13 224 16 minecraft:dirt_path
fill -12 224 16 -12 224 30 minecraft:grass_block
fill 13 224 16 24 224 17 minecraft:grass_block
fill -24 224 17 -20 224 18 minecraft:grass_block
setblock -14 224 17 minecraft:dirt_path
fill -13 224 17 -13 224 29 minecraft:grass_block
fill -14 224 18 -14 224 28 minecraft:grass_block
fill 13 224 18 23 224 19 minecraft:grass_block
fill -23 224 19 -20 224 19 minecraft:grass_block
fill -22 224 20 -15 224 21 minecraft:grass_block
fill 13 224 20 22 224 20 minecraft:grass_block
fill 13 224 21 21 224 22 minecraft:grass_block
fill 41 224 21 41 225 21 minecraft:dirt
fill -21 224 22 -15 224 22 minecraft:grass_block
setblock 43 224 22 minecraft:rooted_dirt
fill -20 224 23 -15 224 23 minecraft:grass_block
fill 13 224 23 20 224 23 minecraft:grass_block
fill 40 224 23 40 225 23 minecraft:dirt
fill -19 224 24 -15 224 24 minecraft:grass_block
fill 13 224 24 19 224 24 minecraft:grass_block
fill 38 224 24 38 225 25 minecraft:dirt
fill 43 224 24 43 225 24 minecraft:dirt
fill -18 224 25 -15 224 25 minecraft:grass_block
fill 13 224 25 18 224 25 minecraft:grass_block
fill 36 224 25 36 225 25 minecraft:dirt
fill 41 224 25 42 225 25 minecraft:dirt
fill 44 224 25 44 225 25 minecraft:dirt
fill -17 224 26 -15 224 26 minecraft:grass_block
fill 13 224 26 17 224 26 minecraft:grass_block
fill 39 224 26 40 225 26 minecraft:dirt
fill -16 224 27 -15 224 27 minecraft:grass_block
fill -2 224 27 2 224 31 minecraft:spruce_planks
fill 13 224 27 15 224 27 minecraft:grass_block
fill 42 224 27 43 225 27 minecraft:dirt
setblock -15 224 28 minecraft:grass_block
fill 13 224 28 14 224 28 minecraft:grass_block
fill 39 224 28 40 225 28 minecraft:dirt
fill 8 224 29 11 224 29 minecraft:grass_block
fill 0 224 32 0 224 38 minecraft:spruce_slab[type=top]
setblock 33 225 -36 minecraft:barrel[facing=up]
setblock 34 225 -36 minecraft:hay_block[axis=y]
setblock 35 225 -36 minecraft:barrel[facing=up]
setblock 39 225 -36 minecraft:barrel[facing=up]
setblock 40 225 -36 minecraft:blast_furnace[facing=south]
setblock 41 225 -36 minecraft:barrel[facing=up]
setblock 37 225 -35 minecraft:composter
setblock 33 225 -34 minecraft:spruce_fence[east=true]
setblock 34 225 -34 minecraft:composter
setblock 35 225 -34 minecraft:spruce_fence[west=true]
setblock 39 225 -34 minecraft:spruce_fence[east=true]
setblock 40 225 -34 minecraft:smithing_table
setblock 41 225 -34 minecraft:spruce_fence[west=true]
setblock 32 225 -32 minecraft:barrel[facing=up]
setblock 42 225 -32 minecraft:hay_block[axis=y]
setblock 30 225 -30 minecraft:barrel[facing=up]
setblock 32 225 -30 minecraft:spruce_fence[south=true]
setblock 42 225 -30 minecraft:spruce_fence[south=true]
setblock 44 225 -30 minecraft:barrel[facing=up]
fill -5 225 -29 -3 225 -28 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 225 -29 minecraft:target
setblock 32 225 -29 minecraft:barrel[facing=up]
setblock 37 225 -29 minecraft:bell[attachment=floor,facing=south]
setblock 42 225 -29 minecraft:fletching_table
setblock 44 225 -29 minecraft:oak_log[axis=y]
setblock 30 225 -28 minecraft:barrel[facing=up]
setblock 32 225 -28 minecraft:spruce_fence[north=true]
setblock 42 225 -28 minecraft:spruce_fence[north=true]
setblock 44 225 -28 minecraft:barrel[facing=up]
setblock -5 225 -27 minecraft:azalea_leaves[persistent=true]
fill -4 225 -27 -4 226 -27 minecraft:flowering_azalea_leaves[persistent=true]
setblock -3 225 -27 minecraft:azalea_leaves[persistent=true]
fill -40 225 -26 -39 225 -26 minecraft:stone
fill -3 225 -26 -3 231 -25 minecraft:stripped_dark_oak_log[axis=y]
fill -2 225 -26 2 225 -26 minecraft:polished_deepslate
fill 3 225 -26 3 231 -25 minecraft:stripped_dark_oak_log[axis=y]
setblock 32 225 -26 minecraft:hay_block[axis=x]
setblock 42 225 -26 minecraft:barrel[facing=up]
fill -5 225 -25 -4 225 -25 minecraft:polished_deepslate
fill -2 225 -25 -2 227 -25 minecraft:bookshelf
fill 2 225 -25 2 227 -25 minecraft:bookshelf
fill 4 225 -25 5 225 -25 minecraft:polished_deepslate
fill 34 225 -25 34 226 -25 minecraft:spruce_fence
fill 40 225 -25 40 226 -25 minecraft:spruce_fence
fill 42 225 -25 44 225 -25 minecraft:flowering_azalea_leaves[persistent=true]
fill -43 225 -24 -43 226 -24 minecraft:stone
setblock -37 225 -24 minecraft:dripstone_block
fill -6 225 -24 -5 225 -24 minecraft:polished_deepslate
fill -3 225 -24 -3 227 -24 minecraft:bookshelf
fill 3 225 -24 3 227 -24 minecraft:bookshelf
fill 5 225 -24 6 225 -24 minecraft:polished_deepslate
fill 31 225 -24 31 228 -24 minecraft:cherry_log[axis=y]
fill 42 225 -24 43 225 -24 minecraft:flowering_azalea_leaves[persistent=true]
fill 44 225 -24 44 226 -24 minecraft:azalea_leaves[persistent=true]
setblock -44 225 -23 minecraft:stone
fill -37 225 -23 -37 226 -23 minecraft:stone
fill -7 225 -23 -7 225 -22 minecraft:polished_deepslate
fill 7 225 -23 7 225 -22 minecraft:polished_deepslate
setblock 42 225 -23 minecraft:azalea_leaves[persistent=true]
fill 43 225 -23 44 225 -23 minecraft:flowering_azalea_leaves[persistent=true]
setblock -44 225 -22 minecraft:dripstone_block
setblock 35 225 -22 minecraft:spruce_fence[south=true]
setblock 39 225 -22 minecraft:spruce_fence[south=true]
fill -42 225 -21 -42 225 -19 minecraft:stone
fill -40 225 -21 -39 225 -20 minecraft:cobblestone
fill -38 225 -21 -38 225 -19 minecraft:stone
fill -36 225 -21 -36 227 -21 minecraft:stone
fill -8 225 -21 -7 231 -21 minecraft:stripped_dark_oak_log[axis=y]
fill -6 225 -21 -6 227 -21 minecraft:bookshelf
fill 6 225 -21 6 227 -21 minecraft:bookshelf
fill 7 225 -21 8 231 -21 minecraft:stripped_dark_oak_log[axis=y]
fill 35 225 -21 35 225 -13 minecraft:spruce_fence[north=true,south=true]
fill 39 225 -21 39 225 -13 minecraft:spruce_fence[north=true,south=true]
setblock -44 225 -20 minecraft:andesite
setblock -41 225 -20 minecraft:cobblestone
fill -8 225 -20 -8 225 -16 minecraft:polished_deepslate
fill -7 225 -20 -7 227 -20 minecraft:bookshelf
setblock 0 225 -20 minecraft:polished_deepslate_stairs[facing=south,half=bottom]
fill 7 225 -20 7 227 -20 minecraft:bookshelf
fill 8 225 -20 8 225 -16 minecraft:polished_deepslate
setblock -43 225 -19 minecraft:andesite
fill -41 225 -19 -41 226 -19 minecraft:stone
setblock -40 225 -19 minecraft:amethyst_block
setblock -39 225 -19 minecraft:stone
fill -1 225 -19 1 225 -17 minecraft:polished_deepslate
setblock -2 225 -18 minecraft:polished_deepslate_stairs[facing=east,half=bottom]
setblock 2 225 -18 minecraft:polished_deepslate_stairs[facing=west,half=bottom]
fill -7 225 -16 -7 227 -16 minecraft:bookshelf
setblock 0 225 -16 minecraft:polished_deepslate_stairs[facing=north,half=bottom]
fill 7 225 -16 7 227 -16 minecraft:bookshelf
fill -8 225 -15 -7 231 -15 minecraft:stripped_dark_oak_log[axis=y]
fill -6 225 -15 -6 227 -15 minecraft:bookshelf
fill 6 225 -15 6 227 -15 minecraft:bookshelf
fill 7 225 -15 8 231 -15 minecraft:stripped_dark_oak_log[axis=y]
fill 15 225 -15 15 230 -15 minecraft:cherry_log[axis=y]
setblock 23 225 -15 minecraft:azalea_leaves[persistent=true]
fill 24 225 -15 25 225 -15 minecraft:flowering_azalea_leaves[persistent=true]
fill -12 225 -14 -11 225 -13 minecraft:azalea_leaves[persistent=true]
fill -10 225 -14 -10 225 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill -7 225 -14 -7 225 -13 minecraft:polished_deepslate
fill 7 225 -14 7 225 -13 minecraft:polished_deepslate
fill 23 225 -14 24 226 -14 minecraft:flowering_azalea_leaves[persistent=true]
setblock 25 225 -14 minecraft:azalea_leaves[persistent=true]
fill -25 225 -13 -25 225 -11 minecraft:flowering_azalea_leaves[persistent=true]
fill -24 225 -13 -24 226 -13 minecraft:azalea_leaves[persistent=true]
fill -23 225 -13 -23 225 -12 minecraft:flowering_azalea_leaves[persistent=true]
fill -6 225 -13 -6 225 -12 minecraft:polished_deepslate
fill 6 225 -13 6 225 -12 minecraft:polished_deepslate
setblock 23 225 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill 24 225 -13 24 226 -13 minecraft:azalea_leaves[persistent=true]
setblock 25 225 -13 minecraft:flowering_azalea_leaves[persistent=true]
fill -24 225 -12 -24 226 -11 minecraft:flowering_azalea_leaves[persistent=true]
fill -12 225 -12 -11 225 -12 minecraft:flowering_azalea_leaves[persistent=true]
setblock -10 225 -12 minecraft:azalea_leaves[persistent=true]
fill -3 225 -12 -3 227 -12 minecraft:bookshelf
fill 3 225 -12 3 227 -12 minecraft:bookshelf
setblock 28 225 -12 minecraft:spruce_fence[east=true]
fill 29 225 -12 34 225 -12 minecraft:spruce_fence[east=true,west=true]
fill 35 225 -12 35 227 -12 minecraft:stripped_spruce_log[axis=y]
fill 39 225 -12 39 227 -12 minecraft:stripped_spruce_log[axis=y]
setblock -23 225 -11 minecraft:azalea_leaves[persistent=true]
setblock -4 225 -11 minecraft:polished_deepslate
fill -3 225 -11 -3 231 -10 minecraft:stripped_dark_oak_log[axis=y]
fill 3 225 -11 3 231 -10 minecraft:stripped_dark_oak_log[axis=y]
setblock 4 225 -11 minecraft:polished_deepslate
fill 39 225 -11 39 225 -9 minecraft:spruce_fence[north=true,south=true]
fill -2 225 -10 -2 229 -10 minecraft:polished_deepslate
fill 2 225 -10 2 229 -10 minecraft:polished_deepslate
fill -15 225 -9 -15 229 -9 minecraft:cherry_log[axis=y]
setblock 28 225 -8 minecraft:spruce_fence[east=true]
fill 29 225 -8 34 225 -8 minecraft:spruce_fence[east=true,west=true]
fill 35 225 -8 35 227 -8 minecraft:stripped_spruce_log[axis=y]
fill 36 225 -8 38 225 -8 minecraft:spruce_fence[east=true,west=true]
fill 39 225 -8 39 227 -8 minecraft:stripped_spruce_log[axis=y]
fill 13 225 -6 13 228 -6 minecraft:stripped_spruce_log[axis=y]
fill 14 225 -6 18 225 -6 minecraft:spruce_fence[east=true,west=true]
fill 19 225 -6 19 228 -6 minecraft:stripped_spruce_log[axis=y]
fill 20 225 -6 22 225 -6 minecraft:spruce_fence[east=true,west=true]
setblock 23 225 -6 minecraft:spruce_fence[east=true,south=true,west=true]
setblock 24 225 -6 minecraft:spruce_fence[east=true,west=true]
fill 25 225 -6 25 228 -6 minecraft:stripped_spruce_log[axis=y]
fill -5 225 -5 -5 226 -5 minecraft:spruce_fence
fill 5 225 -5 5 226 -5 minecraft:spruce_fence
setblock 21 225 -5 minecraft:grindstone[face=floor,facing=north]
setblock 23 225 -5 minecraft:smithing_table
fill 25 225 -5 25 225 -1 minecraft:spruce_fence[north=true,south=true]
fill 26 225 -5 26 225 -3 minecraft:azalea_leaves[persistent=true]
setblock 27 225 -5 minecraft:flowering_azalea_leaves[persistent=true]
fill -2 225 -4 2 225 -4 minecraft:polished_deepslate_slab[type=bottom]
setblock 27 225 -4 minecraft:azalea_leaves[persistent=true]
setblock -34 225 -3 minecraft:spruce_fence[east=true,south=true]
fill -33 225 -3 -29 225 -3 minecraft:spruce_fence[east=true,west=true]
setblock -28 225 -3 minecraft:spruce_fence[west=true]
fill -3 225 -3 -2 225 -3 minecraft:polished_deepslate_slab[type=bottom]
fill 2 225 -3 3 225 -3 minecraft:polished_deepslate_slab[type=bottom]
setblock 27 225 -3 minecraft:flowering_azalea_leaves[persistent=true]
fill -34 225 -2 -34 225 2 minecraft:spruce_fence[north=true,south=true]
