setblock 14 222 -16 minecraft:rooted_dirt
fill 16 222 -16 17 222 -16 minecraft:rooted_dirt
fill 20 222 -16 21 223 -16 minecraft:dirt
fill 23 222 -16 23 223 -11 minecraft:dirt
fill 26 222 -16 26 223 -14 minecraft:dirt
setblock 28 222 -16 minecraft:rooted_dirt
fill -21 222 -15 -21 222 -14 minecraft:rooted_dirt
fill -20 222 -15 -20 223 -15 minecraft:dirt
fill -19 222 -15 -19 222 -14 minecraft:rooted_dirt
fill -16 222 -15 -16 223 -15 minecraft:dirt
fill -14 222 -15 -14 223 -14 minecraft:dirt
fill -13 222 -15 -13 222 -14 minecraft:rooted_dirt
fill -9 222 -15 -8 222 -15 minecraft:dirt
setblock -7 222 -15 minecraft:rooted_dirt
setblock -4 222 -15 minecraft:dirt
setblock -1 222 -15 minecraft:dirt
fill 2 222 -15 2 222 -10 minecraft:dirt
setblock 6 222 -15 minecraft:dirt
fill 8 222 -15 8 222 -10 minecraft:dirt
fill 13 222 -15 14 223 -15 minecraft:dirt
fill 16 222 -15 16 223 -14 minecraft:dirt
setblock 17 222 -15 minecraft:rooted_dirt
setblock 20 222 -15 minecraft:rooted_dirt
fill 21 222 -15 21 223 -15 minecraft:dirt
fill 22 222 -15 22 222 -14 minecraft:rooted_dirt
fill 25 222 -15 25 223 -15 minecraft:dirt
setblock 27 222 -15 minecraft:rooted_dirt
fill 28 222 -15 28 223 -15 minecraft:dirt
fill 29 222 -15 29 222 -13 minecraft:rooted_dirt
fill -24 222 -14 -23 223 -14 minecraft:dirt
fill -20 222 -14 -20 222 -12 minecraft:rooted_dirt
fill -9 222 -14 -9 223 -13 minecraft:dirt
setblock -8 222 -14 minecraft:rooted_dirt
setblock -7 222 -14 minecraft:dirt
setblock -6 222 -14 minecraft:rooted_dirt
setblock -3 222 -14 minecraft:dirt
fill -2 222 -14 -1 222 -14 minecraft:rooted_dirt
setblock 1 222 -14 minecraft:rooted_dirt
setblock 4 222 -14 minecraft:dirt
fill 5 222 -14 6 222 -14 minecraft:rooted_dirt
fill 7 222 -14 7 222 -9 minecraft:dirt
fill 9 222 -14 10 223 -14 minecraft:dirt
setblock 11 222 -14 minecraft:rooted_dirt
setblock 13 222 -14 minecraft:rooted_dirt
fill 14 222 -14 14 223 -14 minecraft:dirt
fill 17 222 -14 17 223 -13 minecraft:dirt
fill 20 222 -14 20 223 -8 minecraft:dirt
setblock 21 222 -14 minecraft:rooted_dirt
fill 24 222 -14 24 223 -9 minecraft:dirt
fill 25 222 -14 25 222 -12 minecraft:rooted_dirt
fill 27 222 -14 27 223 -13 minecraft:dirt
setblock 28 222 -14 minecraft:rooted_dirt
fill -29 222 -13 -29 223 -13 minecraft:dirt
fill -27 222 -13 -27 223 -12 minecraft:dirt
fill -21 222 -13 -21 223 -11 minecraft:dirt
fill -19 222 -13 -18 223 -10 minecraft:dirt
fill -16 222 -13 -16 223 -13 minecraft:dirt
setblock -14 222 -13 minecraft:rooted_dirt
fill -13 222 -13 -13 223 -11 minecraft:dirt
setblock -10 222 -13 minecraft:rooted_dirt
fill -6 222 -13 -6 222 -12 minecraft:dirt
setblock -4 222 -13 minecraft:dirt
fill -2 222 -13 -2 222 -11 minecraft:dirt
setblock -1 222 -13 minecraft:rooted_dirt
fill 1 222 -13 1 222 -11 minecraft:dirt
fill 4 222 -13 5 222 -13 minecraft:rooted_dirt
fill 6 222 -13 6 222 -11 minecraft:dirt
fill 9 222 -13 9 223 -10 minecraft:dirt
setblock 10 222 -13 minecraft:rooted_dirt
setblock 16 222 -13 minecraft:rooted_dirt
fill 21 222 -13 22 223 -11 minecraft:dirt
setblock 26 222 -13 minecraft:rooted_dirt
fill 28 222 -13 28 223 -7 minecraft:dirt
fill 30 222 -13 30 223 -11 minecraft:dirt
fill -30 222 -12 -30 223 -9 minecraft:dirt
fill -26 222 -12 -26 223 -11 minecraft:dirt
fill -17 222 -12 -17 223 -10 minecraft:dirt
fill -14 222 -12 -14 223 -10 minecraft:dirt
fill -10 222 -12 -10 223 -10 minecraft:dirt
setblock -5 222 -12 minecraft:dirt
setblock -3 222 -12 minecraft:dirt
fill -1 222 -12 -1 222 -10 minecraft:dirt
fill 4 222 -12 5 222 -10 minecraft:dirt
fill 10 222 -12 10 223 -12 minecraft:dirt
fill 12 222 -12 12 223 -12 minecraft:dirt
fill 16 222 -12 16 223 -12 minecraft:dirt
fill 17 222 -12 18 222 -12 minecraft:rooted_dirt
fill 26 222 -12 26 223 -10 minecraft:dirt
setblock 27 222 -12 minecraft:rooted_dirt
fill 29 222 -12 29 223 -10 minecraft:dirt
fill -24 222 -11 -24 223 -10 minecraft:dirt
fill -20 222 -11 -20 223 -11 minecraft:dirt
fill -16 222 -11 -15 223 -6 minecraft:dirt
fill -8 222 -11 -8 223 -11 minecraft:dirt
fill 0 222 -11 0 222 -8 minecraft:rooted_dirt
setblock 3 222 -11 minecraft:rooted_dirt
fill 18 222 -11 18 223 -11 minecraft:dirt
setblock 19 222 -11 minecraft:rooted_dirt
fill 25 222 -11 25 223 -8 minecraft:dirt
fill 27 222 -11 27 223 -11 minecraft:dirt
fill -31 222 -10 -31 223 -5 minecraft:dirt
fill -28 222 -10 -28 223 -10 minecraft:dirt
setblock -13 222 -10 minecraft:rooted_dirt
fill -9 222 -10 -8 222 -10 minecraft:rooted_dirt
setblock 1 222 -10 minecraft:rooted_dirt
setblock 3 222 -10 minecraft:dirt
setblock 6 222 -10 minecraft:rooted_dirt
fill 19 222 -10 19 222 -3 minecraft:dirt
setblock 21 222 -10 minecraft:rooted_dirt
fill 22 222 -10 22 223 -10 minecraft:dirt
setblock 23 222 -10 minecraft:rooted_dirt
setblock 27 222 -10 minecraft:rooted_dirt
fill 31 222 -10 31 223 -10 minecraft:dirt
fill -29 222 -9 -29 223 -7 minecraft:dirt
fill -27 222 -9 -27 223 -8 minecraft:dirt
fill -23 222 -9 -23 223 -7 minecraft:dirt
fill -18 222 -9 -18 223 -7 minecraft:dirt
setblock -17 222 -9 minecraft:rooted_dirt
setblock -14 222 -9 minecraft:rooted_dirt
fill -9 222 -9 -8 223 -9 minecraft:dirt
setblock -7 222 -9 minecraft:rooted_dirt
fill -5 222 -9 -4 223 -9 minecraft:dirt
setblock -1 222 -9 minecraft:rooted_dirt
fill 1 222 -9 1 222 -8 minecraft:dirt
setblock 2 222 -9 minecraft:rooted_dirt
fill 12 222 -9 12 223 -8 minecraft:dirt
fill 21 222 -9 21 222 1 minecraft:dirt
fill 23 222 -9 23 223 -9 minecraft:dirt
fill 27 222 -9 27 223 -8 minecraft:dirt
fill -26 222 -8 -26 223 -5 minecraft:dirt
fill -17 222 -8 -17 223 -8 minecraft:dirt
fill -14 222 -8 -11 223 -8 minecraft:dirt
setblock -9 222 -8 minecraft:rooted_dirt
fill -8 222 -8 -7 223 -8 minecraft:dirt
fill 5 222 -8 5 223 -8 minecraft:dirt
fill 11 222 -8 11 223 -7 minecraft:dirt
fill -30 222 -7 -30 223 -7 minecraft:dirt
fill -25 222 -7 -24 223 -4 minecraft:dirt
fill -20 222 -7 -20 223 -7 minecraft:dirt
setblock -17 222 -7 minecraft:rooted_dirt
fill -14 222 -7 -14 223 -7 minecraft:dirt
fill -10 222 -7 -9 223 -7 minecraft:dirt
setblock -8 222 -7 minecraft:rooted_dirt
fill -7 222 -7 -7 223 -7 minecraft:dirt
fill -1 222 -7 0 223 -7 minecraft:dirt
fill 6 222 -7 6 223 -5 minecraft:dirt
fill 15 222 -7 15 222 -6 minecraft:dirt
fill 18 222 -7 18 222 -5 minecraft:dirt
setblock 20 222 -7 minecraft:rooted_dirt
fill 23 222 -7 23 222 -4 minecraft:dirt
fill 26 222 -7 26 223 -7 minecraft:dirt
fill -30 222 -6 -28 222 -6 minecraft:rooted_dirt
fill -27 222 -6 -27 223 -6 minecraft:dirt
fill -23 222 -6 -22 222 -6 minecraft:rooted_dirt
fill -17 222 -6 -17 223 -5 minecraft:dirt
fill -12 222 -6 -12 223 -2 minecraft:dirt
fill -9 222 -6 -8 223 -6 minecraft:dirt
fill -6 222 -6 -6 223 -6 minecraft:dirt
fill -3 222 -6 -2 223 -6 minecraft:dirt
fill 1 222 -6 4 223 -6 minecraft:dirt
setblock 5 222 -6 minecraft:rooted_dirt
fill 7 222 -6 7 222 -5 minecraft:rooted_dirt
fill 8 222 -6 9 223 -6 minecraft:dirt
fill 12 222 -6 12 223 -6 minecraft:dirt
fill 20 222 -6 20 222 -5 minecraft:dirt
fill 22 222 -6 22 222 -5 minecraft:dirt
fill 29 222 -6 29 223 -6 minecraft:dirt
setblock -30 222 -5 minecraft:rooted_dirt
fill -29 222 -5 -28 223 -5 minecraft:dirt
setblock -27 222 -5 minecraft:rooted_dirt
fill -23 222 -5 -21 223 -5 minecraft:dirt
fill -20 222 -5 -19 222 -5 minecraft:rooted_dirt
fill -13 222 -5 -13 222 -4 minecraft:rooted_dirt
fill -11 222 -5 -10 223 -5 minecraft:dirt
fill -2 222 -5 -2 223 -5 minecraft:dirt
fill 2 222 -5 5 223 -5 minecraft:dirt
fill 8 222 -5 8 223 -5 minecraft:dirt
setblock 9 222 -5 minecraft:rooted_dirt
fill 10 222 -5 10 223 -4 minecraft:dirt
setblock 17 222 -5 minecraft:rooted_dirt
fill 24 222 -5 24 222 -4 minecraft:dirt
fill 27 222 -5 27 223 -5 minecraft:dirt
setblock -31 222 -4 minecraft:rooted_dirt
fill -30 222 -4 -30 223 -2 minecraft:dirt
fill -29 222 -4 -28 222 -4 minecraft:rooted_dirt
fill -27 222 -4 -27 223 -2 minecraft:dirt
setblock -26 222 -4 minecraft:rooted_dirt
fill -23 222 -4 -23 222 -2 minecraft:rooted_dirt
fill -22 222 -4 -20 223 -3 minecraft:dirt
fill -19 222 -4 -19 222 -2 minecraft:rooted_dirt
fill -11 222 -4 -11 223 -3 minecraft:dirt
setblock -10 222 -4 minecraft:rooted_dirt
fill -7 222 -4 -7 223 -4 minecraft:dirt
fill -4 222 -4 -4 223 1 minecraft:dirt
fill 2 222 -4 2 223 -3 minecraft:dirt
setblock 3 222 -4 minecraft:rooted_dirt
fill 4 222 -4 5 223 -2 minecraft:dirt
setblock 6 222 -4 minecraft:rooted_dirt
fill 7 222 -4 7 223 -2 minecraft:dirt
setblock 8 222 -4 minecraft:rooted_dirt
fill 9 222 -4 9 223 -2 minecraft:dirt
fill 12 222 -4 12 223 -3 minecraft:dirt
setblock 15 222 -4 minecraft:rooted_dirt
fill 16 222 -4 17 222 -4 minecraft:dirt
setblock 18 222 -4 minecraft:rooted_dirt
setblock 20 222 -4 minecraft:rooted_dirt
fill 22 222 -4 22 222 -3 minecraft:rooted_dirt
fill 25 222 -4 25 222 -2 minecraft:dirt
fill 29 222 -4 29 223 -2 minecraft:dirt
fill 31 222 -4 31 223 -1 minecraft:dirt
fill -31 222 -3 -31 223 -3 minecraft:dirt
fill -29 222 -3 -28 223 -2 minecraft:dirt
fill -26 222 -3 -25 223 -2 minecraft:dirt
setblock -24 222 -3 minecraft:rooted_dirt
fill -15 222 -3 -15 223 -3 minecraft:dirt
fill -13 222 -3 -13 223 -3 minecraft:dirt
fill -10 222 -3 -10 223 -2 minecraft:dirt
fill -2 222 -3 -2 223 -3 minecraft:dirt
setblock 1 222 -3 minecraft:dirt
fill 3 222 -3 3 223 -2 minecraft:dirt
