fill 5 222 6 5 223 6 minecraft:dirt
fill 8 222 6 8 223 6 minecraft:dirt
fill 19 222 6 19 222 8 minecraft:dirt
setblock 23 222 6 minecraft:rooted_dirt
fill 25 222 6 26 222 6 minecraft:dirt
fill 28 222 6 28 223 6 minecraft:dirt
fill -28 222 7 -26 223 8 minecraft:dirt
fill -23 222 7 -23 223 7 minecraft:dirt
setblock -21 222 7 minecraft:rooted_dirt
fill -15 222 7 -15 223 7 minecraft:dirt
setblock -10 222 7 minecraft:rooted_dirt
fill -9 222 7 -9 223 13 minecraft:dirt
fill -8 222 7 -7 222 7 minecraft:rooted_dirt
fill -6 222 7 -6 223 7 minecraft:dirt
fill -2 222 7 -2 223 7 minecraft:dirt
fill 2 222 7 3 223 12 minecraft:dirt
fill 4 222 7 5 222 7 minecraft:rooted_dirt
fill 9 222 7 10 223 7 minecraft:dirt
setblock 22 222 7 minecraft:rooted_dirt
fill 23 222 7 23 223 11 minecraft:dirt
setblock 25 222 7 minecraft:rooted_dirt
fill 26 222 7 27 223 7 minecraft:dirt
fill -23 222 8 -23 222 9 minecraft:rooted_dirt
fill -21 222 8 -21 223 9 minecraft:dirt
setblock -19 222 8 minecraft:rooted_dirt
fill -10 222 8 -10 223 13 minecraft:dirt
fill -8 222 8 -7 223 9 minecraft:dirt
setblock -6 222 8 minecraft:rooted_dirt
setblock -2 222 8 minecraft:rooted_dirt
fill 4 222 8 5 223 8 minecraft:dirt
fill 10 222 8 10 223 8 minecraft:dirt
fill 22 222 8 22 223 10 minecraft:dirt
fill 24 222 8 24 222 9 minecraft:rooted_dirt
fill 25 222 8 25 223 11 minecraft:dirt
fill 27 222 8 27 223 9 minecraft:dirt
fill 29 222 8 29 223 8 minecraft:dirt
fill -27 222 9 -26 222 9 minecraft:rooted_dirt
setblock -22 222 9 minecraft:rooted_dirt
fill -19 222 9 -18 223 9 minecraft:dirt
fill -15 222 9 -15 223 14 minecraft:dirt
setblock -11 222 9 minecraft:rooted_dirt
fill -6 222 9 -6 223 9 minecraft:dirt
fill -2 222 9 -2 223 11 minecraft:dirt
fill -1 222 9 -1 222 10 minecraft:rooted_dirt
fill 0 222 9 0 223 11 minecraft:dirt
setblock 1 222 9 minecraft:rooted_dirt
fill 4 222 9 5 222 9 minecraft:rooted_dirt
fill 6 222 9 7 223 9 minecraft:dirt
fill 9 222 9 9 223 9 minecraft:dirt
fill 13 222 9 13 223 9 minecraft:dirt
fill 20 222 9 21 223 9 minecraft:dirt
fill 26 222 9 26 223 14 minecraft:dirt
fill -26 222 10 -26 223 10 minecraft:dirt
fill -23 222 10 -23 223 10 minecraft:dirt
fill -17 222 10 -17 222 13 minecraft:rooted_dirt
fill -16 222 10 -16 223 10 minecraft:dirt
fill -14 222 10 -13 223 10 minecraft:dirt
fill -11 222 10 -11 223 12 minecraft:dirt
fill -8 222 10 -8 223 10 minecraft:dirt
fill -7 222 10 -6 222 10 minecraft:rooted_dirt
fill 1 222 10 1 223 11 minecraft:dirt
fill 4 222 10 4 223 10 minecraft:dirt
fill 5 222 10 6 222 10 minecraft:rooted_dirt
fill 8 222 10 8 223 10 minecraft:dirt
fill 14 222 10 14 223 10 minecraft:dirt
fill 20 222 10 20 223 12 minecraft:dirt
setblock 21 222 10 minecraft:rooted_dirt
fill 24 222 10 24 223 10 minecraft:dirt
fill -27 222 11 -27 223 11 minecraft:dirt
fill -18 222 11 -18 223 16 minecraft:dirt
fill -16 222 11 -16 222 12 minecraft:rooted_dirt
setblock -14 222 11 minecraft:rooted_dirt
fill -12 222 11 -12 223 11 minecraft:dirt
setblock -8 222 11 minecraft:rooted_dirt
fill -7 222 11 -6 223 11 minecraft:dirt
fill -1 222 11 -1 223 11 minecraft:dirt
setblock 4 222 11 minecraft:rooted_dirt
fill 5 222 11 6 223 13 minecraft:dirt
fill 10 222 11 13 223 11 minecraft:dirt
fill 21 222 11 21 223 11 minecraft:dirt
setblock 22 222 11 minecraft:rooted_dirt
setblock 24 222 11 minecraft:rooted_dirt
fill 27 222 11 27 223 12 minecraft:dirt
fill -25 222 12 -25 223 13 minecraft:dirt
setblock -24 222 12 minecraft:rooted_dirt
fill -23 222 12 -23 223 18 minecraft:dirt
fill -20 222 12 -20 223 12 minecraft:dirt
fill -14 222 12 -14 223 13 minecraft:dirt
fill -8 222 12 -7 223 14 minecraft:dirt
setblock -6 222 12 minecraft:rooted_dirt
fill 4 222 12 4 223 13 minecraft:dirt
fill 7 222 12 10 223 12 minecraft:dirt
setblock 21 222 12 minecraft:rooted_dirt
fill 22 222 12 22 223 13 minecraft:dirt
setblock 23 222 12 minecraft:rooted_dirt
fill 24 222 12 24 223 12 minecraft:dirt
setblock 25 222 12 minecraft:rooted_dirt
fill -24 222 13 -24 223 14 minecraft:dirt
fill -16 222 13 -16 223 14 minecraft:dirt
fill -12 222 13 -12 223 13 minecraft:dirt
fill -6 222 13 -6 223 13 minecraft:dirt
setblock 2 222 13 minecraft:rooted_dirt
fill 3 222 13 3 223 14 minecraft:dirt
fill 8 222 13 8 223 13 minecraft:dirt
fill 13 222 13 14 223 13 minecraft:dirt
fill 16 222 13 16 223 13 minecraft:dirt
fill 18 222 13 18 223 13 minecraft:dirt
fill 23 222 13 23 223 14 minecraft:dirt
fill 24 222 13 24 222 14 minecraft:rooted_dirt
fill 25 222 13 25 223 13 minecraft:dirt
fill -26 222 14 -26 223 14 minecraft:dirt
setblock -25 222 14 minecraft:rooted_dirt
setblock -22 222 14 minecraft:rooted_dirt
fill -21 222 14 -19 223 14 minecraft:dirt
fill -17 222 14 -17 223 14 minecraft:dirt
fill -11 222 14 -11 223 14 minecraft:dirt
setblock -9 222 14 minecraft:rooted_dirt
fill 0 222 14 2 223 14 minecraft:dirt
setblock 4 222 14 minecraft:rooted_dirt
fill 5 222 14 5 223 15 minecraft:dirt
fill 9 222 14 9 223 14 minecraft:dirt
fill 11 222 14 13 223 15 minecraft:dirt
fill 19 222 14 19 223 14 minecraft:dirt
setblock 25 222 14 minecraft:rooted_dirt
fill -25 222 15 -25 223 16 minecraft:dirt
setblock -24 222 15 minecraft:rooted_dirt
fill -22 222 15 -22 223 15 minecraft:dirt
setblock -21 222 15 minecraft:rooted_dirt
fill -20 222 15 -19 223 17 minecraft:dirt
fill -8 222 15 -8 223 15 minecraft:dirt
fill -5 222 15 -5 223 15 minecraft:dirt
fill -2 222 15 -2 223 26 minecraft:dirt
setblock -1 222 15 minecraft:rooted_dirt
fill 0 222 15 1 223 15 minecraft:dirt
fill 2 222 15 2 222 16 minecraft:rooted_dirt
fill 4 222 15 4 223 15 minecraft:dirt
fill 10 222 15 10 223 17 minecraft:dirt
fill 14 222 15 14 223 16 minecraft:dirt
fill 20 222 15 20 223 17 minecraft:dirt
setblock 23 222 15 minecraft:rooted_dirt
fill 24 222 15 25 223 15 minecraft:dirt
fill -24 222 16 -24 223 18 minecraft:dirt
setblock -22 222 16 minecraft:rooted_dirt
fill -21 222 16 -21 223 18 minecraft:dirt
fill -16 222 16 -16 223 17 minecraft:dirt
setblock -12 222 16 minecraft:rooted_dirt
fill -7 222 16 -6 223 16 minecraft:dirt
fill -4 222 16 -4 223 20 minecraft:dirt
fill -1 222 16 0 223 16 minecraft:dirt
setblock 1 222 16 minecraft:rooted_dirt
fill 8 222 16 9 223 16 minecraft:dirt
fill 11 222 16 12 223 18 minecraft:dirt
setblock 13 222 16 minecraft:rooted_dirt
fill 21 222 16 21 223 16 minecraft:dirt
fill 23 222 16 24 223 17 minecraft:dirt
fill -22 222 17 -22 223 17 minecraft:dirt
fill -12 222 17 -12 223 19 minecraft:dirt
fill -10 222 17 -10 223 20 minecraft:dirt
fill -5 222 17 -5 223 20 minecraft:dirt
fill -3 222 17 -3 222 18 minecraft:rooted_dirt
fill -1 222 17 0 222 17 minecraft:rooted_dirt
fill 1 222 17 2 223 19 minecraft:dirt
fill 5 222 17 5 223 17 minecraft:dirt
fill 13 222 17 13 223 18 minecraft:dirt
fill 16 222 17 16 223 18 minecraft:dirt
fill 19 222 17 19 223 17 minecraft:dirt
fill 22 222 17 22 223 18 minecraft:dirt
setblock -22 222 18 minecraft:rooted_dirt
fill -20 222 18 -20 223 19 minecraft:dirt
setblock -19 222 18 minecraft:rooted_dirt
fill -17 222 18 -17 223 18 minecraft:dirt
fill -15 222 18 -15 223 18 minecraft:dirt
fill -13 222 18 -13 223 22 minecraft:dirt
fill -11 222 18 -11 223 23 minecraft:dirt
fill -8 222 18 -8 223 19 minecraft:dirt
fill -6 222 18 -6 223 18 minecraft:dirt
fill -1 222 18 0 223 18 minecraft:dirt
fill -9 222 19 -9 223 21 minecraft:dirt
fill -7 222 19 -7 223 27 minecraft:dirt
setblock -6 222 19 minecraft:rooted_dirt
fill -3 222 19 -3 223 22 minecraft:dirt
fill -1 222 19 0 222 19 minecraft:rooted_dirt
fill 3 222 19 3 223 19 minecraft:dirt
fill 5 222 19 6 223 19 minecraft:dirt
fill 10 222 19 10 223 20 minecraft:dirt
fill 15 222 19 15 223 19 minecraft:dirt
fill 20 222 19 20 223 19 minecraft:dirt
fill 23 222 19 23 223 19 minecraft:dirt
setblock -12 222 20 minecraft:rooted_dirt
setblock -8 222 20 minecraft:rooted_dirt
fill -6 222 20 -6 223 20 minecraft:dirt
fill -1 222 20 1 223 21 minecraft:dirt
setblock 2 222 20 minecraft:rooted_dirt
fill 9 222 20 9 223 20 minecraft:dirt
fill 22 222 20 22 223 20 minecraft:dirt
fill -22 222 21 -22 223 21 minecraft:dirt
fill -19 222 21 -19 223 21 minecraft:dirt
fill -17 222 21 -16 223 21 minecraft:dirt
fill -12 222 21 -12 223 25 minecraft:dirt
setblock -10 222 21 minecraft:rooted_dirt
fill -8 222 21 -8 223 21 minecraft:dirt
fill -6 222 21 -4 222 21 minecraft:rooted_dirt
fill 2 222 21 2 223 21 minecraft:dirt
fill 7 222 21 7 223 21 minecraft:dirt
fill 12 222 21 12 223 23 minecraft:dirt
setblock 41 222 21 minecraft:stone
fill -21 222 22 -20 223 22 minecraft:dirt
fill -18 222 22 -18 223 22 minecraft:dirt
fill -10 222 22 -10 223 23 minecraft:dirt
fill -9 222 22 -8 222 23 minecraft:rooted_dirt
fill -6 222 22 -6 223 24 minecraft:dirt
setblock -5 222 22 minecraft:rooted_dirt
fill -4 222 22 -4 223 22 minecraft:dirt
setblock -1 222 22 minecraft:rooted_dirt
fill 9 222 22 9 223 23 minecraft:dirt
fill 11 222 22 11 223 24 minecraft:dirt
fill 13 222 22 15 223 22 minecraft:dirt
setblock 16 222 22 minecraft:rooted_dirt
fill 17 222 22 19 223 22 minecraft:dirt
fill 38 222 22 39 222 22 minecraft:stone
