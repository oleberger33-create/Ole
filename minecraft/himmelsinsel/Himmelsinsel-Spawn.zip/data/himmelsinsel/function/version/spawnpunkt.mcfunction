# Ab Minecraft 1.21.11: Gamerules heißen jetzt snake_case, Spawn mit Blickrichtung
setworldspawn 0 225 6 180 0
gamerule respawn_radius 0
