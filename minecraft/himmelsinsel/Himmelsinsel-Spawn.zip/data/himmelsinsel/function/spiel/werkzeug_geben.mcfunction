tag @s add hs.werkzeug
give @s minecraft:iron_sword
give @s minecraft:iron_pickaxe
give @s minecraft:iron_axe
give @s minecraft:iron_shovel
