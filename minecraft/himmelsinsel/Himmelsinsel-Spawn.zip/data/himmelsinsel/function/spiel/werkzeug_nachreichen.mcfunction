# Für alle, die das Starterpaket schon vor den Werkzeugen bekommen haben
function himmelsinsel:spiel/werkzeug_geben
tellraw @s ["",{"text":"✦ Nachlieferung zum Starterpaket: ","color":"gold","bold":true},{"text":"Eisenschwert, -spitzhacke, -axt und -schaufel!","color":"yellow"}]
execute at @s run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.8 1.2
