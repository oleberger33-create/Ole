effect give @a[tag=hs.fall] minecraft:slow_falling 3 0 true
execute as @a[tag=hs.fall] at @s if block ~ ~ ~ minecraft:water run tag @s remove hs.fall
tag @a[tag=hs.fall,nbt={OnGround:1b}] remove hs.fall
schedule function himmelsinsel:spiel/halbsekunde 10t
