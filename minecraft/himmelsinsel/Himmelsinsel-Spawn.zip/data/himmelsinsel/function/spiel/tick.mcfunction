# /trigger spawn
scoreboard players enable @a spawn
execute as @a[scores={spawn=1..}] run function himmelsinsel:spiel/spawn_befehl
# Schutzzone: auf der Insel wird aus Überleben Abenteuer
execute if score #schutz hs.config matches 1 run function himmelsinsel:spiel/schutz
execute unless score #schutz hs.config matches 1 as @a[tag=hs.adv] run function himmelsinsel:spiel/schutz_raus
# Fallschirm für alle, die von der Insel springen
execute if score #fallschirm hs.config matches 1 as @a[x=-48,y=184,z=-48,dx=96,dy=36,dz=96,tag=!hs.fall] run function himmelsinsel:spiel/fallschirm_an
# Himmelstor: wer im Portal steht, kommt hoch (auch falls das Endtransitportal selbst nicht teleportiert)
execute as @a[x=-3,y=-64,z=33,dx=6,dy=247,dz=8] at @s if block ~ ~ ~ minecraft:end_gateway run function himmelsinsel:spiel/zum_spawn_still
# Nach dem Tod und beim Einloggen: wer unten unter der Insel steht, kommt hoch
execute as @e[type=minecraft:player,scores={hs.tod=1..}] run function himmelsinsel:spiel/nach_tod
execute as @a[scores={hs.weg=1..}] run function himmelsinsel:spiel/nach_login
