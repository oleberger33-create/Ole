execute unless block 15 225 -5 minecraft:anvil run setblock 15 225 -5 minecraft:anvil[facing=east]
execute unless block 17 225 -5 minecraft:anvil run setblock 17 225 -5 minecraft:anvil[facing=east]
execute unless block 19 225 -5 minecraft:anvil run setblock 19 225 -5 minecraft:anvil[facing=east]
