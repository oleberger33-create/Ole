function himmelsinsel:spiel/zum_spawn_still
scoreboard players operation @s hs.cd = #abklingzeit hs.config
tellraw @s {"text":"✦ Zurück auf der Himmelsinsel!","color":"light_purple"}
