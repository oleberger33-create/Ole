execute store result storage himmelsinsel:home x double 0.01 run scoreboard players get @s hs.hx
execute store result storage himmelsinsel:home y double 0.01 run scoreboard players get @s hs.hy
execute store result storage himmelsinsel:home z double 0.01 run scoreboard players get @s hs.hz
execute store result storage himmelsinsel:home yaw float 1 run scoreboard players get @s hs.hr
data modify storage himmelsinsel:home dim set value "minecraft:overworld"
execute if score @s hs.hd matches 1 run data modify storage himmelsinsel:home dim set value "minecraft:the_nether"
execute if score @s hs.hd matches 2 run data modify storage himmelsinsel:home dim set value "minecraft:the_end"
execute at @s run particle minecraft:portal ~ ~1 ~ 0.4 0.8 0.4 0.5 40
function himmelsinsel:spiel/home_tp with storage himmelsinsel:home
scoreboard players operation @s hs.cd = #abklingzeit hs.config
execute at @s run playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 0.7 1.1
execute at @s run particle minecraft:portal ~ ~1 ~ 0.4 0.8 0.4 0.5 40
tellraw @s {"text":"⌂ Willkommen zu Hause!","color":"gold"}
