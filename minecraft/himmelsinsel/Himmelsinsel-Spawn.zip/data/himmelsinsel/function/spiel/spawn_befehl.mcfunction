execute if score #spawn_befehl hs.config matches 0 run tellraw @s {"text":"Der Spawn-Befehl ist auf diesem Server ausgeschaltet.","color":"red"}
execute if score #spawn_befehl hs.config matches 1 if score @s hs.cd matches 1.. run tellraw @s ["",{"text":"Bitte warte noch ","color":"red"},{"score":{"name":"@s","objective":"hs.cd"},"color":"yellow"},{"text":" Sekunden.","color":"red"}]
execute if score #spawn_befehl hs.config matches 1 unless score @s hs.cd matches 1.. run function himmelsinsel:spiel/zum_spawn
scoreboard players set @s spawn 0
