gamemode adventure @s
tag @s add hs.adv
title @s actionbar {"text":"Spawn-Bereich: Hier kann nichts abgebaut werden","color":"light_purple"}
