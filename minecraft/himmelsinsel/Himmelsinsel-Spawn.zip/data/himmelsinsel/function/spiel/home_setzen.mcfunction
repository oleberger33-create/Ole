scoreboard players set @s sethome 0
execute if score #homes hs.config matches 0 run tellraw @s {"text":"Homes sind auf diesem Server ausgeschaltet.","color":"red"}
execute if score #homes hs.config matches 1 run function himmelsinsel:spiel/home_speichern
