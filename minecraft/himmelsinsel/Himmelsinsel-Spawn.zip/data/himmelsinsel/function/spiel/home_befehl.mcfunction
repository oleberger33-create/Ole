scoreboard players set @s home 0
execute if score #homes hs.config matches 0 run tellraw @s {"text":"Homes sind auf diesem Server ausgeschaltet.","color":"red"}
execute if score #homes hs.config matches 1 unless score @s hs.hd matches 0.. run tellraw @s ["",{"text":"Du hast noch kein Zuhause. Stell dich an die Stelle und nutze ","color":"red"},{"text":"/trigger sethome","color":"aqua","underlined":true,"click_event":{"action":"run_command","command":"/trigger sethome"},"hover_event":{"action":"show_text","value":"Klicken, um hier dein Zuhause zu setzen"}}]
execute if score #homes hs.config matches 1 if score @s hs.hd matches 0.. if score @s hs.cd matches 1.. run tellraw @s ["",{"text":"Bitte warte noch ","color":"red"},{"score":{"name":"@s","objective":"hs.cd"},"color":"yellow"},{"text":" Sekunden.","color":"red"}]
execute if score #homes hs.config matches 1 if score @s hs.hd matches 0.. unless score @s hs.cd matches 1.. run function himmelsinsel:spiel/home_reisen
