tag @s add hs.fall
effect give @s minecraft:slow_falling 5 0 true
title @s actionbar {"text":"☂ Fallschirm geöffnet – gute Landung!","color":"aqua"}
