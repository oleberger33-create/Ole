# Wiederbelebt am Weltspawn, aber unten gelandet? Dann nach oben. Wer ein eigenes Bett hat, bleibt dort.
scoreboard players set @s hs.tod 0
execute if score #todespunkt hs.config matches 1 run function himmelsinsel:spiel/todespunkt
execute unless data entity @s respawn if entity @s[x=-36,y=-64,z=-36,dx=72,dy=247,dz=72] run function himmelsinsel:spiel/zum_spawn_still
