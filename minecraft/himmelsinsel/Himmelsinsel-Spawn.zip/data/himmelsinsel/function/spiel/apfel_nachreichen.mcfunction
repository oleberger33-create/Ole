# Für alle, die das Starterpaket schon vor dem Apfel bekommen haben
function himmelsinsel:spiel/apfel_geben
tellraw @s ["",{"text":"✦ Nachlieferung zum Starterpaket: ","color":"gold","bold":true},{"text":"ein verzauberter goldener Apfel!","color":"yellow"}]
execute at @s run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.8 1.2
