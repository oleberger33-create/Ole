gamemode survival @s[gamemode=adventure]
tag @s remove hs.adv
