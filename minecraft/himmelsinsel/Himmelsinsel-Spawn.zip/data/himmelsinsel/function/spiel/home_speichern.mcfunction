# Position auf ein Hundertstel genau, dazu Blickrichtung und Dimension
execute store result score @s hs.hx run data get entity @s Pos[0] 100
execute store result score @s hs.hy run data get entity @s Pos[1] 100
execute store result score @s hs.hz run data get entity @s Pos[2] 100
execute store result score @s hs.hr run data get entity @s Rotation[0]
scoreboard players set @s hs.hd 0
execute if dimension minecraft:the_nether run scoreboard players set @s hs.hd 1
execute if dimension minecraft:the_end run scoreboard players set @s hs.hd 2
tellraw @s ["",{"text":"⌂ Zuhause gesetzt! ","color":"gold","bold":true},{"text":"Zurück kommst du jederzeit mit ","color":"gray"},{"text":"/trigger home","color":"aqua","underlined":true,"click_event":{"action":"run_command","command":"/trigger home"},"hover_event":{"action":"show_text","value":"Klicken, um nach Hause zu reisen"}}]
execute at @s run playsound minecraft:block.note_block.chime player @s ~ ~ ~ 0.8 1.4
