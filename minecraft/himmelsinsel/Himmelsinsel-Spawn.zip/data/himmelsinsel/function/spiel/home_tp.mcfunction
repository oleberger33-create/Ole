# Makro: Werte kommen aus storage himmelsinsel:home
$execute in $(dim) run tp @s $(x) $(y) $(z) $(yaw) 0
