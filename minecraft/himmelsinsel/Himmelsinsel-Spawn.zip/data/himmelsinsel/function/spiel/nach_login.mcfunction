# #login_spawn: 0 = nie, 1 = wer sich unter der Insel ausgeloggt hat, 2 = jeder bei jedem Login
scoreboard players set @s hs.weg 0
execute if score #login_spawn hs.config matches 2 run function himmelsinsel:spiel/zum_spawn_still
execute if score #login_spawn hs.config matches 1 if entity @s[x=-36,y=-64,z=-36,dx=72,dy=247,dz=72] run function himmelsinsel:spiel/zum_spawn_still
