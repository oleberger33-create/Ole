scoreboard players remove @a[scores={hs.cd=1..}] hs.cd 1
execute if score #fertig hs.state matches 1 run function himmelsinsel:spiel/pflege
execute if score #fertig hs.state matches 1 as @a[tag=!hs.gesehen] run function himmelsinsel:spiel/willkommen
schedule function himmelsinsel:spiel/sekunde 20t
