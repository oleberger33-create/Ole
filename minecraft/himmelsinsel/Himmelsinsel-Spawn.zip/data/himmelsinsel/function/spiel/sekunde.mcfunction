scoreboard players remove @a[scores={hs.cd=1..}] hs.cd 1
execute if score #fertig hs.state matches 1 run function himmelsinsel:spiel/pflege
execute if score #fertig hs.state matches 1 as @a[tag=!hs.gesehen] run function himmelsinsel:spiel/willkommen
execute if score #starterpaket hs.config matches 1 as @e[type=minecraft:player,tag=!hs.starter] run function himmelsinsel:spiel/starterpaket
execute if score #starterpaket hs.config matches 1 as @e[type=minecraft:player,tag=hs.starter,tag=!hs.werkzeug] run function himmelsinsel:spiel/werkzeug_nachreichen
schedule function himmelsinsel:spiel/sekunde 20t
