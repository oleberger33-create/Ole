scoreboard players remove @a[scores={hs.cd=1..}] hs.cd 1
execute if score #fertig hs.state matches 1 run function himmelsinsel:spiel/pflege
execute if score #fertig hs.state matches 1 as @a[tag=!hs.gesehen] run function himmelsinsel:spiel/willkommen
execute if score #fertig hs.state matches 1 as @a[tag=hs.gesehen,tag=!hs.neu1] run function himmelsinsel:spiel/neuigkeiten
execute if score #fertig hs.state matches 1 if score #stufe hs.state matches 0 unless score #ausbau hs.state matches 1.. unless score #ausbau_stufe hs.state matches 1.. run function himmelsinsel:ausbau/start
execute if score #starterpaket hs.config matches 1 as @e[type=minecraft:player,tag=!hs.starter] run function himmelsinsel:spiel/starterpaket
execute if score #starterpaket hs.config matches 1 as @e[type=minecraft:player,tag=hs.starter,tag=!hs.werkzeug] run function himmelsinsel:spiel/werkzeug_nachreichen
execute if score #starterpaket hs.config matches 1 as @e[type=minecraft:player,tag=hs.starter,tag=!hs.apfel] run function himmelsinsel:spiel/apfel_nachreichen
schedule function himmelsinsel:spiel/sekunde 20t
