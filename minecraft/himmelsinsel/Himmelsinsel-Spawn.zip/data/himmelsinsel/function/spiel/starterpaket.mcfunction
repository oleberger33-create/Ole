# Einmal pro Spieler. Rüstung und Schild werden direkt angelegt, wenn der Platz frei ist,
# sonst landen sie im Inventar (bei vollem Inventar fallen Sachen vor die Füße).
tag @s add hs.starter
execute unless items entity @s armor.head * run item replace entity @s armor.head with minecraft:iron_helmet
execute if items entity @s armor.head * unless items entity @s armor.head minecraft:iron_helmet run give @s minecraft:iron_helmet
execute unless items entity @s armor.chest * run item replace entity @s armor.chest with minecraft:iron_chestplate
execute if items entity @s armor.chest * unless items entity @s armor.chest minecraft:iron_chestplate run give @s minecraft:iron_chestplate
execute unless items entity @s armor.legs * run item replace entity @s armor.legs with minecraft:iron_leggings
execute if items entity @s armor.legs * unless items entity @s armor.legs minecraft:iron_leggings run give @s minecraft:iron_leggings
execute unless items entity @s armor.feet * run item replace entity @s armor.feet with minecraft:iron_boots
execute if items entity @s armor.feet * unless items entity @s armor.feet minecraft:iron_boots run give @s minecraft:iron_boots
execute unless items entity @s weapon.offhand * run item replace entity @s weapon.offhand with minecraft:shield
execute if items entity @s weapon.offhand * unless items entity @s weapon.offhand minecraft:shield run give @s minecraft:shield
function himmelsinsel:spiel/werkzeug_geben
give @s minecraft:emerald 64
give @s minecraft:bow
give @s minecraft:arrow 32
give @s minecraft:cooked_beef 16
tellraw @s ["",{"text":"✦ Starterpaket erhalten: ","color":"gold","bold":true},{"text":"Eisenrüstung, Schild, Eisenwerkzeuge, Bogen mit 32 Pfeilen, 16 Steaks und 64 Smaragde für die Zauberbibliothek!","color":"yellow"}]
execute at @s run playsound minecraft:entity.player.levelup player @s ~ ~ ~ 0.8 1.2
