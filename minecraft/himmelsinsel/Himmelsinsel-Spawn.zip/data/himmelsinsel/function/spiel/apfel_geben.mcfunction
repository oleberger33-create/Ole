tag @s add hs.apfel
give @s minecraft:enchanted_golden_apple
