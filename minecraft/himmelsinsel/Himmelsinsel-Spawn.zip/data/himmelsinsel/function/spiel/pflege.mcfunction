# Abgenutzte Ambosse ersetzen, Monster von der Insel entfernen, Glitzern
execute if loaded 15 225 -5 run function himmelsinsel:spiel/ambosse
kill @e[type=#himmelsinsel:monster,x=-48,y=184,z=-48,dx=96,dy=90,dz=96]
execute at @e[type=minecraft:text_display,tag=hs.bodenschild,limit=1] positioned ~-0.5 ~-4.5 ~3.5 align xyz run function himmelsinsel:spiel/bodenstation
particle minecraft:enchant 0.5 227 -17.5 2.5 1.5 2.5 0.6 25
