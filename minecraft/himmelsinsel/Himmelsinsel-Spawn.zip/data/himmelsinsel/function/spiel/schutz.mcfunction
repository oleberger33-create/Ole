tag @a remove hs.in
tag @a[x=-48,y=184,z=-48,dx=96,dy=90,dz=96] add hs.in
execute at @e[type=minecraft:text_display,tag=hs.bodenschild,limit=1] positioned ~-8 ~-10.7 ~-4 run tag @a[dx=15,dy=16,dz=15] add hs.in
execute as @a[tag=hs.in,gamemode=survival] run function himmelsinsel:spiel/schutz_rein
execute as @a[tag=hs.adv,tag=!hs.in] run function himmelsinsel:spiel/schutz_raus
