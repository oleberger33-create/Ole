# Schaltet alles ab. Insel, Händler und Schilder bleiben stehen.
schedule clear himmelsinsel:spiel/sekunde
schedule clear himmelsinsel:spiel/halbsekunde
execute as @a[tag=hs.adv] run gamemode survival @s[gamemode=adventure]
tag @a remove hs.adv
tag @a remove hs.in
tag @a remove hs.fall
tag @a remove hs.gesehen
tag @a remove hs.neu1
forceload remove -48 -48 47 47
scoreboard objectives remove hs.state
scoreboard objectives remove hs.config
scoreboard objectives remove hs.cd
scoreboard objectives remove spawn
scoreboard objectives remove hs.tod
scoreboard objectives remove hs.weg
scoreboard objectives remove home
scoreboard objectives remove sethome
scoreboard objectives remove hs.hx
scoreboard objectives remove hs.hy
scoreboard objectives remove hs.hz
scoreboard objectives remove hs.hr
scoreboard objectives remove hs.hd
scoreboard objectives remove hs.tx
scoreboard objectives remove hs.ty
scoreboard objectives remove hs.tz
scoreboard objectives remove hs.herz
tellraw @s {"text":"Himmelsinsel deaktiviert. Jetzt noch das Datapack abschalten: /datapack list zeigt den Namen, dann /datapack disable <name>","color":"yellow"}
