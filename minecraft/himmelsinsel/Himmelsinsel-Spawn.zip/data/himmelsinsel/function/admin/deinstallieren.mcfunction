# Schaltet alles ab. Insel, Händler und Schilder bleiben stehen.
schedule clear himmelsinsel:spiel/sekunde
schedule clear himmelsinsel:spiel/halbsekunde
execute as @a[tag=hs.adv] run gamemode survival @s[gamemode=adventure]
tag @a remove hs.adv
tag @a remove hs.in
tag @a remove hs.fall
tag @a remove hs.gesehen
forceload remove -48 -48 47 47
scoreboard objectives remove hs.state
scoreboard objectives remove hs.config
scoreboard objectives remove hs.cd
scoreboard objectives remove spawn
scoreboard objectives remove hs.tod
scoreboard objectives remove hs.weg
tellraw @s {"text":"Himmelsinsel deaktiviert. Jetzt noch das Datapack abschalten: /datapack list zeigt den Namen, dann /datapack disable <name>","color":"yellow"}
