# Startet den Bau in einer bestehenden Welt (in neuen Welten passiert das automatisch)
execute if score #fertig hs.state matches 1 run tellraw @s {"text":"Die Insel steht schon. Neu bauen: /function himmelsinsel:admin/neu_bauen","color":"yellow"}
execute unless score #fertig hs.state matches 1 if score #stufe hs.state matches ..0 run function himmelsinsel:bau/vorbereiten
