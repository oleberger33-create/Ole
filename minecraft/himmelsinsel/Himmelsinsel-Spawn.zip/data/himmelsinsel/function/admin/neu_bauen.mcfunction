# Baut Insel, Händler und Schilder komplett neu (z. B. nach einem Update des Datapacks)
scoreboard players set #fertig hs.state 0
function himmelsinsel:bau/vorbereiten
tellraw @a {"text":"[Himmelsinsel] Wird neu gebaut …","color":"light_purple"}
