# Wird bei jedem Serverstart und /reload ausgeführt
scoreboard objectives add hs.state dummy
scoreboard objectives add hs.config dummy
scoreboard objectives add hs.cd dummy
scoreboard objectives add spawn trigger "Zum Spawn"
execute unless score #stufe hs.state = #stufe hs.state run scoreboard players set #stufe hs.state 0
execute if score #stufe hs.state matches -1 run tellraw @a ["",{"text":"[Himmelsinsel] ","color":"light_purple"},{"text":"Bestehende Welt erkannt – es wurde noch nichts gebaut. Ein Admin startet den Bau mit ","color":"white"},{"text":"/function himmelsinsel:admin/bauen","color":"aqua"},{"text":" (Einstellungen vorher mit /function himmelsinsel:admin/info prüfen).","color":"gray"}]
# Einstellungen – werden nur beim allerersten Laden gesetzt (siehe README)
execute unless score #spawn_befehl hs.config = #spawn_befehl hs.config run scoreboard players set #spawn_befehl hs.config 1
execute unless score #abklingzeit hs.config = #abklingzeit hs.config run scoreboard players set #abklingzeit hs.config 30
execute unless score #schutz hs.config = #schutz hs.config run scoreboard players set #schutz hs.config 1
execute unless score #fallschirm hs.config = #fallschirm hs.config run scoreboard players set #fallschirm hs.config 1
execute unless score #bodenstation hs.config = #bodenstation hs.config run scoreboard players set #bodenstation hs.config 1
schedule function himmelsinsel:spiel/sekunde 20t
schedule function himmelsinsel:spiel/halbsekunde 10t
