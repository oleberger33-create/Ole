# Wird bei jedem Serverstart und /reload ausgeführt
scoreboard objectives add hs.state dummy
scoreboard objectives add hs.config dummy
scoreboard objectives add hs.cd dummy
scoreboard objectives add spawn trigger "Zum Spawn"
scoreboard objectives add hs.tod deathCount
scoreboard objectives add hs.weg minecraft.custom:minecraft.leave_game
scoreboard objectives add home trigger "Nach Hause"
scoreboard objectives add sethome trigger "Zuhause setzen"
scoreboard objectives add hs.hx dummy
scoreboard objectives add hs.hy dummy
scoreboard objectives add hs.hz dummy
scoreboard objectives add hs.hr dummy
scoreboard objectives add hs.hd dummy
scoreboard objectives add hs.tx dummy
scoreboard objectives add hs.ty dummy
scoreboard objectives add hs.tz dummy
scoreboard objectives add hs.herz health {"text":"❤","color":"red"}
scoreboard objectives modify hs.herz rendertype hearts
execute unless score #stufe hs.state = #stufe hs.state run scoreboard players set #stufe hs.state 0
execute if score #stufe hs.state matches -1 run tellraw @a ["",{"text":"[Himmelsinsel] ","color":"light_purple"},{"text":"Bestehende Welt erkannt – es wurde noch nichts gebaut. Ein Admin startet den Bau mit ","color":"white"},{"text":"/function himmelsinsel:admin/bauen","color":"aqua"},{"text":" (Einstellungen vorher mit /function himmelsinsel:admin/info prüfen).","color":"gray"}]
# Einstellungen – werden nur beim allerersten Laden gesetzt (siehe README)
execute unless score #spawn_befehl hs.config = #spawn_befehl hs.config run scoreboard players set #spawn_befehl hs.config 1
execute unless score #abklingzeit hs.config = #abklingzeit hs.config run scoreboard players set #abklingzeit hs.config 30
execute unless score #schutz hs.config = #schutz hs.config run scoreboard players set #schutz hs.config 1
execute unless score #fallschirm hs.config = #fallschirm hs.config run scoreboard players set #fallschirm hs.config 1
execute unless score #bodenstation hs.config = #bodenstation hs.config run scoreboard players set #bodenstation hs.config 1
execute unless score #login_spawn hs.config = #login_spawn hs.config run scoreboard players set #login_spawn hs.config 1
execute unless score #starterpaket hs.config = #starterpaket hs.config run scoreboard players set #starterpaket hs.config 1
execute unless score #homes hs.config = #homes hs.config run scoreboard players set #homes hs.config 1
execute unless score #todespunkt hs.config = #todespunkt hs.config run scoreboard players set #todespunkt hs.config 1
execute unless score #herzen hs.config = #herzen hs.config run scoreboard players set #herzen hs.config 1
execute if score #herzen hs.config matches 1 run scoreboard objectives setdisplay list hs.herz
# Einmalig: eine Person im Bett reicht, um die Nacht zu überspringen (danach frei per /gamerule)
execute unless score #schlafen hs.state matches 1 run function himmelsinsel:version/schlafen
scoreboard players set #schlafen hs.state 1
schedule function himmelsinsel:spiel/sekunde 20t
schedule function himmelsinsel:spiel/halbsekunde 10t
