execute unless score #fertig hs.state matches 1 run function himmelsinsel:bau/tick
execute if score #fertig hs.state matches 1 run function himmelsinsel:spiel/tick
