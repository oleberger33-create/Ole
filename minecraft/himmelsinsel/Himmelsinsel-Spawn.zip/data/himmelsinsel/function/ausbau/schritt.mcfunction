# Ein Teil pro Tick
execute if score #ausbau_stufe hs.state matches 1 run function himmelsinsel:ausbau/teil_01
execute if score #ausbau_stufe hs.state matches 2 run function himmelsinsel:ausbau/teil_02
execute if score #ausbau_stufe hs.state matches 3 run function himmelsinsel:ausbau/teil_03
execute if score #ausbau_stufe hs.state matches 4 run function himmelsinsel:ausbau/teil_04
scoreboard players add #ausbau_stufe hs.state 1
# Danach 2 Sekunden warten, bis alle Wesen der geladenen Chunks da sind
execute if score #ausbau_stufe hs.state matches 45.. run function himmelsinsel:ausbau/fertig
