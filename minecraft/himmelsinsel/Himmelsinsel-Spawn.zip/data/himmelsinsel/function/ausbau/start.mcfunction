# Neue Teile der Insel (z. B. die Marktinsel) in einer schon gebauten Welt nachrüsten
forceload add -48 -48 47 47
scoreboard players set #ausbau_stufe hs.state 1
tellraw @a {"text":"[Himmelsinsel] Baue Erweiterungen an …","color":"light_purple"}
