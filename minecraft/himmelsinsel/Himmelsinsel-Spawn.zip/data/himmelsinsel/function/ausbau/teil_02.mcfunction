fill 41 220 -28 43 220 -26 minecraft:mossy_cobblestone
fill 29 220 -27 29 221 -26 minecraft:mossy_cobblestone
fill 31 220 -27 31 220 -26 minecraft:mossy_cobblestone
setblock 40 220 -27 minecraft:stone
fill 44 220 -27 44 221 -27 minecraft:mossy_cobblestone
setblock 45 220 -27 minecraft:dripstone_block
setblock 44 220 -26 minecraft:stone
fill 41 220 -25 42 220 -25 minecraft:mossy_cobblestone
fill 44 220 -25 44 221 -25 minecraft:andesite
setblock 42 220 -24 minecraft:mossy_cobblestone
fill 43 220 -24 43 221 -24 minecraft:andesite
setblock 31 220 -23 minecraft:stone
fill 42 220 -23 42 220 -22 minecraft:andesite
setblock 43 220 -23 minecraft:dripstone_block
fill 32 220 -22 34 220 -22 minecraft:stone
fill 34 220 -21 41 220 -21 minecraft:stone
fill 35 221 -38 35 223 -29 minecraft:dirt
setblock 36 221 -38 minecraft:rooted_dirt
fill 37 221 -38 37 223 -36 minecraft:dirt
setblock 38 221 -38 minecraft:rooted_dirt
setblock 33 221 -37 minecraft:stone
setblock 34 221 -37 minecraft:tuff
fill 36 221 -37 36 223 -36 minecraft:dirt
fill 38 221 -37 42 223 -37 minecraft:dirt
fill 31 221 -36 32 221 -36 minecraft:stone
setblock 33 221 -36 minecraft:tuff
fill 38 221 -36 41 223 -35 minecraft:dirt
setblock 42 221 -36 minecraft:rooted_dirt
fill 43 221 -36 44 223 -36 minecraft:dirt
setblock 30 221 -35 minecraft:stone
setblock 34 221 -35 minecraft:tuff
fill 36 221 -35 37 221 -35 minecraft:rooted_dirt
fill 42 221 -35 43 223 -35 minecraft:dirt
setblock 44 221 -35 minecraft:rooted_dirt
fill 29 221 -34 29 221 -33 minecraft:rooted_dirt
fill 30 221 -34 30 223 -33 minecraft:dirt
fill 34 221 -34 34 223 -25 minecraft:dirt
fill 36 221 -34 39 223 -33 minecraft:dirt
setblock 40 221 -34 minecraft:stone
setblock 45 221 -34 minecraft:dripstone_block
fill 31 221 -33 33 223 -33 minecraft:dirt
fill 45 221 -33 45 221 -32 minecraft:stone
fill 28 221 -32 29 223 -30 minecraft:dirt
fill 30 221 -32 31 221 -32 minecraft:rooted_dirt
fill 32 221 -32 33 223 -32 minecraft:dirt
fill 36 221 -32 38 223 -31 minecraft:dirt
fill 30 221 -31 31 223 -29 minecraft:dirt
fill 32 221 -31 32 221 -30 minecraft:rooted_dirt
fill 33 221 -31 33 223 -31 minecraft:dirt
fill 39 221 -31 39 223 -31 minecraft:dirt
fill 40 221 -31 40 221 -30 minecraft:rooted_dirt
setblock 41 221 -31 minecraft:stone
fill 46 221 -31 46 221 -28 minecraft:stone
setblock 33 221 -30 minecraft:rooted_dirt
fill 36 221 -30 36 223 -30 minecraft:dirt
setblock 37 221 -30 minecraft:rooted_dirt
fill 38 221 -30 38 223 -25 minecraft:dirt
setblock 39 221 -30 minecraft:rooted_dirt
fill 41 221 -30 41 223 -30 minecraft:dirt
setblock 42 221 -30 minecraft:stone
fill 28 221 -29 29 221 -28 minecraft:stone
fill 32 221 -29 33 223 -28 minecraft:dirt
setblock 36 221 -29 minecraft:stone
fill 37 221 -29 37 223 -29 minecraft:dirt
fill 39 221 -29 40 223 -29 minecraft:dirt
setblock 41 221 -29 minecraft:rooted_dirt
fill 42 221 -29 42 223 -25 minecraft:dirt
fill 30 221 -28 30 223 -28 minecraft:dirt
setblock 31 221 -28 minecraft:rooted_dirt
fill 39 221 -28 39 223 -23 minecraft:dirt
setblock 40 221 -28 minecraft:rooted_dirt
fill 41 221 -28 41 223 -28 minecraft:dirt
setblock 43 221 -28 minecraft:stone
setblock 28 221 -27 minecraft:stone
setblock 30 221 -27 minecraft:rooted_dirt
fill 31 221 -27 32 223 -27 minecraft:dirt
fill 33 221 -27 33 221 -26 minecraft:rooted_dirt
fill 40 221 -27 40 223 -24 minecraft:dirt
setblock 41 221 -27 minecraft:rooted_dirt
fill 43 221 -27 43 221 -26 minecraft:mossy_cobblestone
fill 45 221 -27 45 221 -25 minecraft:stone
fill 30 221 -26 30 223 -25 minecraft:dirt
setblock 31 221 -26 minecraft:rooted_dirt
fill 32 221 -26 32 223 -26 minecraft:dirt
setblock 35 221 -26 minecraft:stone
setblock 37 221 -26 minecraft:stone
fill 41 221 -26 41 223 -25 minecraft:dirt
setblock 44 221 -26 minecraft:andesite
setblock 29 221 -25 minecraft:mossy_cobblestone
fill 31 221 -25 31 223 -25 minecraft:dirt
fill 32 221 -25 32 221 -24 minecraft:rooted_dirt
fill 33 221 -25 33 223 -23 minecraft:dirt
fill 30 221 -24 31 221 -24 minecraft:rooted_dirt
fill 34 221 -24 34 221 -21 minecraft:stone
setblock 38 221 -24 minecraft:rooted_dirt
fill 41 221 -24 42 221 -24 minecraft:rooted_dirt
fill 44 221 -24 44 221 -23 minecraft:andesite
fill 31 221 -23 32 223 -23 minecraft:dirt
fill 35 221 -23 37 221 -20 minecraft:stone
fill 38 221 -23 38 223 -23 minecraft:dirt
fill 40 221 -23 40 221 -22 minecraft:rooted_dirt
fill 41 221 -23 42 223 -22 minecraft:dirt
fill 43 221 -23 43 221 -22 minecraft:andesite
setblock 32 221 -22 minecraft:rooted_dirt
fill 33 221 -22 33 221 -21 minecraft:stone
fill 38 221 -22 38 221 -20 minecraft:stone
setblock 39 221 -22 minecraft:rooted_dirt
fill 39 221 -21 39 221 -20 minecraft:stone
fill 40 221 -21 41 223 -21 minecraft:dirt
setblock 40 221 -20 minecraft:stone
fill 36 222 -38 36 223 -38 minecraft:dirt
fill 38 222 -38 39 223 -38 minecraft:dirt
fill 33 222 -37 33 223 -37 minecraft:dirt
setblock 34 222 -37 minecraft:rooted_dirt
fill 31 222 -36 31 222 -35 minecraft:rooted_dirt
fill 32 222 -36 32 223 -34 minecraft:dirt
setblock 33 222 -36 minecraft:rooted_dirt
fill 34 222 -36 34 223 -35 minecraft:dirt
fill 42 222 -36 42 223 -36 minecraft:dirt
fill 30 222 -35 30 223 -35 minecraft:dirt
fill 33 222 -35 33 223 -35 minecraft:dirt
fill 36 222 -35 37 223 -35 minecraft:dirt
fill 44 222 -35 44 223 -35 minecraft:dirt
fill 29 222 -34 29 223 -33 minecraft:dirt
fill 31 222 -34 31 223 -34 minecraft:dirt
setblock 33 222 -34 minecraft:rooted_dirt
fill 40 222 -34 43 223 -33 minecraft:dirt
setblock 44 222 -34 minecraft:rooted_dirt
fill 45 222 -34 45 223 -34 minecraft:dirt
fill 44 222 -33 44 223 -30 minecraft:dirt
setblock 45 222 -33 minecraft:rooted_dirt
fill 30 222 -32 31 223 -32 minecraft:dirt
fill 39 222 -32 39 223 -32 minecraft:dirt
setblock 40 222 -32 minecraft:rooted_dirt
fill 41 222 -32 43 223 -32 minecraft:dirt
fill 45 222 -32 45 223 -32 minecraft:dirt
fill 32 222 -31 32 223 -30 minecraft:dirt
fill 40 222 -31 41 223 -31 minecraft:dirt
fill 42 222 -31 43 222 -31 minecraft:rooted_dirt
setblock 45 222 -31 minecraft:rooted_dirt
fill 46 222 -31 46 223 -28 minecraft:dirt
fill 33 222 -30 33 223 -30 minecraft:dirt
fill 37 222 -30 37 223 -30 minecraft:dirt
fill 39 222 -30 40 223 -30 minecraft:dirt
fill 42 222 -30 43 223 -30 minecraft:dirt
fill 45 222 -30 45 223 -30 minecraft:dirt
fill 28 222 -29 29 223 -29 minecraft:dirt
fill 36 222 -29 36 223 -25 minecraft:dirt
fill 41 222 -29 41 223 -29 minecraft:dirt
fill 43 222 -29 45 222 -29 minecraft:rooted_dirt
setblock 28 222 -28 minecraft:rooted_dirt
fill 29 222 -28 29 223 -28 minecraft:dirt
fill 31 222 -28 31 223 -28 minecraft:dirt
setblock 35 222 -28 minecraft:rooted_dirt
fill 37 222 -28 37 223 -26 minecraft:dirt
fill 40 222 -28 40 223 -28 minecraft:dirt
setblock 43 222 -28 minecraft:rooted_dirt
fill 44 222 -28 44 223 -25 minecraft:dirt
setblock 45 222 -28 minecraft:rooted_dirt
fill 28 222 -27 28 223 -26 minecraft:dirt
setblock 29 222 -27 minecraft:rooted_dirt
fill 30 222 -27 30 223 -27 minecraft:dirt
fill 33 222 -27 33 223 -26 minecraft:dirt
fill 35 222 -27 35 223 -27 minecraft:dirt
fill 41 222 -27 41 223 -27 minecraft:dirt
fill 43 222 -27 43 223 -26 minecraft:dirt
fill 45 222 -27 45 223 -24 minecraft:dirt
fill 29 222 -26 29 223 -26 minecraft:dirt
fill 31 222 -26 31 223 -26 minecraft:dirt
setblock 35 222 -26 minecraft:rooted_dirt
setblock 29 222 -25 minecraft:rooted_dirt
fill 32 222 -25 32 223 -24 minecraft:dirt
fill 35 222 -25 35 223 -24 minecraft:dirt
setblock 37 222 -25 minecraft:rooted_dirt
setblock 43 222 -25 minecraft:rooted_dirt
fill 30 222 -24 31 223 -24 minecraft:dirt
setblock 34 222 -24 minecraft:rooted_dirt
setblock 36 222 -24 minecraft:rooted_dirt
fill 37 222 -24 38 223 -24 minecraft:dirt
fill 41 222 -24 43 223 -24 minecraft:dirt
fill 44 222 -24 44 222 -23 minecraft:rooted_dirt
fill 34 222 -23 34 223 -21 minecraft:dirt
setblock 35 222 -23 minecraft:rooted_dirt
fill 36 222 -23 36 223 -22 minecraft:dirt
setblock 37 222 -23 minecraft:rooted_dirt
fill 40 222 -23 40 223 -22 minecraft:dirt
fill 43 222 -23 43 223 -22 minecraft:dirt
fill 32 222 -22 32 223 -22 minecraft:dirt
setblock 33 222 -22 minecraft:rooted_dirt
fill 35 222 -22 35 223 -20 minecraft:dirt
fill 37 222 -22 39 223 -20 minecraft:dirt
fill 33 222 -21 33 223 -21 minecraft:dirt
setblock 36 222 -21 minecraft:rooted_dirt
fill 42 222 -21 42 223 -21 minecraft:dirt
setblock 34 222 -20 minecraft:rooted_dirt
fill 36 222 -20 36 223 -20 minecraft:dirt
setblock 40 222 -20 minecraft:rooted_dirt
setblock 34 223 -37 minecraft:dirt
fill 31 223 -36 31 223 -35 minecraft:dirt
setblock 33 223 -36 minecraft:dirt
setblock 33 223 -34 minecraft:dirt
setblock 44 223 -34 minecraft:dirt
setblock 45 223 -33 minecraft:dirt
setblock 40 223 -32 minecraft:dirt
fill 42 223 -31 43 223 -31 minecraft:dirt
setblock 45 223 -31 minecraft:dirt
fill 43 223 -29 45 223 -29 minecraft:dirt
setblock 28 223 -28 minecraft:dirt
setblock 35 223 -28 minecraft:dirt
setblock 43 223 -28 minecraft:dirt
setblock 45 223 -28 minecraft:dirt
setblock 29 223 -27 minecraft:dirt
setblock 35 223 -26 minecraft:dirt
setblock 29 223 -25 minecraft:dirt
setblock 37 223 -25 minecraft:dirt
setblock 43 223 -25 minecraft:dirt
setblock 34 223 -24 minecraft:dirt
setblock 36 223 -24 minecraft:dirt
fill 44 223 -24 44 223 -23 minecraft:dirt
setblock 35 223 -23 minecraft:dirt
