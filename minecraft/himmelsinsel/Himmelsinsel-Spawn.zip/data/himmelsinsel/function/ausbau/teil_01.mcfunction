setblock 12 226 -9 minecraft:air
setblock 21 226 -11 minecraft:air
setblock 23 226 -9 minecraft:air
setblock 31 226 -6 minecraft:air
setblock 6 225 -6 minecraft:air
setblock 6 225 -5 minecraft:air
setblock 8 225 -6 minecraft:air
setblock 9 225 -9 minecraft:air
setblock 10 225 -10 minecraft:air
setblock 11 225 -10 minecraft:air
setblock 11 225 -8 minecraft:air
setblock 12 225 -11 minecraft:air
setblock 12 225 -9 minecraft:air
setblock 13 225 -11 minecraft:air
setblock 13 225 -10 minecraft:air
setblock 16 225 -10 minecraft:air
setblock 17 225 -10 minecraft:air
setblock 17 225 -9 minecraft:air
setblock 18 225 -10 minecraft:air
setblock 18 225 -9 minecraft:air
setblock 19 225 -9 minecraft:air
setblock 20 225 -11 minecraft:air
setblock 20 225 -10 minecraft:air
setblock 21 225 -11 minecraft:air
setblock 23 225 -11 minecraft:air
setblock 23 225 -9 minecraft:air
setblock 24 225 -10 minecraft:air
setblock 24 225 -9 minecraft:air
setblock 25 225 -12 minecraft:air
setblock 25 225 -11 minecraft:air
setblock 26 225 -11 minecraft:air
setblock 26 225 -10 minecraft:air
setblock 27 225 -12 minecraft:air
setblock 27 225 -10 minecraft:air
setblock 27 225 -9 minecraft:air
setblock 27 225 -8 minecraft:air
setblock 28 225 -11 minecraft:air
setblock 28 225 -10 minecraft:air
setblock 28 225 -9 minecraft:air
setblock 29 225 -9 minecraft:air
setblock 30 225 -11 minecraft:air
setblock 30 225 -9 minecraft:air
setblock 31 225 -9 minecraft:air
fill 37 208 -29 37 209 -29 minecraft:andesite
fill 36 209 -34 36 220 -34 minecraft:stone
fill 38 209 -29 38 220 -29 minecraft:stone
setblock 36 210 -35 minecraft:deepslate
fill 37 210 -30 38 220 -30 minecraft:stone
setblock 36 210 -29 minecraft:andesite
fill 37 210 -29 37 220 -29 minecraft:stone
setblock 37 210 -28 minecraft:amethyst_block
fill 38 210 -28 38 220 -28 minecraft:stone
fill 36 211 -35 36 217 -35 minecraft:stone
fill 36 211 -30 36 220 -29 minecraft:stone
fill 39 211 -29 39 214 -28 minecraft:stone
setblock 37 211 -28 minecraft:andesite
fill 36 212 -31 38 220 -31 minecraft:stone
fill 35 212 -30 35 220 -29 minecraft:stone
fill 39 212 -30 39 214 -30 minecraft:stone
fill 36 212 -28 37 221 -28 minecraft:stone
setblock 37 212 -27 minecraft:dripstone_block
fill 38 212 -27 38 220 -27 minecraft:stone
fill 35 213 -35 35 219 -34 minecraft:stone
fill 37 213 -34 37 220 -34 minecraft:stone
fill 36 213 -33 36 220 -33 minecraft:stone
fill 35 213 -31 35 220 -31 minecraft:stone
setblock 39 213 -31 minecraft:stone
fill 34 213 -29 34 220 -29 minecraft:stone
fill 40 213 -29 40 214 -28 minecraft:stone
fill 35 213 -28 35 221 -28 minecraft:stone
fill 36 213 -27 37 221 -27 minecraft:stone
fill 39 213 -27 39 220 -27 minecraft:stone
fill 37 214 -35 37 216 -35 minecraft:stone
fill 35 214 -32 38 220 -32 minecraft:stone
fill 34 214 -31 34 220 -30 minecraft:stone
fill 39 214 -31 39 218 -31 minecraft:andesite
fill 40 214 -30 40 217 -30 minecraft:andesite
fill 34 214 -28 34 220 -28 minecraft:stone
fill 35 214 -27 35 221 -27 minecraft:stone
setblock 40 214 -27 minecraft:amethyst_block
fill 37 214 -26 39 220 -26 minecraft:stone
fill 35 215 -33 35 220 -33 minecraft:stone
fill 37 215 -33 37 220 -33 minecraft:stone
fill 34 215 -32 34 220 -32 minecraft:stone
fill 39 215 -32 39 217 -32 minecraft:andesite
fill 40 215 -31 40 217 -31 minecraft:andesite
fill 33 215 -30 33 220 -28 minecraft:stone
fill 39 215 -30 39 217 -29 minecraft:andesite
setblock 41 215 -30 minecraft:amethyst_block
setblock 40 215 -29 minecraft:andesite
setblock 41 215 -29 minecraft:dripstone_block
fill 39 215 -28 41 219 -28 minecraft:stone
fill 34 215 -27 34 220 -27 minecraft:stone
fill 40 215 -27 41 219 -27 minecraft:stone
setblock 35 215 -26 minecraft:amethyst_block
fill 36 215 -26 36 221 -26 minecraft:stone
fill 40 215 -26 40 220 -26 minecraft:stone
fill 38 215 -25 39 220 -25 minecraft:stone
fill 36 216 -36 36 217 -36 minecraft:stone
fill 34 216 -34 34 220 -33 minecraft:stone
fill 38 216 -33 39 220 -33 minecraft:stone
fill 33 216 -32 33 219 -31 minecraft:stone
setblock 40 216 -32 minecraft:dripstone_block
fill 41 216 -31 41 217 -31 minecraft:andesite
fill 32 216 -30 32 220 -29 minecraft:stone
fill 41 216 -30 41 220 -29 minecraft:stone
fill 40 216 -29 40 220 -29 minecraft:stone
setblock 32 216 -28 minecraft:amethyst_block
fill 32 216 -27 33 220 -27 minecraft:stone
fill 34 216 -26 35 220 -26 minecraft:stone
fill 41 216 -26 41 219 -26 minecraft:stone
setblock 36 216 -25 minecraft:andesite
setblock 37 216 -25 minecraft:dripstone_block
fill 40 216 -25 40 220 -25 minecraft:stone
setblock 38 216 -24 minecraft:andesite
fill 39 216 -24 39 220 -24 minecraft:stone
fill 35 217 -36 35 218 -36 minecraft:stone
fill 34 217 -35 34 220 -35 minecraft:stone
fill 37 217 -35 37 220 -35 minecraft:tuff
fill 38 217 -34 40 220 -34 minecraft:stone
fill 33 217 -33 33 218 -33 minecraft:stone
fill 40 217 -33 41 221 -33 minecraft:stone
fill 32 217 -32 32 219 -31 minecraft:stone
setblock 40 217 -32 minecraft:andesite
fill 41 217 -32 41 221 -32 minecraft:stone
fill 31 217 -30 31 220 -28 minecraft:stone
fill 42 217 -30 42 218 -28 minecraft:stone
fill 32 217 -28 32 220 -28 minecraft:stone
setblock 42 217 -27 minecraft:amethyst_block
fill 32 217 -26 33 220 -26 minecraft:stone
fill 42 217 -26 42 218 -26 minecraft:stone
fill 33 217 -25 33 220 -25 minecraft:stone
setblock 34 217 -25 minecraft:dripstone_block
fill 35 217 -25 37 221 -25 minecraft:stone
fill 41 217 -25 41 219 -25 minecraft:stone
fill 36 217 -24 37 217 -24 minecraft:andesite
fill 38 217 -24 38 220 -24 minecraft:stone
setblock 40 217 -24 minecraft:dripstone_block
fill 39 217 -23 39 220 -23 minecraft:stone
fill 36 218 -36 37 220 -36 minecraft:tuff
fill 36 218 -35 36 220 -35 minecraft:tuff
setblock 38 218 -35 minecraft:dripstone_block
fill 39 218 -35 40 220 -35 minecraft:stone
setblock 33 218 -34 minecraft:dripstone_block
fill 41 218 -34 41 221 -34 minecraft:stone
setblock 32 218 -33 minecraft:stone
fill 42 218 -33 42 221 -31 minecraft:stone
fill 31 218 -32 31 219 -31 minecraft:stone
fill 39 218 -32 40 221 -32 minecraft:stone
fill 30 218 -31 30 220 -31 minecraft:stone
fill 40 218 -31 41 220 -31 minecraft:stone
setblock 30 218 -30 minecraft:dripstone_block
setblock 39 218 -30 minecraft:andesite
fill 40 218 -30 40 220 -30 minecraft:stone
fill 43 218 -30 43 221 -29 minecraft:stone
fill 30 218 -29 30 218 -28 minecraft:stone
fill 39 218 -29 39 220 -29 minecraft:stone
fill 43 218 -28 43 219 -27 minecraft:cobblestone
fill 31 218 -27 31 219 -26 minecraft:stone
setblock 42 218 -27 minecraft:stone
fill 32 218 -25 32 220 -25 minecraft:stone
fill 34 218 -25 34 220 -24 minecraft:stone
fill 42 218 -25 42 219 -25 minecraft:stone
fill 33 218 -24 33 220 -24 minecraft:stone
fill 35 218 -24 37 221 -24 minecraft:stone
fill 40 218 -24 41 220 -23 minecraft:stone
setblock 36 218 -23 minecraft:andesite
fill 37 218 -23 38 220 -23 minecraft:stone
fill 36 219 -37 37 220 -37 minecraft:tuff
setblock 34 219 -36 minecraft:stone
fill 35 219 -36 35 220 -36 minecraft:tuff
setblock 38 219 -36 minecraft:tuff
fill 39 219 -36 41 220 -36 minecraft:stone
fill 33 219 -35 33 221 -35 minecraft:stone
fill 38 219 -35 38 220 -35 minecraft:stone
fill 41 219 -35 42 220 -35 minecraft:stone
setblock 43 219 -35 minecraft:dripstone_block
setblock 31 219 -34 minecraft:amethyst_block
fill 32 219 -34 33 219 -33 minecraft:andesite
fill 42 219 -34 43 221 -34 minecraft:stone
fill 30 219 -33 31 220 -33 minecraft:andesite
fill 43 219 -33 43 221 -31 minecraft:stone
fill 30 219 -32 30 220 -32 minecraft:stone
fill 29 219 -31 29 220 -28 minecraft:stone
fill 39 219 -31 39 220 -30 minecraft:stone
fill 30 219 -30 30 220 -29 minecraft:stone
fill 42 219 -30 42 220 -29 minecraft:stone
fill 44 219 -30 44 219 -27 minecraft:stone
fill 30 219 -28 30 219 -27 minecraft:cobblestone
fill 42 219 -28 42 219 -26 minecraft:cobblestone
setblock 30 219 -26 minecraft:stone
setblock 43 219 -26 minecraft:cobblestone
fill 31 219 -25 31 220 -24 minecraft:stone
fill 43 219 -25 43 221 -25 minecraft:andesite
fill 32 219 -24 32 220 -23 minecraft:stone
fill 42 219 -24 42 219 -23 minecraft:andesite
fill 33 219 -23 36 220 -23 minecraft:stone
fill 35 219 -22 41 220 -22 minecraft:stone
setblock 34 220 -37 minecraft:dripstone_block
setblock 35 220 -37 minecraft:tuff
fill 38 220 -37 41 220 -37 minecraft:stone
setblock 33 220 -36 minecraft:stone
fill 34 220 -36 34 221 -36 minecraft:tuff
setblock 38 220 -36 minecraft:stone
fill 42 220 -36 43 220 -36 minecraft:stone
fill 31 220 -35 32 221 -34 minecraft:stone
setblock 35 220 -35 minecraft:tuff
fill 43 220 -35 44 220 -35 minecraft:stone
setblock 30 220 -34 minecraft:stone
fill 33 220 -34 33 221 -34 minecraft:stone
setblock 35 220 -34 minecraft:stone
fill 44 220 -34 44 221 -28 minecraft:stone
fill 29 220 -33 29 220 -32 minecraft:stone
fill 32 220 -33 33 220 -32 minecraft:andesite
setblock 31 220 -32 minecraft:andesite
fill 28 220 -31 28 220 -28 minecraft:stone
fill 31 220 -31 33 220 -31 minecraft:stone
fill 45 220 -31 45 221 -28 minecraft:stone
fill 30 220 -28 30 220 -24 minecraft:mossy_cobblestone
fill 39 220 -28 40 220 -28 minecraft:stone
