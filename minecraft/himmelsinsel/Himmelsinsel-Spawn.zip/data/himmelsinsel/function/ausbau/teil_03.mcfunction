setblock 37 223 -23 minecraft:dirt
setblock 33 223 -22 minecraft:dirt
setblock 36 223 -21 minecraft:dirt
setblock 34 223 -20 minecraft:dirt
setblock 40 223 -20 minecraft:dirt
fill 35 223 -19 35 223 -13 minecraft:spruce_log[axis=z]
fill 39 223 -19 39 223 -13 minecraft:spruce_log[axis=z]
fill 31 223 -12 34 223 -12 minecraft:spruce_log[axis=x]
setblock 35 223 -12 minecraft:stripped_spruce_log[axis=y]
fill 36 223 -12 38 224 -8 minecraft:spruce_planks
setblock 39 223 -12 minecraft:stripped_spruce_log[axis=y]
fill 35 223 -11 35 224 -9 minecraft:spruce_planks
fill 39 223 -11 39 224 -9 minecraft:spruce_planks
fill 32 223 -8 34 223 -8 minecraft:spruce_log[axis=x]
setblock 35 223 -8 minecraft:stripped_spruce_log[axis=y]
setblock 39 223 -8 minecraft:stripped_spruce_log[axis=y]
fill 35 224 -38 39 224 -37 minecraft:grass_block
fill 33 224 -37 34 224 -37 minecraft:grass_block
fill 40 224 -37 42 224 -37 minecraft:grass_block
fill 31 224 -36 32 224 -31 minecraft:grass_block
fill 33 224 -36 35 224 -34 minecraft:spruce_planks
fill 36 224 -36 38 224 -34 minecraft:grass_block
fill 39 224 -36 41 224 -34 minecraft:spruce_planks
fill 42 224 -36 44 224 -31 minecraft:grass_block
fill 30 224 -35 30 224 -31 minecraft:grass_block
fill 29 224 -34 29 224 -25 minecraft:grass_block
fill 45 224 -34 45 224 -24 minecraft:grass_block
fill 33 224 -33 34 224 -33 minecraft:grass_block
fill 35 224 -33 39 224 -33 minecraft:polished_andesite
fill 40 224 -33 41 224 -33 minecraft:grass_block
fill 28 224 -32 28 224 -26 minecraft:grass_block
setblock 33 224 -32 minecraft:grass_block
fill 34 224 -32 35 224 -32 minecraft:polished_andesite
fill 36 224 -32 38 224 -31 minecraft:stone_bricks
fill 39 224 -32 40 224 -32 minecraft:polished_andesite
setblock 41 224 -32 minecraft:grass_block
fill 33 224 -31 34 224 -31 minecraft:polished_andesite
fill 35 224 -31 35 224 -27 minecraft:stone_bricks
setblock 39 224 -31 minecraft:cracked_stone_bricks
fill 40 224 -31 41 224 -31 minecraft:polished_andesite
fill 46 224 -31 46 224 -28 minecraft:grass_block
fill 30 224 -30 32 224 -28 minecraft:spruce_planks
fill 33 224 -30 33 224 -27 minecraft:polished_andesite
setblock 34 224 -30 minecraft:mossy_stone_bricks
fill 36 224 -30 38 224 -30 minecraft:polished_andesite
fill 39 224 -30 40 224 -29 minecraft:stone_bricks
fill 41 224 -30 41 224 -27 minecraft:polished_andesite
fill 42 224 -30 44 224 -28 minecraft:spruce_planks
fill 34 224 -29 34 224 -28 minecraft:stone_bricks
fill 36 224 -29 36 224 -28 minecraft:polished_andesite
setblock 37 224 -29 minecraft:chiseled_stone_bricks
fill 38 224 -29 38 224 -28 minecraft:polished_andesite
setblock 37 224 -28 minecraft:polished_andesite
setblock 39 224 -28 minecraft:stone_bricks
setblock 40 224 -28 minecraft:cracked_stone_bricks
fill 30 224 -27 32 224 -24 minecraft:grass_block
fill 34 224 -27 34 224 -26 minecraft:polished_andesite
fill 36 224 -27 37 224 -27 minecraft:stone_bricks
fill 38 224 -27 39 224 -27 minecraft:mossy_stone_bricks
fill 40 224 -27 40 224 -26 minecraft:polished_andesite
fill 42 224 -27 44 224 -23 minecraft:grass_block
fill 33 224 -26 33 224 -21 minecraft:grass_block
fill 35 224 -26 35 224 -25 minecraft:polished_andesite
setblock 36 224 -26 minecraft:stone_bricks
setblock 37 224 -26 minecraft:mossy_stone_bricks
setblock 38 224 -26 minecraft:stone_bricks
fill 39 224 -26 39 224 -25 minecraft:polished_andesite
fill 41 224 -26 41 224 -21 minecraft:grass_block
fill 34 224 -25 34 224 -20 minecraft:grass_block
fill 36 224 -25 38 224 -25 minecraft:polished_andesite
fill 40 224 -25 40 224 -20 minecraft:grass_block
fill 35 224 -24 35 224 -23 minecraft:grass_block
fill 36 224 -24 38 224 -23 minecraft:dirt_path
fill 39 224 -24 39 224 -23 minecraft:grass_block
fill 31 224 -23 32 224 -23 minecraft:grass_block
setblock 32 224 -22 minecraft:grass_block
fill 35 224 -22 39 224 -13 minecraft:spruce_planks
fill 42 224 -22 43 224 -22 minecraft:grass_block
setblock 42 224 -21 minecraft:grass_block
fill 28 224 -12 35 224 -12 minecraft:spruce_planks
setblock 39 224 -12 minecraft:spruce_planks
fill 12 224 -11 27 224 -9 minecraft:dirt_path
fill 28 224 -11 34 224 -8 minecraft:spruce_planks
fill 10 224 -10 11 224 -8 minecraft:dirt_path
fill 8 224 -9 9 224 -7 minecraft:dirt_path
fill 7 224 -8 7 224 -6 minecraft:dirt_path
setblock 35 224 -8 minecraft:spruce_planks
setblock 39 224 -8 minecraft:spruce_planks
fill 6 224 -7 6 224 -5 minecraft:dirt_path
setblock 10 224 -7 minecraft:dirt_path
setblock 5 224 -6 minecraft:dirt_path
setblock 8 224 -6 minecraft:dirt_path
setblock 33 225 -36 minecraft:barrel[facing=up]
setblock 34 225 -36 minecraft:hay_block[axis=y]
setblock 35 225 -36 minecraft:barrel[facing=up]
setblock 39 225 -36 minecraft:barrel[facing=up]
setblock 40 225 -36 minecraft:blast_furnace[facing=south]
setblock 41 225 -36 minecraft:barrel[facing=up]
setblock 37 225 -35 minecraft:composter
setblock 33 225 -34 minecraft:spruce_fence[east=true]
setblock 34 225 -34 minecraft:composter
setblock 35 225 -34 minecraft:spruce_fence[west=true]
setblock 39 225 -34 minecraft:spruce_fence[east=true]
setblock 40 225 -34 minecraft:smithing_table
setblock 41 225 -34 minecraft:spruce_fence[west=true]
setblock 32 225 -32 minecraft:barrel[facing=up]
setblock 42 225 -32 minecraft:hay_block[axis=y]
setblock 30 225 -30 minecraft:barrel[facing=up]
setblock 32 225 -30 minecraft:spruce_fence[south=true]
setblock 42 225 -30 minecraft:spruce_fence[south=true]
setblock 44 225 -30 minecraft:barrel[facing=up]
setblock 30 225 -29 minecraft:target
setblock 32 225 -29 minecraft:barrel[facing=up]
setblock 37 225 -29 minecraft:bell[attachment=floor,facing=south]
setblock 42 225 -29 minecraft:fletching_table
setblock 44 225 -29 minecraft:oak_log[axis=y]
setblock 30 225 -28 minecraft:barrel[facing=up]
setblock 32 225 -28 minecraft:spruce_fence[north=true]
setblock 42 225 -28 minecraft:spruce_fence[north=true]
setblock 44 225 -28 minecraft:barrel[facing=up]
setblock 32 225 -26 minecraft:hay_block[axis=x]
setblock 42 225 -26 minecraft:barrel[facing=up]
fill 34 225 -25 34 226 -25 minecraft:spruce_fence
fill 40 225 -25 40 226 -25 minecraft:spruce_fence
fill 42 225 -25 44 225 -25 minecraft:flowering_azalea_leaves[persistent=true]
fill 31 225 -24 31 228 -24 minecraft:cherry_log[axis=y]
fill 42 225 -24 43 225 -24 minecraft:flowering_azalea_leaves[persistent=true]
fill 44 225 -24 44 226 -24 minecraft:azalea_leaves[persistent=true]
setblock 42 225 -23 minecraft:azalea_leaves[persistent=true]
fill 43 225 -23 44 225 -23 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 225 -22 minecraft:spruce_fence[south=true]
setblock 39 225 -22 minecraft:spruce_fence[south=true]
fill 35 225 -21 35 225 -13 minecraft:spruce_fence[north=true,south=true]
fill 39 225 -21 39 225 -13 minecraft:spruce_fence[north=true,south=true]
setblock 28 225 -12 minecraft:spruce_fence[east=true]
fill 29 225 -12 34 225 -12 minecraft:spruce_fence[east=true,west=true]
fill 35 225 -12 35 227 -12 minecraft:stripped_spruce_log[axis=y]
fill 39 225 -12 39 227 -12 minecraft:stripped_spruce_log[axis=y]
fill 39 225 -11 39 225 -9 minecraft:spruce_fence[north=true,south=true]
setblock 28 225 -8 minecraft:spruce_fence[east=true]
fill 29 225 -8 34 225 -8 minecraft:spruce_fence[east=true,west=true]
fill 35 225 -8 35 227 -8 minecraft:stripped_spruce_log[axis=y]
fill 36 225 -8 38 225 -8 minecraft:spruce_fence[east=true,west=true]
fill 39 225 -8 39 227 -8 minecraft:stripped_spruce_log[axis=y]
fill 33 226 -36 33 227 -36 minecraft:spruce_fence
fill 35 226 -36 35 227 -36 minecraft:spruce_fence
fill 39 226 -36 39 227 -36 minecraft:spruce_fence
fill 41 226 -36 41 227 -36 minecraft:spruce_fence
fill 33 226 -34 33 227 -34 minecraft:spruce_fence
fill 35 226 -34 35 227 -34 minecraft:spruce_fence
fill 39 226 -34 39 227 -34 minecraft:spruce_fence
fill 41 226 -34 41 227 -34 minecraft:spruce_fence
fill 30 226 -30 30 227 -30 minecraft:spruce_fence
fill 32 226 -30 32 227 -30 minecraft:spruce_fence
fill 42 226 -30 42 227 -30 minecraft:spruce_fence
fill 44 226 -30 44 227 -30 minecraft:spruce_fence
fill 30 226 -28 30 227 -28 minecraft:spruce_fence
fill 32 226 -28 32 227 -28 minecraft:spruce_fence
fill 42 226 -28 42 227 -28 minecraft:spruce_fence
fill 44 226 -28 44 227 -28 minecraft:spruce_fence
fill 43 226 -25 43 226 -24 minecraft:azalea_leaves[persistent=true]
setblock 42 226 -24 minecraft:flowering_azalea_leaves[persistent=true]
setblock 43 226 -23 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 226 -17 minecraft:spruce_fence
setblock 39 226 -17 minecraft:spruce_fence
setblock 31 226 -12 minecraft:spruce_fence
setblock 31 226 -8 minecraft:spruce_fence
setblock 30 227 -24 minecraft:cherry_log[axis=x]
fill 30 227 -23 30 230 -22 minecraft:cherry_leaves[persistent=true]
fill 29 227 -22 29 229 -22 minecraft:cherry_leaves[persistent=true]
fill 33 228 -36 33 228 -34 minecraft:white_wool
fill 34 228 -36 34 228 -34 minecraft:lime_wool
fill 35 228 -36 35 228 -34 minecraft:white_wool
fill 39 228 -36 39 228 -34 minecraft:white_wool
fill 40 228 -36 40 228 -34 minecraft:orange_wool
fill 41 228 -36 41 228 -34 minecraft:white_wool
fill 30 228 -30 32 228 -30 minecraft:black_wool
fill 42 228 -30 44 228 -30 minecraft:white_wool
fill 30 228 -29 32 228 -29 minecraft:red_wool
fill 42 228 -29 44 228 -29 minecraft:brown_wool
fill 30 228 -28 32 228 -28 minecraft:black_wool
fill 42 228 -28 44 228 -28 minecraft:white_wool
fill 30 228 -26 31 229 -25 minecraft:cherry_leaves[persistent=true]
fill 29 228 -25 29 230 -25 minecraft:cherry_leaves[persistent=true]
fill 28 228 -24 28 229 -24 minecraft:cherry_leaves[persistent=true]
setblock 29 228 -24 minecraft:cherry_log[axis=y]
fill 30 228 -24 30 231 -24 minecraft:cherry_leaves[persistent=true]
fill 29 228 -23 29 230 -23 minecraft:cherry_leaves[persistent=true]
fill 31 228 -23 31 230 -23 minecraft:cherry_leaves[persistent=true]
fill 34 228 -13 40 228 -13 minecraft:spruce_slab[type=bottom]
fill 34 228 -12 34 228 -7 minecraft:spruce_slab[type=bottom]
fill 35 228 -12 39 228 -8 minecraft:spruce_planks
fill 40 228 -12 40 228 -7 minecraft:spruce_slab[type=bottom]
fill 35 228 -7 39 228 -7 minecraft:spruce_slab[type=bottom]
fill 29 229 -26 29 230 -26 minecraft:cherry_leaves[persistent=true]
fill 32 229 -25 32 229 -24 minecraft:cherry_leaves[persistent=true]
fill 29 229 -24 29 231 -24 minecraft:cherry_leaves[persistent=true]
fill 31 229 -24 31 231 -24 minecraft:cherry_leaves[persistent=true]
setblock 37 229 -10 minecraft:spruce_slab[type=bottom]
fill 30 230 -25 31 230 -25 minecraft:cherry_leaves[persistent=true]
fill 32 230 -24 32 230 -23 minecraft:cherry_leaves[persistent=true]
setblock 31 230 -22 minecraft:cherry_leaves[persistent=true]
setblock 30 231 -25 minecraft:cherry_leaves[persistent=true]
setblock 30 231 -23 minecraft:cherry_leaves[persistent=true]
setblock 34 227 -34 minecraft:lantern[hanging=true]
setblock 40 227 -34 minecraft:lantern[hanging=true]
setblock 32 227 -29 minecraft:lantern[hanging=true]
setblock 42 227 -29 minecraft:lantern[hanging=true]
setblock 34 227 -25 minecraft:lantern[hanging=false]
setblock 40 227 -25 minecraft:lantern[hanging=false]
setblock 35 227 -17 minecraft:lantern[hanging=false]
setblock 39 227 -17 minecraft:lantern[hanging=false]
setblock 31 227 -12 minecraft:lantern[hanging=false]
setblock 37 227 -10 minecraft:lantern[hanging=true]
setblock 31 227 -8 minecraft:lantern[hanging=false]
setblock 40 226 -37 minecraft:tall_grass[half=upper]
setblock 42 226 -37 minecraft:tall_grass[half=upper]
setblock 44 226 -36 minecraft:tall_grass[half=upper]
setblock 32 226 -34 minecraft:tall_grass[half=upper]
setblock 41 226 -33 minecraft:tall_grass[half=upper]
