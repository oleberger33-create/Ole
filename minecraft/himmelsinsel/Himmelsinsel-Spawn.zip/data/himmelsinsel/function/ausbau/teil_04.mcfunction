setblock 45 226 -33 minecraft:tall_grass[half=upper]
setblock 44 226 -31 minecraft:tall_grass[half=upper]
setblock 35 225 -38 minecraft:short_grass
setblock 36 225 -38 minecraft:fern
setblock 33 225 -37 minecraft:short_grass
setblock 35 225 -37 minecraft:fern
setblock 40 225 -37 minecraft:tall_grass[half=lower]
setblock 42 225 -37 minecraft:tall_grass[half=lower]
fill 31 225 -36 31 225 -34 minecraft:short_grass
setblock 42 225 -36 minecraft:short_grass
setblock 44 225 -36 minecraft:tall_grass[half=lower]
setblock 30 225 -35 minecraft:short_grass
setblock 32 225 -35 minecraft:short_grass
setblock 38 225 -35 minecraft:pink_petals[facing=west,flower_amount=4]
fill 43 225 -35 44 225 -35 minecraft:short_grass
setblock 29 225 -34 minecraft:poppy
setblock 30 225 -34 minecraft:fern
setblock 32 225 -34 minecraft:tall_grass[half=lower]
setblock 37 225 -34 minecraft:short_grass
setblock 43 225 -34 minecraft:cornflower
setblock 29 225 -33 minecraft:short_grass
fill 32 225 -33 33 225 -33 minecraft:short_grass
setblock 40 225 -33 minecraft:wildflowers[facing=south,flower_amount=2]
setblock 41 225 -33 minecraft:tall_grass[half=lower]
setblock 42 225 -33 minecraft:short_grass
setblock 44 225 -33 minecraft:short_grass
setblock 45 225 -33 minecraft:tall_grass[half=lower]
setblock 31 225 -32 minecraft:short_grass
setblock 33 225 -32 minecraft:wildflowers[facing=south,flower_amount=2]
setblock 43 225 -32 minecraft:short_grass
fill 45 225 -32 45 225 -30 minecraft:short_grass
fill 29 225 -31 29 225 -30 minecraft:short_grass
setblock 31 225 -31 minecraft:oxeye_daisy
setblock 32 225 -31 minecraft:short_grass
setblock 43 225 -31 minecraft:wildflowers[facing=east,flower_amount=1]
setblock 44 225 -31 minecraft:tall_grass[half=lower]
setblock 28 225 -28 minecraft:short_grass
setblock 29 225 -28 minecraft:fern
setblock 45 225 -28 minecraft:pink_petals[facing=south,flower_amount=3]
setblock 46 225 -28 minecraft:short_grass
setblock 29 225 -27 minecraft:short_grass
setblock 32 225 -27 minecraft:short_grass
setblock 42 225 -27 minecraft:wildflowers[facing=north,flower_amount=2]
setblock 28 225 -26 minecraft:short_grass
setblock 30 225 -26 minecraft:short_grass
setblock 41 225 -26 minecraft:pink_petals[facing=south,flower_amount=3]
setblock 45 225 -24 minecraft:short_grass
setblock 33 225 -23 minecraft:short_grass
setblock 35 225 -23 minecraft:short_grass
fill 39 225 -23 40 225 -23 minecraft:short_grass
setblock 41 225 -23 minecraft:fern
setblock 32 225 -22 minecraft:pink_petals[facing=north,flower_amount=2]
setblock 41 225 -22 minecraft:short_grass
setblock 42 225 -22 minecraft:wildflowers[facing=south,flower_amount=2]
fill 34 225 -21 34 225 -20 minecraft:short_grass
setblock 40 225 -21 minecraft:short_grass
setblock 41 225 -21 minecraft:oxeye_daisy
fill 45 222 -35 45 223 -35 minecraft:vine[west=true]
fill 28 221 -34 28 223 -33 minecraft:vine[east=true]
fill 47 222 -28 47 223 -28 minecraft:vine[west=true]
fill 32 222 -21 32 223 -21 minecraft:vine[north=true]
fill 41 219 -20 41 223 -20 minecraft:vine[west=true]
setblock 39 221 -38 minecraft:hanging_roots
setblock 28 221 -26 minecraft:hanging_roots
fill 36 220 -38 38 220 -38 minecraft:hanging_roots
setblock 32 220 -36 minecraft:glow_lichen[up=true]
setblock 45 220 -34 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 46 220 -31 minecraft:glow_lichen[up=true]
setblock 44 220 -23 minecraft:glow_lichen[up=true]
setblock 43 220 -22 minecraft:glow_lichen[up=true]
setblock 34 219 -37 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock 41 219 -37 minecraft:cave_vines_plant[berries=false]
fill 44 219 -31 45 219 -31 minecraft:glow_lichen[up=true]
setblock 28 219 -28 minecraft:glow_lichen[up=true]
setblock 29 219 -27 minecraft:cave_vines_plant[berries=false]
setblock 45 219 -27 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock 31 219 -23 minecraft:cave_vines_plant[berries=false]
setblock 43 219 -23 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock 34 218 -37 minecraft:pointed_dripstone[thickness=middle,vertical_direction=down]
setblock 41 218 -37 minecraft:cave_vines_plant[berries=true]
setblock 41 218 -35 minecraft:glow_lichen[up=true]
setblock 43 218 -35 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock 31 218 -34 minecraft:amethyst_cluster[facing=down]
setblock 43 218 -34 minecraft:glow_lichen[up=true]
setblock 44 218 -30 minecraft:glow_lichen[up=true]
setblock 29 218 -27 minecraft:cave_vines[age=25,berries=true]
setblock 45 218 -27 minecraft:pointed_dripstone[thickness=middle,vertical_direction=down]
setblock 31 218 -24 minecraft:glow_lichen[up=true]
setblock 31 218 -23 minecraft:cave_vines[age=25,berries=true]
setblock 43 218 -23 minecraft:pointed_dripstone[thickness=middle,vertical_direction=down]
setblock 34 217 -37 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 41 217 -37 minecraft:cave_vines_plant[berries=false]
setblock 38 217 -35 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
fill 39 217 -35 40 217 -35 minecraft:glow_lichen[up=true]
setblock 43 217 -35 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 33 217 -34 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 42 217 -32 minecraft:cave_vines_plant[berries=false]
setblock 42 217 -31 minecraft:glow_lichen[up=true]
setblock 30 217 -30 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
fill 31 216 -27 31 217 -27 minecraft:cave_vines_plant[berries=false]
setblock 45 217 -27 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 33 217 -24 minecraft:glow_lichen[up=true]
fill 41 217 -24 41 217 -23 minecraft:glow_lichen[up=true]
setblock 43 217 -23 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 34 216 -37 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 41 216 -37 minecraft:cave_vines[age=25,berries=true]
setblock 35 216 -36 minecraft:glow_lichen[up=true]
setblock 34 216 -35 minecraft:cave_vines_plant[berries=false]
setblock 38 216 -35 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 43 216 -35 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 42 216 -32 minecraft:cave_vines[age=25,berries=false]
setblock 30 216 -30 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 42 216 -27 minecraft:amethyst_cluster[facing=down]
setblock 45 216 -27 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 42 216 -26 minecraft:glow_lichen[up=true]
setblock 34 216 -25 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock 40 216 -24 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 39 216 -23 minecraft:glow_lichen[up=true]
setblock 43 216 -23 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 34 215 -35 minecraft:cave_vines_plant[berries=true]
setblock 40 215 -32 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 30 215 -30 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 32 215 -28 minecraft:amethyst_cluster[facing=down]
setblock 31 215 -27 minecraft:cave_vines[age=25,berries=false]
setblock 34 215 -25 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 37 215 -25 minecraft:pointed_dripstone[thickness=base,vertical_direction=down]
setblock 38 215 -24 minecraft:glow_lichen[up=true]
setblock 34 214 -35 minecraft:cave_vines_plant[berries=false]
setblock 35 214 -33 minecraft:glow_lichen[up=true]
setblock 40 214 -32 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 33 214 -30 minecraft:glow_lichen[up=true]
setblock 41 214 -30 minecraft:amethyst_cluster[facing=down]
setblock 41 214 -29 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 33 214 -28 minecraft:glow_lichen[up=true]
setblock 35 214 -26 minecraft:amethyst_cluster[facing=down]
setblock 34 214 -25 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 37 214 -25 minecraft:pointed_dripstone[thickness=middle,vertical_direction=down]
setblock 34 213 -35 minecraft:cave_vines[age=25,berries=true]
setblock 37 213 -35 minecraft:glow_lichen[up=true]
setblock 34 213 -31 minecraft:glow_lichen[up=true]
setblock 41 213 -29 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 40 213 -27 minecraft:amethyst_cluster[facing=down]
setblock 37 213 -25 minecraft:pointed_dripstone[thickness=frustum,vertical_direction=down]
setblock 35 212 -35 minecraft:glow_lichen[up=true]
setblock 35 212 -28 minecraft:glow_lichen[up=true]
setblock 36 212 -27 minecraft:glow_lichen[up=true]
setblock 37 212 -25 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 39 211 -30 minecraft:glow_lichen[up=true]
setblock 37 211 -27 minecraft:pointed_dripstone[thickness=tip,vertical_direction=down]
setblock 36 210 -30 minecraft:glow_lichen[up=true]
setblock 38 209 -30 minecraft:glow_lichen[up=true]
setblock 37 209 -28 minecraft:amethyst_cluster[facing=down]
