function himmelsinsel:bau/wesen
forceload remove -48 -48 47 47
scoreboard players set #ausbau_stufe hs.state 0
scoreboard players set #ausbau hs.state 1
tellraw @a ["",{"text":"[Himmelsinsel] ","color":"light_purple"},{"text":"Neu: die Marktinsel im Nordosten der Spawn-Insel!","color":"white"}]
