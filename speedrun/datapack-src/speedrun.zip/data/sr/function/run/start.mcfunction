execute unless entity @a[team=!] run return run tellraw @a[tag=sr_starter] [{"text": "[Speedrun] ", "color": "yellow"}, {"text": "Erst eine Rolle wählen (Knöpfe auf der Insel oder Esc → Speedrun-Menü).", "color": "red"}]
scoreboard players add #run sr 1
scoreboard players operation #slot sr = #run sr
scoreboard players remove #slot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:run/pick_pos
execute store result storage sr:run x int 1 run scoreboard players get #cx sr
execute store result storage sr:run z int 1 run scoreboard players get #cz sr
tag @a[team=!] add sr_run
tag @a[team=!] remove sr_lobby
execute as @a[tag=sr_run] run function sr:player/reset_state
gamemode survival @a[tag=sr_run]
time set 0
weather clear
difficulty normal
function sr:tasks/reset
scoreboard players set #crystals sr 0
scoreboard players set @a sr_endt 0
execute in minecraft:overworld run tp @a[tag=sr_run] 0 200 0
scoreboard players set #try sr 0
function sr:run/place with storage sr:run
execute as @a[tag=sr_run] at @s run spawnpoint @s ~ ~ ~
scoreboard players set #ticks sr 0
scoreboard players set #active sr 1
bossbar set sr:timer value 0
bossbar set sr:timer players @a[tag=sr_run]
bossbar set sr:timer visible true
title @a[tag=sr_run] title [{"text": "Run #", "color": "yellow"}, {"score": {"name": "#run", "objective": "sr"}, "color": "yellow"}]
title @a[tag=sr_run] subtitle {"text": "Los geht’s! Aufgaben stehen rechts.", "color": "white"}
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.6 1.2
tellraw @a [{"text": "[Speedrun] ", "color": "yellow"}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " gestartet bei ", "color": "gray"}, {"nbt": "x", "storage": "sr:run", "color": "white"}, {"text": " / ", "color": "gray"}, {"nbt": "z", "storage": "sr:run", "color": "white"}]
