scoreboard players add #try sr 1
execute if score #try sr matches 6.. run return run tellraw @a {"text":"[Speedrun] Konnte keinen Startplatz finden.","color":"red"}
scoreboard players add #slot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:run/pick_pos
execute store result storage sr:run x int 1 run scoreboard players get #cx sr
execute store result storage sr:run z int 1 run scoreboard players get #cz sr
function sr:run/place with storage sr:run
