execute as @a[tag=sr_run] at @s if dimension minecraft:the_end run scoreboard players add @s sr_endt 1
execute if score #crystals sr matches 1 run return 0
execute unless entity @a[tag=sr_run,scores={sr_endt=6..}] run return 0
execute in minecraft:the_end if entity @e[type=minecraft:ender_dragon] run return run scoreboard players set #crystals sr 1
scoreboard players set #crystals sr 1
give @r[tag=sr_run,scores={sr_endt=6..}] minecraft:end_crystal 4
tellraw @a[tag=sr_run] [{"text": "[Speedrun] ", "color": "yellow"}, {"text": "Der Drache ist aus einem alten Run schon tot. Setzt die 4 Endkristalle auf die 4 Seiten des Ausgangsportals in der Mitte, dann kommt er zurück.", "color": "light_purple"}]
