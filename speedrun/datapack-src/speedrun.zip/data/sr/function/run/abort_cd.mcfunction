scoreboard players set #cd sr 0
title @a clear
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " hat den Countdown abgebrochen.", "color": "red"}]
