execute if score #cd sr matches 1.. run return run function sr:run/abort_cd
execute if score #active sr matches 0 run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Gerade läuft kein Run.", "color": "gray"}]
scoreboard players set #active sr 0
bossbar set sr:t1 visible false
bossbar set sr:t2 visible false
bossbar set sr:t3 visible false
bossbar set sr:t4 visible false
bossbar set sr:t5 visible false
bossbar set sr:t6 visible false
bossbar set sr:t7 visible false
bossbar set sr:t8 visible false
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@s", "color": "white"}, {"text": " hat den Run abgebrochen.", "color": "red"}]
execute as @a[tag=sr_run] run function sr:player/to_lobby
execute as @a[tag=sr_spec] run function sr:player/to_lobby
