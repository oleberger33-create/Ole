scoreboard players add #ticks sr 1
scoreboard players operation #t sr = #ticks sr
scoreboard players operation #t sr %= #20 sr
execute if score #t sr matches 0 run function sr:run/second
