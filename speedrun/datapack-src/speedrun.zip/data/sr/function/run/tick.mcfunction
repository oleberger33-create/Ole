scoreboard players add #st sr 1
execute if entity @a[tag=sr_run] run scoreboard players add #ticks sr 1
execute if score #st sr matches 20.. run function sr:run/second
