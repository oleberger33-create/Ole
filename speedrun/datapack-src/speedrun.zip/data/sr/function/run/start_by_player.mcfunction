tag @s add sr_starter
function sr:run/start
tag @a remove sr_starter
