execute if score #active sr matches 0 run return run tellraw @s [{"text": "[Speedrun] ", "color": "yellow"}, {"text": "Gerade läuft kein Run.", "color": "red"}]
execute unless entity @s[team=!] run return run tellraw @s [{"text": "[Speedrun] ", "color": "yellow"}, {"text": "Erst eine Rolle wählen.", "color": "red"}]
execute if entity @s[tag=sr_run] run return run tellraw @s [{"text": "[Speedrun] ", "color": "yellow"}, {"text": "Du bist schon im Run.", "color": "gray"}]
execute unless entity @a[tag=sr_run] run return run tellraw @s [{"text": "[Speedrun] ", "color": "yellow"}, {"text": "Niemand ist gerade im Run.", "color": "red"}]
function sr:player/reset_state
tag @s remove sr_lobby
tag @s add sr_run
gamemode survival @s
tp @s @r[tag=sr_run,distance=0..,limit=1,tag=!sr_lobby]
execute at @s run spawnpoint @s ~ ~ ~
bossbar set sr:timer players @a[tag=sr_run]
