execute if score #active sr matches 1 run return 0
execute unless score #run sr = #finrun sr run return 0
execute as @a[tag=sr_run] run function sr:player/to_lobby
execute as @a[tag=sr_spec] run function sr:player/to_lobby
