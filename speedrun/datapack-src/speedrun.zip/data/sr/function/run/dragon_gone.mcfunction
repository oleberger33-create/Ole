scoreboard players set #wn sr 0
execute if score #wn sr matches 0 if entity @a[tag=sr_run,team=sr_t1,advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #wn sr 1
execute if score #wn sr matches 0 if entity @a[tag=sr_run,team=sr_t2,advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #wn sr 2
execute if score #wn sr matches 0 if entity @a[tag=sr_run,team=sr_t3,advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #wn sr 3
execute if score #wn sr matches 0 if entity @a[tag=sr_run,team=sr_t4,advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #wn sr 4
execute if score #wn sr matches 0 if entity @a[tag=sr_run,team=sr_t5,advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #wn sr 5
execute if score #wn sr matches 0 if entity @a[tag=sr_run,team=sr_t6,advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #wn sr 6
execute if score #wn sr matches 0 if entity @a[tag=sr_run,team=sr_t7,advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #wn sr 7
execute if score #wn sr matches 0 if entity @a[tag=sr_run,team=sr_t8,advancements={minecraft:end/kill_dragon=true}] run scoreboard players set #wn sr 8
execute if score #wn sr matches 0 in minecraft:the_end positioned 0 64 0 as @p[tag=sr_run,distance=..200] run scoreboard players operation #wn sr = @s sr_team
execute if score #wn sr matches 0 run scoreboard players set #wn sr 1
execute store result storage sr:run win.n int 1 run scoreboard players get #wn sr
function sr:run/finish with storage sr:run win
