scoreboard players set #active sr 0
scoreboard players operation #fmin sr = #min sr
scoreboard players operation #fsec sr = #sec sr
execute if score #best sr matches 0 run scoreboard players operation #best sr = #ticks sr
execute if score #ticks sr < #best sr run scoreboard players operation #best sr = #ticks sr
scoreboard players operation #last sr = #ticks sr
function sr:sidebar/lobby
title @a[tag=sr_run] title {"text": "Drache besiegt!", "color": "gold"}
execute if score #sec sr matches 10.. run title @a[tag=sr_run] subtitle [{"text": "Zeit ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}}, {"text": ":"}, {"score": {"name": "#sec", "objective": "sr"}}]
execute if score #sec sr matches ..9 run title @a[tag=sr_run] subtitle [{"text": "Zeit ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}}, {"text": ":0"}, {"score": {"name": "#sec", "objective": "sr"}}]
execute as @a[tag=sr_run] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
tellraw @a [{"text": "[Speedrun] ", "color": "yellow"}, {"text": "Run #", "color": "gold"}, {"score": {"name": "#run", "objective": "sr"}, "color": "gold"}, {"text": " geschafft! ", "color": "gold"}, {"text": "[Zurück zur Lobby]", "color": "aqua", "click_event": {"action": "run_command", "command": "/trigger sr_aktion set 2"}}]
