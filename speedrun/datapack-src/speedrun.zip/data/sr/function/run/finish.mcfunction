scoreboard players set #finished sr 1
scoreboard players set #active sr 0
$scoreboard players set #winner sr $(n)
scoreboard players operation #s sr = #ticks sr
scoreboard players operation #s sr /= #20 sr
scoreboard players operation #min sr = #s sr
scoreboard players operation #min sr /= #60 sr
scoreboard players operation #sec sr = #s sr
scoreboard players operation #sec sr %= #60 sr
execute if score #runmode sr matches 1 unless score #best1 sr matches 1.. run scoreboard players operation #best1 sr = #ticks sr
execute if score #runmode sr matches 1 if score #ticks sr < #best1 sr run scoreboard players operation #best1 sr = #ticks sr
execute if score #runmode sr matches 2 unless score #best2 sr matches 1.. run scoreboard players operation #best2 sr = #ticks sr
execute if score #runmode sr matches 2 if score #ticks sr < #best2 sr run scoreboard players operation #best2 sr = #ticks sr
execute if score #runmode sr matches 3 unless score #best3 sr matches 1.. run scoreboard players operation #best3 sr = #ticks sr
execute if score #runmode sr matches 3 if score #ticks sr < #best3 sr run scoreboard players operation #best3 sr = #ticks sr
execute if score #runmode sr matches 4 unless score #best4 sr matches 1.. run scoreboard players operation #best4 sr = #ticks sr
execute if score #runmode sr matches 4 if score #ticks sr < #best4 sr run scoreboard players operation #best4 sr = #ticks sr
execute if score #runmode sr matches 5 unless score #best5 sr matches 1.. run scoreboard players operation #best5 sr = #ticks sr
execute if score #runmode sr matches 5 if score #ticks sr < #best5 sr run scoreboard players operation #best5 sr = #ticks sr
scoreboard players operation #last sr = #ticks sr
function sr:holo/leaderboard
function sr:sidebar/lobby
title @a times 10 80 20
execute if score #winner sr matches 1 if score #teams sr matches 2.. run title @a title {"text": "Team Rot gewinnt!", "color": "red", "bold": true}
execute if score #winner sr matches 1 if score #teams sr matches 1 run title @a title {"text": "Drache besiegt!", "color": "gold", "bold": true}
execute if score #winner sr matches 1 run scoreboard players add @a[tag=sr_run,scores={sr_team=1}] sr_wins 1
execute if score #winner sr matches 1 as @a[tag=sr_run,scores={sr_team=1}] at @s run function sr:fx/fireworks
execute if score #winner sr matches 1 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " · Sieger: ", "color": "gray"}, {"text": "Team Rot", "color": "red", "bold": true}, {"text": " ", "color": "gray"}, {"selector": "@a[tag=sr_run,scores={sr_team=1}]", "color": "white"}]
execute if score #winner sr matches 2 if score #teams sr matches 2.. run title @a title {"text": "Team Blau gewinnt!", "color": "blue", "bold": true}
execute if score #winner sr matches 2 if score #teams sr matches 1 run title @a title {"text": "Drache besiegt!", "color": "gold", "bold": true}
execute if score #winner sr matches 2 run scoreboard players add @a[tag=sr_run,scores={sr_team=2}] sr_wins 1
execute if score #winner sr matches 2 as @a[tag=sr_run,scores={sr_team=2}] at @s run function sr:fx/fireworks
execute if score #winner sr matches 2 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " · Sieger: ", "color": "gray"}, {"text": "Team Blau", "color": "blue", "bold": true}, {"text": " ", "color": "gray"}, {"selector": "@a[tag=sr_run,scores={sr_team=2}]", "color": "white"}]
execute if score #winner sr matches 3 if score #teams sr matches 2.. run title @a title {"text": "Team Grün gewinnt!", "color": "green", "bold": true}
execute if score #winner sr matches 3 if score #teams sr matches 1 run title @a title {"text": "Drache besiegt!", "color": "gold", "bold": true}
execute if score #winner sr matches 3 run scoreboard players add @a[tag=sr_run,scores={sr_team=3}] sr_wins 1
execute if score #winner sr matches 3 as @a[tag=sr_run,scores={sr_team=3}] at @s run function sr:fx/fireworks
execute if score #winner sr matches 3 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " · Sieger: ", "color": "gray"}, {"text": "Team Grün", "color": "green", "bold": true}, {"text": " ", "color": "gray"}, {"selector": "@a[tag=sr_run,scores={sr_team=3}]", "color": "white"}]
execute if score #winner sr matches 4 if score #teams sr matches 2.. run title @a title {"text": "Team Gelb gewinnt!", "color": "yellow", "bold": true}
execute if score #winner sr matches 4 if score #teams sr matches 1 run title @a title {"text": "Drache besiegt!", "color": "gold", "bold": true}
execute if score #winner sr matches 4 run scoreboard players add @a[tag=sr_run,scores={sr_team=4}] sr_wins 1
execute if score #winner sr matches 4 as @a[tag=sr_run,scores={sr_team=4}] at @s run function sr:fx/fireworks
execute if score #winner sr matches 4 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " · Sieger: ", "color": "gray"}, {"text": "Team Gelb", "color": "yellow", "bold": true}, {"text": " ", "color": "gray"}, {"selector": "@a[tag=sr_run,scores={sr_team=4}]", "color": "white"}]
execute if score #winner sr matches 5 if score #teams sr matches 2.. run title @a title {"text": "Team Türkis gewinnt!", "color": "aqua", "bold": true}
execute if score #winner sr matches 5 if score #teams sr matches 1 run title @a title {"text": "Drache besiegt!", "color": "gold", "bold": true}
execute if score #winner sr matches 5 run scoreboard players add @a[tag=sr_run,scores={sr_team=5}] sr_wins 1
execute if score #winner sr matches 5 as @a[tag=sr_run,scores={sr_team=5}] at @s run function sr:fx/fireworks
execute if score #winner sr matches 5 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " · Sieger: ", "color": "gray"}, {"text": "Team Türkis", "color": "aqua", "bold": true}, {"text": " ", "color": "gray"}, {"selector": "@a[tag=sr_run,scores={sr_team=5}]", "color": "white"}]
execute if score #winner sr matches 6 if score #teams sr matches 2.. run title @a title {"text": "Team Lila gewinnt!", "color": "light_purple", "bold": true}
execute if score #winner sr matches 6 if score #teams sr matches 1 run title @a title {"text": "Drache besiegt!", "color": "gold", "bold": true}
execute if score #winner sr matches 6 run scoreboard players add @a[tag=sr_run,scores={sr_team=6}] sr_wins 1
execute if score #winner sr matches 6 as @a[tag=sr_run,scores={sr_team=6}] at @s run function sr:fx/fireworks
execute if score #winner sr matches 6 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " · Sieger: ", "color": "gray"}, {"text": "Team Lila", "color": "light_purple", "bold": true}, {"text": " ", "color": "gray"}, {"selector": "@a[tag=sr_run,scores={sr_team=6}]", "color": "white"}]
execute if score #winner sr matches 7 if score #teams sr matches 2.. run title @a title {"text": "Team Orange gewinnt!", "color": "gold", "bold": true}
execute if score #winner sr matches 7 if score #teams sr matches 1 run title @a title {"text": "Drache besiegt!", "color": "gold", "bold": true}
execute if score #winner sr matches 7 run scoreboard players add @a[tag=sr_run,scores={sr_team=7}] sr_wins 1
execute if score #winner sr matches 7 as @a[tag=sr_run,scores={sr_team=7}] at @s run function sr:fx/fireworks
execute if score #winner sr matches 7 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " · Sieger: ", "color": "gray"}, {"text": "Team Orange", "color": "gold", "bold": true}, {"text": " ", "color": "gray"}, {"selector": "@a[tag=sr_run,scores={sr_team=7}]", "color": "white"}]
execute if score #winner sr matches 8 if score #teams sr matches 2.. run title @a title {"text": "Team Weiß gewinnt!", "color": "white", "bold": true}
execute if score #winner sr matches 8 if score #teams sr matches 1 run title @a title {"text": "Drache besiegt!", "color": "gold", "bold": true}
execute if score #winner sr matches 8 run scoreboard players add @a[tag=sr_run,scores={sr_team=8}] sr_wins 1
execute if score #winner sr matches 8 as @a[tag=sr_run,scores={sr_team=8}] at @s run function sr:fx/fireworks
execute if score #winner sr matches 8 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " · Sieger: ", "color": "gray"}, {"text": "Team Weiß", "color": "white", "bold": true}, {"text": " ", "color": "gray"}, {"selector": "@a[tag=sr_run,scores={sr_team=8}]", "color": "white"}]
execute if score #sec sr matches 10.. run title @a subtitle [{"text": "Zeit ", "color": "gray"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}]
execute if score #sec sr matches ..9 run title @a subtitle [{"text": "Zeit ", "color": "gray"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}]
execute if score #sec sr matches 10.. run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zeit ", "color": "gray"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}]
execute if score #sec sr matches ..9 run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Zeit ", "color": "gray"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}]
execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
bossbar set sr:t1 visible false
bossbar set sr:t2 visible false
bossbar set sr:t3 visible false
bossbar set sr:t4 visible false
bossbar set sr:t5 visible false
bossbar set sr:t6 visible false
bossbar set sr:t7 visible false
bossbar set sr:t8 visible false
scoreboard players operation #finrun sr = #run sr
schedule function sr:run/auto_lobby 400t
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "In 20 Sekunden geht es zurück zur Lobby. ", "color": "gray"}, {"text": "[Jetzt zur Lobby]", "color": "aqua", "bold": false, "click_event": {"action": "run_command", "command": "/trigger sr_aktion set 2"}}]
