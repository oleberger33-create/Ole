scoreboard players set #active sr 0
bossbar set sr:t1 visible false
bossbar set sr:t2 visible false
bossbar set sr:t3 visible false
bossbar set sr:t4 visible false
bossbar set sr:t5 visible false
bossbar set sr:t6 visible false
bossbar set sr:t7 visible false
bossbar set sr:t8 visible false
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run beendet – niemand mehr im Run.", "color": "gray"}]
