execute unless entity @a[tag=sr_run] run return run function sr:run/empty
scoreboard players operation #s sr = #ticks sr
scoreboard players operation #s sr /= #20 sr
scoreboard players operation #min sr = #s sr
scoreboard players operation #min sr /= #60 sr
scoreboard players operation #sec sr = #s sr
scoreboard players operation #sec sr %= #60 sr
execute if entity @a[tag=sr_run,team=sr_t1] run function sr:team/second_t1
execute if entity @a[tag=sr_run,team=sr_t2] run function sr:team/second_t2
execute if entity @a[tag=sr_run,team=sr_t3] run function sr:team/second_t3
execute if entity @a[tag=sr_run,team=sr_t4] run function sr:team/second_t4
execute if entity @a[tag=sr_run,team=sr_t5] run function sr:team/second_t5
execute if entity @a[tag=sr_run,team=sr_t6] run function sr:team/second_t6
execute if entity @a[tag=sr_run,team=sr_t7] run function sr:team/second_t7
execute if entity @a[tag=sr_run,team=sr_t8] run function sr:team/second_t8
scoreboard players operation #half sr = #s sr
scoreboard players operation #half sr %= #2 sr
execute if score #half sr matches 0 as @a[tag=sr_run] run function sr:role/actionbar
function sr:run/end_watch
