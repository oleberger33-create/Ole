execute unless entity @a[tag=sr_run] run return run function sr:run/empty
scoreboard players operation #s sr = #ticks sr
scoreboard players operation #s sr /= #20 sr
scoreboard players operation #min sr = #s sr
scoreboard players operation #min sr /= #60 sr
scoreboard players operation #sec sr = #s sr
scoreboard players operation #sec sr %= #60 sr
execute if entity @a[tag=sr_run,scores={sr_team=1}] run function sr:team/second_t1
execute if entity @a[tag=sr_run,scores={sr_team=2}] run function sr:team/second_t2
execute if entity @a[tag=sr_run,scores={sr_team=3}] run function sr:team/second_t3
execute if entity @a[tag=sr_run,scores={sr_team=4}] run function sr:team/second_t4
execute if entity @a[tag=sr_run,scores={sr_team=5}] run function sr:team/second_t5
execute if entity @a[tag=sr_run,scores={sr_team=6}] run function sr:team/second_t6
execute if entity @a[tag=sr_run,scores={sr_team=7}] run function sr:team/second_t7
execute if entity @a[tag=sr_run,scores={sr_team=8}] run function sr:team/second_t8
execute as @a[tag=sr_run,scores={sr_slot=1..16}] at @s run function sr:p/second
scoreboard players operation #five sr = #s sr
scoreboard players operation #five sr %= #5 sr
execute if score #five sr matches 0 run effect give @a[tag=sr_run] minecraft:glowing infinite 0 true
function sr:run/end_watch
