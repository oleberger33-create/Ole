scoreboard players operation #s sr = #ticks sr
scoreboard players operation #s sr /= #20 sr
scoreboard players operation #min sr = #s sr
scoreboard players operation #min sr /= #60 sr
scoreboard players operation #sec sr = #s sr
scoreboard players operation #sec sr %= #60 sr
execute if score #sec sr matches 10.. run bossbar set sr:timer name [{"text": "Run #", "color": "yellow"}, {"score": {"name": "#run", "objective": "sr"}, "color": "yellow"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#donecount", "objective": "sr"}, "color": "green"}, {"text": "/15", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:timer name [{"text": "Run #", "color": "yellow"}, {"score": {"name": "#run", "objective": "sr"}, "color": "yellow"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#donecount", "objective": "sr"}, "color": "green"}, {"text": "/15", "color": "green"}]
bossbar set sr:timer players @a[tag=sr_run]
function sr:tasks/check
function sr:run/end_crystals
