scoreboard players set #st sr 0
execute if entity @a[tag=sr_run] run scoreboard players set #empty sr 0
execute unless entity @a[tag=sr_run] run scoreboard players add #empty sr 1
execute if score #empty sr matches 600.. run return run function sr:run/empty
execute unless entity @a[tag=sr_run] run return 0
scoreboard players operation #s sr = #ticks sr
scoreboard players operation #s sr /= #20 sr
scoreboard players operation #min sr = #s sr
scoreboard players operation #min sr /= #60 sr
scoreboard players operation #sec sr = #s sr
scoreboard players operation #sec sr %= #60 sr
function sr:time/fmt
execute if entity @a[tag=sr_run,scores={sr_team=1}] run function sr:team/second_t1
execute if entity @a[tag=sr_run,scores={sr_team=2}] run function sr:team/second_t2
execute if entity @a[tag=sr_run,scores={sr_team=3}] run function sr:team/second_t3
execute if entity @a[tag=sr_run,scores={sr_team=4}] run function sr:team/second_t4
execute if entity @a[tag=sr_run,scores={sr_team=5}] run function sr:team/second_t5
execute if entity @a[tag=sr_run,scores={sr_team=6}] run function sr:team/second_t6
execute if entity @a[tag=sr_run,scores={sr_team=7}] run function sr:team/second_t7
execute if entity @a[tag=sr_run,scores={sr_team=8}] run function sr:team/second_t8
execute as @a[tag=sr_run,scores={sr_slot=1..16}] at @s run function sr:p/second
execute as @a[tag=sr_run] unless score @s sr_slot matches 1..16 run function sr:role/actionbar
title @a[tag=sr_spec] actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "Zuschauer", "color": "aqua", "bold": false}]
title @a[tag=sr_lobby] actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "Run läuft", "color": "yellow", "bold": false}, {"text": " · Zuschauen: Fernrohr (Slot 5)", "color": "gray", "bold": false}]
execute as @a[tag=sr_run,gamemode=survival] at @s if dimension minecraft:overworld if entity @s[x=-40,dx=80,y=185,dy=120,z=-40,dz=80] run function sr:p/rescue
scoreboard players operation #five sr = #s sr
scoreboard players operation #five sr %= #5 sr
execute if score #five sr matches 0 run effect give @a[tag=sr_run] minecraft:glowing infinite 0 true
function sr:run/end_watch
