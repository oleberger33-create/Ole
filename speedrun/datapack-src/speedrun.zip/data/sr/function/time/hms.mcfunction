$data modify storage sr:run tstr set value "$(h):$(mp)$(m):$(sp)$(s)"
