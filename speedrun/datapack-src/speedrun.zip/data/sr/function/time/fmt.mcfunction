scoreboard players operation #th sr = #s sr
scoreboard players operation #th sr /= #3600 sr
scoreboard players operation #tm sr = #s sr
scoreboard players operation #tm sr /= #60 sr
execute if score #th sr matches 1.. run scoreboard players operation #tm sr %= #60 sr
scoreboard players operation #ts sr = #s sr
scoreboard players operation #ts sr %= #60 sr
execute store result storage sr:tmp t.h int 1 run scoreboard players get #th sr
execute store result storage sr:tmp t.m int 1 run scoreboard players get #tm sr
execute store result storage sr:tmp t.s int 1 run scoreboard players get #ts sr
data modify storage sr:tmp t.mp set value ""
data modify storage sr:tmp t.sp set value ""
execute if score #tm sr matches ..9 run data modify storage sr:tmp t.mp set value "0"
execute if score #ts sr matches ..9 run data modify storage sr:tmp t.sp set value "0"
execute if score #th sr matches 1.. run return run function sr:time/hms with storage sr:tmp t
function sr:time/ms with storage sr:tmp t
