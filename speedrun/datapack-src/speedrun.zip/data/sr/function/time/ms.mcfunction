$data modify storage sr:run tstr set value "$(m):$(sp)$(s)"
