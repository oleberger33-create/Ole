scoreboard players add #mode sr 1
execute if score #mode sr matches 6.. run scoreboard players set #mode sr 1
function sr:mode/apply
