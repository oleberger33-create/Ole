$scoreboard players set #mode sr $(m)
function sr:mode/apply
