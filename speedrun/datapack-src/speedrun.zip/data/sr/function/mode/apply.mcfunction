function sr:mode/apply_silent
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Modus: ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "yellow", "bold": true}]
execute as @a at @s run playsound minecraft:block.note_block.bell master @s ~ ~ ~ 0.8 1.2
