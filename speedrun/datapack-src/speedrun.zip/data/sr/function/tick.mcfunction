scoreboard players enable @a sr_rolle
scoreboard players enable @a sr_aktion
execute as @a[tag=!sr_seen] run function sr:player/first_join
execute as @a[scores={sr_leave=1..}] run function sr:player/rejoin
execute as @a[scores={sr_rolle=1..}] run function sr:role/pick
execute as @a[scores={sr_aktion=1..}] run function sr:player/action
execute if score #built sr matches 1 run function sr:lobby/inputs
execute as @a[tag=sr_lobby] run function sr:lobby/keep
execute if score #active sr matches 1 run function sr:run/tick
