scoreboard players enable @a sr_rolle
scoreboard players enable @a sr_aktion
execute as @a[tag=!sr_seen2] run function sr:player/first_join
execute as @a[scores={sr_leave=1..}] run function sr:player/rejoin
execute as @a[scores={sr_rolle=1..}] run function sr:role/pref
execute as @a[scores={sr_aktion=1..}] run function sr:player/action
execute as @a[scores={sr_click=1..}] run function sr:item/click
scoreboard players add #itick sr 1
execute if score #itick sr matches 10.. run function sr:item/sweep
execute as @a[tag=sr_lobby] run function sr:lobby/keep
execute if score #cd sr matches 1.. run function sr:start/cd_tick
execute if score #active sr matches 1 run function sr:run/tick
execute if score #resume sr matches 1 if entity @a[name=matsllll] if entity @a[name=Qelloxx] run function sr:fix/resume
execute unless score #gb_fngreg sr matches 1 if entity @a[name=FNGreg] run function sr:fix/giveback_fngreg
execute unless score #gb_qelloxx sr matches 1 if entity @a[name=Qelloxx] run function sr:fix/giveback_qelloxx
