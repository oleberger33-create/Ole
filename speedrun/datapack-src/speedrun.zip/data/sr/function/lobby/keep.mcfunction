effect give @s minecraft:resistance infinite 4 true
effect give @s minecraft:saturation infinite 0 true
execute unless entity @s[gamemode=adventure] unless entity @s[gamemode=creative] run gamemode adventure @s
execute at @s unless dimension minecraft:overworld run function sr:player/tp_lobby
execute at @s if dimension minecraft:overworld unless entity @s[y=185,dy=200] run function sr:player/tp_lobby
execute at @s if dimension minecraft:overworld unless entity @s[x=-40,dx=80,z=-40,dz=80] run function sr:player/tp_lobby
execute if entity @s[tag=sr_refresh] run return run function sr:item/hotbar
execute unless items entity @s hotbar.0 *[minecraft:custom_data~{sr:"start"}] run return run function sr:item/hotbar
execute unless items entity @s hotbar.1 *[minecraft:custom_data~{sr:"mode"}] run return run function sr:item/hotbar
execute unless items entity @s hotbar.2 *[minecraft:custom_data~{sr:"role"}] run return run function sr:item/hotbar
execute unless items entity @s hotbar.4 *[minecraft:custom_data~{sr:"watch"}] run return run function sr:item/hotbar
execute unless items entity @s hotbar.8 *[minecraft:custom_data~{sr:"menu"}] run return run function sr:item/hotbar
