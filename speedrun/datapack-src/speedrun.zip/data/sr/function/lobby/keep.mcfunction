effect give @s minecraft:resistance infinite 4 true
effect give @s minecraft:saturation infinite 0 true
execute unless entity @s[gamemode=adventure] unless entity @s[gamemode=creative] unless entity @s[gamemode=spectator] run gamemode adventure @s
execute at @s unless dimension minecraft:overworld run function sr:player/tp_lobby
execute at @s if dimension minecraft:overworld unless entity @s[y=185,dy=200] run function sr:player/tp_lobby
execute at @s if dimension minecraft:overworld unless entity @s[x=-40,dx=80,z=-40,dz=80] run function sr:player/tp_lobby
