kill @e[type=minecraft:text_display,tag=sr_holo]
execute in minecraft:overworld run fill -14 190 -14 14 212 14 minecraft:air
execute in minecraft:overworld run fill -3 199 -10 3 199 -10 minecraft:grass_block
execute in minecraft:overworld run fill -5 199 -9 5 199 -9 minecraft:grass_block
execute in minecraft:overworld run fill -6 199 -8 6 199 -8 minecraft:grass_block
execute in minecraft:overworld run fill -7 199 -7 7 199 -7 minecraft:grass_block
execute in minecraft:overworld run fill -8 199 -6 8 199 -6 minecraft:grass_block
execute in minecraft:overworld run fill -9 199 -5 9 199 -5 minecraft:grass_block
execute in minecraft:overworld run fill -9 199 -4 9 199 -4 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 -3 10 199 -3 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 -2 10 199 -2 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 -1 10 199 -1 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 0 10 199 0 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 1 10 199 1 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 2 10 199 2 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 3 10 199 3 minecraft:grass_block
execute in minecraft:overworld run fill -9 199 4 9 199 4 minecraft:grass_block
execute in minecraft:overworld run fill -9 199 5 9 199 5 minecraft:grass_block
execute in minecraft:overworld run fill -8 199 6 8 199 6 minecraft:grass_block
execute in minecraft:overworld run fill -7 199 7 7 199 7 minecraft:grass_block
execute in minecraft:overworld run fill -6 199 8 6 199 8 minecraft:grass_block
execute in minecraft:overworld run fill -5 199 9 5 199 9 minecraft:grass_block
execute in minecraft:overworld run fill -3 199 10 3 199 10 minecraft:grass_block
execute in minecraft:overworld run fill -3 198 -9 3 198 -9 minecraft:dirt
execute in minecraft:overworld run fill -5 198 -8 5 198 -8 minecraft:dirt
execute in minecraft:overworld run fill -6 198 -7 6 198 -7 minecraft:dirt
execute in minecraft:overworld run fill -7 198 -6 7 198 -6 minecraft:dirt
execute in minecraft:overworld run fill -8 198 -5 8 198 -5 minecraft:dirt
execute in minecraft:overworld run fill -8 198 -4 8 198 -4 minecraft:dirt
execute in minecraft:overworld run fill -9 198 -3 9 198 -3 minecraft:dirt
execute in minecraft:overworld run fill -9 198 -2 9 198 -2 minecraft:dirt
execute in minecraft:overworld run fill -9 198 -1 9 198 -1 minecraft:dirt
execute in minecraft:overworld run fill -9 198 0 9 198 0 minecraft:dirt
execute in minecraft:overworld run fill -9 198 1 9 198 1 minecraft:dirt
execute in minecraft:overworld run fill -9 198 2 9 198 2 minecraft:dirt
execute in minecraft:overworld run fill -9 198 3 9 198 3 minecraft:dirt
execute in minecraft:overworld run fill -8 198 4 8 198 4 minecraft:dirt
execute in minecraft:overworld run fill -8 198 5 8 198 5 minecraft:dirt
execute in minecraft:overworld run fill -7 198 6 7 198 6 minecraft:dirt
execute in minecraft:overworld run fill -6 198 7 6 198 7 minecraft:dirt
execute in minecraft:overworld run fill -5 198 8 5 198 8 minecraft:dirt
execute in minecraft:overworld run fill -3 198 9 3 198 9 minecraft:dirt
execute in minecraft:overworld run fill -2 197 -8 2 197 -8 minecraft:dirt
execute in minecraft:overworld run fill -4 197 -7 4 197 -7 minecraft:dirt
execute in minecraft:overworld run fill -6 197 -6 6 197 -6 minecraft:dirt
execute in minecraft:overworld run fill -6 197 -5 6 197 -5 minecraft:dirt
execute in minecraft:overworld run fill -7 197 -4 7 197 -4 minecraft:dirt
execute in minecraft:overworld run fill -7 197 -3 7 197 -3 minecraft:dirt
execute in minecraft:overworld run fill -8 197 -2 8 197 -2 minecraft:dirt
execute in minecraft:overworld run fill -8 197 -1 8 197 -1 minecraft:dirt
execute in minecraft:overworld run fill -8 197 0 8 197 0 minecraft:dirt
execute in minecraft:overworld run fill -8 197 1 8 197 1 minecraft:dirt
execute in minecraft:overworld run fill -8 197 2 8 197 2 minecraft:dirt
execute in minecraft:overworld run fill -7 197 3 7 197 3 minecraft:dirt
execute in minecraft:overworld run fill -7 197 4 7 197 4 minecraft:dirt
execute in minecraft:overworld run fill -6 197 5 6 197 5 minecraft:dirt
execute in minecraft:overworld run fill -6 197 6 6 197 6 minecraft:dirt
execute in minecraft:overworld run fill -4 197 7 4 197 7 minecraft:dirt
execute in minecraft:overworld run fill -2 197 8 2 197 8 minecraft:dirt
execute in minecraft:overworld run fill -2 196 -7 2 196 -7 minecraft:stone
execute in minecraft:overworld run fill -4 196 -6 4 196 -6 minecraft:stone
execute in minecraft:overworld run fill -5 196 -5 5 196 -5 minecraft:stone
execute in minecraft:overworld run fill -6 196 -4 6 196 -4 minecraft:stone
execute in minecraft:overworld run fill -6 196 -3 6 196 -3 minecraft:stone
execute in minecraft:overworld run fill -7 196 -2 7 196 -2 minecraft:stone
execute in minecraft:overworld run fill -7 196 -1 7 196 -1 minecraft:stone
execute in minecraft:overworld run fill -7 196 0 7 196 0 minecraft:stone
execute in minecraft:overworld run fill -7 196 1 7 196 1 minecraft:stone
execute in minecraft:overworld run fill -7 196 2 7 196 2 minecraft:stone
execute in minecraft:overworld run fill -6 196 3 6 196 3 minecraft:stone
execute in minecraft:overworld run fill -6 196 4 6 196 4 minecraft:stone
execute in minecraft:overworld run fill -5 196 5 5 196 5 minecraft:stone
execute in minecraft:overworld run fill -4 196 6 4 196 6 minecraft:stone
execute in minecraft:overworld run fill -2 196 7 2 196 7 minecraft:stone
execute in minecraft:overworld run fill -2 195 -5 2 195 -5 minecraft:stone
execute in minecraft:overworld run fill -3 195 -4 3 195 -4 minecraft:stone
execute in minecraft:overworld run fill -4 195 -3 4 195 -3 minecraft:stone
execute in minecraft:overworld run fill -5 195 -2 5 195 -2 minecraft:stone
execute in minecraft:overworld run fill -5 195 -1 5 195 -1 minecraft:stone
execute in minecraft:overworld run fill -5 195 0 5 195 0 minecraft:stone
execute in minecraft:overworld run fill -5 195 1 5 195 1 minecraft:stone
execute in minecraft:overworld run fill -5 195 2 5 195 2 minecraft:stone
execute in minecraft:overworld run fill -4 195 3 4 195 3 minecraft:stone
execute in minecraft:overworld run fill -3 195 4 3 195 4 minecraft:stone
execute in minecraft:overworld run fill -2 195 5 2 195 5 minecraft:stone
execute in minecraft:overworld run fill -1 194 -3 1 194 -3 minecraft:cobblestone
execute in minecraft:overworld run fill -2 194 -2 2 194 -2 minecraft:cobblestone
execute in minecraft:overworld run fill -3 194 -1 3 194 -1 minecraft:cobblestone
execute in minecraft:overworld run fill -3 194 0 3 194 0 minecraft:cobblestone
execute in minecraft:overworld run fill -3 194 1 3 194 1 minecraft:cobblestone
execute in minecraft:overworld run fill -2 194 2 2 194 2 minecraft:cobblestone
execute in minecraft:overworld run fill -1 194 3 1 194 3 minecraft:cobblestone
execute in minecraft:overworld run fill -1 193 -1 1 193 -1 minecraft:cobblestone
execute in minecraft:overworld run fill -1 193 0 1 193 0 minecraft:cobblestone
execute in minecraft:overworld run fill -1 193 1 1 193 1 minecraft:cobblestone
execute in minecraft:overworld run fill -1 199 -1 1 199 1 minecraft:polished_andesite
execute in minecraft:overworld run setblock 0 199 0 minecraft:gold_block
execute in minecraft:overworld run setblock -6 200 -4 minecraft:orange_concrete
execute in minecraft:overworld run setblock -6 200 -3 minecraft:stone_button[face=wall,facing=south]
execute in minecraft:overworld run setblock -6 201 -4 minecraft:dark_oak_sign[rotation=0]{front_text:{has_glowing_text:true,messages:[{"text": "Kämpfer", "color": "gold", "bold": true},{"text": "Wunschrolle"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock -2 200 -4 minecraft:purple_concrete
execute in minecraft:overworld run setblock -2 200 -3 minecraft:stone_button[face=wall,facing=south]
execute in minecraft:overworld run setblock -2 201 -4 minecraft:dark_oak_sign[rotation=0]{front_text:{has_glowing_text:true,messages:[{"text": "Portal & Perlen", "color": "light_purple", "bold": true},{"text": "Wunschrolle"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock 2 200 -4 minecraft:green_concrete
execute in minecraft:overworld run setblock 2 200 -3 minecraft:stone_button[face=wall,facing=south]
execute in minecraft:overworld run setblock 2 201 -4 minecraft:dark_oak_sign[rotation=0]{front_text:{has_glowing_text:true,messages:[{"text": "Versorger", "color": "green", "bold": true},{"text": "Wunschrolle"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock 6 200 -4 minecraft:light_blue_concrete
execute in minecraft:overworld run setblock 6 200 -3 minecraft:stone_button[face=wall,facing=south]
execute in minecraft:overworld run setblock 6 201 -4 minecraft:dark_oak_sign[rotation=0]{front_text:{has_glowing_text:true,messages:[{"text": "Späher", "color": "aqua", "bold": true},{"text": "Wunschrolle"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock -4 200 5 minecraft:yellow_concrete
execute in minecraft:overworld run setblock -4 200 4 minecraft:stone_button[face=wall,facing=north]
execute in minecraft:overworld run setblock -4 201 5 minecraft:dark_oak_sign[rotation=8]{front_text:{has_glowing_text:true,messages:[{"text": "Modus", "color": "yellow", "bold": true},{"text": "wechseln"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock 0 200 5 minecraft:gold_block
execute in minecraft:overworld run setblock 0 200 4 minecraft:lever[face=wall,facing=north,powered=false]
execute in minecraft:overworld run setblock 0 201 5 minecraft:dark_oak_sign[rotation=8]{front_text:{has_glowing_text:true,messages:[{"text": "RUN STARTEN", "color": "green", "bold": true},{"text": "Hebel ziehen"},{"text": "Countdown 5 s"},{"text": ""}]}}
execute in minecraft:overworld run setblock 4 200 5 minecraft:gray_concrete
execute in minecraft:overworld run setblock 4 200 4 minecraft:stone_button[face=wall,facing=north]
execute in minecraft:overworld run setblock 4 201 5 minecraft:dark_oak_sign[rotation=8]{front_text:{has_glowing_text:true,messages:[{"text": "Zuschauen", "color": "aqua", "bold": true},{"text": "an / aus"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock -8 200 -6 minecraft:oak_fence
execute in minecraft:overworld run setblock -8 201 -6 minecraft:lantern
execute in minecraft:overworld run setblock 8 200 -6 minecraft:oak_fence
execute in minecraft:overworld run setblock 8 201 -6 minecraft:lantern
execute in minecraft:overworld run setblock -8 200 6 minecraft:oak_fence
execute in minecraft:overworld run setblock -8 201 6 minecraft:lantern
execute in minecraft:overworld run setblock 8 200 6 minecraft:oak_fence
execute in minecraft:overworld run setblock 8 201 6 minecraft:lantern
execute in minecraft:overworld run setblock 0 200 -9 minecraft:oak_fence
execute in minecraft:overworld run setblock 0 201 -9 minecraft:lantern
execute in minecraft:overworld run setblock 0 200 9 minecraft:oak_fence
execute in minecraft:overworld run setblock 0 201 9 minecraft:lantern
execute in minecraft:overworld run setblock -6 200 2 minecraft:potted_poppy
execute in minecraft:overworld run setblock 6 200 2 minecraft:potted_poppy
execute in minecraft:overworld run setblock -3 200 8 minecraft:potted_poppy
execute in minecraft:overworld run setblock 3 200 -8 minecraft:potted_poppy
execute in minecraft:overworld run setblock -8 200 0 minecraft:potted_poppy
execute in minecraft:overworld run setblock 8 200 0 minecraft:potted_poppy
execute in minecraft:overworld run summon minecraft:text_display 0 205.0 -7 {Tags:["sr_holo","sr_holo_title"],billboard:"center",background:0,shadow:true,text:{"text": "SPEEDRUN", "color": "gold", "bold": true},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[4.0f,4.0f,4.0f]}}
execute in minecraft:overworld run summon minecraft:text_display 0 204.2 -7 {Tags:["sr_holo","sr_holo_sub"],billboard:"center",background:0,shadow:true,text:{"text": "Wer killt den Drachen zuerst?", "color": "gray"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.4f,1.4f,1.4f]}}
function sr:mode/apply_silent
function sr:holo/leaderboard
scoreboard players set #built sr 2
scoreboard players set #lever sr 0
scoreboard players set #b1 sr 0
scoreboard players set #b2 sr 0
scoreboard players set #b3 sr 0
scoreboard players set #b4 sr 0
scoreboard players set #b5 sr 0
scoreboard players set #b6 sr 0
scoreboard players set #b7 sr 0
