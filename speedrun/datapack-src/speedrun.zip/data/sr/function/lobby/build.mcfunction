execute in minecraft:overworld run fill -14 192 -14 14 210 14 minecraft:air
execute in minecraft:overworld run fill -3 199 -10 3 199 -10 minecraft:grass_block
execute in minecraft:overworld run fill -5 199 -9 5 199 -9 minecraft:grass_block
execute in minecraft:overworld run fill -6 199 -8 6 199 -8 minecraft:grass_block
execute in minecraft:overworld run fill -7 199 -7 7 199 -7 minecraft:grass_block
execute in minecraft:overworld run fill -8 199 -6 8 199 -6 minecraft:grass_block
execute in minecraft:overworld run fill -9 199 -5 9 199 -5 minecraft:grass_block
execute in minecraft:overworld run fill -9 199 -4 9 199 -4 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 -3 10 199 -3 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 -2 10 199 -2 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 -1 10 199 -1 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 0 10 199 0 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 1 10 199 1 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 2 10 199 2 minecraft:grass_block
execute in minecraft:overworld run fill -10 199 3 10 199 3 minecraft:grass_block
execute in minecraft:overworld run fill -9 199 4 9 199 4 minecraft:grass_block
execute in minecraft:overworld run fill -9 199 5 9 199 5 minecraft:grass_block
execute in minecraft:overworld run fill -8 199 6 8 199 6 minecraft:grass_block
execute in minecraft:overworld run fill -7 199 7 7 199 7 minecraft:grass_block
execute in minecraft:overworld run fill -6 199 8 6 199 8 minecraft:grass_block
execute in minecraft:overworld run fill -5 199 9 5 199 9 minecraft:grass_block
execute in minecraft:overworld run fill -3 199 10 3 199 10 minecraft:grass_block
execute in minecraft:overworld run fill -3 198 -9 3 198 -9 minecraft:dirt
execute in minecraft:overworld run fill -5 198 -8 5 198 -8 minecraft:dirt
execute in minecraft:overworld run fill -6 198 -7 6 198 -7 minecraft:dirt
execute in minecraft:overworld run fill -7 198 -6 7 198 -6 minecraft:dirt
execute in minecraft:overworld run fill -8 198 -5 8 198 -5 minecraft:dirt
execute in minecraft:overworld run fill -8 198 -4 8 198 -4 minecraft:dirt
execute in minecraft:overworld run fill -9 198 -3 9 198 -3 minecraft:dirt
execute in minecraft:overworld run fill -9 198 -2 9 198 -2 minecraft:dirt
execute in minecraft:overworld run fill -9 198 -1 9 198 -1 minecraft:dirt
execute in minecraft:overworld run fill -9 198 0 9 198 0 minecraft:dirt
execute in minecraft:overworld run fill -9 198 1 9 198 1 minecraft:dirt
execute in minecraft:overworld run fill -9 198 2 9 198 2 minecraft:dirt
execute in minecraft:overworld run fill -9 198 3 9 198 3 minecraft:dirt
execute in minecraft:overworld run fill -8 198 4 8 198 4 minecraft:dirt
execute in minecraft:overworld run fill -8 198 5 8 198 5 minecraft:dirt
execute in minecraft:overworld run fill -7 198 6 7 198 6 minecraft:dirt
execute in minecraft:overworld run fill -6 198 7 6 198 7 minecraft:dirt
execute in minecraft:overworld run fill -5 198 8 5 198 8 minecraft:dirt
execute in minecraft:overworld run fill -3 198 9 3 198 9 minecraft:dirt
execute in minecraft:overworld run fill -2 197 -8 2 197 -8 minecraft:dirt
execute in minecraft:overworld run fill -4 197 -7 4 197 -7 minecraft:dirt
execute in minecraft:overworld run fill -6 197 -6 6 197 -6 minecraft:dirt
execute in minecraft:overworld run fill -6 197 -5 6 197 -5 minecraft:dirt
execute in minecraft:overworld run fill -7 197 -4 7 197 -4 minecraft:dirt
execute in minecraft:overworld run fill -7 197 -3 7 197 -3 minecraft:dirt
execute in minecraft:overworld run fill -8 197 -2 8 197 -2 minecraft:dirt
execute in minecraft:overworld run fill -8 197 -1 8 197 -1 minecraft:dirt
execute in minecraft:overworld run fill -8 197 0 8 197 0 minecraft:dirt
execute in minecraft:overworld run fill -8 197 1 8 197 1 minecraft:dirt
execute in minecraft:overworld run fill -8 197 2 8 197 2 minecraft:dirt
execute in minecraft:overworld run fill -7 197 3 7 197 3 minecraft:dirt
execute in minecraft:overworld run fill -7 197 4 7 197 4 minecraft:dirt
execute in minecraft:overworld run fill -6 197 5 6 197 5 minecraft:dirt
execute in minecraft:overworld run fill -6 197 6 6 197 6 minecraft:dirt
execute in minecraft:overworld run fill -4 197 7 4 197 7 minecraft:dirt
execute in minecraft:overworld run fill -2 197 8 2 197 8 minecraft:dirt
execute in minecraft:overworld run fill -2 196 -6 2 196 -6 minecraft:stone
execute in minecraft:overworld run fill -4 196 -5 4 196 -5 minecraft:stone
execute in minecraft:overworld run fill -5 196 -4 5 196 -4 minecraft:stone
execute in minecraft:overworld run fill -5 196 -3 5 196 -3 minecraft:stone
execute in minecraft:overworld run fill -6 196 -2 6 196 -2 minecraft:stone
execute in minecraft:overworld run fill -6 196 -1 6 196 -1 minecraft:stone
execute in minecraft:overworld run fill -6 196 0 6 196 0 minecraft:stone
execute in minecraft:overworld run fill -6 196 1 6 196 1 minecraft:stone
execute in minecraft:overworld run fill -6 196 2 6 196 2 minecraft:stone
execute in minecraft:overworld run fill -5 196 3 5 196 3 minecraft:stone
execute in minecraft:overworld run fill -5 196 4 5 196 4 minecraft:stone
execute in minecraft:overworld run fill -4 196 5 4 196 5 minecraft:stone
execute in minecraft:overworld run fill -2 196 6 2 196 6 minecraft:stone
execute in minecraft:overworld run fill -2 195 -4 2 195 -4 minecraft:stone
execute in minecraft:overworld run fill -3 195 -3 3 195 -3 minecraft:stone
execute in minecraft:overworld run fill -4 195 -2 4 195 -2 minecraft:stone
execute in minecraft:overworld run fill -4 195 -1 4 195 -1 minecraft:stone
execute in minecraft:overworld run fill -4 195 0 4 195 0 minecraft:stone
execute in minecraft:overworld run fill -4 195 1 4 195 1 minecraft:stone
execute in minecraft:overworld run fill -4 195 2 4 195 2 minecraft:stone
execute in minecraft:overworld run fill -3 195 3 3 195 3 minecraft:stone
execute in minecraft:overworld run fill -2 195 4 2 195 4 minecraft:stone
execute in minecraft:overworld run fill -1 194 -2 1 194 -2 minecraft:cobblestone
execute in minecraft:overworld run fill -2 194 -1 2 194 -1 minecraft:cobblestone
execute in minecraft:overworld run fill -2 194 0 2 194 0 minecraft:cobblestone
execute in minecraft:overworld run fill -2 194 1 2 194 1 minecraft:cobblestone
execute in minecraft:overworld run fill -1 194 2 1 194 2 minecraft:cobblestone
execute in minecraft:overworld run setblock 0 194 0 minecraft:cobblestone
execute in minecraft:overworld run setblock -4 200 -4 minecraft:orange_concrete
execute in minecraft:overworld run setblock -4 200 -3 minecraft:stone_button[face=wall,facing=south]
execute in minecraft:overworld run setblock -4 201 -4 minecraft:dark_oak_sign[rotation=0]{front_text:{has_glowing_text:true,messages:[{"text": "Ole", "color": "gold", "bold": true},{"text": "Kämpfer"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock 0 200 -4 minecraft:purple_concrete
execute in minecraft:overworld run setblock 0 200 -3 minecraft:stone_button[face=wall,facing=south]
execute in minecraft:overworld run setblock 0 201 -4 minecraft:dark_oak_sign[rotation=0]{front_text:{has_glowing_text:true,messages:[{"text": "Mats", "color": "light_purple", "bold": true},{"text": "Portal & Perlen"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock 4 200 -4 minecraft:green_concrete
execute in minecraft:overworld run setblock 4 200 -3 minecraft:stone_button[face=wall,facing=south]
execute in minecraft:overworld run setblock 4 201 -4 minecraft:dark_oak_sign[rotation=0]{front_text:{has_glowing_text:true,messages:[{"text": "Sammy", "color": "green", "bold": true},{"text": "Versorger"},{"text": "Knopf drücken"},{"text": ""}]}}
execute in minecraft:overworld run setblock 0 200 5 minecraft:gold_block
execute in minecraft:overworld run setblock 0 200 4 minecraft:lever[face=wall,facing=north,powered=false]
execute in minecraft:overworld run setblock 0 201 5 minecraft:dark_oak_sign[rotation=8]{front_text:{has_glowing_text:true,messages:[{"text": "Neuer Run", "color": "yellow", "bold": true},{"text": "Hebel ziehen"},{"text": "Alle mit Rolle"},{"text": "starten"}]}}
execute in minecraft:overworld run setblock -7 200 -7 minecraft:oak_fence
execute in minecraft:overworld run setblock -7 201 -7 minecraft:lantern
execute in minecraft:overworld run setblock 7 200 -7 minecraft:oak_fence
execute in minecraft:overworld run setblock 7 201 -7 minecraft:lantern
execute in minecraft:overworld run setblock -7 200 7 minecraft:oak_fence
execute in minecraft:overworld run setblock -7 201 7 minecraft:lantern
execute in minecraft:overworld run setblock 7 200 7 minecraft:oak_fence
execute in minecraft:overworld run setblock 7 201 7 minecraft:lantern
execute in minecraft:overworld run setblock -6 200 2 minecraft:potted_poppy
execute in minecraft:overworld run setblock 6 200 2 minecraft:potted_poppy
execute in minecraft:overworld run setblock -2 200 7 minecraft:potted_poppy
execute in minecraft:overworld run setblock 3 200 -7 minecraft:potted_poppy
scoreboard players set #built sr 1
scoreboard players set #lever sr 0
scoreboard players set #b1 sr 0
scoreboard players set #b2 sr 0
scoreboard players set #b3 sr 0
tellraw @a {"text": "[Speedrun] Lobby-Insel gebaut.", "color": "gray"}
