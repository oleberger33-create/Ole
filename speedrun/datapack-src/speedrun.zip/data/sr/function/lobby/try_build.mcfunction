execute in minecraft:overworld if loaded 0 199 0 if loaded 10 199 10 if loaded -10 199 -10 run return run function sr:lobby/build
schedule function sr:lobby/try_build 20t
