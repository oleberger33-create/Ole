execute in minecraft:overworld if block -6 200 -3 minecraft:stone_button[powered=true] if score #b1 sr matches 0 positioned -6 200 -2 as @p[distance=..6] run scoreboard players set @s sr_rolle 1
execute in minecraft:overworld if block -6 200 -3 minecraft:stone_button[powered=true] run scoreboard players set #b1 sr 1
execute in minecraft:overworld if block -6 200 -3 minecraft:stone_button[powered=false] run scoreboard players set #b1 sr 0
execute in minecraft:overworld if block -2 200 -3 minecraft:stone_button[powered=true] if score #b2 sr matches 0 positioned -2 200 -2 as @p[distance=..6] run scoreboard players set @s sr_rolle 2
execute in minecraft:overworld if block -2 200 -3 minecraft:stone_button[powered=true] run scoreboard players set #b2 sr 1
execute in minecraft:overworld if block -2 200 -3 minecraft:stone_button[powered=false] run scoreboard players set #b2 sr 0
execute in minecraft:overworld if block 2 200 -3 minecraft:stone_button[powered=true] if score #b3 sr matches 0 positioned 2 200 -2 as @p[distance=..6] run scoreboard players set @s sr_rolle 3
execute in minecraft:overworld if block 2 200 -3 minecraft:stone_button[powered=true] run scoreboard players set #b3 sr 1
execute in minecraft:overworld if block 2 200 -3 minecraft:stone_button[powered=false] run scoreboard players set #b3 sr 0
execute in minecraft:overworld if block 6 200 -3 minecraft:stone_button[powered=true] if score #b4 sr matches 0 positioned 6 200 -2 as @p[distance=..6] run scoreboard players set @s sr_rolle 4
execute in minecraft:overworld if block 6 200 -3 minecraft:stone_button[powered=true] run scoreboard players set #b4 sr 1
execute in minecraft:overworld if block 6 200 -3 minecraft:stone_button[powered=false] run scoreboard players set #b4 sr 0
execute in minecraft:overworld if block -4 200 4 minecraft:stone_button[powered=true] if score #b5 sr matches 0 positioned -4 200 3 as @p[distance=..6] run scoreboard players set @s sr_aktion 5
execute in minecraft:overworld if block -4 200 4 minecraft:stone_button[powered=true] run scoreboard players set #b5 sr 1
execute in minecraft:overworld if block -4 200 4 minecraft:stone_button[powered=false] run scoreboard players set #b5 sr 0
execute in minecraft:overworld if block 4 200 4 minecraft:stone_button[powered=true] if score #b6 sr matches 0 positioned 4 200 3 as @p[distance=..6] run scoreboard players set @s sr_aktion 4
execute in minecraft:overworld if block 4 200 4 minecraft:stone_button[powered=true] run scoreboard players set #b6 sr 1
execute in minecraft:overworld if block 4 200 4 minecraft:stone_button[powered=false] run scoreboard players set #b6 sr 0
execute in minecraft:overworld if block 0 200 4 minecraft:lever[powered=true] run function sr:lobby/lever
