execute in minecraft:overworld run setblock 0 200 4 minecraft:lever[face=wall,facing=north,powered=false]
execute in minecraft:overworld positioned 0 200 3 as @p[distance=..8] run tag @s add sr_starter
function sr:start/request
tag @a remove sr_starter
