execute as @a[tag=sr_run,scores={sr_team=4}] at @s if dimension minecraft:the_end run return 1
execute if entity @a[tag=sr_run,scores={sr_team=4},advancements={minecraft:story/enter_the_end=true}] run return 1
return 0
