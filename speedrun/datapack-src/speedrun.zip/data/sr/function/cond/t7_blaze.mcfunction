scoreboard players set #sum sr 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t7] store result score @s sr_tmp run clear @s minecraft:blaze_rod 0
execute as @a[tag=sr_run,team=sr_t7] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t7] store result score @s sr_tmp run clear @s minecraft:blaze_powder 0
execute as @a[tag=sr_run,team=sr_t7] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t7] store result score @s sr_tmp run clear @s minecraft:ender_eye 0
execute as @a[tag=sr_run,team=sr_t7] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
execute if score #sum sr matches 14.. run return 1
return 0
