execute as @a[tag=sr_run,team=sr_t5] at @s if dimension minecraft:the_nether run return 1
execute if entity @a[tag=sr_run,team=sr_t5,advancements={minecraft:story/enter_the_nether=true}] run return 1
return 0
