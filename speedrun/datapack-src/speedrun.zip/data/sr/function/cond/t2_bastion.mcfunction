execute if entity @a[tag=sr_run,scores={sr_team=2},advancements={minecraft:nether/find_bastion=true}] run return 1
return 0
