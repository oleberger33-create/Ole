scoreboard players set #sum sr 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t6] store result score @s sr_tmp run clear @s minecraft:ender_eye 0
execute as @a[tag=sr_run,team=sr_t6] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players operation #t6_v_eyes sr = #sum sr
scoreboard players display numberformat eyes sr_s6 fixed [{"score": {"name": "#t6_v_eyes", "objective": "sr"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
execute if score #sum sr matches 12.. run return 1
return 0
