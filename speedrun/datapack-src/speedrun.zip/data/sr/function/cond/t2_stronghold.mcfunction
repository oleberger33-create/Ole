execute if entity @a[tag=sr_run,team=sr_t2,advancements={minecraft:story/follow_ender_eye=true}] run return 1
return 0
