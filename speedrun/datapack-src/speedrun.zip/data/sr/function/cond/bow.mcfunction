scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_mats] store result score @s sr_tmp run clear @s minecraft:bow 0
execute as @a[tag=sr_run,team=sr_mats] run scoreboard players operation #c sr += @s sr_tmp
execute if score #c sr matches 0 run return 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_mats] store result score @s sr_tmp run clear @s minecraft:arrow 0
execute as @a[tag=sr_run,team=sr_mats] run scoreboard players operation #c sr += @s sr_tmp
execute if score #c sr matches 16.. run return 1
return 0
