scoreboard players set #sum sr 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t7] store result score @s sr_tmp run clear @s #minecraft:beds 0
execute as @a[tag=sr_run,team=sr_t7] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players operation #t7_v_beds sr = #sum sr
scoreboard players display numberformat beds sr_s7 fixed [{"score": {"name": "#t7_v_beds", "objective": "sr"}, "color": "yellow"}, {"text": "/7", "color": "gray"}]
execute if score #sum sr matches 7.. run return 1
return 0
