execute if entity @a[tag=sr_run,team=sr_t1,advancements={minecraft:nether/find_bastion=true}] run return 1
return 0
