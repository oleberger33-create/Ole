scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t8] store result score @s sr_tmp run clear @s minecraft:shield 0
execute as @a[tag=sr_run,team=sr_t8] run scoreboard players operation #c sr += @s sr_tmp
execute if score #c sr matches 0 run return 0
scoreboard players set #sum sr 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t8] store result score @s sr_tmp run clear @s minecraft:iron_sword 0
execute as @a[tag=sr_run,team=sr_t8] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t8] store result score @s sr_tmp run clear @s minecraft:diamond_sword 0
execute as @a[tag=sr_run,team=sr_t8] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,team=sr_t8] store result score @s sr_tmp run clear @s minecraft:netherite_sword 0
execute as @a[tag=sr_run,team=sr_t8] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
execute if score #sum sr matches 1.. run return 1
return 0
