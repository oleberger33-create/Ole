scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=6}] store result score @s sr_tmp run clear @s minecraft:flint_and_steel 0
execute as @a[tag=sr_run,scores={sr_team=6}] run scoreboard players operation #c sr += @s sr_tmp
execute if score #c sr matches 0 run return 0
scoreboard players set #sum sr 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=6}] store result score @s sr_tmp run clear @s minecraft:bucket 0
execute as @a[tag=sr_run,scores={sr_team=6}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=6}] store result score @s sr_tmp run clear @s minecraft:water_bucket 0
execute as @a[tag=sr_run,scores={sr_team=6}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=6}] store result score @s sr_tmp run clear @s minecraft:lava_bucket 0
execute as @a[tag=sr_run,scores={sr_team=6}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
execute if score #sum sr matches 1.. run return 1
return 0
