execute if entity @a[tag=sr_run,advancements={minecraft:nether/find_fortress=true}] run return 1
return 0
