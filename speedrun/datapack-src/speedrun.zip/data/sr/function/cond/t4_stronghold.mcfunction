execute if entity @a[tag=sr_run,scores={sr_team=4},advancements={minecraft:story/follow_ender_eye=true}] run return 1
return 0
