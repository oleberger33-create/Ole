scoreboard players set #sum sr 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run] store result score @s sr_tmp run clear @s minecraft:ender_pearl 0
execute as @a[tag=sr_run] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run] store result score @s sr_tmp run clear @s minecraft:ender_eye 0
execute as @a[tag=sr_run] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
execute if score #sum sr matches 12.. run return 1
return 0
