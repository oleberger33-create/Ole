scoreboard players set #sum sr 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=5}] store result score @s sr_tmp run clear @s minecraft:ender_pearl 0
execute as @a[tag=sr_run,scores={sr_team=5}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=5}] store result score @s sr_tmp run clear @s minecraft:ender_eye 0
execute as @a[tag=sr_run,scores={sr_team=5}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players operation #t5_v_pearls sr = #sum sr
scoreboard players display numberformat pearls sr_s5 fixed [{"score": {"name": "#t5_v_pearls", "objective": "sr"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
execute if score #sum sr matches 12.. run return 1
return 0
