execute if entity @a[tag=sr_run,team=sr_t7,advancements={minecraft:nether/find_fortress=true}] run return 1
return 0
