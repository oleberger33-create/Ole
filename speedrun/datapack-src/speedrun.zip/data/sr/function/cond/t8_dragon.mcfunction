execute if entity @a[tag=sr_run,scores={sr_team=8},advancements={minecraft:end/kill_dragon=true}] run return 1
return 0
