execute if entity @a[tag=sr_run,team=sr_t8,advancements={minecraft:end/kill_dragon=true}] run return 1
return 0
