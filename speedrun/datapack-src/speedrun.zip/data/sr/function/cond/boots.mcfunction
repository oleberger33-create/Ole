execute as @a[tag=sr_run,team=sr_mats] if items entity @s armor.feet minecraft:golden_boots run return 1
return 0
