scoreboard players set #sum sr 0
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:cooked_beef 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:cooked_porkchop 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:cooked_mutton 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:cooked_chicken 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:cooked_rabbit 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:cooked_cod 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:cooked_salmon 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:bread 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:baked_potato 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players set #c sr 0
execute as @a[tag=sr_run,scores={sr_team=3}] store result score @s sr_tmp run clear @s minecraft:golden_carrot 0
execute as @a[tag=sr_run,scores={sr_team=3}] run scoreboard players operation #c sr += @s sr_tmp
scoreboard players operation #sum sr += #c sr
scoreboard players operation #t3_v_food sr = #sum sr
scoreboard players display numberformat food sr_s3 fixed [{"score": {"name": "#t3_v_food", "objective": "sr"}, "color": "yellow"}, {"text": "/20", "color": "gray"}]
execute if score #sum sr matches 20.. run return 1
return 0
