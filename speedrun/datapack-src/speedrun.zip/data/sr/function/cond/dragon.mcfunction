execute if entity @a[tag=sr_run,advancements={minecraft:end/kill_dragon=true}] run return 1
return 0
