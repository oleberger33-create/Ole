execute if entity @a[tag=sr_run,scores={sr_team=5},advancements={minecraft:nether/find_fortress=true}] run return 1
return 0
