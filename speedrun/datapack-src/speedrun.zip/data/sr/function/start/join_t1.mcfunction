team join sr_t1 @s
tag @s remove sr_pending
scoreboard players set @s sr_team 1
