tag @s add sr_starter
function sr:start/request
tag @a remove sr_starter
