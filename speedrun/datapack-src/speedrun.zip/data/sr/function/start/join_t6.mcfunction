team join sr_t6 @s
tag @s remove sr_pending
scoreboard players set @s sr_team 6
