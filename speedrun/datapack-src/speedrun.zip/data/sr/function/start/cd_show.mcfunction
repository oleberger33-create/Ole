title @a times 0 25 5
title @a title {"score": {"name": "#cd", "objective": "sr"}, "color": "gold", "bold": true}
title @a subtitle [{"text": "Modus ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "yellow"}]
execute as @a at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 1 1
