scoreboard players add #k sr 1
scoreboard players operation @s sr_slot = #k sr
execute store result storage sr:tmp s.k int 1 run scoreboard players get #k sr
execute if score #k sr matches ..16 run function sr:start/slot_join with storage sr:tmp s
