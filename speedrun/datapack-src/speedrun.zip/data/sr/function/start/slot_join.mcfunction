$team join sr_p$(k) @s
$execute if score @s sr_team matches 1 run team modify sr_p$(k) prefix {"text": "[Rot] ", "color": "red"}
$execute if score @s sr_team matches 2 run team modify sr_p$(k) prefix {"text": "[Blau] ", "color": "blue"}
$execute if score @s sr_team matches 3 run team modify sr_p$(k) prefix {"text": "[Grün] ", "color": "green"}
$execute if score @s sr_team matches 4 run team modify sr_p$(k) prefix {"text": "[Gelb] ", "color": "yellow"}
$execute if score @s sr_team matches 5 run team modify sr_p$(k) prefix {"text": "[Türkis] ", "color": "aqua"}
$execute if score @s sr_team matches 6 run team modify sr_p$(k) prefix {"text": "[Lila] ", "color": "light_purple"}
$execute if score @s sr_team matches 7 run team modify sr_p$(k) prefix {"text": "[Orange] ", "color": "gold"}
$execute if score @s sr_team matches 8 run team modify sr_p$(k) prefix {"text": "[Weiß] ", "color": "white"}
execute if score @s sr_slot matches 1 run waypoint modify @s color gold
execute if score @s sr_slot matches 2 run waypoint modify @s color light_purple
execute if score @s sr_slot matches 3 run waypoint modify @s color green
execute if score @s sr_slot matches 4 run waypoint modify @s color aqua
execute if score @s sr_slot matches 5 run waypoint modify @s color red
execute if score @s sr_slot matches 6 run waypoint modify @s color blue
execute if score @s sr_slot matches 7 run waypoint modify @s color yellow
execute if score @s sr_slot matches 8 run waypoint modify @s color white
execute if score @s sr_slot matches 9 run waypoint modify @s color dark_green
execute if score @s sr_slot matches 10 run waypoint modify @s color dark_aqua
execute if score @s sr_slot matches 11 run waypoint modify @s color dark_red
execute if score @s sr_slot matches 12 run waypoint modify @s color dark_purple
execute if score @s sr_slot matches 13 run waypoint modify @s color gray
execute if score @s sr_slot matches 14 run waypoint modify @s color dark_blue
execute if score @s sr_slot matches 15 run waypoint modify @s color dark_gray
execute if score @s sr_slot matches 16 run waypoint modify @s color black
