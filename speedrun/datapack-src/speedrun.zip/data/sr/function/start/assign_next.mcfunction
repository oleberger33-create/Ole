execute unless entity @a[tag=sr_pending] run return 0
execute if score #n sr matches 1 as @r[tag=sr_pending] run function sr:start/join_t1
execute if score #n sr matches 2 as @r[tag=sr_pending] run function sr:start/join_t2
execute if score #n sr matches 3 as @r[tag=sr_pending] run function sr:start/join_t3
execute if score #n sr matches 4 as @r[tag=sr_pending] run function sr:start/join_t4
execute if score #n sr matches 5 as @r[tag=sr_pending] run function sr:start/join_t5
execute if score #n sr matches 6 as @r[tag=sr_pending] run function sr:start/join_t6
execute if score #n sr matches 7 as @r[tag=sr_pending] run function sr:start/join_t7
execute if score #n sr matches 8 as @r[tag=sr_pending] run function sr:start/join_t8
scoreboard players add #c sr 1
execute if score #c sr >= #k sr run scoreboard players add #n sr 1
execute if score #c sr >= #k sr run scoreboard players set #c sr 0
execute if score #n sr matches 9.. run scoreboard players set #n sr 1
function sr:start/assign_next
