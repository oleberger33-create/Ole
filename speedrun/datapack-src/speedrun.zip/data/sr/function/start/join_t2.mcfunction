tag @s remove sr_pending
scoreboard players set @s sr_team 2
