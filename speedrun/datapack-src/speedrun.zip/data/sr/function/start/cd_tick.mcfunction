scoreboard players add #cdt sr 1
execute if score #cdt sr matches 20.. run function sr:start/cd_step
