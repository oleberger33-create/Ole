execute if score #cd sr matches 1.. run return 0
execute if score #active sr matches 1 run return run tellraw @a[tag=sr_starter] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Ein Run läuft gerade. ", "color": "red"}, {"text": "[Run abbrechen]", "color": "red", "bold": false, "click_event": {"action": "run_command", "command": "/trigger sr_aktion set 6"}}]
execute unless entity @a[tag=!sr_watch] run return run tellraw @a[tag=sr_starter] [{"text": "» ", "color": "gold", "bold": true}, {"text": "Niemand spielt mit – alle schauen zu.", "color": "red"}]
scoreboard players set #cd sr 5
scoreboard players set #cdt sr 0
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"selector": "@a[tag=sr_starter]", "color": "white"}, {"text": " startet einen Run: ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "yellow", "bold": true}]
function sr:start/cd_show
