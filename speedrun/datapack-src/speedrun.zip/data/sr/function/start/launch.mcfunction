scoreboard players add #run sr 1
scoreboard players operation #runmode sr = #mode sr
team leave @a
tag @a remove sr_run
tag @a remove sr_spec
tag @a remove sr_hasrole
tag @a remove sr_pending
scoreboard players set @a sr_role -1
scoreboard players set @a sr_team 0
tag @a[tag=!sr_watch] add sr_pending
scoreboard players set #k sr 99
execute if score #mode sr matches 1 run scoreboard players set #k sr 1
execute if score #mode sr matches 2 run scoreboard players set #k sr 2
execute if score #mode sr matches 3 run scoreboard players set #k sr 3
execute if score #mode sr matches 4 run scoreboard players set #k sr 4
execute if score #mode sr matches 5 run scoreboard players set #k sr 99
scoreboard players set #n sr 1
scoreboard players set #c sr 0
function sr:start/assign_next
scoreboard players set #teams sr 0
execute if entity @a[team=sr_t1] run scoreboard players add #teams sr 1
execute if entity @a[team=sr_t2] run scoreboard players add #teams sr 1
execute if entity @a[team=sr_t3] run scoreboard players add #teams sr 1
execute if entity @a[team=sr_t4] run scoreboard players add #teams sr 1
execute if entity @a[team=sr_t5] run scoreboard players add #teams sr 1
execute if entity @a[team=sr_t6] run scoreboard players add #teams sr 1
execute if entity @a[team=sr_t7] run scoreboard players add #teams sr 1
execute if entity @a[team=sr_t8] run scoreboard players add #teams sr 1
tag @a[team=!] add sr_run
tag @a[tag=sr_run] remove sr_lobby
execute as @a[tag=sr_run] run function sr:player/reset_state
gamemode survival @a[tag=sr_run]
effect give @a[tag=sr_run] minecraft:glowing infinite 0 true
time set 0
weather clear
difficulty normal
scoreboard players set #crystals sr 0
scoreboard players set #dseen sr 0
scoreboard players set #finished sr 0
execute in minecraft:overworld run tp @a[tag=sr_run] 0 200 0
execute if entity @a[team=sr_t1] run function sr:team/setup_t1
execute unless entity @a[team=sr_t1] run bossbar set sr:t1 visible false
execute if entity @a[team=sr_t2] run function sr:team/setup_t2
execute unless entity @a[team=sr_t2] run bossbar set sr:t2 visible false
execute if entity @a[team=sr_t3] run function sr:team/setup_t3
execute unless entity @a[team=sr_t3] run bossbar set sr:t3 visible false
execute if entity @a[team=sr_t4] run function sr:team/setup_t4
execute unless entity @a[team=sr_t4] run bossbar set sr:t4 visible false
execute if entity @a[team=sr_t5] run function sr:team/setup_t5
execute unless entity @a[team=sr_t5] run bossbar set sr:t5 visible false
execute if entity @a[team=sr_t6] run function sr:team/setup_t6
execute unless entity @a[team=sr_t6] run bossbar set sr:t6 visible false
execute if entity @a[team=sr_t7] run function sr:team/setup_t7
execute unless entity @a[team=sr_t7] run bossbar set sr:t7 visible false
execute if entity @a[team=sr_t8] run function sr:team/setup_t8
execute unless entity @a[team=sr_t8] run bossbar set sr:t8 visible false
execute as @a[tag=sr_run] at @s run spawnpoint @s ~ ~ ~
scoreboard players set #ticks sr 0
scoreboard players set #active sr 1
execute as @a[tag=sr_run] run function sr:role/brief
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.6 1.2
execute as @a[tag=sr_watch] run function sr:player/spectate
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " gestartet · ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "yellow"}, {"text": " · ", "color": "gray"}, {"score": {"name": "#teams", "objective": "sr"}, "color": "white"}, {"text": " Team(s)", "color": "gray"}]
