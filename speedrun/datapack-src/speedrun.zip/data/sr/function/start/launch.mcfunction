scoreboard players add #run sr 1
scoreboard players operation #runmode sr = #mode sr
team leave @a
scoreboard players set @a sr_slot 0
tag @a remove sr_run
tag @a remove sr_spec
tag @a remove sr_hasrole
tag @a remove sr_pending
scoreboard players set @a sr_role -1
scoreboard players set @a sr_team 0
tag @a[tag=!sr_watch] add sr_pending
scoreboard players set #k sr 99
execute if score #mode sr matches 1 run scoreboard players set #k sr 1
execute if score #mode sr matches 2 run scoreboard players set #k sr 2
execute if score #mode sr matches 3 run scoreboard players set #k sr 3
execute if score #mode sr matches 4 run scoreboard players set #k sr 4
execute if score #mode sr matches 5 run scoreboard players set #k sr 99
scoreboard players set #n sr 1
scoreboard players set #c sr 0
function sr:start/assign_next
scoreboard players set #teams sr 0
execute if entity @a[scores={sr_team=1}] run scoreboard players add #teams sr 1
execute if entity @a[scores={sr_team=2}] run scoreboard players add #teams sr 1
execute if entity @a[scores={sr_team=3}] run scoreboard players add #teams sr 1
execute if entity @a[scores={sr_team=4}] run scoreboard players add #teams sr 1
execute if entity @a[scores={sr_team=5}] run scoreboard players add #teams sr 1
execute if entity @a[scores={sr_team=6}] run scoreboard players add #teams sr 1
execute if entity @a[scores={sr_team=7}] run scoreboard players add #teams sr 1
execute if entity @a[scores={sr_team=8}] run scoreboard players add #teams sr 1
tag @a[scores={sr_team=1..}] add sr_run
tag @a[tag=sr_run] remove sr_lobby
execute as @a[tag=sr_run] run function sr:player/reset_state
gamemode survival @a[tag=sr_run]
effect give @a[tag=sr_run] minecraft:glowing infinite 0 true
time set 0
weather clear
difficulty normal
scoreboard players set #crystals sr 0
scoreboard players set #dseen sr 0
scoreboard players set #finished sr 0
execute in minecraft:overworld run tp @a[tag=sr_run] 0 200 0
execute if entity @a[scores={sr_team=1}] run function sr:team/setup_t1
execute unless entity @a[scores={sr_team=1}] run bossbar set sr:t1 visible false
execute if entity @a[scores={sr_team=2}] run function sr:team/setup_t2
execute unless entity @a[scores={sr_team=2}] run bossbar set sr:t2 visible false
execute if entity @a[scores={sr_team=3}] run function sr:team/setup_t3
execute unless entity @a[scores={sr_team=3}] run bossbar set sr:t3 visible false
execute if entity @a[scores={sr_team=4}] run function sr:team/setup_t4
execute unless entity @a[scores={sr_team=4}] run bossbar set sr:t4 visible false
execute if entity @a[scores={sr_team=5}] run function sr:team/setup_t5
execute unless entity @a[scores={sr_team=5}] run bossbar set sr:t5 visible false
execute if entity @a[scores={sr_team=6}] run function sr:team/setup_t6
execute unless entity @a[scores={sr_team=6}] run bossbar set sr:t6 visible false
execute if entity @a[scores={sr_team=7}] run function sr:team/setup_t7
execute unless entity @a[scores={sr_team=7}] run bossbar set sr:t7 visible false
execute if entity @a[scores={sr_team=8}] run function sr:team/setup_t8
execute unless entity @a[scores={sr_team=8}] run bossbar set sr:t8 visible false
execute as @a[tag=sr_run] at @s run spawnpoint @s ~ ~ ~
execute as @a[tag=sr_run] store result score @s sr_sx run data get entity @s Pos[0]
execute as @a[tag=sr_run] store result score @s sr_sy run data get entity @s Pos[1]
execute as @a[tag=sr_run] store result score @s sr_sz run data get entity @s Pos[2]
scoreboard players set #k sr 0
execute as @a[tag=sr_run] run function sr:start/slot
scoreboard players set @a[tag=sr_run] sr_pu_blaze 0
scoreboard players set @a[tag=sr_run] sr_pu_pearl 0
scoreboard players set @a[tag=sr_run] sr_cr_eye 0
scoreboard players set @a[tag=sr_run] sr_cr_f0 0
scoreboard players set @a[tag=sr_run] sr_cr_f1 0
scoreboard players set @a[tag=sr_run] sr_cr_f2 0
scoreboard players set @a[tag=sr_run] sr_cr_f3 0
scoreboard players set @a[tag=sr_run] sr_cr_f4 0
scoreboard players set @a[tag=sr_run] sr_cr_f5 0
scoreboard players set @a[tag=sr_run] sr_cr_f6 0
scoreboard players set @a[tag=sr_run] sr_cr_f7 0
scoreboard players set @a[tag=sr_run] sr_cr_f8 0
scoreboard players set @a[tag=sr_run] sr_cr_f9 0
scoreboard players set @a[tag=sr_run] sr_d_bastion 0
scoreboard players set @a[tag=sr_run] sr_d_beds 0
scoreboard players set @a[tag=sr_run] sr_d_blaze 0
scoreboard players set @a[tag=sr_run] sr_d_dragon 0
scoreboard players set @a[tag=sr_run] sr_d_end 0
scoreboard players set @a[tag=sr_run] sr_d_eyes 0
scoreboard players set @a[tag=sr_run] sr_d_food 0
scoreboard players set @a[tag=sr_run] sr_d_fortress 0
scoreboard players set @a[tag=sr_run] sr_d_gear 0
scoreboard players set @a[tag=sr_run] sr_d_nether 0
scoreboard players set @a[tag=sr_run] sr_d_pearls 0
scoreboard players set @a[tag=sr_run] sr_d_stronghold 0
scoreboard players set @a[tag=sr_run] sr_d_tools 0
scoreboard players set @a[tag=sr_run] sr_v_blaze 0
scoreboard players set @a[tag=sr_run] sr_v_pearls 0
scoreboard players set @a[tag=sr_run] sr_v_beds 0
scoreboard players set @a[tag=sr_run] sr_v_food 0
scoreboard players set @a[tag=sr_run] sr_v_eyes 0
execute as @a[tag=sr_run,scores={sr_slot=1..16}] run function sr:p/init
scoreboard players set #ticks sr 0
scoreboard players set #st sr 0
scoreboard players set #empty sr 0
scoreboard players set #active sr 1
data modify storage sr:run tstr set value "0:00"
execute as @a[tag=sr_run] run function sr:role/brief
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.ender_dragon.growl master @s ~ ~ ~ 0.6 1.2
execute as @a[tag=sr_watch] run function sr:player/spectate
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run #", "color": "white"}, {"score": {"name": "#run", "objective": "sr"}, "color": "white"}, {"text": " gestartet · ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "yellow"}, {"text": " · ", "color": "gray"}, {"score": {"name": "#teams", "objective": "sr"}, "color": "white"}, {"text": " Team(s)", "color": "gray"}]
