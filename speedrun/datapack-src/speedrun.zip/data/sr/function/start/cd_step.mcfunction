scoreboard players set #cdt sr 0
scoreboard players remove #cd sr 1
execute if score #cd sr matches 0 run return run function sr:start/launch
function sr:start/cd_show
