team join sr_t8 @s
tag @s remove sr_pending
scoreboard players set @s sr_team 8
