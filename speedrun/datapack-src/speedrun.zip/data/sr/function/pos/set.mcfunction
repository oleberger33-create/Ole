$scoreboard players set #cx sr $(x)
$scoreboard players set #cz sr $(z)
