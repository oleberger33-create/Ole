scoreboard players add #try sr 1
execute if score #try sr matches 6.. run return run tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Konnte keinen Startplatz finden.", "color": "red"}]
scoreboard players add #slot sr 1
scoreboard players add #nextslot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
function sr:pos/place with storage sr:run place
