execute if score #active sr matches 1 unless entity @s[tag=sr_run] run return run function sr:player/spectate
execute if entity @s[tag=sr_watch] run return run function sr:player/watch_off
tag @s add sr_watch
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du schaust beim nächsten Run zu. ", "color": "aqua"}, {"text": "[Doch mitspielen]", "color": "green", "bold": false, "click_event": {"action": "run_command", "command": "/trigger sr_aktion set 4"}}]
