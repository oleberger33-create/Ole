tag @s remove sr_run
tag @s add sr_lobby
function sr:player/reset_state
gamemode adventure @s
function sr:player/tp_lobby
execute in minecraft:overworld run spawnpoint @s 0 200 0
bossbar set sr:timer players @a[tag=sr_run]
