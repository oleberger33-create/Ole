team leave @s
tag @s remove sr_run
tag @s remove sr_spec
tag @s add sr_lobby
scoreboard players set @s sr_role -1
scoreboard players set @s sr_team 0
function sr:player/reset_state
gamemode adventure @s
function sr:player/tp_lobby
execute in minecraft:overworld run spawnpoint @s 0 200 0
function sr:item/hotbar
