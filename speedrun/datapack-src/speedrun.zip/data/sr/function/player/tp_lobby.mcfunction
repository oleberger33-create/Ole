execute in minecraft:overworld run tp @s 0 200 0 180 0
