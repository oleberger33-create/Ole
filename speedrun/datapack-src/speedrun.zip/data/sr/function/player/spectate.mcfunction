tag @s remove sr_lobby
tag @s add sr_spec
effect clear @s
gamemode spectator @s
tp @s @r[tag=sr_run]
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du schaust live zu. ", "color": "aqua"}, {"text": "[Zurück zur Lobby]", "color": "aqua", "bold": false, "click_event": {"action": "run_command", "command": "/trigger sr_aktion set 2"}}]
