execute if score @s sr_aktion matches 1 run function sr:start/by_player
execute if score @s sr_aktion matches 2 run function sr:player/to_lobby
execute if score @s sr_aktion matches 3 run dialog show @s sr:menu
execute if score @s sr_aktion matches 4 run function sr:player/watch
execute if score @s sr_aktion matches 5 run function sr:mode/cycle
execute if score @s sr_aktion matches 6 run function sr:run/abort
execute if score @s sr_aktion matches 7 run function sr:role/plan
execute if score @s sr_aktion matches 8 run function sr:fx/share_me
execute if score @s sr_aktion matches 9 run function sr:zettel/open
execute if score @s sr_aktion matches 11 run function sr:mode/set {m:1}
execute if score @s sr_aktion matches 12 run function sr:mode/set {m:2}
execute if score @s sr_aktion matches 13 run function sr:mode/set {m:3}
execute if score @s sr_aktion matches 14 run function sr:mode/set {m:4}
execute if score @s sr_aktion matches 15 run function sr:mode/set {m:5}
scoreboard players set @s sr_aktion 0
