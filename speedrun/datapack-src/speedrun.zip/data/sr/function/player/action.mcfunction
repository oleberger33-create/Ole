execute if score @s sr_aktion matches 1 run function sr:run/start_by_player
execute if score @s sr_aktion matches 2 run function sr:player/to_lobby
execute if score @s sr_aktion matches 3 run dialog show @s sr:menu
execute if score @s sr_aktion matches 4 run function sr:run/join
scoreboard players set @s sr_aktion 0
