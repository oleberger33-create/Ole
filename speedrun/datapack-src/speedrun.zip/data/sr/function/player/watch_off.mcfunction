tag @s remove sr_watch
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du spielst beim nächsten Run mit.", "color": "green"}]
