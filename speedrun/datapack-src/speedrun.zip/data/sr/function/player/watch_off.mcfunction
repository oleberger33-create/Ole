tag @s remove sr_watch
tag @s add sr_refresh
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du spielst beim nächsten Run mit.", "color": "green"}]
