scoreboard players set @s sr_leave 0
execute unless entity @s[tag=sr_run] unless entity @s[tag=sr_spec] run function sr:player/to_lobby
execute if entity @s[tag=sr_spec] if score #active sr matches 0 run function sr:player/to_lobby
execute if entity @s[tag=sr_run] if score #active sr matches 0 run function sr:player/to_lobby
execute if entity @s[tag=sr_lobby] run function sr:player/welcome
