tag @s add sr_seen2
scoreboard players set @s sr_leave 0
function sr:player/to_lobby
function sr:player/welcome
title @s times 10 50 15
title @s title {"text": "SPEEDRUN", "color": "gold", "bold": true}
title @s subtitle {"text": "Modus wählen · Hebel ziehen · Drache töten", "color": "gray"}
