scoreboard players set #itick sr 0
execute as @e[type=minecraft:item] if items entity @s contents *[minecraft:custom_data~{sr_item:1b}] run kill @s
clear @a[tag=!sr_lobby] *[minecraft:custom_data~{sr_item:1b}]
