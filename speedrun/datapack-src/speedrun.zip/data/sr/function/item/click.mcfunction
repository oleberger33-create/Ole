scoreboard players set @s sr_click 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{sr_zettel:1b}] run return run function sr:zettel/click
execute unless items entity @s weapon.mainhand minecraft:carrot_on_a_stick if items entity @s weapon.offhand *[minecraft:custom_data~{sr_zettel:1b}] run return run function sr:zettel/click
execute unless entity @s[tag=sr_lobby] run return 0
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{sr:"start"}] run return run function sr:start/by_player
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{sr:"mode"}] run return run function sr:mode/cycle
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{sr:"role"}] run return run function sr:role/cycle
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{sr:"watch"}] run return run function sr:player/watch
execute if items entity @s weapon.mainhand *[minecraft:custom_data~{sr:"menu"}] run return run dialog show @s sr:menu
