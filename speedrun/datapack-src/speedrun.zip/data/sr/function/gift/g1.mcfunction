scoreboard players set #gift_g1 sr 1
give FNGreg minecraft:obsidian 10
give FNGreg minecraft:flint_and_steel 1
tellraw FNGreg [{"text": "» ", "color": "gold", "bold": true}, {"text": "Geschenk erhalten: 10 Obsidian und 1 Feuerzeug", "color": "green"}]
