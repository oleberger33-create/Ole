execute in minecraft:overworld run forceload add -16 -16 15 15
scoreboard objectives remove sr_ole
scoreboard objectives remove sr_mats
scoreboard objectives remove sr_sammy
team remove sr_ole
team remove sr_mats
team remove sr_sammy
scoreboard objectives add sr dummy
scoreboard objectives add sr_tmp dummy
scoreboard objectives add sr_done dummy
scoreboard objectives add sr_rolle trigger
scoreboard objectives add sr_aktion trigger
scoreboard objectives add sr_leave minecraft.custom:minecraft.leave_game
scoreboard objectives add sr_endt dummy
scoreboard objectives add sr_pref dummy
scoreboard objectives add sr_role dummy
scoreboard objectives add sr_team dummy
scoreboard objectives add sr_click minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add sr_slot dummy
scoreboard objectives add sr_zcd dummy
scoreboard objectives add sr_sx dummy
scoreboard objectives add sr_sy dummy
scoreboard objectives add sr_sz dummy
scoreboard objectives add sr_pu_blaze minecraft.picked_up:minecraft.blaze_rod
scoreboard objectives add sr_pu_pearl minecraft.picked_up:minecraft.ender_pearl
scoreboard objectives add sr_cr_eye minecraft.crafted:minecraft.ender_eye
scoreboard objectives add sr_cr_f0 minecraft.crafted:minecraft.cooked_beef
scoreboard objectives add sr_cr_f1 minecraft.crafted:minecraft.cooked_porkchop
scoreboard objectives add sr_cr_f2 minecraft.crafted:minecraft.cooked_mutton
scoreboard objectives add sr_cr_f3 minecraft.crafted:minecraft.cooked_chicken
scoreboard objectives add sr_cr_f4 minecraft.crafted:minecraft.cooked_rabbit
scoreboard objectives add sr_cr_f5 minecraft.crafted:minecraft.cooked_cod
scoreboard objectives add sr_cr_f6 minecraft.crafted:minecraft.cooked_salmon
scoreboard objectives add sr_cr_f7 minecraft.crafted:minecraft.bread
scoreboard objectives add sr_cr_f8 minecraft.crafted:minecraft.baked_potato
scoreboard objectives add sr_cr_f9 minecraft.crafted:minecraft.golden_carrot
scoreboard objectives add sr_d_bastion dummy
scoreboard objectives add sr_d_beds dummy
scoreboard objectives add sr_d_blaze dummy
scoreboard objectives add sr_d_dragon dummy
scoreboard objectives add sr_d_end dummy
scoreboard objectives add sr_d_eyes dummy
scoreboard objectives add sr_d_food dummy
scoreboard objectives add sr_d_fortress dummy
scoreboard objectives add sr_d_gear dummy
scoreboard objectives add sr_d_nether dummy
scoreboard objectives add sr_d_pearls dummy
scoreboard objectives add sr_d_stronghold dummy
scoreboard objectives add sr_d_tools dummy
scoreboard objectives add sr_v_blaze dummy
scoreboard objectives add sr_v_pearls dummy
scoreboard objectives add sr_v_beds dummy
scoreboard objectives add sr_v_food dummy
scoreboard objectives add sr_v_eyes dummy
scoreboard objectives add sr_wins dummy {"text": "Siege", "color": "gold"}
scoreboard objectives setdisplay list sr_wins
scoreboard objectives add sr_lobby dummy {"text": "SPEEDRUN", "color": "gold", "bold": true}
scoreboard objectives modify sr_lobby numberformat blank
scoreboard objectives setdisplay sidebar sr_lobby
team remove sr_t1
scoreboard objectives add sr_s1 dummy {"text": "Team Rot", "color": "red", "bold": true}
scoreboard objectives modify sr_s1 numberformat blank
bossbar add sr:t1 {"text": "Team Rot"}
bossbar set sr:t1 color red
bossbar set sr:t1 style notched_12
bossbar set sr:t1 max 13
team remove sr_t2
scoreboard objectives add sr_s2 dummy {"text": "Team Blau", "color": "blue", "bold": true}
scoreboard objectives modify sr_s2 numberformat blank
bossbar add sr:t2 {"text": "Team Blau"}
bossbar set sr:t2 color blue
bossbar set sr:t2 style notched_12
bossbar set sr:t2 max 13
team remove sr_t3
scoreboard objectives add sr_s3 dummy {"text": "Team Grün", "color": "green", "bold": true}
scoreboard objectives modify sr_s3 numberformat blank
bossbar add sr:t3 {"text": "Team Grün"}
bossbar set sr:t3 color green
bossbar set sr:t3 style notched_12
bossbar set sr:t3 max 13
team remove sr_t4
scoreboard objectives add sr_s4 dummy {"text": "Team Gelb", "color": "yellow", "bold": true}
scoreboard objectives modify sr_s4 numberformat blank
bossbar add sr:t4 {"text": "Team Gelb"}
bossbar set sr:t4 color yellow
bossbar set sr:t4 style notched_12
bossbar set sr:t4 max 13
team remove sr_t5
scoreboard objectives add sr_s5 dummy {"text": "Team Türkis", "color": "aqua", "bold": true}
scoreboard objectives modify sr_s5 numberformat blank
bossbar add sr:t5 {"text": "Team Türkis"}
bossbar set sr:t5 color blue
bossbar set sr:t5 style notched_12
bossbar set sr:t5 max 13
team remove sr_t6
scoreboard objectives add sr_s6 dummy {"text": "Team Lila", "color": "light_purple", "bold": true}
scoreboard objectives modify sr_s6 numberformat blank
bossbar add sr:t6 {"text": "Team Lila"}
bossbar set sr:t6 color pink
bossbar set sr:t6 style notched_12
bossbar set sr:t6 max 13
team remove sr_t7
scoreboard objectives add sr_s7 dummy {"text": "Team Orange", "color": "gold", "bold": true}
scoreboard objectives modify sr_s7 numberformat blank
bossbar add sr:t7 {"text": "Team Orange"}
bossbar set sr:t7 color yellow
bossbar set sr:t7 style notched_12
bossbar set sr:t7 max 13
team remove sr_t8
scoreboard objectives add sr_s8 dummy {"text": "Team Weiß", "color": "white", "bold": true}
scoreboard objectives modify sr_s8 numberformat blank
bossbar add sr:t8 {"text": "Team Weiß"}
bossbar set sr:t8 color white
bossbar set sr:t8 style notched_12
bossbar set sr:t8 max 13
team add sr_p1
team modify sr_p1 color gold
team modify sr_p1 friendlyFire false
team modify sr_p1 nametagVisibility always
scoreboard objectives add sr_o1 dummy
scoreboard objectives modify sr_o1 numberformat blank
scoreboard objectives setdisplay sidebar.team.gold sr_o1
team add sr_p2
team modify sr_p2 color light_purple
team modify sr_p2 friendlyFire false
team modify sr_p2 nametagVisibility always
scoreboard objectives add sr_o2 dummy
scoreboard objectives modify sr_o2 numberformat blank
scoreboard objectives setdisplay sidebar.team.light_purple sr_o2
team add sr_p3
team modify sr_p3 color green
team modify sr_p3 friendlyFire false
team modify sr_p3 nametagVisibility always
scoreboard objectives add sr_o3 dummy
scoreboard objectives modify sr_o3 numberformat blank
scoreboard objectives setdisplay sidebar.team.green sr_o3
team add sr_p4
team modify sr_p4 color aqua
team modify sr_p4 friendlyFire false
team modify sr_p4 nametagVisibility always
scoreboard objectives add sr_o4 dummy
scoreboard objectives modify sr_o4 numberformat blank
scoreboard objectives setdisplay sidebar.team.aqua sr_o4
team add sr_p5
team modify sr_p5 color red
team modify sr_p5 friendlyFire false
team modify sr_p5 nametagVisibility always
scoreboard objectives add sr_o5 dummy
scoreboard objectives modify sr_o5 numberformat blank
scoreboard objectives setdisplay sidebar.team.red sr_o5
team add sr_p6
team modify sr_p6 color blue
team modify sr_p6 friendlyFire false
team modify sr_p6 nametagVisibility always
scoreboard objectives add sr_o6 dummy
scoreboard objectives modify sr_o6 numberformat blank
scoreboard objectives setdisplay sidebar.team.blue sr_o6
team add sr_p7
team modify sr_p7 color yellow
team modify sr_p7 friendlyFire false
team modify sr_p7 nametagVisibility always
scoreboard objectives add sr_o7 dummy
scoreboard objectives modify sr_o7 numberformat blank
scoreboard objectives setdisplay sidebar.team.yellow sr_o7
team add sr_p8
team modify sr_p8 color white
team modify sr_p8 friendlyFire false
team modify sr_p8 nametagVisibility always
scoreboard objectives add sr_o8 dummy
scoreboard objectives modify sr_o8 numberformat blank
scoreboard objectives setdisplay sidebar.team.white sr_o8
team add sr_p9
team modify sr_p9 color dark_green
team modify sr_p9 friendlyFire false
team modify sr_p9 nametagVisibility always
scoreboard objectives add sr_o9 dummy
scoreboard objectives modify sr_o9 numberformat blank
scoreboard objectives setdisplay sidebar.team.dark_green sr_o9
team add sr_p10
team modify sr_p10 color dark_aqua
team modify sr_p10 friendlyFire false
team modify sr_p10 nametagVisibility always
scoreboard objectives add sr_o10 dummy
scoreboard objectives modify sr_o10 numberformat blank
scoreboard objectives setdisplay sidebar.team.dark_aqua sr_o10
team add sr_p11
team modify sr_p11 color dark_red
team modify sr_p11 friendlyFire false
team modify sr_p11 nametagVisibility always
scoreboard objectives add sr_o11 dummy
scoreboard objectives modify sr_o11 numberformat blank
scoreboard objectives setdisplay sidebar.team.dark_red sr_o11
team add sr_p12
team modify sr_p12 color dark_purple
team modify sr_p12 friendlyFire false
team modify sr_p12 nametagVisibility always
scoreboard objectives add sr_o12 dummy
scoreboard objectives modify sr_o12 numberformat blank
scoreboard objectives setdisplay sidebar.team.dark_purple sr_o12
team add sr_p13
team modify sr_p13 color gray
team modify sr_p13 friendlyFire false
team modify sr_p13 nametagVisibility always
scoreboard objectives add sr_o13 dummy
scoreboard objectives modify sr_o13 numberformat blank
scoreboard objectives setdisplay sidebar.team.gray sr_o13
team add sr_p14
team modify sr_p14 color dark_blue
team modify sr_p14 friendlyFire false
team modify sr_p14 nametagVisibility always
scoreboard objectives add sr_o14 dummy
scoreboard objectives modify sr_o14 numberformat blank
scoreboard objectives setdisplay sidebar.team.dark_blue sr_o14
team add sr_p15
team modify sr_p15 color dark_gray
team modify sr_p15 friendlyFire false
team modify sr_p15 nametagVisibility always
scoreboard objectives add sr_o15 dummy
scoreboard objectives modify sr_o15 numberformat blank
scoreboard objectives setdisplay sidebar.team.dark_gray sr_o15
team add sr_p16
team modify sr_p16 color black
team modify sr_p16 friendlyFire false
team modify sr_p16 nametagVisibility always
scoreboard objectives add sr_o16 dummy
scoreboard objectives modify sr_o16 numberformat blank
scoreboard objectives setdisplay sidebar.team.black sr_o16
scoreboard players set #20 sr 20
scoreboard players set #60 sr 60
scoreboard players set #2 sr 2
scoreboard players set #5 sr 5
scoreboard players set #3600 sr 3600
execute unless data storage sr:run tstr run data modify storage sr:run tstr set value "0:00"
scoreboard players set #npos sr 60
execute unless score #run sr matches 0.. run scoreboard players set #run sr 0
execute unless score #active sr matches 0.. run scoreboard players set #active sr 0
execute unless score #mode sr matches 1..5 run scoreboard players set #mode sr 3
execute unless score #nextslot sr matches 0.. run scoreboard players set #nextslot sr 0
scoreboard players set #cd sr 0
function sr:mode/apply_silent
gamerule respawn_radius 0
gamerule pvp false
gamerule spawn_phantoms false
gamerule locator_bar true
gamerule show_advancement_messages false
setworldspawn 0 200 0
execute in minecraft:overworld run forceload add -16 -16 15 15
function sr:sidebar/lobby
execute unless score #built sr matches 3 run schedule function sr:lobby/try_build 40t
