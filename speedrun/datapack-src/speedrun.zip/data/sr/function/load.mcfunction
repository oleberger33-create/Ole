scoreboard objectives add sr dummy
scoreboard objectives add sr_tmp dummy
scoreboard objectives add sr_done dummy
scoreboard objectives add sr_rolle trigger
scoreboard objectives add sr_aktion trigger
scoreboard objectives add sr_leave minecraft.custom:minecraft.leave_game
scoreboard objectives add sr_endt dummy
scoreboard objectives add sr_lobby dummy {"text": "Speedrun-Lobby", "bold": true}
scoreboard objectives add sr_ole dummy {"text": "Ole · Kämpfer", "color": "gold", "bold": true}
scoreboard objectives modify sr_ole numberformat blank
team add sr_ole
team modify sr_ole color gold
team modify sr_ole friendlyFire false
scoreboard objectives setdisplay sidebar.team.gold sr_ole
scoreboard objectives add sr_mats dummy {"text": "Mats · Portal & Perlen", "color": "light_purple", "bold": true}
scoreboard objectives modify sr_mats numberformat blank
team add sr_mats
team modify sr_mats color light_purple
team modify sr_mats friendlyFire false
scoreboard objectives setdisplay sidebar.team.light_purple sr_mats
scoreboard objectives add sr_sammy dummy {"text": "Sammy · Versorger", "color": "green", "bold": true}
scoreboard objectives modify sr_sammy numberformat blank
team add sr_sammy
team modify sr_sammy color green
team modify sr_sammy friendlyFire false
scoreboard objectives setdisplay sidebar.team.green sr_sammy
scoreboard objectives setdisplay sidebar sr_lobby
scoreboard players set #20 sr 20
scoreboard players set #60 sr 60
scoreboard players set #npos sr 60
execute unless score #run sr matches 0.. run scoreboard players set #run sr 0
execute unless score #active sr matches 0.. run scoreboard players set #active sr 0
execute unless score #best sr matches 0.. run scoreboard players set #best sr 0
bossbar add sr:timer {"text": "Speedrun"}
bossbar set sr:timer color yellow
bossbar set sr:timer style notched_10
bossbar set sr:timer max 15
gamerule respawn_radius 0
gamerule pvp false
gamerule spawn_phantoms false
setworldspawn 0 200 0
execute in minecraft:overworld run forceload add -16 -16 15 15
function sr:sidebar/lobby
execute unless score #sidebar sr matches 1 run function sr:tasks/reset
execute unless score #built sr matches 1 run schedule function sr:lobby/try_build 40t
