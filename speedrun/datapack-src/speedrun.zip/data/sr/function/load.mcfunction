execute in minecraft:overworld run forceload add -16 -16 15 15
scoreboard objectives remove sr_ole
scoreboard objectives remove sr_mats
scoreboard objectives remove sr_sammy
team remove sr_ole
team remove sr_mats
team remove sr_sammy
scoreboard objectives add sr dummy
scoreboard objectives add sr_tmp dummy
scoreboard objectives add sr_done dummy
scoreboard objectives add sr_rolle trigger
scoreboard objectives add sr_aktion trigger
scoreboard objectives add sr_leave minecraft.custom:minecraft.leave_game
scoreboard objectives add sr_endt dummy
scoreboard objectives add sr_pref dummy
scoreboard objectives add sr_role dummy
scoreboard objectives add sr_team dummy
scoreboard objectives add sr_click minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add sr_wins dummy {"text": "Siege", "color": "gold"}
scoreboard objectives setdisplay list sr_wins
scoreboard objectives add sr_lobby dummy {"text": "SPEEDRUN", "color": "gold", "bold": true}
scoreboard objectives modify sr_lobby numberformat blank
scoreboard objectives setdisplay sidebar sr_lobby
team add sr_t1
team modify sr_t1 color red
team modify sr_t1 displayName {"text": "Team Rot", "color": "red"}
team modify sr_t1 prefix {"text": "[Rot] ", "color": "red"}
team modify sr_t1 friendlyFire false
scoreboard objectives add sr_s1 dummy {"text": "Team Rot", "color": "red", "bold": true}
scoreboard objectives modify sr_s1 numberformat blank
scoreboard objectives setdisplay sidebar.team.red sr_s1
bossbar add sr:t1 {"text": "Team Rot"}
bossbar set sr:t1 color red
bossbar set sr:t1 style notched_12
bossbar set sr:t1 max 12
team add sr_t2
team modify sr_t2 color blue
team modify sr_t2 displayName {"text": "Team Blau", "color": "blue"}
team modify sr_t2 prefix {"text": "[Blau] ", "color": "blue"}
team modify sr_t2 friendlyFire false
scoreboard objectives add sr_s2 dummy {"text": "Team Blau", "color": "blue", "bold": true}
scoreboard objectives modify sr_s2 numberformat blank
scoreboard objectives setdisplay sidebar.team.blue sr_s2
bossbar add sr:t2 {"text": "Team Blau"}
bossbar set sr:t2 color blue
bossbar set sr:t2 style notched_12
bossbar set sr:t2 max 12
team add sr_t3
team modify sr_t3 color green
team modify sr_t3 displayName {"text": "Team Grün", "color": "green"}
team modify sr_t3 prefix {"text": "[Grün] ", "color": "green"}
team modify sr_t3 friendlyFire false
scoreboard objectives add sr_s3 dummy {"text": "Team Grün", "color": "green", "bold": true}
scoreboard objectives modify sr_s3 numberformat blank
scoreboard objectives setdisplay sidebar.team.green sr_s3
bossbar add sr:t3 {"text": "Team Grün"}
bossbar set sr:t3 color green
bossbar set sr:t3 style notched_12
bossbar set sr:t3 max 12
team add sr_t4
team modify sr_t4 color yellow
team modify sr_t4 displayName {"text": "Team Gelb", "color": "yellow"}
team modify sr_t4 prefix {"text": "[Gelb] ", "color": "yellow"}
team modify sr_t4 friendlyFire false
scoreboard objectives add sr_s4 dummy {"text": "Team Gelb", "color": "yellow", "bold": true}
scoreboard objectives modify sr_s4 numberformat blank
scoreboard objectives setdisplay sidebar.team.yellow sr_s4
bossbar add sr:t4 {"text": "Team Gelb"}
bossbar set sr:t4 color yellow
bossbar set sr:t4 style notched_12
bossbar set sr:t4 max 12
team add sr_t5
team modify sr_t5 color aqua
team modify sr_t5 displayName {"text": "Team Türkis", "color": "aqua"}
team modify sr_t5 prefix {"text": "[Türkis] ", "color": "aqua"}
team modify sr_t5 friendlyFire false
scoreboard objectives add sr_s5 dummy {"text": "Team Türkis", "color": "aqua", "bold": true}
scoreboard objectives modify sr_s5 numberformat blank
scoreboard objectives setdisplay sidebar.team.aqua sr_s5
bossbar add sr:t5 {"text": "Team Türkis"}
bossbar set sr:t5 color blue
bossbar set sr:t5 style notched_12
bossbar set sr:t5 max 12
team add sr_t6
team modify sr_t6 color light_purple
team modify sr_t6 displayName {"text": "Team Lila", "color": "light_purple"}
team modify sr_t6 prefix {"text": "[Lila] ", "color": "light_purple"}
team modify sr_t6 friendlyFire false
scoreboard objectives add sr_s6 dummy {"text": "Team Lila", "color": "light_purple", "bold": true}
scoreboard objectives modify sr_s6 numberformat blank
scoreboard objectives setdisplay sidebar.team.light_purple sr_s6
bossbar add sr:t6 {"text": "Team Lila"}
bossbar set sr:t6 color pink
bossbar set sr:t6 style notched_12
bossbar set sr:t6 max 12
team add sr_t7
team modify sr_t7 color gold
team modify sr_t7 displayName {"text": "Team Orange", "color": "gold"}
team modify sr_t7 prefix {"text": "[Orange] ", "color": "gold"}
team modify sr_t7 friendlyFire false
scoreboard objectives add sr_s7 dummy {"text": "Team Orange", "color": "gold", "bold": true}
scoreboard objectives modify sr_s7 numberformat blank
scoreboard objectives setdisplay sidebar.team.gold sr_s7
bossbar add sr:t7 {"text": "Team Orange"}
bossbar set sr:t7 color yellow
bossbar set sr:t7 style notched_12
bossbar set sr:t7 max 12
team add sr_t8
team modify sr_t8 color white
team modify sr_t8 displayName {"text": "Team Weiß", "color": "white"}
team modify sr_t8 prefix {"text": "[Weiß] ", "color": "white"}
team modify sr_t8 friendlyFire false
scoreboard objectives add sr_s8 dummy {"text": "Team Weiß", "color": "white", "bold": true}
scoreboard objectives modify sr_s8 numberformat blank
scoreboard objectives setdisplay sidebar.team.white sr_s8
bossbar add sr:t8 {"text": "Team Weiß"}
bossbar set sr:t8 color white
bossbar set sr:t8 style notched_12
bossbar set sr:t8 max 12
scoreboard players set #20 sr 20
scoreboard players set #60 sr 60
scoreboard players set #2 sr 2
scoreboard players set #npos sr 60
execute unless score #run sr matches 0.. run scoreboard players set #run sr 0
execute unless score #active sr matches 0.. run scoreboard players set #active sr 0
execute unless score #mode sr matches 1..5 run scoreboard players set #mode sr 3
execute unless score #nextslot sr matches 0.. run scoreboard players set #nextslot sr 0
scoreboard players set #cd sr 0
function sr:mode/apply_silent
gamerule respawn_radius 0
gamerule pvp false
gamerule spawn_phantoms false
gamerule show_advancement_messages false
setworldspawn 0 200 0
execute in minecraft:overworld run forceload add -16 -16 15 15
function sr:sidebar/lobby
execute unless score #built sr matches 3 run schedule function sr:lobby/try_build 40t
