scoreboard players set #donecount sr 0
scoreboard players set #sidebar sr 1
scoreboard players set #gear sr_done 0
scoreboard players set #tools sr_done 0
scoreboard players set #beds sr_done 0
scoreboard players set #food sr_done 0
scoreboard players set #nether sr_done 0
scoreboard players set #fortress sr_done 0
scoreboard players set #bastion sr_done 0
scoreboard players set #boots sr_done 0
scoreboard players set #blaze sr_done 0
scoreboard players set #pearls sr_done 0
scoreboard players set #eyes sr_done 0
scoreboard players set #bow sr_done 0
scoreboard players set #stronghold sr_done 0
scoreboard players set #end sr_done 0
scoreboard players set #dragon sr_done 0
scoreboard players reset * sr_ole
scoreboard players set ole0 sr_ole 7
scoreboard players display name ole0 sr_ole {"text": "☐ Schild + Eisenschwert", "color": "gray", "strikethrough": false}
scoreboard players set ole1 sr_ole 6
scoreboard players display name ole1 sr_ole {"text": "☐ Nether betreten", "color": "gray", "strikethrough": false}
scoreboard players set ole2 sr_ole 5
scoreboard players display name ole2 sr_ole {"text": "☐ Festung gefunden", "color": "gray", "strikethrough": false}
scoreboard players set ole3 sr_ole 4
scoreboard players display name ole3 sr_ole {"text": "☐ 7+ Blaze-Ruten", "color": "gray", "strikethrough": false}
scoreboard players set ole4 sr_ole 3
scoreboard players display name ole4 sr_ole {"text": "☐ Stronghold gefunden", "color": "gray", "strikethrough": false}
scoreboard players set ole5 sr_ole 2
scoreboard players display name ole5 sr_ole {"text": "☐ End betreten", "color": "gray", "strikethrough": false}
scoreboard players set ole6 sr_ole 1
scoreboard players display name ole6 sr_ole {"text": "☐ Drache besiegt", "color": "gray", "strikethrough": false}
scoreboard players reset * sr_mats
scoreboard players set mats0 sr_mats 7
scoreboard players display name mats0 sr_mats {"text": "☐ Eimer + Feuerzeug", "color": "gray", "strikethrough": false}
scoreboard players set mats1 sr_mats 6
scoreboard players display name mats1 sr_mats {"text": "☐ Nether betreten", "color": "gray", "strikethrough": false}
scoreboard players set mats2 sr_mats 5
scoreboard players display name mats2 sr_mats {"text": "☐ Goldene Stiefel an", "color": "gray", "strikethrough": false}
scoreboard players set mats3 sr_mats 4
scoreboard players display name mats3 sr_mats {"text": "☐ Bastion gefunden", "color": "gray", "strikethrough": false}
scoreboard players set mats4 sr_mats 3
scoreboard players display name mats4 sr_mats {"text": "☐ 12+ Enderperlen", "color": "gray", "strikethrough": false}
scoreboard players set mats5 sr_mats 2
scoreboard players display name mats5 sr_mats {"text": "☐ Bogen + 16 Pfeile", "color": "gray", "strikethrough": false}
scoreboard players set mats6 sr_mats 1
scoreboard players display name mats6 sr_mats {"text": "☐ Drache besiegt", "color": "gray", "strikethrough": false}
scoreboard players reset * sr_sammy
scoreboard players set sammy0 sr_sammy 7
scoreboard players display name sammy0 sr_sammy {"text": "☐ 7 Betten", "color": "gray", "strikethrough": false}
scoreboard players set sammy1 sr_sammy 6
scoreboard players display name sammy1 sr_sammy {"text": "☐ 30 Essen", "color": "gray", "strikethrough": false}
scoreboard players set sammy2 sr_sammy 5
scoreboard players display name sammy2 sr_sammy {"text": "☐ Nether betreten", "color": "gray", "strikethrough": false}
scoreboard players set sammy3 sr_sammy 4
scoreboard players display name sammy3 sr_sammy {"text": "☐ 12 Enderaugen", "color": "gray", "strikethrough": false}
scoreboard players set sammy4 sr_sammy 3
scoreboard players display name sammy4 sr_sammy {"text": "☐ Stronghold gefunden", "color": "gray", "strikethrough": false}
scoreboard players set sammy5 sr_sammy 2
scoreboard players display name sammy5 sr_sammy {"text": "☐ End betreten", "color": "gray", "strikethrough": false}
scoreboard players set sammy6 sr_sammy 1
scoreboard players display name sammy6 sr_sammy {"text": "☐ Drache besiegt", "color": "gray", "strikethrough": false}
