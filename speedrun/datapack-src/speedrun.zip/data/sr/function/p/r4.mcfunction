scoreboard players set #found sr 0
execute if score @s sr_d_gear matches 0 if function sr:pc/gear run function sr:pd/gear
$execute if score @s sr_d_gear matches 1 run scoreboard players display name s0 sr_o$(k) {"text": "✔ Schild + Eisenschwert bauen", "color": "green"}
$execute if score @s sr_d_gear matches 1 run scoreboard players display numberformat s0 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_gear matches 0 if score #found sr matches 0 run scoreboard players display name s0 sr_o$(k) {"text": "▶ Schild + Eisenschwert bauen", "color": "yellow", "bold": true}
execute if score @s sr_d_gear matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Späher] ", "color": "yellow", "bold": true}, {"text": "Schritt 1/6 ▸ ", "color": "gray", "bold": false}, {"text": "Schild + Eisenschwert bauen", "color": "white", "bold": false}]
$execute if score @s sr_d_gear matches 0 if score #found sr matches 1 run scoreboard players display name s0 sr_o$(k) {"text": "☐ Schild + Eisenschwert bauen", "color": "gray"}
execute if score @s sr_d_gear matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_nether matches 0 if function sr:pc/nether run function sr:pd/nether
$execute if score @s sr_d_nether matches 1 run scoreboard players display name s1 sr_o$(k) {"text": "✔ In den Nether", "color": "green"}
$execute if score @s sr_d_nether matches 1 run scoreboard players display numberformat s1 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_nether matches 0 if score #found sr matches 0 run scoreboard players display name s1 sr_o$(k) {"text": "▶ In den Nether", "color": "yellow", "bold": true}
execute if score @s sr_d_nether matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Späher] ", "color": "yellow", "bold": true}, {"text": "Schritt 2/6 ▸ ", "color": "gray", "bold": false}, {"text": "In den Nether", "color": "white", "bold": false}]
$execute if score @s sr_d_nether matches 0 if score #found sr matches 1 run scoreboard players display name s1 sr_o$(k) {"text": "☐ In den Nether", "color": "gray"}
execute if score @s sr_d_nether matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_eyes matches 0 if function sr:pc/eyes run function sr:pd/eyes
$execute if score @s sr_d_eyes matches 1 run scoreboard players display name s2 sr_o$(k) {"text": "✔ Enderaugen craften", "color": "green"}
$execute if score @s sr_d_eyes matches 1 run scoreboard players display numberformat s2 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_eyes matches 0 if score #found sr matches 0 run scoreboard players display name s2 sr_o$(k) {"text": "▶ Enderaugen craften", "color": "yellow", "bold": true}
execute if score @s sr_d_eyes matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Späher] ", "color": "yellow", "bold": true}, {"text": "Schritt 3/6 ▸ ", "color": "gray", "bold": false}, {"text": "Enderaugen craften", "color": "white", "bold": false}, {"text": "   ", "bold": false}, {"score": {"name": "@s", "objective": "sr_v_eyes"}, "color": "yellow", "bold": false}, {"text": "/12", "color": "gray", "bold": false}]
$execute if score @s sr_d_eyes matches 0 if score #found sr matches 1 run scoreboard players display name s2 sr_o$(k) {"text": "☐ Enderaugen craften", "color": "gray"}
$execute if score @s sr_d_eyes matches 0 run scoreboard players display numberformat s2 sr_o$(k) fixed [{"score": {"name": "@s", "objective": "sr_v_eyes"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
execute if score @s sr_d_eyes matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_stronghold matches 0 if function sr:pc/stronghold run function sr:pd/stronghold
$execute if score @s sr_d_stronghold matches 1 run scoreboard players display name s3 sr_o$(k) {"text": "✔ Augen werfen, Stronghold finden", "color": "green"}
$execute if score @s sr_d_stronghold matches 1 run scoreboard players display numberformat s3 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_stronghold matches 0 if score #found sr matches 0 run scoreboard players display name s3 sr_o$(k) {"text": "▶ Augen werfen, Stronghold finden", "color": "yellow", "bold": true}
execute if score @s sr_d_stronghold matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Späher] ", "color": "yellow", "bold": true}, {"text": "Schritt 4/6 ▸ ", "color": "gray", "bold": false}, {"text": "Augen werfen, Stronghold finden", "color": "white", "bold": false}]
$execute if score @s sr_d_stronghold matches 0 if score #found sr matches 1 run scoreboard players display name s3 sr_o$(k) {"text": "☐ Augen werfen, Stronghold finden", "color": "gray"}
execute if score @s sr_d_stronghold matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_end matches 0 if function sr:pc/end run function sr:pd/end
$execute if score @s sr_d_end matches 1 run scoreboard players display name s4 sr_o$(k) {"text": "✔ Endportal öffnen und rein", "color": "green"}
$execute if score @s sr_d_end matches 1 run scoreboard players display numberformat s4 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_end matches 0 if score #found sr matches 0 run scoreboard players display name s4 sr_o$(k) {"text": "▶ Endportal öffnen und rein", "color": "yellow", "bold": true}
execute if score @s sr_d_end matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Späher] ", "color": "yellow", "bold": true}, {"text": "Schritt 5/6 ▸ ", "color": "gray", "bold": false}, {"text": "Endportal öffnen und rein", "color": "white", "bold": false}]
$execute if score @s sr_d_end matches 0 if score #found sr matches 1 run scoreboard players display name s4 sr_o$(k) {"text": "☐ Endportal öffnen und rein", "color": "gray"}
execute if score @s sr_d_end matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_dragon matches 0 if function sr:pc/dragon run function sr:pd/dragon
$execute if score @s sr_d_dragon matches 1 run scoreboard players display name s5 sr_o$(k) {"text": "✔ Kristalle abschießen, Drachen töten", "color": "green"}
$execute if score @s sr_d_dragon matches 1 run scoreboard players display numberformat s5 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_dragon matches 0 if score #found sr matches 0 run scoreboard players display name s5 sr_o$(k) {"text": "▶ Kristalle abschießen, Drachen töten", "color": "yellow", "bold": true}
execute if score @s sr_d_dragon matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Späher] ", "color": "yellow", "bold": true}, {"text": "Schritt 6/6 ▸ ", "color": "gray", "bold": false}, {"text": "Kristalle abschießen, Drachen töten", "color": "white", "bold": false}]
$execute if score @s sr_d_dragon matches 0 if score #found sr matches 1 run scoreboard players display name s5 sr_o$(k) {"text": "☐ Kristalle abschießen, Drachen töten", "color": "gray"}
execute if score @s sr_d_dragon matches 0 run scoreboard players set #found sr 1
execute if score #found sr matches 0 run title @s actionbar [{"text": "[Späher] ", "color": "yellow", "bold": true}, {"text": "Alles erledigt – hilf deinem Team!", "color": "green", "bold": false}]
$execute if score #t$(n)_blaze sr_done matches 1 run scoreboard players display numberformat g1 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_blaze sr_done matches 0 run scoreboard players display numberformat g1 sr_o$(k) fixed [{"score": {"name": "#t$(n)_v_blaze", "objective": "sr"}, "color": "yellow"}, {"text": "/7", "color": "gray"}]
$execute if score #t$(n)_pearls sr_done matches 1 run scoreboard players display numberformat g2 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_pearls sr_done matches 0 run scoreboard players display numberformat g2 sr_o$(k) fixed [{"score": {"name": "#t$(n)_v_pearls", "objective": "sr"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
$execute if score #t$(n)_eyes sr_done matches 1 run scoreboard players display numberformat g3 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_eyes sr_done matches 0 run scoreboard players display numberformat g3 sr_o$(k) fixed [{"score": {"name": "#t$(n)_v_eyes", "objective": "sr"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
$execute if score #t$(n)_stronghold sr_done matches 1 run scoreboard players display numberformat g4 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_stronghold sr_done matches 0 run scoreboard players display numberformat g4 sr_o$(k) fixed {"text": "–", "color": "dark_gray"}
$execute if score #t$(n)_dragon sr_done matches 1 run scoreboard players display numberformat g5 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_dragon sr_done matches 0 run scoreboard players display numberformat g5 sr_o$(k) fixed {"text": "–", "color": "dark_gray"}
$execute if score #sec sr matches 10.. run scoreboard objectives modify sr_o$(k) displayname [{"text": "Späher", "color": "yellow", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
$execute if score #sec sr matches ..9 run scoreboard objectives modify sr_o$(k) displayname [{"text": "Späher", "color": "yellow", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
