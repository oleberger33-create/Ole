scoreboard players set #found sr 0
execute if score @s sr_d_gear matches 0 if function sr:pc/gear run function sr:pd/gear
$execute if score @s sr_d_gear matches 1 run scoreboard players display name s0 sr_o$(k) {"text": "✔ Schild + Eisenschwert bauen", "color": "green"}
$execute if score @s sr_d_gear matches 1 run scoreboard players display numberformat s0 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_gear matches 0 if score #found sr matches 0 run scoreboard players display name s0 sr_o$(k) {"text": "▶ Schild + Eisenschwert bauen", "color": "yellow", "bold": true}
execute if score @s sr_d_gear matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "[Kämpfer] ", "color": "yellow", "bold": true}, {"text": "Schritt 1/7 ▸ ", "color": "gray", "bold": false}, {"text": "Schild + Eisenschwert bauen", "color": "white", "bold": false}]
$execute if score @s sr_d_gear matches 0 if score #found sr matches 1 run scoreboard players display name s0 sr_o$(k) {"text": "☐ Schild + Eisenschwert bauen", "color": "gray"}
execute if score @s sr_d_gear matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_nether matches 0 if function sr:pc/nether run function sr:pd/nether
$execute if score @s sr_d_nether matches 1 run scoreboard players display name s1 sr_o$(k) {"text": "✔ Durchs Portal in den Nether", "color": "green"}
$execute if score @s sr_d_nether matches 1 run scoreboard players display numberformat s1 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_nether matches 0 if score #found sr matches 0 run scoreboard players display name s1 sr_o$(k) {"text": "▶ Durchs Portal in den Nether", "color": "yellow", "bold": true}
execute if score @s sr_d_nether matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "[Kämpfer] ", "color": "yellow", "bold": true}, {"text": "Schritt 2/7 ▸ ", "color": "gray", "bold": false}, {"text": "Durchs Portal in den Nether", "color": "white", "bold": false}]
$execute if score @s sr_d_nether matches 0 if score #found sr matches 1 run scoreboard players display name s1 sr_o$(k) {"text": "☐ Durchs Portal in den Nether", "color": "gray"}
execute if score @s sr_d_nether matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_fortress matches 0 if function sr:pc/fortress run function sr:pd/fortress
$execute if score @s sr_d_fortress matches 1 run scoreboard players display name s2 sr_o$(k) {"text": "✔ Festung finden", "color": "green"}
$execute if score @s sr_d_fortress matches 1 run scoreboard players display numberformat s2 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_fortress matches 0 if score #found sr matches 0 run scoreboard players display name s2 sr_o$(k) {"text": "▶ Festung finden", "color": "yellow", "bold": true}
execute if score @s sr_d_fortress matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "[Kämpfer] ", "color": "yellow", "bold": true}, {"text": "Schritt 3/7 ▸ ", "color": "gray", "bold": false}, {"text": "Festung finden", "color": "white", "bold": false}]
$execute if score @s sr_d_fortress matches 0 if score #found sr matches 1 run scoreboard players display name s2 sr_o$(k) {"text": "☐ Festung finden", "color": "gray"}
execute if score @s sr_d_fortress matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_blaze matches 0 if function sr:pc/blaze run function sr:pd/blaze
$execute if score @s sr_d_blaze matches 1 run scoreboard players display name s3 sr_o$(k) {"text": "✔ Blaze-Ruten farmen", "color": "green"}
$execute if score @s sr_d_blaze matches 1 run scoreboard players display numberformat s3 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_blaze matches 0 if score #found sr matches 0 run scoreboard players display name s3 sr_o$(k) {"text": "▶ Blaze-Ruten farmen", "color": "yellow", "bold": true}
execute if score @s sr_d_blaze matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "[Kämpfer] ", "color": "yellow", "bold": true}, {"text": "Schritt 4/7 ▸ ", "color": "gray", "bold": false}, {"text": "Blaze-Ruten farmen", "color": "white", "bold": false}, {"text": "   ", "bold": false}, {"score": {"name": "@s", "objective": "sr_v_blaze"}, "color": "yellow", "bold": false}, {"text": "/7", "color": "gray", "bold": false}]
$execute if score @s sr_d_blaze matches 0 if score #found sr matches 1 run scoreboard players display name s3 sr_o$(k) {"text": "☐ Blaze-Ruten farmen", "color": "gray"}
$execute if score @s sr_d_blaze matches 0 run scoreboard players display numberformat s3 sr_o$(k) fixed [{"score": {"name": "@s", "objective": "sr_v_blaze"}, "color": "yellow"}, {"text": "/7", "color": "gray"}]
execute if score @s sr_d_blaze matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_stronghold matches 0 if function sr:pc/stronghold run function sr:pd/stronghold
$execute if score @s sr_d_stronghold matches 1 run scoreboard players display name s4 sr_o$(k) {"text": "✔ Zum Stronghold", "color": "green"}
$execute if score @s sr_d_stronghold matches 1 run scoreboard players display numberformat s4 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_stronghold matches 0 if score #found sr matches 0 run scoreboard players display name s4 sr_o$(k) {"text": "▶ Zum Stronghold", "color": "yellow", "bold": true}
execute if score @s sr_d_stronghold matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "[Kämpfer] ", "color": "yellow", "bold": true}, {"text": "Schritt 5/7 ▸ ", "color": "gray", "bold": false}, {"text": "Zum Stronghold", "color": "white", "bold": false}]
$execute if score @s sr_d_stronghold matches 0 if score #found sr matches 1 run scoreboard players display name s4 sr_o$(k) {"text": "☐ Zum Stronghold", "color": "gray"}
execute if score @s sr_d_stronghold matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_end matches 0 if function sr:pc/end run function sr:pd/end
$execute if score @s sr_d_end matches 1 run scoreboard players display name s5 sr_o$(k) {"text": "✔ Ins End", "color": "green"}
$execute if score @s sr_d_end matches 1 run scoreboard players display numberformat s5 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_end matches 0 if score #found sr matches 0 run scoreboard players display name s5 sr_o$(k) {"text": "▶ Ins End", "color": "yellow", "bold": true}
execute if score @s sr_d_end matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "[Kämpfer] ", "color": "yellow", "bold": true}, {"text": "Schritt 6/7 ▸ ", "color": "gray", "bold": false}, {"text": "Ins End", "color": "white", "bold": false}]
$execute if score @s sr_d_end matches 0 if score #found sr matches 1 run scoreboard players display name s5 sr_o$(k) {"text": "☐ Ins End", "color": "gray"}
execute if score @s sr_d_end matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_dragon matches 0 if function sr:pc/dragon run function sr:pd/dragon
$execute if score @s sr_d_dragon matches 1 run scoreboard players display name s6 sr_o$(k) {"text": "✔ Käfig-Kristalle zerstören, Drachen mit Betten sprengen", "color": "green"}
$execute if score @s sr_d_dragon matches 1 run scoreboard players display numberformat s6 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_dragon matches 0 if score #found sr matches 0 run scoreboard players display name s6 sr_o$(k) {"text": "▶ Käfig-Kristalle zerstören, Drachen mit Betten sprengen", "color": "yellow", "bold": true}
execute if score @s sr_d_dragon matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "[Kämpfer] ", "color": "yellow", "bold": true}, {"text": "Schritt 7/7 ▸ ", "color": "gray", "bold": false}, {"text": "Käfig-Kristalle zerstören, Drachen mit Betten sprengen", "color": "white", "bold": false}]
$execute if score @s sr_d_dragon matches 0 if score #found sr matches 1 run scoreboard players display name s6 sr_o$(k) {"text": "☐ Käfig-Kristalle zerstören, Drachen mit Betten sprengen", "color": "gray"}
execute if score @s sr_d_dragon matches 0 run scoreboard players set #found sr 1
execute if score #found sr matches 0 run title @s actionbar [{"text": "⏱ ", "color": "white", "bold": false}, {"nbt": "tstr", "storage": "sr:run", "interpret": true, "color": "white", "bold": true}, {"text": "  ·  ", "color": "dark_gray", "bold": false}, {"text": "[Kämpfer] ", "color": "yellow", "bold": true}, {"text": "Alles erledigt – hilf deinem Team!", "color": "green", "bold": false}]
$execute if score #t$(n)_blaze sr_done matches 1 run scoreboard players display numberformat g1 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_blaze sr_done matches 0 run scoreboard players display numberformat g1 sr_o$(k) fixed [{"score": {"name": "#t$(n)_v_blaze", "objective": "sr"}, "color": "yellow"}, {"text": "/7", "color": "gray"}]
$execute if score #t$(n)_pearls sr_done matches 1 run scoreboard players display numberformat g2 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_pearls sr_done matches 0 run scoreboard players display numberformat g2 sr_o$(k) fixed [{"score": {"name": "#t$(n)_v_pearls", "objective": "sr"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
$execute if score #t$(n)_eyes sr_done matches 1 run scoreboard players display numberformat g3 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_eyes sr_done matches 0 run scoreboard players display numberformat g3 sr_o$(k) fixed [{"score": {"name": "#t$(n)_v_eyes", "objective": "sr"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
$execute if score #t$(n)_stronghold sr_done matches 1 run scoreboard players display numberformat g4 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_stronghold sr_done matches 0 run scoreboard players display numberformat g4 sr_o$(k) fixed {"text": "–", "color": "dark_gray"}
$execute if score #t$(n)_dragon sr_done matches 1 run scoreboard players display numberformat g5 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score #t$(n)_dragon sr_done matches 0 run scoreboard players display numberformat g5 sr_o$(k) fixed {"text": "–", "color": "dark_gray"}
$execute if score #sec sr matches 10.. run scoreboard objectives modify sr_o$(k) displayname [{"text": "Kämpfer", "color": "yellow", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
$execute if score #sec sr matches ..9 run scoreboard objectives modify sr_o$(k) displayname [{"text": "Kämpfer", "color": "yellow", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
