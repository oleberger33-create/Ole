execute store result storage sr:tmp s.x int 1 run scoreboard players get @s sr_sx
execute store result storage sr:tmp s.y int 1 run scoreboard players get @s sr_sy
execute store result storage sr:tmp s.z int 1 run scoreboard players get @s sr_sz
function sr:p/tp_start with storage sr:tmp s
function sr:p/fix_spawn
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du warst in der Lobby gelandet – zurück zu deinem Startpunkt.", "color": "aqua"}]
