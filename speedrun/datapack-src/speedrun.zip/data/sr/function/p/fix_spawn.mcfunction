execute store result storage sr:tmp s.x int 1 run scoreboard players get @s sr_sx
execute store result storage sr:tmp s.y int 1 run scoreboard players get @s sr_sy
execute store result storage sr:tmp s.z int 1 run scoreboard players get @s sr_sz
function sr:p/spawn_start with storage sr:tmp s
