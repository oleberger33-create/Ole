$scoreboard players reset * sr_o$(k)
$scoreboard objectives modify sr_o$(k) displayname {"text": "Solo", "color": "yellow", "bold": true}
$scoreboard players set s0 sr_o$(k) 100
$scoreboard players display name s0 sr_o$(k) {"text": "☐ Eimer + Feuerzeug bauen", "color": "gray"}
$scoreboard players set s1 sr_o$(k) 99
$scoreboard players display name s1 sr_o$(k) {"text": "☐ Portal gießen, ab in den Nether", "color": "gray"}
$scoreboard players set s2 sr_o$(k) 98
$scoreboard players display name s2 sr_o$(k) {"text": "☐ Festung finden", "color": "gray"}
$scoreboard players set s3 sr_o$(k) 97
$scoreboard players display name s3 sr_o$(k) {"text": "☐ Blaze-Ruten farmen", "color": "gray"}
$scoreboard players display numberformat s3 sr_o$(k) fixed {"text": "0/7", "color": "gray"}
$scoreboard players set s4 sr_o$(k) 96
$scoreboard players display name s4 sr_o$(k) {"text": "☐ Bastion: Gold gegen Perlen tauschen", "color": "gray"}
$scoreboard players display numberformat s4 sr_o$(k) fixed {"text": "0/12", "color": "gray"}
$scoreboard players set s5 sr_o$(k) 95
$scoreboard players display name s5 sr_o$(k) {"text": "☐ Wolle sammeln, Betten craften", "color": "gray"}
$scoreboard players display numberformat s5 sr_o$(k) fixed {"text": "0/7", "color": "gray"}
$scoreboard players set s6 sr_o$(k) 94
$scoreboard players display name s6 sr_o$(k) {"text": "☐ Enderaugen craften", "color": "gray"}
$scoreboard players display numberformat s6 sr_o$(k) fixed {"text": "0/12", "color": "gray"}
$scoreboard players set s7 sr_o$(k) 93
$scoreboard players display name s7 sr_o$(k) {"text": "☐ Augen werfen, Stronghold finden", "color": "gray"}
$scoreboard players set s8 sr_o$(k) 92
$scoreboard players display name s8 sr_o$(k) {"text": "☐ Endportal öffnen und rein", "color": "gray"}
$scoreboard players set s9 sr_o$(k) 91
$scoreboard players display name s9 sr_o$(k) {"text": "☐ Drachen töten", "color": "gray"}
