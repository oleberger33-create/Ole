$execute in $(dim) store success score #ok sr run spreadplayers $(x) $(z) 0 6 under $(y) false @s
$execute if score #ok sr matches 0 in $(dim) store success score #ok sr run spreadplayers $(x) $(z) 0 24 under $(y) false @s
