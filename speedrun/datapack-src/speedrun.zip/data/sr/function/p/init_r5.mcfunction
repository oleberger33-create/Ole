$scoreboard players reset * sr_o$(k)
$scoreboard objectives modify sr_o$(k) displayname {"text": "Nether-Läufer", "color": "yellow", "bold": true}
$scoreboard players set s0 sr_o$(k) 100
$scoreboard players display name s0 sr_o$(k) {"text": "☐ In den Nether", "color": "gray"}
$scoreboard players set s1 sr_o$(k) 99
$scoreboard players display name s1 sr_o$(k) {"text": "☐ Festung finden", "color": "gray"}
$scoreboard players set s2 sr_o$(k) 98
$scoreboard players display name s2 sr_o$(k) {"text": "☐ Blaze-Ruten farmen", "color": "gray"}
$scoreboard players display numberformat s2 sr_o$(k) fixed {"text": "0/7", "color": "gray"}
$scoreboard players set s3 sr_o$(k) 97
$scoreboard players display name s3 sr_o$(k) {"text": "☐ Bastion finden", "color": "gray"}
$scoreboard players set s4 sr_o$(k) 96
$scoreboard players display name s4 sr_o$(k) {"text": "☐ Gold gegen Perlen tauschen", "color": "gray"}
$scoreboard players display numberformat s4 sr_o$(k) fixed {"text": "0/12", "color": "gray"}
$scoreboard players set s5 sr_o$(k) 95
$scoreboard players display name s5 sr_o$(k) {"text": "☐ Zum Stronghold", "color": "gray"}
$scoreboard players set s6 sr_o$(k) 94
$scoreboard players display name s6 sr_o$(k) {"text": "☐ Ins End", "color": "gray"}
$scoreboard players set s7 sr_o$(k) 93
$scoreboard players display name s7 sr_o$(k) {"text": "☐ Drachen töten", "color": "gray"}
$scoreboard players set g0 sr_o$(k) 50
$scoreboard players display name g0 sr_o$(k) {"text": "── Team ──", "color": "dark_gray"}
$scoreboard players set g1 sr_o$(k) 49
$scoreboard players display name g1 sr_o$(k) {"text": "Blaze-Ruten", "color": "gray"}
$scoreboard players set g2 sr_o$(k) 48
$scoreboard players display name g2 sr_o$(k) {"text": "Enderperlen", "color": "gray"}
$scoreboard players set g3 sr_o$(k) 47
$scoreboard players display name g3 sr_o$(k) {"text": "Enderaugen", "color": "gray"}
$scoreboard players set g4 sr_o$(k) 46
$scoreboard players display name g4 sr_o$(k) {"text": "Stronghold", "color": "gray"}
$scoreboard players set g5 sr_o$(k) 45
$scoreboard players display name g5 sr_o$(k) {"text": "Drache", "color": "gray"}
