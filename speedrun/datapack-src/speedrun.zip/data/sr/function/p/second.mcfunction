execute store result storage sr:tmp p.k int 1 run scoreboard players get @s sr_slot
execute store result storage sr:tmp p.n int 1 run scoreboard players get @s sr_team
execute if score @s sr_role matches 0 run return run function sr:p/r0 with storage sr:tmp p
execute if score @s sr_role matches 1 run return run function sr:p/r1 with storage sr:tmp p
execute if score @s sr_role matches 2 run return run function sr:p/r2 with storage sr:tmp p
execute if score @s sr_role matches 3 run return run function sr:p/r3 with storage sr:tmp p
execute if score @s sr_role matches 4 run return run function sr:p/r4 with storage sr:tmp p
execute if score @s sr_role matches 5 run return run function sr:p/r5 with storage sr:tmp p
execute if score @s sr_role matches 6 run return run function sr:p/r6 with storage sr:tmp p
