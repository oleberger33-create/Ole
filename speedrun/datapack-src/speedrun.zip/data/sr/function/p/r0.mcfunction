scoreboard players set #found sr 0
execute if score @s sr_d_tools matches 0 if function sr:pc/tools run function sr:pd/tools
$execute if score @s sr_d_tools matches 1 run scoreboard players display name s0 sr_o$(k) {"text": "✔ Eimer + Feuerzeug bauen", "color": "green"}
$execute if score @s sr_d_tools matches 1 run scoreboard players display numberformat s0 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_tools matches 0 if score #found sr matches 0 run scoreboard players display name s0 sr_o$(k) {"text": "▶ Eimer + Feuerzeug bauen", "color": "yellow", "bold": true}
execute if score @s sr_d_tools matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 1/10 ▸ ", "color": "gray", "bold": false}, {"text": "Eimer + Feuerzeug bauen", "color": "white", "bold": false}]
$execute if score @s sr_d_tools matches 0 if score #found sr matches 1 run scoreboard players display name s0 sr_o$(k) {"text": "☐ Eimer + Feuerzeug bauen", "color": "gray"}
execute if score @s sr_d_tools matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_nether matches 0 if function sr:pc/nether run function sr:pd/nether
$execute if score @s sr_d_nether matches 1 run scoreboard players display name s1 sr_o$(k) {"text": "✔ Portal gießen, ab in den Nether", "color": "green"}
$execute if score @s sr_d_nether matches 1 run scoreboard players display numberformat s1 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_nether matches 0 if score #found sr matches 0 run scoreboard players display name s1 sr_o$(k) {"text": "▶ Portal gießen, ab in den Nether", "color": "yellow", "bold": true}
execute if score @s sr_d_nether matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 2/10 ▸ ", "color": "gray", "bold": false}, {"text": "Portal gießen, ab in den Nether", "color": "white", "bold": false}]
$execute if score @s sr_d_nether matches 0 if score #found sr matches 1 run scoreboard players display name s1 sr_o$(k) {"text": "☐ Portal gießen, ab in den Nether", "color": "gray"}
execute if score @s sr_d_nether matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_fortress matches 0 if function sr:pc/fortress run function sr:pd/fortress
$execute if score @s sr_d_fortress matches 1 run scoreboard players display name s2 sr_o$(k) {"text": "✔ Festung finden", "color": "green"}
$execute if score @s sr_d_fortress matches 1 run scoreboard players display numberformat s2 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_fortress matches 0 if score #found sr matches 0 run scoreboard players display name s2 sr_o$(k) {"text": "▶ Festung finden", "color": "yellow", "bold": true}
execute if score @s sr_d_fortress matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 3/10 ▸ ", "color": "gray", "bold": false}, {"text": "Festung finden", "color": "white", "bold": false}]
$execute if score @s sr_d_fortress matches 0 if score #found sr matches 1 run scoreboard players display name s2 sr_o$(k) {"text": "☐ Festung finden", "color": "gray"}
execute if score @s sr_d_fortress matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_blaze matches 0 if function sr:pc/blaze run function sr:pd/blaze
$execute if score @s sr_d_blaze matches 1 run scoreboard players display name s3 sr_o$(k) {"text": "✔ Blaze-Ruten farmen", "color": "green"}
$execute if score @s sr_d_blaze matches 1 run scoreboard players display numberformat s3 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_blaze matches 0 if score #found sr matches 0 run scoreboard players display name s3 sr_o$(k) {"text": "▶ Blaze-Ruten farmen", "color": "yellow", "bold": true}
execute if score @s sr_d_blaze matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 4/10 ▸ ", "color": "gray", "bold": false}, {"text": "Blaze-Ruten farmen", "color": "white", "bold": false}, {"text": "   ", "bold": false}, {"score": {"name": "@s", "objective": "sr_v_blaze"}, "color": "yellow", "bold": false}, {"text": "/7", "color": "gray", "bold": false}]
$execute if score @s sr_d_blaze matches 0 if score #found sr matches 1 run scoreboard players display name s3 sr_o$(k) {"text": "☐ Blaze-Ruten farmen", "color": "gray"}
$execute if score @s sr_d_blaze matches 0 run scoreboard players display numberformat s3 sr_o$(k) fixed [{"score": {"name": "@s", "objective": "sr_v_blaze"}, "color": "yellow"}, {"text": "/7", "color": "gray"}]
execute if score @s sr_d_blaze matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_pearls matches 0 if function sr:pc/pearls run function sr:pd/pearls
$execute if score @s sr_d_pearls matches 1 run scoreboard players display name s4 sr_o$(k) {"text": "✔ Bastion: Gold gegen Perlen tauschen", "color": "green"}
$execute if score @s sr_d_pearls matches 1 run scoreboard players display numberformat s4 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_pearls matches 0 if score #found sr matches 0 run scoreboard players display name s4 sr_o$(k) {"text": "▶ Bastion: Gold gegen Perlen tauschen", "color": "yellow", "bold": true}
execute if score @s sr_d_pearls matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 5/10 ▸ ", "color": "gray", "bold": false}, {"text": "Bastion: Gold gegen Perlen tauschen", "color": "white", "bold": false}, {"text": "   ", "bold": false}, {"score": {"name": "@s", "objective": "sr_v_pearls"}, "color": "yellow", "bold": false}, {"text": "/12", "color": "gray", "bold": false}]
$execute if score @s sr_d_pearls matches 0 if score #found sr matches 1 run scoreboard players display name s4 sr_o$(k) {"text": "☐ Bastion: Gold gegen Perlen tauschen", "color": "gray"}
$execute if score @s sr_d_pearls matches 0 run scoreboard players display numberformat s4 sr_o$(k) fixed [{"score": {"name": "@s", "objective": "sr_v_pearls"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
execute if score @s sr_d_pearls matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_beds matches 0 if function sr:pc/beds run function sr:pd/beds
$execute if score @s sr_d_beds matches 1 run scoreboard players display name s5 sr_o$(k) {"text": "✔ Wolle sammeln, Betten craften", "color": "green"}
$execute if score @s sr_d_beds matches 1 run scoreboard players display numberformat s5 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_beds matches 0 if score #found sr matches 0 run scoreboard players display name s5 sr_o$(k) {"text": "▶ Wolle sammeln, Betten craften", "color": "yellow", "bold": true}
execute if score @s sr_d_beds matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 6/10 ▸ ", "color": "gray", "bold": false}, {"text": "Wolle sammeln, Betten craften", "color": "white", "bold": false}, {"text": "   ", "bold": false}, {"score": {"name": "@s", "objective": "sr_v_beds"}, "color": "yellow", "bold": false}, {"text": "/7", "color": "gray", "bold": false}]
$execute if score @s sr_d_beds matches 0 if score #found sr matches 1 run scoreboard players display name s5 sr_o$(k) {"text": "☐ Wolle sammeln, Betten craften", "color": "gray"}
$execute if score @s sr_d_beds matches 0 run scoreboard players display numberformat s5 sr_o$(k) fixed [{"score": {"name": "@s", "objective": "sr_v_beds"}, "color": "yellow"}, {"text": "/7", "color": "gray"}]
execute if score @s sr_d_beds matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_eyes matches 0 if function sr:pc/eyes run function sr:pd/eyes
$execute if score @s sr_d_eyes matches 1 run scoreboard players display name s6 sr_o$(k) {"text": "✔ Enderaugen craften", "color": "green"}
$execute if score @s sr_d_eyes matches 1 run scoreboard players display numberformat s6 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_eyes matches 0 if score #found sr matches 0 run scoreboard players display name s6 sr_o$(k) {"text": "▶ Enderaugen craften", "color": "yellow", "bold": true}
execute if score @s sr_d_eyes matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 7/10 ▸ ", "color": "gray", "bold": false}, {"text": "Enderaugen craften", "color": "white", "bold": false}, {"text": "   ", "bold": false}, {"score": {"name": "@s", "objective": "sr_v_eyes"}, "color": "yellow", "bold": false}, {"text": "/12", "color": "gray", "bold": false}]
$execute if score @s sr_d_eyes matches 0 if score #found sr matches 1 run scoreboard players display name s6 sr_o$(k) {"text": "☐ Enderaugen craften", "color": "gray"}
$execute if score @s sr_d_eyes matches 0 run scoreboard players display numberformat s6 sr_o$(k) fixed [{"score": {"name": "@s", "objective": "sr_v_eyes"}, "color": "yellow"}, {"text": "/12", "color": "gray"}]
execute if score @s sr_d_eyes matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_stronghold matches 0 if function sr:pc/stronghold run function sr:pd/stronghold
$execute if score @s sr_d_stronghold matches 1 run scoreboard players display name s7 sr_o$(k) {"text": "✔ Augen werfen, Stronghold finden", "color": "green"}
$execute if score @s sr_d_stronghold matches 1 run scoreboard players display numberformat s7 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_stronghold matches 0 if score #found sr matches 0 run scoreboard players display name s7 sr_o$(k) {"text": "▶ Augen werfen, Stronghold finden", "color": "yellow", "bold": true}
execute if score @s sr_d_stronghold matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 8/10 ▸ ", "color": "gray", "bold": false}, {"text": "Augen werfen, Stronghold finden", "color": "white", "bold": false}]
$execute if score @s sr_d_stronghold matches 0 if score #found sr matches 1 run scoreboard players display name s7 sr_o$(k) {"text": "☐ Augen werfen, Stronghold finden", "color": "gray"}
execute if score @s sr_d_stronghold matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_end matches 0 if function sr:pc/end run function sr:pd/end
$execute if score @s sr_d_end matches 1 run scoreboard players display name s8 sr_o$(k) {"text": "✔ Endportal öffnen und rein", "color": "green"}
$execute if score @s sr_d_end matches 1 run scoreboard players display numberformat s8 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_end matches 0 if score #found sr matches 0 run scoreboard players display name s8 sr_o$(k) {"text": "▶ Endportal öffnen und rein", "color": "yellow", "bold": true}
execute if score @s sr_d_end matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 9/10 ▸ ", "color": "gray", "bold": false}, {"text": "Endportal öffnen und rein", "color": "white", "bold": false}]
$execute if score @s sr_d_end matches 0 if score #found sr matches 1 run scoreboard players display name s8 sr_o$(k) {"text": "☐ Endportal öffnen und rein", "color": "gray"}
execute if score @s sr_d_end matches 0 run scoreboard players set #found sr 1
execute if score @s sr_d_dragon matches 0 if function sr:pc/dragon run function sr:pd/dragon
$execute if score @s sr_d_dragon matches 1 run scoreboard players display name s9 sr_o$(k) {"text": "✔ Drachen töten", "color": "green"}
$execute if score @s sr_d_dragon matches 1 run scoreboard players display numberformat s9 sr_o$(k) fixed {"text": "✔", "color": "green", "bold": true}
$execute if score @s sr_d_dragon matches 0 if score #found sr matches 0 run scoreboard players display name s9 sr_o$(k) {"text": "▶ Drachen töten", "color": "yellow", "bold": true}
execute if score @s sr_d_dragon matches 0 if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Schritt 10/10 ▸ ", "color": "gray", "bold": false}, {"text": "Drachen töten", "color": "white", "bold": false}]
$execute if score @s sr_d_dragon matches 0 if score #found sr matches 1 run scoreboard players display name s9 sr_o$(k) {"text": "☐ Drachen töten", "color": "gray"}
execute if score @s sr_d_dragon matches 0 run scoreboard players set #found sr 1
execute if score #found sr matches 0 run title @s actionbar [{"text": "[Solo] ", "color": "yellow", "bold": true}, {"text": "Alles erledigt – hilf deinem Team!", "color": "green", "bold": false}]
$execute if score #sec sr matches 10.. run scoreboard objectives modify sr_o$(k) displayname [{"text": "Solo", "color": "yellow", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
$execute if score #sec sr matches ..9 run scoreboard objectives modify sr_o$(k) displayname [{"text": "Solo", "color": "yellow", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
