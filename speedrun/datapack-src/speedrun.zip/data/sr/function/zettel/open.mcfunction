tag @a remove sr_zg
scoreboard players set #zt sr 0
execute if entity @s[tag=sr_run] run scoreboard players operation #zt sr = @s sr_team
execute if entity @s[tag=sr_spec] at @s as @p[tag=sr_run] run scoreboard players operation #zt sr = @s sr_team
execute if entity @s[tag=sr_spec] if score #zt sr matches 0 as @r[tag=sr_run] run scoreboard players operation #zt sr = @s sr_team
execute if score #zt sr matches 1.. as @a[tag=sr_run] if score @s sr_team = #zt sr run tag @s add sr_zg
execute if score #zt sr matches 0 run tag @s add sr_zg
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:wooden_pickaxe 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:stone_pickaxe 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:copper_pickaxe 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:iron_pickaxe 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:golden_pickaxe 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:diamond_pickaxe 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:netherite_pickaxe 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_pick int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_pick set value '{text:"",color:"gray"}'
execute if score #zv sr matches 1.. run data modify storage sr:zettel d.c_pick set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:iron_sword 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:diamond_sword 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:netherite_sword 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_sword int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_sword set value '{text:"",color:"gray"}'
execute if score #zv sr matches 1.. run data modify storage sr:zettel d.c_sword set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:shield 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_shield int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_shield set value '{text:"",color:"gray"}'
execute if score #zv sr matches 1.. run data modify storage sr:zettel d.c_shield set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:bucket 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:water_bucket 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:lava_bucket 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_bucket int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_bucket set value '{text:"",color:"gray"}'
execute if score #zv sr matches 1.. run data modify storage sr:zettel d.c_bucket set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:flint_and_steel 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_flint int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_flint set value '{text:"",color:"gray"}'
execute if score #zv sr matches 1.. run data modify storage sr:zettel d.c_flint set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:obsidian 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_obsi int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_obsi set value '{text:"",color:"gray"}'
execute if score #zv sr matches 10.. run data modify storage sr:zettel d.c_obsi set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cooked_beef 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cooked_porkchop 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cooked_mutton 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cooked_chicken 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cooked_rabbit 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cooked_cod 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cooked_salmon 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:bread 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:baked_potato 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:golden_carrot 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_food int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_food set value '{text:"",color:"gray"}'
execute if score #zv sr matches 20.. run data modify storage sr:zettel d.c_food set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s #minecraft:beds 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_beds int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_beds set value '{text:"",color:"gray"}'
execute if score #zv sr matches 7.. run data modify storage sr:zettel d.c_beds set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:blaze_rod 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:blaze_powder 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:ender_eye 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
scoreboard players operation #zv sr /= #2 sr
execute store result storage sr:zettel d.v_blaze int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_blaze set value '{text:"",color:"gray"}'
execute if score #zv sr matches 7.. run data modify storage sr:zettel d.c_blaze set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:ender_pearl 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:ender_eye 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_pearls int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_pearls set value '{text:"",color:"gray"}'
execute if score #zv sr matches 12.. run data modify storage sr:zettel d.c_pearls set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:gold_ingot 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:gold_block 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_gold int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_gold set value '{text:"",color:"gray"}'
execute if score #zv sr matches 32.. run data modify storage sr:zettel d.c_gold set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:ender_eye 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_eyes int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_eyes set value '{text:"",color:"gray"}'
execute if score #zv sr matches 12.. run data modify storage sr:zettel d.c_eyes set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:bow 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:crossbow 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_bow int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_bow set value '{text:"",color:"gray"}'
execute if score #zv sr matches 1.. run data modify storage sr:zettel d.c_bow set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:arrow 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:spectral_arrow 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:tipped_arrow 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_arrows int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_arrows set value '{text:"",color:"gray"}'
execute if score #zv sr matches 16.. run data modify storage sr:zettel d.c_arrows set value '{text:" ✔",color:"green",bold:true}'
scoreboard players set #zv sr 0
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cobblestone 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:cobbled_deepslate 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:netherrack 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:dirt 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute as @a[tag=sr_zg] store result score @s sr_tmp run clear @s minecraft:end_stone 0
execute as @a[tag=sr_zg] run scoreboard players operation #zv sr += @s sr_tmp
execute store result storage sr:zettel d.v_blocks int 1 run scoreboard players get #zv sr
data modify storage sr:zettel d.c_blocks set value '{text:"",color:"gray"}'
execute if score #zv sr matches 64.. run data modify storage sr:zettel d.c_blocks set value '{text:" ✔",color:"green",bold:true}'
data modify storage sr:zettel d.team set value '{text:"Lobby",color:"gray"}'
data modify storage sr:zettel d.time set value "–:––"
execute if score #active sr matches 1 run data modify storage sr:zettel d.time set from storage sr:run tstr
execute if entity @s[tag=sr_run] run data modify storage sr:zettel d.time set from storage sr:run tstr
data modify storage sr:zettel d.who set value '{text:"Zählt nur deine Items (im Run: das ganze Team)",color:"dark_gray"}'
execute if score #zt sr matches 1.. run data modify storage sr:zettel d.who set value '{text:"Zahlen = alle Items deines Teams (online)",color:"dark_gray"}'
execute if entity @s[tag=sr_spec] run data modify storage sr:zettel d.team set value '{text:"Zuschauer",color:"aqua"}'
data modify storage sr:zettel d.role set value '{text:"noch keine – wird beim Start verteilt",color:"gray"}'
data modify storage sr:zettel d.hint set value '{text:"Wunschrolle: Slot 3 in der Lobby",color:"gray"}'
data modify storage sr:zettel d.next set value '{text:"Modus wählen, Netherstern: Run starten",color:"white"}'
data modify storage sr:zettel d.tip set value '{text:"Lobby: Modus mit der Uhr wählen, mit dem Netherstern starten. Im Run zählt dieser Zettel die Items deines ganzen Teams und hakt alles ab.",color:"gray"}'
data modify storage sr:zettel d.cnt set value 0
data modify storage sr:zettel d.t0 set value '[{text:"☐ ",color:"dark_gray"},{text:"Schild + Eisenschwert",color:"gray"}]'
data modify storage sr:zettel d.t1 set value '[{text:"☐ ",color:"dark_gray"},{text:"Eimer + Feuerzeug",color:"gray"}]'
data modify storage sr:zettel d.t2 set value '[{text:"☐ ",color:"dark_gray"},{text:"Nether betreten",color:"gray"}]'
data modify storage sr:zettel d.t3 set value '[{text:"☐ ",color:"dark_gray"},{text:"Festung gefunden",color:"gray"}]'
data modify storage sr:zettel d.t4 set value '[{text:"☐ ",color:"dark_gray"},{text:"Bastion gefunden",color:"gray"}]'
data modify storage sr:zettel d.t5 set value '[{text:"☐ ",color:"dark_gray"},{text:"Blaze-Ruten",color:"gray"}]'
data modify storage sr:zettel d.t6 set value '[{text:"☐ ",color:"dark_gray"},{text:"Enderperlen",color:"gray"}]'
data modify storage sr:zettel d.t7 set value '[{text:"☐ ",color:"dark_gray"},{text:"Betten",color:"gray"}]'
data modify storage sr:zettel d.t8 set value '[{text:"☐ ",color:"dark_gray"},{text:"Essen",color:"gray"}]'
data modify storage sr:zettel d.t9 set value '[{text:"☐ ",color:"dark_gray"},{text:"Enderaugen",color:"gray"}]'
data modify storage sr:zettel d.t10 set value '[{text:"☐ ",color:"dark_gray"},{text:"Stronghold gefunden",color:"gray"}]'
data modify storage sr:zettel d.t11 set value '[{text:"☐ ",color:"dark_gray"},{text:"End betreten",color:"gray"}]'
data modify storage sr:zettel d.t12 set value '[{text:"☐ ",color:"dark_gray"},{text:"Drache besiegt",color:"gray"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 run data modify storage sr:zettel d.role set value '{text:"Solo",color:"yellow",bold:true}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 run data modify storage sr:zettel d.hint set value '{text:"Alles selbst: Portal, Blaze-Ruten, Perlen, Stronghold, Drache",color:"gray"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 run data modify storage sr:zettel d.role set value '{text:"Kämpfer",color:"yellow",bold:true}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 run data modify storage sr:zettel d.hint set value '{text:"Festung, 7 Blaze-Ruten, Käfig-Kristalle, Drache mit Betten sprengen",color:"gray"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 run data modify storage sr:zettel d.role set value '{text:"Portal & Perlen",color:"yellow",bold:true}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 run data modify storage sr:zettel d.hint set value '{text:"Portal (Wasser + Lava), Bastion, Gold gegen 12 Perlen tauschen",color:"gray"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 run data modify storage sr:zettel d.role set value '{text:"Versorger",color:"yellow",bold:true}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 run data modify storage sr:zettel d.hint set value '{text:"Eimer, Feuerzeug, 7 Betten und Essen für das Team",color:"gray"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 run data modify storage sr:zettel d.role set value '{text:"Späher",color:"yellow",bold:true}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 run data modify storage sr:zettel d.hint set value '{text:"Enderaugen craften, Stronghold orten, Endportal öffnen",color:"gray"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 run data modify storage sr:zettel d.role set value '{text:"Nether-Läufer",color:"yellow",bold:true}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 run data modify storage sr:zettel d.hint set value '{text:"Festung + Bastion: 7 Blaze-Ruten und 12 Perlen",color:"gray"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 run data modify storage sr:zettel d.role set value '{text:"Versorger & Wegfinder",color:"yellow",bold:true}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 run data modify storage sr:zettel d.hint set value '{text:"Portal, Betten, Essen, Enderaugen, Stronghold",color:"gray"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 run data modify storage sr:zettel d.next set value '{text:"Alles erledigt – hilf deinem Team!",color:"green"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_dragon matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 10/10: ",color:"gold"},{text:"Drachen töten",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_end matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 9/10: ",color:"gold"},{text:"Endportal öffnen und rein",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_stronghold matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 8/10: ",color:"gold"},{text:"Augen werfen, Stronghold finden",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_eyes matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 7/10: ",color:"gold"},{text:"Enderaugen craften (12)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_beds matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 6/10: ",color:"gold"},{text:"Wolle sammeln, Betten craften (7)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_pearls matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 5/10: ",color:"gold"},{text:"Bastion: Gold gegen Perlen tauschen (12)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_blaze matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 4/10: ",color:"gold"},{text:"Blaze-Ruten farmen (7)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_fortress matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 3/10: ",color:"gold"},{text:"Festung finden",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_nether matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 2/10: ",color:"gold"},{text:"Portal gießen, ab in den Nether",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 0 if score @s sr_d_tools matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 1/10: ",color:"gold"},{text:"Eimer + Feuerzeug bauen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 run data modify storage sr:zettel d.next set value '{text:"Alles erledigt – hilf deinem Team!",color:"green"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 if score @s sr_d_dragon matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 7/7: ",color:"gold"},{text:"Käfig-Kristalle zerstören, Drachen mit Betten sprengen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 if score @s sr_d_end matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 6/7: ",color:"gold"},{text:"Ins End",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 if score @s sr_d_stronghold matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 5/7: ",color:"gold"},{text:"Zum Stronghold",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 if score @s sr_d_blaze matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 4/7: ",color:"gold"},{text:"Blaze-Ruten farmen (7)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 if score @s sr_d_fortress matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 3/7: ",color:"gold"},{text:"Festung finden",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 if score @s sr_d_nether matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 2/7: ",color:"gold"},{text:"Durchs Portal in den Nether",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 1 if score @s sr_d_gear matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 1/7: ",color:"gold"},{text:"Schild + Eisenschwert bauen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 run data modify storage sr:zettel d.next set value '{text:"Alles erledigt – hilf deinem Team!",color:"green"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 if score @s sr_d_dragon matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 7/7: ",color:"gold"},{text:"Kristalle abschießen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 if score @s sr_d_end matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 6/7: ",color:"gold"},{text:"Ins End",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 if score @s sr_d_stronghold matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 5/7: ",color:"gold"},{text:"Zum Stronghold",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 if score @s sr_d_pearls matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 4/7: ",color:"gold"},{text:"Gold gegen Perlen tauschen (12)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 if score @s sr_d_bastion matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 3/7: ",color:"gold"},{text:"Bastion finden, Piglins einmauern",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 if score @s sr_d_nether matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 2/7: ",color:"gold"},{text:"Portal mit Wasser + Lava gießen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 2 if score @s sr_d_tools matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 1/7: ",color:"gold"},{text:"Eimer + Feuerzeug bauen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 run data modify storage sr:zettel d.next set value '{text:"Alles erledigt – hilf deinem Team!",color:"green"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 if score @s sr_d_dragon matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 7/7: ",color:"gold"},{text:"Betten bereithalten, Endermen nicht anschauen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 if score @s sr_d_end matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 6/7: ",color:"gold"},{text:"Ins End",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 if score @s sr_d_stronghold matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 5/7: ",color:"gold"},{text:"Augen werfen, Stronghold finden",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 if score @s sr_d_eyes matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 4/7: ",color:"gold"},{text:"Enderaugen craften (12)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 if score @s sr_d_nether matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 3/7: ",color:"gold"},{text:"In den Nether, beim Tauschen helfen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 if score @s sr_d_food matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 2/7: ",color:"gold"},{text:"Essen braten für alle (20)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 3 if score @s sr_d_beds matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 1/7: ",color:"gold"},{text:"Wolle sammeln, Betten craften (7)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 run data modify storage sr:zettel d.next set value '{text:"Alles erledigt – hilf deinem Team!",color:"green"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 if score @s sr_d_dragon matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 6/6: ",color:"gold"},{text:"Kristalle abschießen, Drachen töten",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 if score @s sr_d_end matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 5/6: ",color:"gold"},{text:"Endportal öffnen und rein",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 if score @s sr_d_stronghold matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 4/6: ",color:"gold"},{text:"Augen werfen, Stronghold finden",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 if score @s sr_d_eyes matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 3/6: ",color:"gold"},{text:"Enderaugen craften (12)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 if score @s sr_d_nether matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 2/6: ",color:"gold"},{text:"In den Nether",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 4 if score @s sr_d_gear matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 1/6: ",color:"gold"},{text:"Schild + Eisenschwert bauen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 run data modify storage sr:zettel d.next set value '{text:"Alles erledigt – hilf deinem Team!",color:"green"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 if score @s sr_d_dragon matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 8/8: ",color:"gold"},{text:"Drachen töten",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 if score @s sr_d_end matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 7/8: ",color:"gold"},{text:"Ins End",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 if score @s sr_d_stronghold matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 6/8: ",color:"gold"},{text:"Zum Stronghold",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 if score @s sr_d_pearls matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 5/8: ",color:"gold"},{text:"Gold gegen Perlen tauschen (12)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 if score @s sr_d_bastion matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 4/8: ",color:"gold"},{text:"Bastion finden",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 if score @s sr_d_blaze matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 3/8: ",color:"gold"},{text:"Blaze-Ruten farmen (7)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 if score @s sr_d_fortress matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 2/8: ",color:"gold"},{text:"Festung finden",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 5 if score @s sr_d_nether matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 1/8: ",color:"gold"},{text:"In den Nether",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 run data modify storage sr:zettel d.next set value '{text:"Alles erledigt – hilf deinem Team!",color:"green"}'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 if score @s sr_d_dragon matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 8/8: ",color:"gold"},{text:"Drachen mit Betten sprengen",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 if score @s sr_d_end matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 7/8: ",color:"gold"},{text:"Ins End",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 if score @s sr_d_stronghold matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 6/8: ",color:"gold"},{text:"Stronghold finden",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 if score @s sr_d_eyes matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 5/8: ",color:"gold"},{text:"Enderaugen craften (12)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 if score @s sr_d_nether matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 4/8: ",color:"gold"},{text:"In den Nether",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 if score @s sr_d_food matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 3/8: ",color:"gold"},{text:"Essen braten (20)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 if score @s sr_d_beds matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 2/8: ",color:"gold"},{text:"Betten craften (7)",color:"white"}]'
execute if entity @s[tag=sr_run] if score @s sr_role matches 6 if score @s sr_d_tools matches 0 run data modify storage sr:zettel d.next set value '[{text:"Schritt 1/8: ",color:"gold"},{text:"Eimer + Feuerzeug, Portal gießen",color:"white"}]'
execute if score #zt sr matches 1 run function sr:zettel/team_t1
execute if score #zt sr matches 2 run function sr:zettel/team_t2
execute if score #zt sr matches 3 run function sr:zettel/team_t3
execute if score #zt sr matches 4 run function sr:zettel/team_t4
execute if score #zt sr matches 5 run function sr:zettel/team_t5
execute if score #zt sr matches 6 run function sr:zettel/team_t6
execute if score #zt sr matches 7 run function sr:zettel/team_t7
execute if score #zt sr matches 8 run function sr:zettel/team_t8
execute if entity @s[tag=sr_spec] run data modify storage sr:zettel d.role set value '{text:"Zuschauer",color:"aqua",bold:true}'
execute if entity @s[tag=sr_spec] run data modify storage sr:zettel d.hint set value '{text:"Du siehst den Stand des Teams, das dir am nächsten ist.",color:"gray"}'
execute if entity @s[tag=sr_spec] run data modify storage sr:zettel d.next set value '{text:"Zurück zur Lobby: Esc → Speedrun-Menü",color:"white"}'
execute if entity @s[tag=sr_spec] if score #zt sr matches 1.. run data modify storage sr:zettel d.who set value '{text:"Zahlen = alle Items dieses Teams (online)",color:"dark_gray"}'
function sr:zettel/show with storage sr:zettel d
tag @a remove sr_zg
playsound minecraft:item.book.page_turn master @s ~ ~ ~ 0.8 1.1
