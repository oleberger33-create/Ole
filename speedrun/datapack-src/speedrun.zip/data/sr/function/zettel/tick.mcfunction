scoreboard players set #ztick sr 0
execute as @e[type=minecraft:item] if items entity @s contents *[minecraft:custom_data~{sr_zettel:1b}] run kill @s
execute as @e[type=minecraft:player] run function sr:zettel/keep
