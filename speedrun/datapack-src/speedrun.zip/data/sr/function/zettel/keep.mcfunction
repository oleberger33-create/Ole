execute store result score #zn sr run clear @s *[minecraft:custom_data~{sr_zettel:1b}] 0
execute if score #zn sr matches 1 run return 0
execute if score #zn sr matches 2.. run clear @s *[minecraft:custom_data~{sr_zettel:1b}]
function sr:zettel/give
