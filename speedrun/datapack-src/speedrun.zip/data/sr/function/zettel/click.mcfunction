execute store result score #znow sr run time query gametime
execute unless score @s sr_zcd matches -2147483648..2147483647 run scoreboard players set @s sr_zcd -1000
scoreboard players operation #zgap sr = #znow sr
scoreboard players operation #zgap sr -= @s sr_zcd
scoreboard players operation @s sr_zcd = #znow sr
execute if score #zgap sr matches 0..9 run return 0
function sr:zettel/open
