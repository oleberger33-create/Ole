execute if score @s sr_rolle matches 1 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Wunschrolle: ", "color": "gray"}, {"text": "Kämpfer", "color": "gold", "bold": true}, {"text": " (zählt ab 3 Spielern pro Team)", "color": "dark_gray"}]
execute if score @s sr_rolle matches 2 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Wunschrolle: ", "color": "gray"}, {"text": "Portal & Perlen", "color": "light_purple", "bold": true}, {"text": " (zählt ab 3 Spielern pro Team)", "color": "dark_gray"}]
execute if score @s sr_rolle matches 3 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Wunschrolle: ", "color": "gray"}, {"text": "Versorger", "color": "green", "bold": true}, {"text": " (zählt ab 3 Spielern pro Team)", "color": "dark_gray"}]
execute if score @s sr_rolle matches 4 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Wunschrolle: ", "color": "gray"}, {"text": "Späher", "color": "aqua", "bold": true}, {"text": " (zählt ab 3 Spielern pro Team)", "color": "dark_gray"}]
scoreboard players operation @s sr_pref = @s sr_rolle
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.4
scoreboard players set @s sr_rolle 0
