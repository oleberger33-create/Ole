tag @a remove sr_cur
tag @a[scores={sr_team=2}] add sr_cur
scoreboard players set #size sr 0
execute as @a[scores={sr_team=2}] run scoreboard players add #size sr 1
execute if score #size sr matches 0 run return 0
execute if score #size sr matches 1 as @a[scores={sr_team=2}] run function sr:role/give {r:0}
execute if score #size sr matches 2 run function sr:role/duo_t2
execute if score #size sr matches 3 run function sr:role/trio_t2
execute if score #size sr matches 4.. run function sr:role/squad_t2
