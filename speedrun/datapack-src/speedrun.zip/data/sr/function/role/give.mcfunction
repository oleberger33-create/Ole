$scoreboard players set @s sr_role $(r)
tag @s add sr_hasrole
scoreboard players set #got sr 1
