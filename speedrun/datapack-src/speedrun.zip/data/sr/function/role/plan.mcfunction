execute unless entity @s[tag=sr_run] run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Dein Plan erscheint, sobald ein Run läuft.", "color": "gray"}]
execute if score @s sr_role matches 0 run return run dialog show @s sr:plan_r0
execute if score @s sr_role matches 1 run return run dialog show @s sr:plan_r1
execute if score @s sr_role matches 2 run return run dialog show @s sr:plan_r2
execute if score @s sr_role matches 3 run return run dialog show @s sr:plan_r3
execute if score @s sr_role matches 4 run return run dialog show @s sr:plan_r4
execute if score @s sr_role matches 5 run return run dialog show @s sr:plan_r5
execute if score @s sr_role matches 6 run return run dialog show @s sr:plan_r6
