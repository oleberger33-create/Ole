scoreboard players set @s sr_role 3
execute if score @s sr_pref matches 1..4 run scoreboard players operation @s sr_role = @s sr_pref
tag @s add sr_hasrole
