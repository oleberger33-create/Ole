scoreboard players set #got sr 0
scoreboard players set #g1 sr 0
execute as @a[team=sr_t8,tag=!sr_hasrole,scores={sr_pref=1..1},limit=1,sort=random] run function sr:role/give {r:1}
execute if score #got sr matches 1 run scoreboard players set #g1 sr 1
scoreboard players set #got sr 0
scoreboard players set #g2 sr 0
execute as @a[team=sr_t8,tag=!sr_hasrole,scores={sr_pref=2..2},limit=1,sort=random] run function sr:role/give {r:2}
execute if score #got sr matches 1 run scoreboard players set #g2 sr 1
scoreboard players set #got sr 0
scoreboard players set #g3 sr 0
execute as @a[team=sr_t8,tag=!sr_hasrole,scores={sr_pref=3..3},limit=1,sort=random] run function sr:role/give {r:3}
execute if score #got sr matches 1 run scoreboard players set #g3 sr 1
scoreboard players set #got sr 0
scoreboard players set #g4 sr 0
execute as @a[team=sr_t8,tag=!sr_hasrole,scores={sr_pref=4..4},limit=1,sort=random] run function sr:role/give {r:4}
execute if score #got sr matches 1 run scoreboard players set #g4 sr 1
scoreboard players set #got sr 0
execute if score #g1 sr matches 0 as @a[team=sr_t8,tag=!sr_hasrole,limit=1,sort=random] run function sr:role/give {r:1}
execute if score #g2 sr matches 0 as @a[team=sr_t8,tag=!sr_hasrole,limit=1,sort=random] run function sr:role/give {r:2}
execute if score #g3 sr matches 0 as @a[team=sr_t8,tag=!sr_hasrole,limit=1,sort=random] run function sr:role/give {r:3}
execute if score #g4 sr matches 0 as @a[team=sr_t8,tag=!sr_hasrole,limit=1,sort=random] run function sr:role/give {r:4}
execute as @a[team=sr_t8,tag=!sr_hasrole] run function sr:role/extra
