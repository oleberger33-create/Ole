scoreboard players set #size sr 0
execute as @a[team=sr_t7] run scoreboard players add #size sr 1
execute if score #size sr matches 0 run return 0
execute if score #size sr matches 1 as @a[team=sr_t7] run function sr:role/give {r:0}
execute if score #size sr matches 2 run function sr:role/duo_t7
execute if score #size sr matches 3 run function sr:role/trio_t7
execute if score #size sr matches 4.. run function sr:role/squad_t7
