execute if score @s sr_rolle matches 1 run team join sr_ole @s
execute if score @s sr_rolle matches 1 run tellraw @a [{"text": "[Speedrun] ", "color": "yellow"}, {"selector": "@s"}, {"text": " spielt jetzt ", "color": "gray"}, {"text": "Ole · Kämpfer", "color": "gold"}]
execute if score @s sr_rolle matches 1 run title @s actionbar {"text": "Rolle: Ole · Kämpfer", "color": "gold"}
execute if score @s sr_rolle matches 2 run team join sr_mats @s
execute if score @s sr_rolle matches 2 run tellraw @a [{"text": "[Speedrun] ", "color": "yellow"}, {"selector": "@s"}, {"text": " spielt jetzt ", "color": "gray"}, {"text": "Mats · Portal & Perlen", "color": "light_purple"}]
execute if score @s sr_rolle matches 2 run title @s actionbar {"text": "Rolle: Mats · Portal & Perlen", "color": "light_purple"}
execute if score @s sr_rolle matches 3 run team join sr_sammy @s
execute if score @s sr_rolle matches 3 run tellraw @a [{"text": "[Speedrun] ", "color": "yellow"}, {"selector": "@s"}, {"text": " spielt jetzt ", "color": "gray"}, {"text": "Sammy · Versorger", "color": "green"}]
execute if score @s sr_rolle matches 3 run title @s actionbar {"text": "Rolle: Sammy · Versorger", "color": "green"}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.4
scoreboard players set @s sr_rolle 0
