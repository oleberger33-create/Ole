title @s times 5 60 15
execute if entity @s[team=sr_t1] run title @s title {"text": "Team Rot", "color": "red", "bold": true}
execute if entity @s[team=sr_t2] run title @s title {"text": "Team Blau", "color": "blue", "bold": true}
execute if entity @s[team=sr_t3] run title @s title {"text": "Team Grün", "color": "green", "bold": true}
execute if entity @s[team=sr_t4] run title @s title {"text": "Team Gelb", "color": "yellow", "bold": true}
execute if entity @s[team=sr_t5] run title @s title {"text": "Team Türkis", "color": "aqua", "bold": true}
execute if entity @s[team=sr_t6] run title @s title {"text": "Team Lila", "color": "light_purple", "bold": true}
execute if entity @s[team=sr_t7] run title @s title {"text": "Team Orange", "color": "gold", "bold": true}
execute if entity @s[team=sr_t8] run title @s title {"text": "Team Weiß", "color": "white", "bold": true}
execute if score @s sr_role matches 0 run title @s subtitle [{"text": "Deine Rolle: ", "color": "gray"}, {"text": "Solo", "color": "yellow", "bold": true}]
execute if score @s sr_role matches 0 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Rolle: ", "color": "gray"}, {"text": "Solo", "color": "yellow", "bold": true}, {"text": " – Alles selbst: Portal, Blaze-Ruten, Perlen, Stronghold, Drache", "color": "white"}]
execute if score @s sr_role matches 1 run title @s subtitle [{"text": "Deine Rolle: ", "color": "gray"}, {"text": "Kämpfer", "color": "yellow", "bold": true}]
execute if score @s sr_role matches 1 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Rolle: ", "color": "gray"}, {"text": "Kämpfer", "color": "yellow", "bold": true}, {"text": " – Festung, 7 Blaze-Ruten, Käfig-Kristalle, Drache mit Betten sprengen", "color": "white"}]
execute if score @s sr_role matches 2 run title @s subtitle [{"text": "Deine Rolle: ", "color": "gray"}, {"text": "Portal & Perlen", "color": "yellow", "bold": true}]
execute if score @s sr_role matches 2 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Rolle: ", "color": "gray"}, {"text": "Portal & Perlen", "color": "yellow", "bold": true}, {"text": " – Portal (Wasser + Lava), Bastion, Gold gegen 12 Perlen tauschen", "color": "white"}]
execute if score @s sr_role matches 3 run title @s subtitle [{"text": "Deine Rolle: ", "color": "gray"}, {"text": "Versorger", "color": "yellow", "bold": true}]
execute if score @s sr_role matches 3 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Rolle: ", "color": "gray"}, {"text": "Versorger", "color": "yellow", "bold": true}, {"text": " – Eimer, Feuerzeug, 7 Betten und Essen für das Team", "color": "white"}]
execute if score @s sr_role matches 4 run title @s subtitle [{"text": "Deine Rolle: ", "color": "gray"}, {"text": "Späher", "color": "yellow", "bold": true}]
execute if score @s sr_role matches 4 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Rolle: ", "color": "gray"}, {"text": "Späher", "color": "yellow", "bold": true}, {"text": " – Enderaugen craften, Stronghold orten, Endportal öffnen", "color": "white"}]
execute if score @s sr_role matches 5 run title @s subtitle [{"text": "Deine Rolle: ", "color": "gray"}, {"text": "Nether-Läufer", "color": "yellow", "bold": true}]
execute if score @s sr_role matches 5 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Rolle: ", "color": "gray"}, {"text": "Nether-Läufer", "color": "yellow", "bold": true}, {"text": " – Festung + Bastion: 7 Blaze-Ruten und 12 Perlen", "color": "white"}]
execute if score @s sr_role matches 6 run title @s subtitle [{"text": "Deine Rolle: ", "color": "gray"}, {"text": "Versorger & Wegfinder", "color": "yellow", "bold": true}]
execute if score @s sr_role matches 6 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Rolle: ", "color": "gray"}, {"text": "Versorger & Wegfinder", "color": "yellow", "bold": true}, {"text": " – Portal, Betten, Essen, Enderaugen, Stronghold", "color": "white"}]
execute if score #teams sr matches 2.. run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "RENNEN! ", "color": "red", "bold": true}, {"text": "Jedes Team startet woanders. Wer zuerst den Drachen tötet, gewinnt.", "color": "white"}]
