scoreboard players set #got sr 0
scoreboard players set #g5 sr 0
execute as @a[team=sr_t1,tag=!sr_hasrole,scores={sr_pref=1..2},limit=1,sort=random] run function sr:role/give {r:5}
execute if score #got sr matches 1 run scoreboard players set #g5 sr 1
scoreboard players set #got sr 0
scoreboard players set #g6 sr 0
execute as @a[team=sr_t1,tag=!sr_hasrole,scores={sr_pref=3..4},limit=1,sort=random] run function sr:role/give {r:6}
execute if score #got sr matches 1 run scoreboard players set #g6 sr 1
scoreboard players set #got sr 0
execute if score #g5 sr matches 0 as @a[team=sr_t1,tag=!sr_hasrole,limit=1,sort=random] run function sr:role/give {r:5}
execute if score #g6 sr matches 0 as @a[team=sr_t1,tag=!sr_hasrole,limit=1,sort=random] run function sr:role/give {r:6}
