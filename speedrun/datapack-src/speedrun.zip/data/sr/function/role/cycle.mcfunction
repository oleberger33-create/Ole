scoreboard players add @s sr_pref 1
execute if score @s sr_pref matches 5.. run scoreboard players set @s sr_pref 0
scoreboard players operation @s sr_rolle = @s sr_pref
execute if score @s sr_rolle matches 1.. run return run function sr:role/pref
scoreboard players set @s sr_rolle 0
tag @s add sr_refresh
tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Wunschrolle: egal (wird automatisch verteilt)", "color": "gray"}]
