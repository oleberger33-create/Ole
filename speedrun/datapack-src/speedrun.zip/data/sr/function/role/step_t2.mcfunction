execute if score @s sr_role matches 0 run return run function sr:role/step_t2_r0
execute if score @s sr_role matches 1 run return run function sr:role/step_t2_r1
execute if score @s sr_role matches 2 run return run function sr:role/step_t2_r2
execute if score @s sr_role matches 3 run return run function sr:role/step_t2_r3
execute if score @s sr_role matches 4 run return run function sr:role/step_t2_r4
execute if score @s sr_role matches 5 run return run function sr:role/step_t2_r5
execute if score @s sr_role matches 6 run return run function sr:role/step_t2_r6
