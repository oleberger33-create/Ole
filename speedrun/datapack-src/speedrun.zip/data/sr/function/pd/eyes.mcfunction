scoreboard players set @s sr_d_eyes 1
tellraw @s [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Dein Schritt erledigt: ", "color": "gray"}, {"text": "Enderaugen", "color": "white"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 1.2
