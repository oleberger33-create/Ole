scoreboard players set @s sr_d_food 1
tellraw @s [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Dein Schritt erledigt: ", "color": "gray"}, {"text": "Essen", "color": "white"}]
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.8 1.2
