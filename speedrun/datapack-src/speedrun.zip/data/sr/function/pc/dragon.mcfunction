execute if score #finished sr matches 1 run return 1
return 0
