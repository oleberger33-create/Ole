execute if entity @s[advancements={minecraft:nether/find_bastion=true}] run return 1
return 0
