scoreboard players set @s sr_v_food 0
scoreboard players operation @s sr_v_food += @s sr_cr_f0
scoreboard players operation @s sr_v_food += @s sr_cr_f1
scoreboard players operation @s sr_v_food += @s sr_cr_f2
scoreboard players operation @s sr_v_food += @s sr_cr_f3
scoreboard players operation @s sr_v_food += @s sr_cr_f4
scoreboard players operation @s sr_v_food += @s sr_cr_f5
scoreboard players operation @s sr_v_food += @s sr_cr_f6
scoreboard players operation @s sr_v_food += @s sr_cr_f7
scoreboard players operation @s sr_v_food += @s sr_cr_f8
scoreboard players operation @s sr_v_food += @s sr_cr_f9
execute if score @s sr_v_food matches 20.. run return 1
return 0
