execute if dimension minecraft:the_nether run return 1
execute if entity @s[advancements={minecraft:story/enter_the_nether=true}] run return 1
return 0
