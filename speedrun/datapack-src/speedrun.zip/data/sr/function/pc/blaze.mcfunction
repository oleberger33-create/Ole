scoreboard players operation @s sr_v_blaze = @s sr_pu_blaze
execute if score @s sr_v_blaze matches 7.. run return 1
return 0
