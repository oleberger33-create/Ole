execute store result score @s sr_v_beds run clear @s #minecraft:beds 0
execute if score @s sr_v_beds matches 7.. run return 1
return 0
