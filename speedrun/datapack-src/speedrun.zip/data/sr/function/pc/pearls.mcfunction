scoreboard players operation @s sr_v_pearls = @s sr_pu_pearl
execute if score @s sr_v_pearls matches 12.. run return 1
return 0
