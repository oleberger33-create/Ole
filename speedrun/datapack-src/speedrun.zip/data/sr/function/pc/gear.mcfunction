execute store result score #a sr run clear @s minecraft:shield 0
execute if score #a sr matches 0 run return 0
execute store result score #b sr run clear @s minecraft:iron_sword 0
execute store result score #c sr run clear @s minecraft:diamond_sword 0
execute store result score #d sr run clear @s minecraft:netherite_sword 0
scoreboard players operation #b sr += #c sr
scoreboard players operation #b sr += #d sr
execute if score #b sr matches 1.. run return 1
return 0
