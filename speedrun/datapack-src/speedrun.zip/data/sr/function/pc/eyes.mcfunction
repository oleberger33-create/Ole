scoreboard players operation @s sr_v_eyes = @s sr_cr_eye
execute if score @s sr_v_eyes matches 12.. run return 1
return 0
