execute store result score #a sr run clear @s minecraft:flint_and_steel 0
execute if score #a sr matches 0 run return 0
execute store result score #b sr run clear @s minecraft:bucket 0
execute store result score #c sr run clear @s minecraft:water_bucket 0
execute store result score #d sr run clear @s minecraft:lava_bucket 0
scoreboard players operation #b sr += #c sr
scoreboard players operation #b sr += #d sr
execute if score #b sr matches 1.. run return 1
return 0
