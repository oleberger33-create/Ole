execute if dimension minecraft:the_end run return 1
execute if entity @s[advancements={minecraft:story/enter_the_end=true}] run return 1
return 0
