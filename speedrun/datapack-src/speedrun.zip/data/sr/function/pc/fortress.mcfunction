execute if entity @s[advancements={minecraft:nether/find_fortress=true}] run return 1
return 0
