execute if entity @s[advancements={minecraft:story/follow_ender_eye=true}] run return 1
return 0
