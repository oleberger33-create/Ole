function sr:role/assign_t3
scoreboard players operation #slot sr = #nextslot sr
scoreboard players add #nextslot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
data modify storage sr:run place set value {n:3}
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
scoreboard players set #try sr 0
function sr:pos/place with storage sr:run place
scoreboard players set #t3_cnt sr 0
scoreboard players reset * sr_s3
scoreboard players set #t3_gear sr_done 0
scoreboard players set gear sr_s3 13
scoreboard players display name gear sr_s3 {"text": "☐ Schild + Eisenschwert", "color": "gray"}
scoreboard players set #t3_tools sr_done 0
scoreboard players set tools sr_s3 12
scoreboard players display name tools sr_s3 {"text": "☐ Eimer + Feuerzeug", "color": "gray"}
scoreboard players set #t3_nether sr_done 0
scoreboard players set nether sr_s3 11
scoreboard players display name nether sr_s3 {"text": "☐ Nether betreten", "color": "gray"}
scoreboard players set #t3_fortress sr_done 0
scoreboard players set fortress sr_s3 10
scoreboard players display name fortress sr_s3 {"text": "☐ Festung gefunden", "color": "gray"}
scoreboard players set #t3_bastion sr_done 0
scoreboard players set bastion sr_s3 9
scoreboard players display name bastion sr_s3 {"text": "☐ Bastion gefunden", "color": "gray"}
scoreboard players set #t3_blaze sr_done 0
scoreboard players set blaze sr_s3 8
scoreboard players display name blaze sr_s3 {"text": "☐ Blaze-Ruten", "color": "gray"}
scoreboard players display numberformat blaze sr_s3 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t3_v_blaze sr 0
scoreboard players set #t3_pearls sr_done 0
scoreboard players set pearls sr_s3 7
scoreboard players display name pearls sr_s3 {"text": "☐ Enderperlen", "color": "gray"}
scoreboard players display numberformat pearls sr_s3 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t3_v_pearls sr 0
scoreboard players set #t3_beds sr_done 0
scoreboard players set beds sr_s3 6
scoreboard players display name beds sr_s3 {"text": "☐ Betten", "color": "gray"}
scoreboard players display numberformat beds sr_s3 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t3_v_beds sr 0
scoreboard players set #t3_food sr_done 0
scoreboard players set food sr_s3 5
scoreboard players display name food sr_s3 {"text": "☐ Essen", "color": "gray"}
scoreboard players display numberformat food sr_s3 fixed {"text": "0/30", "color": "gray"}
scoreboard players set #t3_v_food sr 0
scoreboard players set #t3_eyes sr_done 0
scoreboard players set eyes sr_s3 4
scoreboard players display name eyes sr_s3 {"text": "☐ Enderaugen", "color": "gray"}
scoreboard players display numberformat eyes sr_s3 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t3_v_eyes sr 0
scoreboard players set #t3_stronghold sr_done 0
scoreboard players set stronghold sr_s3 3
scoreboard players display name stronghold sr_s3 {"text": "☐ Stronghold gefunden", "color": "gray"}
scoreboard players set #t3_end sr_done 0
scoreboard players set end sr_s3 2
scoreboard players display name end sr_s3 {"text": "☐ End betreten", "color": "gray"}
scoreboard players set #t3_dragon sr_done 0
scoreboard players set dragon sr_s3 1
scoreboard players display name dragon sr_s3 {"text": "☐ Drache besiegt", "color": "gray"}
scoreboard objectives modify sr_s3 displayname {"text": "Team Grün", "color": "green", "bold": true}
execute as @a[tag=sr_run,team=sr_t3] run waypoint modify @s color green
bossbar set sr:t3 value 0
bossbar set sr:t3 visible true
bossbar set sr:t3 players @a[tag=sr_run,team=sr_t3]
