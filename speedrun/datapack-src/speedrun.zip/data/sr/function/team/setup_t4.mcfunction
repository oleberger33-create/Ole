function sr:role/assign_t4
scoreboard players operation #slot sr = #nextslot sr
scoreboard players add #nextslot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
data modify storage sr:run place set value {n:4}
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
scoreboard players set #try sr 0
function sr:pos/place with storage sr:run place
scoreboard players set #t4_cnt sr 0
scoreboard players reset * sr_s4
scoreboard players set #t4_gear sr_done 0
scoreboard players set gear sr_s4 12
scoreboard players display name gear sr_s4 {"text": "☐ Schild + Eisenschwert", "color": "gray"}
scoreboard players set #t4_tools sr_done 0
scoreboard players set tools sr_s4 11
scoreboard players display name tools sr_s4 {"text": "☐ Eimer + Feuerzeug", "color": "gray"}
scoreboard players set #t4_nether sr_done 0
scoreboard players set nether sr_s4 10
scoreboard players display name nether sr_s4 {"text": "☐ Nether betreten", "color": "gray"}
scoreboard players set #t4_fortress sr_done 0
scoreboard players set fortress sr_s4 9
scoreboard players display name fortress sr_s4 {"text": "☐ Festung gefunden", "color": "gray"}
scoreboard players set #t4_bastion sr_done 0
scoreboard players set bastion sr_s4 8
scoreboard players display name bastion sr_s4 {"text": "☐ Bastion gefunden", "color": "gray"}
scoreboard players set #t4_blaze sr_done 0
scoreboard players set blaze sr_s4 7
scoreboard players display name blaze sr_s4 {"text": "☐ 7+ Blaze-Ruten", "color": "gray"}
scoreboard players set #t4_pearls sr_done 0
scoreboard players set pearls sr_s4 6
scoreboard players display name pearls sr_s4 {"text": "☐ 12+ Enderperlen", "color": "gray"}
scoreboard players set #t4_beds sr_done 0
scoreboard players set beds sr_s4 5
scoreboard players display name beds sr_s4 {"text": "☐ 7 Betten", "color": "gray"}
scoreboard players set #t4_eyes sr_done 0
scoreboard players set eyes sr_s4 4
scoreboard players display name eyes sr_s4 {"text": "☐ 12 Enderaugen", "color": "gray"}
scoreboard players set #t4_stronghold sr_done 0
scoreboard players set stronghold sr_s4 3
scoreboard players display name stronghold sr_s4 {"text": "☐ Stronghold gefunden", "color": "gray"}
scoreboard players set #t4_end sr_done 0
scoreboard players set end sr_s4 2
scoreboard players display name end sr_s4 {"text": "☐ End betreten", "color": "gray"}
scoreboard players set #t4_dragon sr_done 0
scoreboard players set dragon sr_s4 1
scoreboard players display name dragon sr_s4 {"text": "☐ Drache besiegt", "color": "gray"}
bossbar set sr:t4 value 0
bossbar set sr:t4 visible true
bossbar set sr:t4 players @a[tag=sr_run,team=sr_t4]
