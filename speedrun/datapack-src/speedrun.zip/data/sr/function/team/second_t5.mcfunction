execute if score #sec sr matches 10.. run bossbar set sr:t5 name [{"text": "Team Türkis", "color": "aqua", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t5_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:t5 name [{"text": "Team Türkis", "color": "aqua", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t5_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
bossbar set sr:t5 players @a[tag=sr_run,team=sr_t5]
execute if score #sec sr matches 10.. run scoreboard objectives modify sr_s5 displayname [{"text": "Team Türkis", "color": "aqua", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #sec sr matches ..9 run scoreboard objectives modify sr_s5 displayname [{"text": "Team Türkis", "color": "aqua", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #t5_gear sr_done matches 0 if function sr:cond/t5_gear run function sr:done/t5_gear
execute if score #t5_tools sr_done matches 0 if function sr:cond/t5_tools run function sr:done/t5_tools
execute if score #t5_nether sr_done matches 0 if function sr:cond/t5_nether run function sr:done/t5_nether
execute if score #t5_fortress sr_done matches 0 if function sr:cond/t5_fortress run function sr:done/t5_fortress
execute if score #t5_bastion sr_done matches 0 if function sr:cond/t5_bastion run function sr:done/t5_bastion
execute if score #t5_blaze sr_done matches 0 if function sr:cond/t5_blaze run function sr:done/t5_blaze
execute if score #t5_pearls sr_done matches 0 if function sr:cond/t5_pearls run function sr:done/t5_pearls
execute if score #t5_beds sr_done matches 0 if function sr:cond/t5_beds run function sr:done/t5_beds
execute if score #t5_food sr_done matches 0 if function sr:cond/t5_food run function sr:done/t5_food
execute if score #t5_eyes sr_done matches 0 if function sr:cond/t5_eyes run function sr:done/t5_eyes
execute if score #t5_stronghold sr_done matches 0 if function sr:cond/t5_stronghold run function sr:done/t5_stronghold
execute if score #t5_end sr_done matches 0 if function sr:cond/t5_end run function sr:done/t5_end
execute if score #t5_dragon sr_done matches 0 if function sr:cond/t5_dragon run function sr:done/t5_dragon
