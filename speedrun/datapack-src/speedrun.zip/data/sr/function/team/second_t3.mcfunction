execute if score #sec sr matches 10.. run bossbar set sr:t3 name [{"text": "Team Grün", "color": "green", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t3_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:t3 name [{"text": "Team Grün", "color": "green", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t3_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
bossbar set sr:t3 players @a[tag=sr_run,team=sr_t3]
execute if score #sec sr matches 10.. run scoreboard objectives modify sr_s3 displayname [{"text": "Team Grün", "color": "green", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #sec sr matches ..9 run scoreboard objectives modify sr_s3 displayname [{"text": "Team Grün", "color": "green", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #t3_gear sr_done matches 0 if function sr:cond/t3_gear run function sr:done/t3_gear
execute if score #t3_tools sr_done matches 0 if function sr:cond/t3_tools run function sr:done/t3_tools
execute if score #t3_nether sr_done matches 0 if function sr:cond/t3_nether run function sr:done/t3_nether
execute if score #t3_fortress sr_done matches 0 if function sr:cond/t3_fortress run function sr:done/t3_fortress
execute if score #t3_bastion sr_done matches 0 if function sr:cond/t3_bastion run function sr:done/t3_bastion
execute if score #t3_blaze sr_done matches 0 if function sr:cond/t3_blaze run function sr:done/t3_blaze
execute if score #t3_pearls sr_done matches 0 if function sr:cond/t3_pearls run function sr:done/t3_pearls
execute if score #t3_beds sr_done matches 0 if function sr:cond/t3_beds run function sr:done/t3_beds
execute if score #t3_food sr_done matches 0 if function sr:cond/t3_food run function sr:done/t3_food
execute if score #t3_eyes sr_done matches 0 if function sr:cond/t3_eyes run function sr:done/t3_eyes
execute if score #t3_stronghold sr_done matches 0 if function sr:cond/t3_stronghold run function sr:done/t3_stronghold
execute if score #t3_end sr_done matches 0 if function sr:cond/t3_end run function sr:done/t3_end
execute if score #t3_dragon sr_done matches 0 if function sr:cond/t3_dragon run function sr:done/t3_dragon
