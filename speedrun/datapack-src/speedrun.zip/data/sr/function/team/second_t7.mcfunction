execute if score #sec sr matches 10.. run bossbar set sr:t7 name [{"text": "Team Orange", "color": "gold", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t7_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:t7 name [{"text": "Team Orange", "color": "gold", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t7_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
bossbar set sr:t7 players @a[tag=sr_run,scores={sr_team=7}]
execute if score #sec sr matches 10.. run scoreboard objectives modify sr_s7 displayname [{"text": "Team Orange", "color": "gold", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #sec sr matches ..9 run scoreboard objectives modify sr_s7 displayname [{"text": "Team Orange", "color": "gold", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #t7_gear sr_done matches 0 if function sr:cond/t7_gear run function sr:done/t7_gear
execute if score #t7_tools sr_done matches 0 if function sr:cond/t7_tools run function sr:done/t7_tools
execute if score #t7_nether sr_done matches 0 if function sr:cond/t7_nether run function sr:done/t7_nether
execute if score #t7_fortress sr_done matches 0 if function sr:cond/t7_fortress run function sr:done/t7_fortress
execute if score #t7_bastion sr_done matches 0 if function sr:cond/t7_bastion run function sr:done/t7_bastion
execute if score #t7_blaze sr_done matches 0 if function sr:cond/t7_blaze run function sr:done/t7_blaze
execute if score #t7_pearls sr_done matches 0 if function sr:cond/t7_pearls run function sr:done/t7_pearls
execute if score #t7_beds sr_done matches 0 if function sr:cond/t7_beds run function sr:done/t7_beds
execute if score #t7_food sr_done matches 0 if function sr:cond/t7_food run function sr:done/t7_food
execute if score #t7_eyes sr_done matches 0 if function sr:cond/t7_eyes run function sr:done/t7_eyes
execute if score #t7_stronghold sr_done matches 0 if function sr:cond/t7_stronghold run function sr:done/t7_stronghold
execute if score #t7_end sr_done matches 0 if function sr:cond/t7_end run function sr:done/t7_end
execute if score #t7_dragon sr_done matches 0 if function sr:cond/t7_dragon run function sr:done/t7_dragon
