function sr:role/assign_t7
scoreboard players operation #slot sr = #nextslot sr
scoreboard players add #nextslot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
data modify storage sr:run place set value {n:7}
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
scoreboard players set #try sr 0
function sr:pos/place with storage sr:run place
scoreboard players set #t7_cnt sr 0
scoreboard players reset * sr_s7
scoreboard players set #t7_gear sr_done 0
scoreboard players set gear sr_s7 13
scoreboard players display name gear sr_s7 {"text": "☐ Schild + Eisenschwert", "color": "gray"}
scoreboard players set #t7_tools sr_done 0
scoreboard players set tools sr_s7 12
scoreboard players display name tools sr_s7 {"text": "☐ Eimer + Feuerzeug", "color": "gray"}
scoreboard players set #t7_nether sr_done 0
scoreboard players set nether sr_s7 11
scoreboard players display name nether sr_s7 {"text": "☐ Nether betreten", "color": "gray"}
scoreboard players set #t7_fortress sr_done 0
scoreboard players set fortress sr_s7 10
scoreboard players display name fortress sr_s7 {"text": "☐ Festung gefunden", "color": "gray"}
scoreboard players set #t7_bastion sr_done 0
scoreboard players set bastion sr_s7 9
scoreboard players display name bastion sr_s7 {"text": "☐ Bastion gefunden", "color": "gray"}
scoreboard players set #t7_blaze sr_done 0
scoreboard players set blaze sr_s7 8
scoreboard players display name blaze sr_s7 {"text": "☐ Blaze-Ruten", "color": "gray"}
scoreboard players display numberformat blaze sr_s7 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t7_v_blaze sr 0
scoreboard players set #t7_pearls sr_done 0
scoreboard players set pearls sr_s7 7
scoreboard players display name pearls sr_s7 {"text": "☐ Enderperlen", "color": "gray"}
scoreboard players display numberformat pearls sr_s7 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t7_v_pearls sr 0
scoreboard players set #t7_beds sr_done 0
scoreboard players set beds sr_s7 6
scoreboard players display name beds sr_s7 {"text": "☐ Betten", "color": "gray"}
scoreboard players display numberformat beds sr_s7 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t7_v_beds sr 0
scoreboard players set #t7_food sr_done 0
scoreboard players set food sr_s7 5
scoreboard players display name food sr_s7 {"text": "☐ Essen", "color": "gray"}
scoreboard players display numberformat food sr_s7 fixed {"text": "0/20", "color": "gray"}
scoreboard players set #t7_v_food sr 0
scoreboard players set #t7_eyes sr_done 0
scoreboard players set eyes sr_s7 4
scoreboard players display name eyes sr_s7 {"text": "☐ Enderaugen", "color": "gray"}
scoreboard players display numberformat eyes sr_s7 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t7_v_eyes sr 0
scoreboard players set #t7_stronghold sr_done 0
scoreboard players set stronghold sr_s7 3
scoreboard players display name stronghold sr_s7 {"text": "☐ Stronghold gefunden", "color": "gray"}
scoreboard players set #t7_end sr_done 0
scoreboard players set end sr_s7 2
scoreboard players display name end sr_s7 {"text": "☐ End betreten", "color": "gray"}
scoreboard players set #t7_dragon sr_done 0
scoreboard players set dragon sr_s7 1
scoreboard players display name dragon sr_s7 {"text": "☐ Drache besiegt", "color": "gray"}
scoreboard objectives modify sr_s7 displayname {"text": "Team Orange", "color": "gold", "bold": true}
bossbar set sr:t7 value 0
bossbar set sr:t7 visible true
bossbar set sr:t7 players @a[tag=sr_run,scores={sr_team=7}]
