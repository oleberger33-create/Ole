function sr:role/assign_t2
scoreboard players operation #slot sr = #nextslot sr
scoreboard players add #nextslot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
data modify storage sr:run place set value {n:2}
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
scoreboard players set #try sr 0
function sr:pos/place with storage sr:run place
scoreboard players set #t2_cnt sr 0
scoreboard players reset * sr_s2
scoreboard players set #t2_gear sr_done 0
scoreboard players set gear sr_s2 13
scoreboard players display name gear sr_s2 {"text": "☐ Schild + Eisenschwert", "color": "gray"}
scoreboard players set #t2_tools sr_done 0
scoreboard players set tools sr_s2 12
scoreboard players display name tools sr_s2 {"text": "☐ Eimer + Feuerzeug", "color": "gray"}
scoreboard players set #t2_nether sr_done 0
scoreboard players set nether sr_s2 11
scoreboard players display name nether sr_s2 {"text": "☐ Nether betreten", "color": "gray"}
scoreboard players set #t2_fortress sr_done 0
scoreboard players set fortress sr_s2 10
scoreboard players display name fortress sr_s2 {"text": "☐ Festung gefunden", "color": "gray"}
scoreboard players set #t2_bastion sr_done 0
scoreboard players set bastion sr_s2 9
scoreboard players display name bastion sr_s2 {"text": "☐ Bastion gefunden", "color": "gray"}
scoreboard players set #t2_blaze sr_done 0
scoreboard players set blaze sr_s2 8
scoreboard players display name blaze sr_s2 {"text": "☐ Blaze-Ruten", "color": "gray"}
scoreboard players display numberformat blaze sr_s2 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t2_v_blaze sr 0
scoreboard players set #t2_pearls sr_done 0
scoreboard players set pearls sr_s2 7
scoreboard players display name pearls sr_s2 {"text": "☐ Enderperlen", "color": "gray"}
scoreboard players display numberformat pearls sr_s2 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t2_v_pearls sr 0
scoreboard players set #t2_beds sr_done 0
scoreboard players set beds sr_s2 6
scoreboard players display name beds sr_s2 {"text": "☐ Betten", "color": "gray"}
scoreboard players display numberformat beds sr_s2 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t2_v_beds sr 0
scoreboard players set #t2_food sr_done 0
scoreboard players set food sr_s2 5
scoreboard players display name food sr_s2 {"text": "☐ Essen", "color": "gray"}
scoreboard players display numberformat food sr_s2 fixed {"text": "0/30", "color": "gray"}
scoreboard players set #t2_v_food sr 0
scoreboard players set #t2_eyes sr_done 0
scoreboard players set eyes sr_s2 4
scoreboard players display name eyes sr_s2 {"text": "☐ Enderaugen", "color": "gray"}
scoreboard players display numberformat eyes sr_s2 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t2_v_eyes sr 0
scoreboard players set #t2_stronghold sr_done 0
scoreboard players set stronghold sr_s2 3
scoreboard players display name stronghold sr_s2 {"text": "☐ Stronghold gefunden", "color": "gray"}
scoreboard players set #t2_end sr_done 0
scoreboard players set end sr_s2 2
scoreboard players display name end sr_s2 {"text": "☐ End betreten", "color": "gray"}
scoreboard players set #t2_dragon sr_done 0
scoreboard players set dragon sr_s2 1
scoreboard players display name dragon sr_s2 {"text": "☐ Drache besiegt", "color": "gray"}
scoreboard objectives modify sr_s2 displayname {"text": "Team Blau", "color": "blue", "bold": true}
execute as @a[tag=sr_run,team=sr_t2] run waypoint modify @s color blue
bossbar set sr:t2 value 0
bossbar set sr:t2 visible true
bossbar set sr:t2 players @a[tag=sr_run,team=sr_t2]
