execute if score #sec sr matches 10.. run bossbar set sr:t2 name [{"text": "Team Blau", "color": "blue", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t2_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:t2 name [{"text": "Team Blau", "color": "blue", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t2_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
bossbar set sr:t2 players @a[tag=sr_run,scores={sr_team=2}]
execute if score #sec sr matches 10.. run scoreboard objectives modify sr_s2 displayname [{"text": "Team Blau", "color": "blue", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #sec sr matches ..9 run scoreboard objectives modify sr_s2 displayname [{"text": "Team Blau", "color": "blue", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #t2_gear sr_done matches 0 if function sr:cond/t2_gear run function sr:done/t2_gear
execute if score #t2_tools sr_done matches 0 if function sr:cond/t2_tools run function sr:done/t2_tools
execute if score #t2_nether sr_done matches 0 if function sr:cond/t2_nether run function sr:done/t2_nether
execute if score #t2_fortress sr_done matches 0 if function sr:cond/t2_fortress run function sr:done/t2_fortress
execute if score #t2_bastion sr_done matches 0 if function sr:cond/t2_bastion run function sr:done/t2_bastion
execute if score #t2_blaze sr_done matches 0 if function sr:cond/t2_blaze run function sr:done/t2_blaze
execute if score #t2_pearls sr_done matches 0 if function sr:cond/t2_pearls run function sr:done/t2_pearls
execute if score #t2_beds sr_done matches 0 if function sr:cond/t2_beds run function sr:done/t2_beds
execute if score #t2_food sr_done matches 0 if function sr:cond/t2_food run function sr:done/t2_food
execute if score #t2_eyes sr_done matches 0 if function sr:cond/t2_eyes run function sr:done/t2_eyes
execute if score #t2_stronghold sr_done matches 0 if function sr:cond/t2_stronghold run function sr:done/t2_stronghold
execute if score #t2_end sr_done matches 0 if function sr:cond/t2_end run function sr:done/t2_end
execute if score #t2_dragon sr_done matches 0 if function sr:cond/t2_dragon run function sr:done/t2_dragon
