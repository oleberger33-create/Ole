execute if score #sec sr matches 10.. run bossbar set sr:t1 name [{"text": "Team Rot", "color": "red", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t1_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:t1 name [{"text": "Team Rot", "color": "red", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t1_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
bossbar set sr:t1 players @a[tag=sr_run,team=sr_t1]
execute if score #sec sr matches 10.. run scoreboard objectives modify sr_s1 displayname [{"text": "Team Rot", "color": "red", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #sec sr matches ..9 run scoreboard objectives modify sr_s1 displayname [{"text": "Team Rot", "color": "red", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #t1_gear sr_done matches 0 if function sr:cond/t1_gear run function sr:done/t1_gear
execute if score #t1_tools sr_done matches 0 if function sr:cond/t1_tools run function sr:done/t1_tools
execute if score #t1_nether sr_done matches 0 if function sr:cond/t1_nether run function sr:done/t1_nether
execute if score #t1_fortress sr_done matches 0 if function sr:cond/t1_fortress run function sr:done/t1_fortress
execute if score #t1_bastion sr_done matches 0 if function sr:cond/t1_bastion run function sr:done/t1_bastion
execute if score #t1_blaze sr_done matches 0 if function sr:cond/t1_blaze run function sr:done/t1_blaze
execute if score #t1_pearls sr_done matches 0 if function sr:cond/t1_pearls run function sr:done/t1_pearls
execute if score #t1_beds sr_done matches 0 if function sr:cond/t1_beds run function sr:done/t1_beds
execute if score #t1_food sr_done matches 0 if function sr:cond/t1_food run function sr:done/t1_food
execute if score #t1_eyes sr_done matches 0 if function sr:cond/t1_eyes run function sr:done/t1_eyes
execute if score #t1_stronghold sr_done matches 0 if function sr:cond/t1_stronghold run function sr:done/t1_stronghold
execute if score #t1_end sr_done matches 0 if function sr:cond/t1_end run function sr:done/t1_end
execute if score #t1_dragon sr_done matches 0 if function sr:cond/t1_dragon run function sr:done/t1_dragon
