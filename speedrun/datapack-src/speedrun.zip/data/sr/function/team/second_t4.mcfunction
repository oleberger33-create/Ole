execute if score #sec sr matches 10.. run bossbar set sr:t4 name [{"text": "Team Gelb", "color": "yellow", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t4_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:t4 name [{"text": "Team Gelb", "color": "yellow", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t4_cnt", "objective": "sr"}, "color": "green"}, {"text": "/13", "color": "green"}]
bossbar set sr:t4 players @a[tag=sr_run,team=sr_t4]
execute if score #sec sr matches 10.. run scoreboard objectives modify sr_s4 displayname [{"text": "Team Gelb", "color": "yellow", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #sec sr matches ..9 run scoreboard objectives modify sr_s4 displayname [{"text": "Team Gelb", "color": "yellow", "bold": true}, {"text": "  ⏱ ", "color": "white", "bold": false}, {"score": {"name": "#min", "objective": "sr"}, "color": "white", "bold": false}, {"text": ":0", "color": "white", "bold": false}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white", "bold": false}]
execute if score #t4_gear sr_done matches 0 if function sr:cond/t4_gear run function sr:done/t4_gear
execute if score #t4_tools sr_done matches 0 if function sr:cond/t4_tools run function sr:done/t4_tools
execute if score #t4_nether sr_done matches 0 if function sr:cond/t4_nether run function sr:done/t4_nether
execute if score #t4_fortress sr_done matches 0 if function sr:cond/t4_fortress run function sr:done/t4_fortress
execute if score #t4_bastion sr_done matches 0 if function sr:cond/t4_bastion run function sr:done/t4_bastion
execute if score #t4_blaze sr_done matches 0 if function sr:cond/t4_blaze run function sr:done/t4_blaze
execute if score #t4_pearls sr_done matches 0 if function sr:cond/t4_pearls run function sr:done/t4_pearls
execute if score #t4_beds sr_done matches 0 if function sr:cond/t4_beds run function sr:done/t4_beds
execute if score #t4_food sr_done matches 0 if function sr:cond/t4_food run function sr:done/t4_food
execute if score #t4_eyes sr_done matches 0 if function sr:cond/t4_eyes run function sr:done/t4_eyes
execute if score #t4_stronghold sr_done matches 0 if function sr:cond/t4_stronghold run function sr:done/t4_stronghold
execute if score #t4_end sr_done matches 0 if function sr:cond/t4_end run function sr:done/t4_end
execute if score #t4_dragon sr_done matches 0 if function sr:cond/t4_dragon run function sr:done/t4_dragon
