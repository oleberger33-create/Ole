function sr:role/assign_t5
scoreboard players operation #slot sr = #nextslot sr
scoreboard players add #nextslot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
data modify storage sr:run place set value {n:5}
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
scoreboard players set #try sr 0
function sr:pos/place with storage sr:run place
scoreboard players set #t5_cnt sr 0
scoreboard players reset * sr_s5
scoreboard players set #t5_gear sr_done 0
scoreboard players set gear sr_s5 13
scoreboard players display name gear sr_s5 {"text": "☐ Schild + Eisenschwert", "color": "gray"}
scoreboard players set #t5_tools sr_done 0
scoreboard players set tools sr_s5 12
scoreboard players display name tools sr_s5 {"text": "☐ Eimer + Feuerzeug", "color": "gray"}
scoreboard players set #t5_nether sr_done 0
scoreboard players set nether sr_s5 11
scoreboard players display name nether sr_s5 {"text": "☐ Nether betreten", "color": "gray"}
scoreboard players set #t5_fortress sr_done 0
scoreboard players set fortress sr_s5 10
scoreboard players display name fortress sr_s5 {"text": "☐ Festung gefunden", "color": "gray"}
scoreboard players set #t5_bastion sr_done 0
scoreboard players set bastion sr_s5 9
scoreboard players display name bastion sr_s5 {"text": "☐ Bastion gefunden", "color": "gray"}
scoreboard players set #t5_blaze sr_done 0
scoreboard players set blaze sr_s5 8
scoreboard players display name blaze sr_s5 {"text": "☐ Blaze-Ruten", "color": "gray"}
scoreboard players display numberformat blaze sr_s5 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t5_v_blaze sr 0
scoreboard players set #t5_pearls sr_done 0
scoreboard players set pearls sr_s5 7
scoreboard players display name pearls sr_s5 {"text": "☐ Enderperlen", "color": "gray"}
scoreboard players display numberformat pearls sr_s5 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t5_v_pearls sr 0
scoreboard players set #t5_beds sr_done 0
scoreboard players set beds sr_s5 6
scoreboard players display name beds sr_s5 {"text": "☐ Betten", "color": "gray"}
scoreboard players display numberformat beds sr_s5 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t5_v_beds sr 0
scoreboard players set #t5_food sr_done 0
scoreboard players set food sr_s5 5
scoreboard players display name food sr_s5 {"text": "☐ Essen", "color": "gray"}
scoreboard players display numberformat food sr_s5 fixed {"text": "0/30", "color": "gray"}
scoreboard players set #t5_v_food sr 0
scoreboard players set #t5_eyes sr_done 0
scoreboard players set eyes sr_s5 4
scoreboard players display name eyes sr_s5 {"text": "☐ Enderaugen", "color": "gray"}
scoreboard players display numberformat eyes sr_s5 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t5_v_eyes sr 0
scoreboard players set #t5_stronghold sr_done 0
scoreboard players set stronghold sr_s5 3
scoreboard players display name stronghold sr_s5 {"text": "☐ Stronghold gefunden", "color": "gray"}
scoreboard players set #t5_end sr_done 0
scoreboard players set end sr_s5 2
scoreboard players display name end sr_s5 {"text": "☐ End betreten", "color": "gray"}
scoreboard players set #t5_dragon sr_done 0
scoreboard players set dragon sr_s5 1
scoreboard players display name dragon sr_s5 {"text": "☐ Drache besiegt", "color": "gray"}
scoreboard objectives modify sr_s5 displayname {"text": "Team Türkis", "color": "aqua", "bold": true}
execute as @a[tag=sr_run,team=sr_t5] run waypoint modify @s color aqua
bossbar set sr:t5 value 0
bossbar set sr:t5 visible true
bossbar set sr:t5 players @a[tag=sr_run,team=sr_t5]
