execute if score #sec sr matches 10.. run bossbar set sr:t6 name [{"text": "Team Lila", "color": "light_purple", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t6_cnt", "objective": "sr"}, "color": "green"}, {"text": "/12", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:t6 name [{"text": "Team Lila", "color": "light_purple", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t6_cnt", "objective": "sr"}, "color": "green"}, {"text": "/12", "color": "green"}]
bossbar set sr:t6 players @a[tag=sr_run,team=sr_t6]
execute if score #t6_gear sr_done matches 0 if function sr:cond/t6_gear run function sr:done/t6_gear
execute if score #t6_tools sr_done matches 0 if function sr:cond/t6_tools run function sr:done/t6_tools
execute if score #t6_nether sr_done matches 0 if function sr:cond/t6_nether run function sr:done/t6_nether
execute if score #t6_fortress sr_done matches 0 if function sr:cond/t6_fortress run function sr:done/t6_fortress
execute if score #t6_bastion sr_done matches 0 if function sr:cond/t6_bastion run function sr:done/t6_bastion
execute if score #t6_blaze sr_done matches 0 if function sr:cond/t6_blaze run function sr:done/t6_blaze
execute if score #t6_pearls sr_done matches 0 if function sr:cond/t6_pearls run function sr:done/t6_pearls
execute if score #t6_beds sr_done matches 0 if function sr:cond/t6_beds run function sr:done/t6_beds
execute if score #t6_eyes sr_done matches 0 if function sr:cond/t6_eyes run function sr:done/t6_eyes
execute if score #t6_stronghold sr_done matches 0 if function sr:cond/t6_stronghold run function sr:done/t6_stronghold
execute if score #t6_end sr_done matches 0 if function sr:cond/t6_end run function sr:done/t6_end
execute if score #t6_dragon sr_done matches 0 if function sr:cond/t6_dragon run function sr:done/t6_dragon
