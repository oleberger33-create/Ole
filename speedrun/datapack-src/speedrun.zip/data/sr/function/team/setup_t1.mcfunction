function sr:role/assign_t1
scoreboard players operation #slot sr = #nextslot sr
scoreboard players add #nextslot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
data modify storage sr:run place set value {n:1}
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
scoreboard players set #try sr 0
function sr:pos/place with storage sr:run place
scoreboard players set #t1_cnt sr 0
scoreboard players reset * sr_s1
scoreboard players set #t1_gear sr_done 0
scoreboard players set gear sr_s1 13
scoreboard players display name gear sr_s1 {"text": "☐ Schild + Eisenschwert", "color": "gray"}
scoreboard players set #t1_tools sr_done 0
scoreboard players set tools sr_s1 12
scoreboard players display name tools sr_s1 {"text": "☐ Eimer + Feuerzeug", "color": "gray"}
scoreboard players set #t1_nether sr_done 0
scoreboard players set nether sr_s1 11
scoreboard players display name nether sr_s1 {"text": "☐ Nether betreten", "color": "gray"}
scoreboard players set #t1_fortress sr_done 0
scoreboard players set fortress sr_s1 10
scoreboard players display name fortress sr_s1 {"text": "☐ Festung gefunden", "color": "gray"}
scoreboard players set #t1_bastion sr_done 0
scoreboard players set bastion sr_s1 9
scoreboard players display name bastion sr_s1 {"text": "☐ Bastion gefunden", "color": "gray"}
scoreboard players set #t1_blaze sr_done 0
scoreboard players set blaze sr_s1 8
scoreboard players display name blaze sr_s1 {"text": "☐ Blaze-Ruten", "color": "gray"}
scoreboard players display numberformat blaze sr_s1 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t1_v_blaze sr 0
scoreboard players set #t1_pearls sr_done 0
scoreboard players set pearls sr_s1 7
scoreboard players display name pearls sr_s1 {"text": "☐ Enderperlen", "color": "gray"}
scoreboard players display numberformat pearls sr_s1 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t1_v_pearls sr 0
scoreboard players set #t1_beds sr_done 0
scoreboard players set beds sr_s1 6
scoreboard players display name beds sr_s1 {"text": "☐ Betten", "color": "gray"}
scoreboard players display numberformat beds sr_s1 fixed {"text": "0/7", "color": "gray"}
scoreboard players set #t1_v_beds sr 0
scoreboard players set #t1_food sr_done 0
scoreboard players set food sr_s1 5
scoreboard players display name food sr_s1 {"text": "☐ Essen", "color": "gray"}
scoreboard players display numberformat food sr_s1 fixed {"text": "0/30", "color": "gray"}
scoreboard players set #t1_v_food sr 0
scoreboard players set #t1_eyes sr_done 0
scoreboard players set eyes sr_s1 4
scoreboard players display name eyes sr_s1 {"text": "☐ Enderaugen", "color": "gray"}
scoreboard players display numberformat eyes sr_s1 fixed {"text": "0/12", "color": "gray"}
scoreboard players set #t1_v_eyes sr 0
scoreboard players set #t1_stronghold sr_done 0
scoreboard players set stronghold sr_s1 3
scoreboard players display name stronghold sr_s1 {"text": "☐ Stronghold gefunden", "color": "gray"}
scoreboard players set #t1_end sr_done 0
scoreboard players set end sr_s1 2
scoreboard players display name end sr_s1 {"text": "☐ End betreten", "color": "gray"}
scoreboard players set #t1_dragon sr_done 0
scoreboard players set dragon sr_s1 1
scoreboard players display name dragon sr_s1 {"text": "☐ Drache besiegt", "color": "gray"}
scoreboard objectives modify sr_s1 displayname {"text": "Team Rot", "color": "red", "bold": true}
execute as @a[tag=sr_run,team=sr_t1] run waypoint modify @s color red
bossbar set sr:t1 value 0
bossbar set sr:t1 visible true
bossbar set sr:t1 players @a[tag=sr_run,team=sr_t1]
