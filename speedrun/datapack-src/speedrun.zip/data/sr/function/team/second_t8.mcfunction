execute if score #sec sr matches 10.. run bossbar set sr:t8 name [{"text": "Team Weiß", "color": "white", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t8_cnt", "objective": "sr"}, "color": "green"}, {"text": "/12", "color": "green"}]
execute if score #sec sr matches ..9 run bossbar set sr:t8 name [{"text": "Team Weiß", "color": "white", "bold": true}, {"text": "  ·  ", "color": "gray"}, {"nbt": "mode", "storage": "sr:run", "interpret": true, "color": "white"}, {"text": "   ⏱ ", "color": "white"}, {"score": {"name": "#min", "objective": "sr"}, "color": "white"}, {"text": ":0", "color": "white"}, {"score": {"name": "#sec", "objective": "sr"}, "color": "white"}, {"text": "   ✔ ", "color": "green"}, {"score": {"name": "#t8_cnt", "objective": "sr"}, "color": "green"}, {"text": "/12", "color": "green"}]
bossbar set sr:t8 players @a[tag=sr_run,team=sr_t8]
execute if score #t8_gear sr_done matches 0 if function sr:cond/t8_gear run function sr:done/t8_gear
execute if score #t8_tools sr_done matches 0 if function sr:cond/t8_tools run function sr:done/t8_tools
execute if score #t8_nether sr_done matches 0 if function sr:cond/t8_nether run function sr:done/t8_nether
execute if score #t8_fortress sr_done matches 0 if function sr:cond/t8_fortress run function sr:done/t8_fortress
execute if score #t8_bastion sr_done matches 0 if function sr:cond/t8_bastion run function sr:done/t8_bastion
execute if score #t8_blaze sr_done matches 0 if function sr:cond/t8_blaze run function sr:done/t8_blaze
execute if score #t8_pearls sr_done matches 0 if function sr:cond/t8_pearls run function sr:done/t8_pearls
execute if score #t8_beds sr_done matches 0 if function sr:cond/t8_beds run function sr:done/t8_beds
execute if score #t8_eyes sr_done matches 0 if function sr:cond/t8_eyes run function sr:done/t8_eyes
execute if score #t8_stronghold sr_done matches 0 if function sr:cond/t8_stronghold run function sr:done/t8_stronghold
execute if score #t8_end sr_done matches 0 if function sr:cond/t8_end run function sr:done/t8_end
execute if score #t8_dragon sr_done matches 0 if function sr:cond/t8_dragon run function sr:done/t8_dragon
