function sr:role/assign_t8
scoreboard players operation #slot sr = #nextslot sr
scoreboard players add #nextslot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
data modify storage sr:run place set value {n:8}
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
scoreboard players set #try sr 0
function sr:pos/place with storage sr:run place
scoreboard players set #t8_cnt sr 0
scoreboard players reset * sr_s8
scoreboard players set #t8_gear sr_done 0
scoreboard players set gear sr_s8 12
scoreboard players display name gear sr_s8 {"text": "☐ Schild + Eisenschwert", "color": "gray"}
scoreboard players set #t8_tools sr_done 0
scoreboard players set tools sr_s8 11
scoreboard players display name tools sr_s8 {"text": "☐ Eimer + Feuerzeug", "color": "gray"}
scoreboard players set #t8_nether sr_done 0
scoreboard players set nether sr_s8 10
scoreboard players display name nether sr_s8 {"text": "☐ Nether betreten", "color": "gray"}
scoreboard players set #t8_fortress sr_done 0
scoreboard players set fortress sr_s8 9
scoreboard players display name fortress sr_s8 {"text": "☐ Festung gefunden", "color": "gray"}
scoreboard players set #t8_bastion sr_done 0
scoreboard players set bastion sr_s8 8
scoreboard players display name bastion sr_s8 {"text": "☐ Bastion gefunden", "color": "gray"}
scoreboard players set #t8_blaze sr_done 0
scoreboard players set blaze sr_s8 7
scoreboard players display name blaze sr_s8 {"text": "☐ 7+ Blaze-Ruten", "color": "gray"}
scoreboard players set #t8_pearls sr_done 0
scoreboard players set pearls sr_s8 6
scoreboard players display name pearls sr_s8 {"text": "☐ 12+ Enderperlen", "color": "gray"}
scoreboard players set #t8_beds sr_done 0
scoreboard players set beds sr_s8 5
scoreboard players display name beds sr_s8 {"text": "☐ 7 Betten", "color": "gray"}
scoreboard players set #t8_eyes sr_done 0
scoreboard players set eyes sr_s8 4
scoreboard players display name eyes sr_s8 {"text": "☐ 12 Enderaugen", "color": "gray"}
scoreboard players set #t8_stronghold sr_done 0
scoreboard players set stronghold sr_s8 3
scoreboard players display name stronghold sr_s8 {"text": "☐ Stronghold gefunden", "color": "gray"}
scoreboard players set #t8_end sr_done 0
scoreboard players set end sr_s8 2
scoreboard players display name end sr_s8 {"text": "☐ End betreten", "color": "gray"}
scoreboard players set #t8_dragon sr_done 0
scoreboard players set dragon sr_s8 1
scoreboard players display name dragon sr_s8 {"text": "☐ Drache besiegt", "color": "gray"}
bossbar set sr:t8 value 0
bossbar set sr:t8 visible true
bossbar set sr:t8 players @a[tag=sr_run,team=sr_t8]
