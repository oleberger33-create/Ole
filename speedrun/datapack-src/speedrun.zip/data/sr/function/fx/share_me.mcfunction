execute unless entity @s[tag=sr_run] run return run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Das geht nur im Run.", "color": "gray"}]
data modify storage sr:run share.label set value "Position"
execute if entity @s[team=sr_t1] at @s run function sr:fx/share_t1 with storage sr:run share
execute if entity @s[team=sr_t2] at @s run function sr:fx/share_t2 with storage sr:run share
execute if entity @s[team=sr_t3] at @s run function sr:fx/share_t3 with storage sr:run share
execute if entity @s[team=sr_t4] at @s run function sr:fx/share_t4 with storage sr:run share
execute if entity @s[team=sr_t5] at @s run function sr:fx/share_t5 with storage sr:run share
execute if entity @s[team=sr_t6] at @s run function sr:fx/share_t6 with storage sr:run share
execute if entity @s[team=sr_t7] at @s run function sr:fx/share_t7 with storage sr:run share
execute if entity @s[team=sr_t8] at @s run function sr:fx/share_t8 with storage sr:run share
