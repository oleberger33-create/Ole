scoreboard players set #t2_nether sr_done 1
scoreboard players add #t2_cnt sr 1
execute store result bossbar sr:t2 value run scoreboard players get #t2_cnt sr
scoreboard players display name nether sr_s2 {"text": "✔ Nether betreten", "color": "green"}
scoreboard players display numberformat nether sr_s2 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,team=sr_t2] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Nether betreten", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t2] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t2] [{"text": "[Blau] ", "color": "blue", "bold": true}, {"text": "Nether betreten", "color": "gray"}]
data modify storage sr:run share.label set value "Nether-Portal"
execute in minecraft:the_nether as @a[tag=sr_run,team=sr_t2,distance=0..,limit=1] at @s run function sr:fx/share_t2 with storage sr:run share
