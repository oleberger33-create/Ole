scoreboard players set #t2_nether sr_done 1
scoreboard players add #t2_cnt sr 1
execute store result bossbar sr:t2 value run scoreboard players get #t2_cnt sr
scoreboard players display name nether sr_s2 {"text": "✔ Nether betreten", "color": "green"}
tellraw @a[tag=sr_run,team=sr_t2] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Nether betreten", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t2] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t2] [{"text": "[Blau] ", "color": "blue", "bold": true}, {"text": "Nether betreten", "color": "gray"}]
