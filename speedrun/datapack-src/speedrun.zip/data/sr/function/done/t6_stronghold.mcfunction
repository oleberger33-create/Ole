scoreboard players set #t6_stronghold sr_done 1
scoreboard players add #t6_cnt sr 1
execute store result bossbar sr:t6 value run scoreboard players get #t6_cnt sr
scoreboard players display name stronghold sr_s6 {"text": "✔ Stronghold gefunden", "color": "green"}
scoreboard players display numberformat stronghold sr_s6 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,team=sr_t6] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Stronghold gefunden", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t6] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t6] [{"text": "[Lila] ", "color": "light_purple", "bold": true}, {"text": "Stronghold gefunden", "color": "gray"}]
data modify storage sr:run share.label set value "Stronghold"
execute as @a[tag=sr_run,team=sr_t6,advancements={minecraft:story/follow_ender_eye=true},limit=1] at @s run function sr:fx/share_t6 with storage sr:run share
