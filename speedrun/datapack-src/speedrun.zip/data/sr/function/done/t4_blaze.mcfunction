scoreboard players set #t4_blaze sr_done 1
scoreboard players add #t4_cnt sr 1
execute store result bossbar sr:t4 value run scoreboard players get #t4_cnt sr
scoreboard players display name blaze sr_s4 {"text": "✔ Blaze-Ruten", "color": "green"}
scoreboard players display numberformat blaze sr_s4 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,scores={sr_team=4}] [{"text": "✔ Team: ", "color": "dark_green", "bold": true}, {"text": "Blaze-Ruten", "color": "gray"}]
execute as @a[tag=sr_run,scores={sr_team=4}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
tag @a remove sr_cur2
tag @a[tag=sr_run,scores={sr_team=4}] add sr_cur2
execute if score #teams sr matches 2.. run tellraw @a[tag=!sr_cur2] [{"text": "[Gelb] ", "color": "yellow", "bold": true}, {"text": "Blaze-Ruten", "color": "gray"}]
