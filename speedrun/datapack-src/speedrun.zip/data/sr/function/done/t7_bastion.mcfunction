scoreboard players set #t7_bastion sr_done 1
scoreboard players add #t7_cnt sr 1
execute store result bossbar sr:t7 value run scoreboard players get #t7_cnt sr
scoreboard players display name bastion sr_s7 {"text": "✔ Bastion gefunden", "color": "green"}
scoreboard players display numberformat bastion sr_s7 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,scores={sr_team=7}] [{"text": "✔ Team: ", "color": "dark_green", "bold": true}, {"text": "Bastion gefunden", "color": "gray"}]
execute as @a[tag=sr_run,scores={sr_team=7}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
tag @a remove sr_cur2
tag @a[tag=sr_run,scores={sr_team=7}] add sr_cur2
execute if score #teams sr matches 2.. run tellraw @a[tag=!sr_cur2] [{"text": "[Orange] ", "color": "gold", "bold": true}, {"text": "Bastion gefunden", "color": "gray"}]
data modify storage sr:run share.label set value "Bastion"
execute as @a[tag=sr_run,scores={sr_team=7},advancements={minecraft:nether/find_bastion=true},limit=1] at @s run function sr:fx/share_t7 with storage sr:run share
