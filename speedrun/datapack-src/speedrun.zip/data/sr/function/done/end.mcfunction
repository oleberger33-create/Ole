scoreboard players set #end sr_done 1
scoreboard players add #donecount sr 1
execute store result bossbar sr:timer value run scoreboard players get #donecount sr
scoreboard players display name ole5 sr_ole {"text": "✔ End betreten", "color": "green", "strikethrough": false}
scoreboard players display name sammy5 sr_sammy {"text": "✔ End betreten", "color": "green", "strikethrough": false}
tellraw @a[tag=sr_run] [{"text": "✔ ", "color": "green"}, {"text": "End betreten", "color": "white"}]
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.6
