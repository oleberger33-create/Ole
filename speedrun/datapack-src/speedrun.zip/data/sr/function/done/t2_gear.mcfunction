scoreboard players set #t2_gear sr_done 1
scoreboard players add #t2_cnt sr 1
execute store result bossbar sr:t2 value run scoreboard players get #t2_cnt sr
scoreboard players display name gear sr_s2 {"text": "✔ Schild + Eisenschwert", "color": "green"}
tellraw @a[tag=sr_run,team=sr_t2] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Schild + Eisenschwert", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t2] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t2] [{"text": "[Blau] ", "color": "blue", "bold": true}, {"text": "Schild + Eisenschwert", "color": "gray"}]
