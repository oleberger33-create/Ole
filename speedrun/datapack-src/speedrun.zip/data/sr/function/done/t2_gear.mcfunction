scoreboard players set #t2_gear sr_done 1
scoreboard players add #t2_cnt sr 1
execute store result bossbar sr:t2 value run scoreboard players get #t2_cnt sr
scoreboard players display name gear sr_s2 {"text": "✔ Schild + Eisenschwert", "color": "green"}
scoreboard players display numberformat gear sr_s2 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,scores={sr_team=2}] [{"text": "✔ Team: ", "color": "dark_green", "bold": true}, {"text": "Schild + Eisenschwert", "color": "gray"}]
execute as @a[tag=sr_run,scores={sr_team=2}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
tag @a remove sr_cur2
tag @a[tag=sr_run,scores={sr_team=2}] add sr_cur2
execute if score #teams sr matches 2.. run tellraw @a[tag=!sr_cur2] [{"text": "[Blau] ", "color": "blue", "bold": true}, {"text": "Schild + Eisenschwert", "color": "gray"}]
