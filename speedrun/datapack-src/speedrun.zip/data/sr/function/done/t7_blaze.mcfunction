scoreboard players set #t7_blaze sr_done 1
scoreboard players add #t7_cnt sr 1
execute store result bossbar sr:t7 value run scoreboard players get #t7_cnt sr
scoreboard players display name blaze sr_s7 {"text": "✔ Blaze-Ruten", "color": "green"}
scoreboard players display numberformat blaze sr_s7 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,scores={sr_team=7}] [{"text": "✔ Team: ", "color": "dark_green", "bold": true}, {"text": "Blaze-Ruten", "color": "gray"}]
execute as @a[tag=sr_run,scores={sr_team=7}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
tag @a remove sr_cur2
tag @a[tag=sr_run,scores={sr_team=7}] add sr_cur2
execute if score #teams sr matches 2.. run tellraw @a[tag=!sr_cur2] [{"text": "[Orange] ", "color": "gold", "bold": true}, {"text": "Blaze-Ruten", "color": "gray"}]
