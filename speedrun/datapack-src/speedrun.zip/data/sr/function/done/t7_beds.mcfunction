scoreboard players set #t7_beds sr_done 1
scoreboard players add #t7_cnt sr 1
execute store result bossbar sr:t7 value run scoreboard players get #t7_cnt sr
scoreboard players display name beds sr_s7 {"text": "✔ Betten", "color": "green"}
scoreboard players display numberformat beds sr_s7 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,team=sr_t7] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Betten", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t7] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t7] [{"text": "[Orange] ", "color": "gold", "bold": true}, {"text": "Betten", "color": "gray"}]
