scoreboard players set #t1_end sr_done 1
scoreboard players add #t1_cnt sr 1
execute store result bossbar sr:t1 value run scoreboard players get #t1_cnt sr
scoreboard players display name end sr_s1 {"text": "✔ End betreten", "color": "green"}
tellraw @a[tag=sr_run,team=sr_t1] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "End betreten", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t1] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t1] [{"text": "[Rot] ", "color": "red", "bold": true}, {"text": "End betreten", "color": "gray"}]
