scoreboard players set #t5_tools sr_done 1
scoreboard players add #t5_cnt sr 1
execute store result bossbar sr:t5 value run scoreboard players get #t5_cnt sr
scoreboard players display name tools sr_s5 {"text": "✔ Eimer + Feuerzeug", "color": "green"}
scoreboard players display numberformat tools sr_s5 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,scores={sr_team=5}] [{"text": "✔ Team: ", "color": "dark_green", "bold": true}, {"text": "Eimer + Feuerzeug", "color": "gray"}]
execute as @a[tag=sr_run,scores={sr_team=5}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
tag @a remove sr_cur2
tag @a[tag=sr_run,scores={sr_team=5}] add sr_cur2
execute if score #teams sr matches 2.. run tellraw @a[tag=!sr_cur2] [{"text": "[Türkis] ", "color": "aqua", "bold": true}, {"text": "Eimer + Feuerzeug", "color": "gray"}]
