scoreboard players set #nether sr_done 1
scoreboard players add #donecount sr 1
execute store result bossbar sr:timer value run scoreboard players get #donecount sr
scoreboard players display name ole1 sr_ole {"text": "✔ Nether betreten", "color": "green", "strikethrough": false}
scoreboard players display name mats1 sr_mats {"text": "✔ Nether betreten", "color": "green", "strikethrough": false}
scoreboard players display name sammy2 sr_sammy {"text": "✔ Nether betreten", "color": "green", "strikethrough": false}
tellraw @a[tag=sr_run] [{"text": "✔ ", "color": "green"}, {"text": "Nether betreten", "color": "white"}]
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.6
