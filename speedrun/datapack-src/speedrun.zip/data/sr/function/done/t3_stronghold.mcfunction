scoreboard players set #t3_stronghold sr_done 1
scoreboard players add #t3_cnt sr 1
execute store result bossbar sr:t3 value run scoreboard players get #t3_cnt sr
scoreboard players display name stronghold sr_s3 {"text": "✔ Stronghold gefunden", "color": "green"}
scoreboard players display numberformat stronghold sr_s3 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,scores={sr_team=3}] [{"text": "✔ Team: ", "color": "dark_green", "bold": true}, {"text": "Stronghold gefunden", "color": "gray"}]
execute as @a[tag=sr_run,scores={sr_team=3}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
tag @a remove sr_cur2
tag @a[tag=sr_run,scores={sr_team=3}] add sr_cur2
execute if score #teams sr matches 2.. run tellraw @a[tag=!sr_cur2] [{"text": "[Grün] ", "color": "green", "bold": true}, {"text": "Stronghold gefunden", "color": "gray"}]
data modify storage sr:run share.label set value "Stronghold"
execute as @a[tag=sr_run,scores={sr_team=3},advancements={minecraft:story/follow_ender_eye=true},limit=1] at @s run function sr:fx/share_t3 with storage sr:run share
