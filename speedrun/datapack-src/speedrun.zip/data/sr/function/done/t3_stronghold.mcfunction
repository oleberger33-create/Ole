scoreboard players set #t3_stronghold sr_done 1
scoreboard players add #t3_cnt sr 1
execute store result bossbar sr:t3 value run scoreboard players get #t3_cnt sr
scoreboard players display name stronghold sr_s3 {"text": "✔ Stronghold gefunden", "color": "green"}
tellraw @a[tag=sr_run,team=sr_t3] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Stronghold gefunden", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t3] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t3] [{"text": "[Grün] ", "color": "green", "bold": true}, {"text": "Stronghold gefunden", "color": "gray"}]
