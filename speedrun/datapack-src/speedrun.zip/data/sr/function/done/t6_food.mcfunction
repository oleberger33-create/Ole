scoreboard players set #t6_food sr_done 1
scoreboard players add #t6_cnt sr 1
execute store result bossbar sr:t6 value run scoreboard players get #t6_cnt sr
scoreboard players display name food sr_s6 {"text": "✔ Essen", "color": "green"}
scoreboard players display numberformat food sr_s6 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,team=sr_t6] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Essen", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t6] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t6] [{"text": "[Lila] ", "color": "light_purple", "bold": true}, {"text": "Essen", "color": "gray"}]
