scoreboard players set #t1_food sr_done 1
scoreboard players add #t1_cnt sr 1
execute store result bossbar sr:t1 value run scoreboard players get #t1_cnt sr
scoreboard players display name food sr_s1 {"text": "✔ Essen", "color": "green"}
scoreboard players display numberformat food sr_s1 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,scores={sr_team=1}] [{"text": "✔ Team: ", "color": "dark_green", "bold": true}, {"text": "Essen", "color": "gray"}]
execute as @a[tag=sr_run,scores={sr_team=1}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
tag @a remove sr_cur2
tag @a[tag=sr_run,scores={sr_team=1}] add sr_cur2
execute if score #teams sr matches 2.. run tellraw @a[tag=!sr_cur2] [{"text": "[Rot] ", "color": "red", "bold": true}, {"text": "Essen", "color": "gray"}]
