scoreboard players set #t5_gear sr_done 1
scoreboard players add #t5_cnt sr 1
execute store result bossbar sr:t5 value run scoreboard players get #t5_cnt sr
scoreboard players display name gear sr_s5 {"text": "✔ Schild + Eisenschwert", "color": "green"}
tellraw @a[tag=sr_run,team=sr_t5] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Schild + Eisenschwert", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t5] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t5] [{"text": "[Türkis] ", "color": "aqua", "bold": true}, {"text": "Schild + Eisenschwert", "color": "gray"}]
