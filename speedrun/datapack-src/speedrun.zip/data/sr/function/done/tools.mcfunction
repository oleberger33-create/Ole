scoreboard players set #tools sr_done 1
scoreboard players add #donecount sr 1
execute store result bossbar sr:timer value run scoreboard players get #donecount sr
scoreboard players display name mats0 sr_mats {"text": "✔ Eimer + Feuerzeug", "color": "green", "strikethrough": false}
tellraw @a[tag=sr_run] [{"text": "✔ ", "color": "green"}, {"text": "Eimer + Feuerzeug", "color": "white"}]
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.6
