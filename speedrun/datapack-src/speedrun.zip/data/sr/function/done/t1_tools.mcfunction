scoreboard players set #t1_tools sr_done 1
scoreboard players add #t1_cnt sr 1
execute store result bossbar sr:t1 value run scoreboard players get #t1_cnt sr
scoreboard players display name tools sr_s1 {"text": "✔ Eimer + Feuerzeug", "color": "green"}
scoreboard players display numberformat tools sr_s1 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,team=sr_t1] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Eimer + Feuerzeug", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t1] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t1] [{"text": "[Rot] ", "color": "red", "bold": true}, {"text": "Eimer + Feuerzeug", "color": "gray"}]
