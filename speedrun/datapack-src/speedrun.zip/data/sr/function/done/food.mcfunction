scoreboard players set #food sr_done 1
scoreboard players add #donecount sr 1
execute store result bossbar sr:timer value run scoreboard players get #donecount sr
scoreboard players display name sammy1 sr_sammy {"text": "✔ 30 Essen", "color": "green", "strikethrough": false}
tellraw @a[tag=sr_run] [{"text": "✔ ", "color": "green"}, {"text": "30 Essen", "color": "white"}]
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.6
