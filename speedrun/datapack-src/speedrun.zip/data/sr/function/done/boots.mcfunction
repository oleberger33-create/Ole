scoreboard players set #boots sr_done 1
scoreboard players add #donecount sr 1
execute store result bossbar sr:timer value run scoreboard players get #donecount sr
scoreboard players display name mats2 sr_mats {"text": "✔ Goldene Stiefel an", "color": "green", "strikethrough": false}
tellraw @a[tag=sr_run] [{"text": "✔ ", "color": "green"}, {"text": "Goldene Stiefel an", "color": "white"}]
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.6
