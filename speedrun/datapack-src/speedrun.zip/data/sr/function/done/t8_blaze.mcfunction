scoreboard players set #t8_blaze sr_done 1
scoreboard players add #t8_cnt sr 1
execute store result bossbar sr:t8 value run scoreboard players get #t8_cnt sr
scoreboard players display name blaze sr_s8 {"text": "✔ Blaze-Ruten", "color": "green"}
scoreboard players display numberformat blaze sr_s8 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,team=sr_t8] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Blaze-Ruten", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t8] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t8] [{"text": "[Weiß] ", "color": "white", "bold": true}, {"text": "Blaze-Ruten", "color": "gray"}]
