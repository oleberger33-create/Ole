scoreboard players set #t2_tools sr_done 1
scoreboard players add #t2_cnt sr 1
execute store result bossbar sr:t2 value run scoreboard players get #t2_cnt sr
scoreboard players display name tools sr_s2 {"text": "✔ Eimer + Feuerzeug", "color": "green"}
scoreboard players display numberformat tools sr_s2 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,team=sr_t2] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Eimer + Feuerzeug", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t2] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t2] [{"text": "[Blau] ", "color": "blue", "bold": true}, {"text": "Eimer + Feuerzeug", "color": "gray"}]
