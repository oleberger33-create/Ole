scoreboard players set #t6_tools sr_done 1
scoreboard players add #t6_cnt sr 1
execute store result bossbar sr:t6 value run scoreboard players get #t6_cnt sr
scoreboard players display name tools sr_s6 {"text": "✔ Eimer + Feuerzeug", "color": "green"}
scoreboard players display numberformat tools sr_s6 fixed {"text": "✔", "color": "green", "bold": true}
tellraw @a[tag=sr_run,scores={sr_team=6}] [{"text": "✔ Team: ", "color": "dark_green", "bold": true}, {"text": "Eimer + Feuerzeug", "color": "gray"}]
execute as @a[tag=sr_run,scores={sr_team=6}] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
tag @a remove sr_cur2
tag @a[tag=sr_run,scores={sr_team=6}] add sr_cur2
execute if score #teams sr matches 2.. run tellraw @a[tag=!sr_cur2] [{"text": "[Lila] ", "color": "light_purple", "bold": true}, {"text": "Eimer + Feuerzeug", "color": "gray"}]
