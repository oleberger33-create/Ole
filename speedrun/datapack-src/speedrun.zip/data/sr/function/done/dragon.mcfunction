scoreboard players set #dragon sr_done 1
scoreboard players add #donecount sr 1
execute store result bossbar sr:timer value run scoreboard players get #donecount sr
scoreboard players display name ole6 sr_ole {"text": "✔ Drache besiegt", "color": "green", "strikethrough": false}
scoreboard players display name mats6 sr_mats {"text": "✔ Drache besiegt", "color": "green", "strikethrough": false}
scoreboard players display name sammy6 sr_sammy {"text": "✔ Drache besiegt", "color": "green", "strikethrough": false}
tellraw @a[tag=sr_run] [{"text": "✔ ", "color": "green"}, {"text": "Drache besiegt", "color": "white"}]
execute as @a[tag=sr_run] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.6 1.6
function sr:run/finish
