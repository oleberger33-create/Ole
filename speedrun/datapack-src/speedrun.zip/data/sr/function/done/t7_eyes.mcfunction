scoreboard players set #t7_eyes sr_done 1
scoreboard players add #t7_cnt sr 1
execute store result bossbar sr:t7 value run scoreboard players get #t7_cnt sr
scoreboard players display name eyes sr_s7 {"text": "✔ 12 Enderaugen", "color": "green"}
tellraw @a[tag=sr_run,team=sr_t7] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "12 Enderaugen", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t7] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t7] [{"text": "[Orange] ", "color": "gold", "bold": true}, {"text": "12 Enderaugen", "color": "gray"}]
