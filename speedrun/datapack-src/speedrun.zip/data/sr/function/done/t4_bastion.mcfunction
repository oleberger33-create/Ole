scoreboard players set #t4_bastion sr_done 1
scoreboard players add #t4_cnt sr 1
execute store result bossbar sr:t4 value run scoreboard players get #t4_cnt sr
scoreboard players display name bastion sr_s4 {"text": "✔ Bastion gefunden", "color": "green"}
tellraw @a[tag=sr_run,team=sr_t4] [{"text": "✔ ", "color": "green", "bold": true}, {"text": "Bastion gefunden", "color": "white"}]
execute as @a[tag=sr_run,team=sr_t4] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.6
execute if score #teams sr matches 2.. run tellraw @a[team=!sr_t4] [{"text": "[Gelb] ", "color": "yellow", "bold": true}, {"text": "Bastion gefunden", "color": "gray"}]
