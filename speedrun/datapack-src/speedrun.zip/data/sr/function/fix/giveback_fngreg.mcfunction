scoreboard players set #gb_fngreg sr 1
give FNGreg minecraft:cobblestone 506
give FNGreg minecraft:cobbled_deepslate 229
give FNGreg minecraft:coal 106
give FNGreg minecraft:raw_copper 64
give FNGreg minecraft:granite 63
give FNGreg minecraft:andesite 50
give FNGreg minecraft:tuff 33
give FNGreg minecraft:diorite 27
give FNGreg minecraft:dirt 19
give FNGreg minecraft:spruce_log 11
give FNGreg minecraft:raw_iron 8
give FNGreg minecraft:gravel 7
give FNGreg minecraft:iron_ingot 5
give FNGreg minecraft:torch 4
give FNGreg minecraft:rotten_flesh 2
give FNGreg minecraft:netherrack 1
give FNGreg minecraft:flint 1
give FNGreg minecraft:spruce_sapling 1
tellraw FNGreg [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Items von vor dem Neustart sind zurück.", "color": "green"}]
