scoreboard players set #resume sr 0
scoreboard players set #resume_done sr 1
scoreboard players set #cd sr 0
team leave @a
tag @a remove sr_hasrole
tag @a remove sr_spec
tag @a[tag=!sr_watch] add sr_run
tag @a[tag=sr_run] remove sr_lobby
scoreboard players set @a[tag=sr_run] sr_team 1
clear @a[tag=sr_run] *[minecraft:custom_data~{sr_item:1b}]
gamemode survival @a[tag=sr_run]
effect clear @a[tag=sr_run]
function sr:role/assign_t1
scoreboard players set #teams sr 1
scoreboard players set #finished sr 0
scoreboard players operation #slot sr = #nextslot sr
scoreboard players remove #slot sr 1
scoreboard players operation #slot sr %= #npos sr
function sr:pos/pick
data modify storage sr:run place set value {n:1}
execute store result storage sr:run place.x int 1 run scoreboard players get #cx sr
execute store result storage sr:run place.z int 1 run scoreboard players get #cz sr
scoreboard players set #try sr 0
function sr:pos/place with storage sr:run place
execute as @a[tag=sr_run] at @s run spawnpoint @s ~ ~ ~
execute as @a[tag=sr_run] store result score @s sr_sx run data get entity @s Pos[0]
execute as @a[tag=sr_run] store result score @s sr_sy run data get entity @s Pos[1]
execute as @a[tag=sr_run] store result score @s sr_sz run data get entity @s Pos[2]
execute as @a[name=matsllll,tag=sr_run] run function sr:fix/to_grave
scoreboard players set #k sr 0
execute as @a[tag=sr_run] run function sr:start/slot
execute as @a[tag=sr_run,scores={sr_slot=1..16}] run function sr:p/init
scoreboard players set #st sr 0
scoreboard players set #empty sr 0
scoreboard players set #active sr 1
bossbar set sr:t1 visible true
bossbar set sr:t1 players @a[tag=sr_run]
effect give @a[tag=sr_run] minecraft:glowing infinite 0 true
tellraw @a [{"text": "» ", "color": "gold", "bold": true}, {"text": "Run fortgesetzt! ", "color": "green", "bold": true}, {"text": "Mats ist bei seinem Grab, die anderen am Startpunkt.", "color": "white"}]
