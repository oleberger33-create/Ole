execute unless data entity @s LastDeathLocation run return 0
data modify storage sr:tmp d.dim set from entity @s LastDeathLocation.dimension
execute store result storage sr:tmp d.x int 1 run data get entity @s LastDeathLocation.pos[0]
execute store result storage sr:tmp d.z int 1 run data get entity @s LastDeathLocation.pos[2]
execute store result score #dy sr run data get entity @s LastDeathLocation.pos[1]
scoreboard players add #dy sr 3
execute store result storage sr:tmp d.y int 1 run scoreboard players get #dy sr
scoreboard players set #ok sr 0
function sr:p/to_death with storage sr:tmp d
execute if score #ok sr matches 1 run tellraw @s [{"text": "» ", "color": "gold", "bold": true}, {"text": "Du bist bei deinem Todespunkt – dein Grab mit deinen Sachen ist hier.", "color": "aqua"}]
