scoreboard players set #gb_qelloxx sr 1
give Qelloxx minecraft:cobblestone 28
give Qelloxx minecraft:cooked_mutton 27
give Qelloxx minecraft:coal 20
give Qelloxx minecraft:white_wool 15
give Qelloxx minecraft:glow_berries 10
give Qelloxx minecraft:birch_log 10
give Qelloxx minecraft:spruce_log 9
give Qelloxx minecraft:bread 8
give Qelloxx minecraft:black_wool 6
give Qelloxx minecraft:oak_log 6
give Qelloxx minecraft:iron_nugget 3
give Qelloxx minecraft:beef 3
give Qelloxx minecraft:dark_oak_log 3
give Qelloxx minecraft:leather 2
give Qelloxx minecraft:copper_axe 1
give Qelloxx minecraft:copper_shovel 1
give Qelloxx minecraft:mossy_cobblestone 1
give Qelloxx minecraft:bundle 1
give Qelloxx minecraft:stone_sword 1
give Qelloxx minecraft:stick 1
tellraw Qelloxx [{"text": "» ", "color": "gold", "bold": true}, {"text": "Deine Items von vor dem Neustart sind zurück.", "color": "green"}]
