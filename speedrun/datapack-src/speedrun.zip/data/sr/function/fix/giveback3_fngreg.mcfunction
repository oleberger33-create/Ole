scoreboard players set #gb3_fngreg sr 1
give FNGreg minecraft:flint_and_steel 1
tellraw FNGreg [{"text": "» ", "color": "gold", "bold": true}, {"text": "Feuerzeug zurück.", "color": "green"}]
