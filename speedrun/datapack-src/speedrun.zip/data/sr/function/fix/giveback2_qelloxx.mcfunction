scoreboard players set #gb2_qelloxx sr 1
give Qelloxx minecraft:copper_axe 1
give Qelloxx minecraft:copper_pickaxe 1
tellraw Qelloxx [{"text": "» ", "color": "gold", "bold": true}, {"text": "Werkzeug zurück.", "color": "green"}]
