scoreboard players set #gb2_fngreg sr 1
give FNGreg minecraft:shield 1
give FNGreg minecraft:iron_sword 1
tellraw FNGreg [{"text": "» ", "color": "gold", "bold": true}, {"text": "Werkzeug zurück.", "color": "green"}]
