scoreboard players reset * sr_lobby
scoreboard players operation #bestsec sr = #best sr
scoreboard players operation #bestsec sr /= #20 sr
scoreboard players operation #lastsec sr = #last sr
scoreboard players operation #lastsec sr /= #20 sr
scoreboard players set l1 sr_lobby 6
scoreboard players display name l1 sr_lobby {"text": "Rolle wählen:", "color": "white"}
scoreboard players display numberformat l1 sr_lobby blank
scoreboard players set l2 sr_lobby 5
scoreboard players display name l2 sr_lobby {"text": " Knöpfe vorne auf der Insel", "color": "gray"}
scoreboard players display numberformat l2 sr_lobby blank
scoreboard players set l3 sr_lobby 4
scoreboard players display name l3 sr_lobby {"text": "Neuer Run: Hebel hinten", "color": "white"}
scoreboard players display numberformat l3 sr_lobby blank
scoreboard players set l4 sr_lobby 3
scoreboard players display name l4 sr_lobby {"text": "Menü: Esc → Speedrun-Menü", "color": "white"}
scoreboard players display numberformat l4 sr_lobby blank
scoreboard players set l5 sr_lobby 2
scoreboard players display name l5 sr_lobby {"text": "Bestzeit (Sek.)", "color": "gold"}
execute store result score l5 sr_lobby run scoreboard players get #bestsec sr
scoreboard players set l6 sr_lobby 1
scoreboard players display name l6 sr_lobby {"text": "Letzter Run (Sek.)", "color": "yellow"}
execute store result score l6 sr_lobby run scoreboard players get #lastsec sr
