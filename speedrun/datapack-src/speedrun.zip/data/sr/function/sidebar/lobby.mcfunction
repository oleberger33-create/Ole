scoreboard players reset * sr_lobby
scoreboard players set a1 sr_lobby 7
scoreboard players display name a1 sr_lobby {"text": " "}
scoreboard players set a2 sr_lobby 6
scoreboard players display name a2 sr_lobby [{"text": "Modus: ", "color": "gray"}, {"text": "Knopf links hinten", "color": "yellow"}]
scoreboard players set a3 sr_lobby 5
scoreboard players display name a3 sr_lobby [{"text": "Start: ", "color": "gray"}, {"text": "Hebel hinten", "color": "green"}]
scoreboard players set a4 sr_lobby 4
scoreboard players display name a4 sr_lobby [{"text": "Rolle: ", "color": "gray"}, {"text": "Knöpfe vorne", "color": "gold"}]
scoreboard players set a5 sr_lobby 3
scoreboard players display name a5 sr_lobby [{"text": "Menü: ", "color": "gray"}, {"text": "Esc → Speedrun", "color": "aqua"}]
scoreboard players set a6 sr_lobby 2
scoreboard players display name a6 sr_lobby {"text": "  "}
scoreboard players set a7 sr_lobby 1
scoreboard players display name a7 sr_lobby [{"text": "Siege stehen in der ", "color": "dark_gray"}, {"text": "Tab-Liste", "color": "gray"}]
