scoreboard players reset * sr_lobby
scoreboard players set a1 sr_lobby 9
scoreboard players display name a1 sr_lobby {"text": " "}
scoreboard players set a2 sr_lobby 8
scoreboard players display name a2 sr_lobby [{"text": "Hotbar-Items: ", "color": "gray"}, {"text": "Rechtsklick", "color": "yellow"}]
scoreboard players set a3 sr_lobby 7
scoreboard players display name a3 sr_lobby [{"text": "1 ", "color": "dark_gray"}, {"text": "Run starten", "color": "green"}]
scoreboard players set a4 sr_lobby 6
scoreboard players display name a4 sr_lobby [{"text": "2 ", "color": "dark_gray"}, {"text": "Modus wechseln", "color": "yellow"}]
scoreboard players set a5 sr_lobby 5
scoreboard players display name a5 sr_lobby [{"text": "3 ", "color": "dark_gray"}, {"text": "Wunschrolle", "color": "gold"}]
scoreboard players set a6 sr_lobby 4
scoreboard players display name a6 sr_lobby [{"text": "5 ", "color": "dark_gray"}, {"text": "Zuschauen", "color": "aqua"}]
scoreboard players set a7 sr_lobby 3
scoreboard players display name a7 sr_lobby [{"text": "9 ", "color": "dark_gray"}, {"text": "Menü", "color": "white"}]
scoreboard players set a8 sr_lobby 2
scoreboard players display name a8 sr_lobby {"text": "  "}
scoreboard players set a9 sr_lobby 1
scoreboard players display name a9 sr_lobby [{"text": "Siege: ", "color": "dark_gray"}, {"text": "Tab-Liste", "color": "gray"}]
